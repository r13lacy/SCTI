# 8/8/16
# For working with protocol buffers, a serialized data format that can transfer data
# between computing languages. We're serializing MMM data and sending them to R
# to be manipulated before going back to MMM.
# File MMMProtoR.proto should be in the same directory as your R script.


# **************** ABOUT MESSAGE FORMAT ********************************************************************************
# Data contained in the proto message (note that index numbering starts at 1, not 0):
#
# ProjMessage$GSVars <-- list of GSVar values
# ProjMessage$GSVarNames <-- list of GSVar names
# ProjMessage$myPops <-- list of populations in this project
# ProjMessage$myPops[[1]]$popVars  <-- list of PSVar values for the first pop
# ProjMessage$myPops[[1]]$popVarNames <-- list of PSVar names for the first pop
# ProjMessage$myPops[[1]]$indivVarNames <-- list of indivudal var names for this pop
# ProjMessage$myPops[[1]]$myIndivs <-- list of individuals for this pop
# ProjMessage$myPops[[1]]$myIndivs[[1]]$myVars <-- list of individual var values
#
# Accessing data from the message structure:
# use [[#]] when accessing an item from a list within the ProjMessage (ie, ProjMessage$myPops[[1]]$popVars[1] to indicate the first pop)
# use [#] to access a value in that list (ie, ProjMessage$myPops[[1]]$popVars[1] to indicate the first pop var from the first pop)
#
# Examples:
# ProjMessage$myPops[[1]]  <-- to access the first pop in the list
# test <- testMessage$myPops[[1]]$popVars <-- assign pop 1's pop vars to an R array called 'test'
# ProjMessage$myPops[[1]]$popVars[1] <-- to access the first pop state var for this pop
# ProjMessage$myPops[[2]]$myIndivs[[2]]$myVars[3] <- "Grackle" <-- assign individual's 3rd var to be 'Grackle'
# **********************************************************************************************************************

# **************** REQUIRED FILE LOADING ********************************************************************************
# load the library to deal with serialized protocol buffer data
# *************** MODIFY PATH HERE ***********************
#library("RProtoBuf", lib.loc="C:/Users/j/Documents/R/win-library/3.3")

# Read in the proto2 file so we can work with messages from C#/MMM
# *************** MODIFY PATH HERE ***********************
#readProtoFiles("C:/Users/j/Documents/Visual\ Studio\ 2015/Projects/MetaModelManager/RLink/MMMProtoR.proto")

# Read in MMM data as a message and interpret it with our proto file
# Note that this filename should be 'tempData.dat' because MMM will always save serialzied data as 'tempData.dat'
# MMM will save the data to the directory where your R script is.
# You can rename the message from 'testMessage' if you like. 
# If so, also change the name at 'serialize(testMessage, tf1)' and 'testMessage$serialize(out)' below.
# *************** MODIFY PATH HERE ***********************
testMessage <- read(ProjMessage, "C:/Users/j/Documents/Visual\ Studio\ 2015/Projects/MetaModelManager/RLink/tempData.dat")
# **********************************************************************************************************************

# **************** YOUR CODE GOES HERE ********************************************************************************

# In this example, we're adding 1 to the 6th indivudal var ('Counter') for each run of the model
i=1

count<-length(testMessage$myPops) +1 
while (i < count) {
  j=1
  count2<-length(testMessage$myPops[[i]]$myIndivs)+1
  while (j < count2) {
    x <- as.numeric(testMessage$myPops[[i]]$myIndivs[[j]]$myVars[6])
    x= x+1
    testMessage$myPops[[i]]$myIndivs[[j]]$myVars[6] <- x
    j=j+1
  }
  i=i+1
}

# **********************************************************************************************************************

# **************** REQUIRED FILE SAVING ********************************************************************************
# Save the modified message to the directory where your R script is.
tf1<-tempfile()
serialize(testMessage,tf1)  # Change 'testMessage' to name you're using, if you changed it
# MMM will look for your modified data in the directory where you said your R script would be.
# *************** MODIFY PATH HERE ***********************
# This should be the same path as the one at top where you read in the MMM message file.
# Note that this filename should be 'tempRData.dat' <-- note the 'R' in that filename!
out<- file("C:/Users/j/Documents/Visual\ Studio\ 2015/Projects/MetaModelManager/RLink/tempRData.dat",open="wb")
testMessage$serialize(out) # Change 'testMessage' to name you're using, if you changed it
close(out)
# **********************************************************************************************************************
