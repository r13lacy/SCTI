﻿using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using MMMCore;
using RDotNet;
using System.Windows.Forms;

namespace RLink
{
    public class MMRLink
    {
        public string ScriptFile = "";
        public bool FirstTurn;

        // Should have created a message with the data from MMM in the viewModel (MAppRLink)

        public MMRLink()
        {
            // Script and file locations should have been entered by user in the View (frmModelSelection)
            // Let's have it write the serialized data to the same directory as the R script (ProjectDir)

            // In future, might set here to tell MMRLink how often to run
        }

        public REngine Initialize(string scriptFile)
        {
            ScriptFile = scriptFile;
            // Start the R engine <-- only do this at the beginning of the very first iteration/scenario
            // leave it running through the entire MMM run
            REngine.SetEnvironmentVariables();
            REngine mmEngine = REngine.GetInstance();

            // test additions by Bob, to reduce how much the user needs to put into the R script
            // RProtoBuf library load apparently doesn't need to specify a path ... and that is useful
            try
            {
                mmEngine.Evaluate("library(RProtoBuf)");

            }
            catch (RDotNet.EvaluationException)
            {
                DialogResult findR = MessageBox.Show("Cannot find package 'RProtoBuf'. Either this package is not installed, " +
                    "or it's in a non-standard location. Hit Cancel to close MMM and go install it, or hit Ok to browse to " +
                    "your install location. Location should be a folder, such as C:/Program Files/R/R-3.3.1/library", "Error Loading R Package", MessageBoxButtons.OKCancel);
                if (findR == DialogResult.Cancel)
                {
                    Environment.Exit(0);
                }
                if (findR == DialogResult.OK)
                {

                    FolderBrowserDialog chooseR = new FolderBrowserDialog();
                    chooseR.Description = "Select R Library Location";
                    DialogResult result = chooseR.ShowDialog();
                    if (!string.IsNullOrWhiteSpace(chooseR.SelectedPath))
                    {
                        string command = "library('RProtoBuf', lib.loc = '" + chooseR.SelectedPath.Replace("\\", "/") + "')";
                        try
                        {
                            mmEngine.Evaluate(command);
                        }
                        catch (Exception)
                        {

                            DialogResult result2 = MessageBox.Show("Package 'RProtoBuf' was not found.", "Error Loading R Package", MessageBoxButtons.OK);
                            if (result2 == DialogResult.OK)
                            {
                                Environment.Exit(0);
                            }
                        }
                    }
                }
            }

// by placing .proto into the ExecutablePath during installation, the user won't need to load it in the R script
//            string protofile = Application.LocalUserAppDataPath + "\\MMMProtoR.proto";
            string protofile = Application.ExecutablePath.Substring(0, Application.ExecutablePath.LastIndexOf("\\")) + "\\MMMProtoR.proto";
            protofile = protofile.Replace('\\', '/');
            mmEngine.Evaluate("readProtoFiles('" + protofile + "')");

            return mmEngine;
        }

        public void RunRScript(REngine engine)
        {
            if (engine.IsRunning)
            {
                string RformatScriptFile = ScriptFile;
                RformatScriptFile = RformatScriptFile.Replace("\\", "/");
                string command = "source(\"" + RformatScriptFile + "\")";
                try
                {
                    Console.WriteLine(command);
                    // Serialized data is saved to ProjectDir by the R script
                    engine.Evaluate(command);

                }
                catch (Exception)
                {
                    // Show the user a message letting them know we probably have the wrong path to their script
                    throw;
                }
            }
            else
                MessageBox.Show("REngine isn't running. Try Initializing."); 
        }

        public void CloseDLL(REngine engine)
        {
            engine.Dispose();
        }

    }
}
