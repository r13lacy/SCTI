using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using MMMCore;

// Note: this code file has not been tested for any specific application. 
// It is intended only to provide a template of the general structure of code that can be used by a model to share data with MetaModelManager.
// For any specific use, the code will likely need to be customized, extended, and thoroughly tested.

namespace MMMyModifier
{
    public class MMMyModifier
    {

        public MMMyModifier()
        {
            // constructor
        }


        // second parameter is whatever file (or null, if nothing) that specifies the project settings (input) that are needed by the Modifier program,
        // usually set up within an external editor program or sometimes by simple manual editing of an input file. 
        public bool Initialize(MMMCore.MDataSet MData, string MyFile)
        {
            // Do whatever stuff needs to be done at the outset of the metamodel, to have this modifier program ready to go


            //  ... do stuff to process input ...
            // e.g., below, variables are read from the file and then added to the Global or Population variables available to MMM

            StreamReader objReader;
            try
            {
                objReader = new StreamReader(MyFile);
            }
            catch
            {
                throw new Exception("MyFile Read Failed");
            }

            string sLine = "";
            char[] splits = { '=', ':', ';' };
            string[] ss;

            while ((sLine = objReader.ReadLine()) != null)
            {

                // file format (an example, myModel can use whatever kind of specification file that it wants)
                // "Globals: T; Y; Z"
                // "PopVars: P; A; B"
                // "IndVars: ID; Sex; Age"

                ss = sLine.Split(splits);
                for (int i = 1; i < ss.GetLength(0); i++)
                {
                    string shareVar = ss[i].Trim().ToUpper();

                    if (ss[0].StartsWith("Ind"))
                    {
                        foreach (MMMCore.MPopulation pop in MData.Populations)
                        {
                            if (pop.GetIndividualVarIndex(shareVar) < 0) // add to MPopulation Ind variables only if not already there
                            {
                                pop.AddIndVar(shareVar);
                            }
                        }
                    }
                    else if (ss[0].StartsWith("Pop"))
                    {
                        foreach (MMMCore.MPopulation pop in MData.Populations)
                        {
                            if (pop.GetVarIndex(shareVar) < 0) // add to MPopulation variables only if not already there
                            {
                                pop.AddVar(shareVar);
                            }
                        }
                    }
                    else if (ss[0].StartsWith("Global"))
                    {
                        if (MData.GetVarIndex(shareVar) < 0) // add to MData global variables only if not already there
                        {
                            MData.VarNames.Add(shareVar);
                            MData.VarTypes.Add(typeof(string));
                            MData.Vars.Add("");
                        }
                    }
                }
            }

            objReader.Close();

            return true;
        }

        // params are 
        //the MMM MDataSet, 
        //the iteration number of the metamodel, 
        //the year of the metamodel (i.e., the number of top level loops through the metamodel that have been completed), 
        //and the number of time steps to be run within the Modifier before passing control back to MMM
        public bool Simulate(MMMCore.MDataSet MData, int iter, int year, int numTimeSteps)
        {
            // this template creates local copies of the MDataSet variables, so that they can be manipulated internally before sending them back to the MMM
            // but operations could have been performed directly on MData.Vars, MData.Populations[p].Vars, and MData.Populations[p].IndList[i].Vars, 
            // without the need for the translation back and forth

            List<object> gvars = new List<object>();
            for (int i = 0; i < MData.Vars.Count; i++)
            {
                gvars.Add(MData.Vars[i]); // get the global variables from MData
            }
            
            for (int p = 0; p < MData.Populations.Count; p++) 
            {
                for (int istep = 0; istep < numTimeSteps; istep++)
                {
                    MMMCore.MPopulation pop = MData.Populations[p];

                    List<object> pvars = new List<object>();
                    for (int i = 0; i < pop.Vars.Count; i++)
                    {
                        pvars.Add(pop.Vars[i]); // get the Population's variables from MData
                    }

                    for(int ii = 0; ii < pop.IndList.Count; ii++)
                    {
                        MIndividual ind = pop.IndList[ii];

                        List<object> ivars = new List<object>();
                        for (int j = 0; j < ind.Vars.Count; j++)
                        {
                            ivars.Add(ind.Vars[j]); // get the individual's variables from MData
                        }



                        // now, do whatever it is that the Modifier does to modify the variables for the individual
                        // ...



                        // then, put individual data back into the MDataSet individual
                        for (int j = 0; j < ind.Vars.Count; j++)
                        {
                            ind.Vars[j] = ivars[j].ToString(); // note that within MData, for now, all variables are stored as strings
                        }

                    }

                    pop.tallyPopulation(); // so tallies available for pop-based modifier programs


                    // now do anything further (such as tallies across individuals) that is needed to modify Population variables
                    // ...


                    // then put the values back into MDataSet population
                    for (int i = 0; i < pop.Vars.Count; i++)
                    {
                        pop.Vars[i] = pvars[i].ToString(); // note that within MData, for now, all variables are stored as strings
                    }

                    // now, do anything further (such as tallies across populations) that is needed to modify Global variables
                    // ...


                } // done with TimeSteps


                // then put the global variable values back into MDataSet
                for (int i = 0; i < MData.Vars.Count; i++)
                {
                    MData.Vars[i] = gvars[i];
                }

            }

            return true; // just a flag saying that all was processed OK
        }



        public bool CloseDLL()
        {

// do anything that needs to be cleaned up, writing to output files, closing files, etc.

            return true;
        }

    
    }
}
