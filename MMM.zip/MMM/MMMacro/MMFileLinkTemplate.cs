using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

// Note: this code file has not been tested for any specific application. 
// It is intended only to provide a template of the general structure of code that can be used by a model to share data with MetaModelManager.
// For any specific use, the code will likely need to be customized, extended, and thoroughly tested.


namespace MMMyModel
{
    public class MMMyModel
    {
        public List<string> myGSvars;
        public List<double> myGSvals;
        public List<string> myPSvars;
        public List<string> myISvars;

        int yr;
        int iter;
        int nTimeSteps;
        int nPops;

        bool PopBase;
        bool sysModel;

        struct MyPop
        {
            public string name;
            public int Nindividuals;
            public List<int> Males;
            public List<int> Females;
            public List<double> myPSvals;
            public List<Individual> IndList;
        }

        struct Individual
        {
            public int name;
            public int age;
            public int sex;
            public List<double> myISvals;
        }

        List<MyPop> myPops;

        public MMMyModel()
        {
            // constructor
            
            myGSvars = new List<string>();
            myPSvars = new List<string>();
            myISvars = new List<string>(); 
            myPops = new List<MyPop>();

            yr = 0;
            iter = 0;
            nTimeSteps = 0;
            nPops = 0;

            PopBase = false; // set to true if pop-based model
            sysModel = true; // set to false if modifier model rather than system model
        }


        // first parameter is the name of the datafile via which MeMoMa passes the current population
        // second parameter is whatever file (or null, if nothing) that specifies the project settings (input) that are needed by the Modifier program,
        // usually set up within an external editor program or sometimes by simple manual editing of an input file. 
        public bool Initialize(string datafilename, string MyFile)
        {
            // Do whatever stuff needs to be done at the outset of the metamodel, to have this modifier program ready to go
            // For example, call the constructor for your model...
            //  ... do stuff to process input ...
            // e.g., below, variables are read from the file and then added to the Individual, Global, or Population variables to be provided to MMM
            
            StreamReader objReader;
            try
            {
                objReader = new StreamReader(MyFile);
            }
            catch
            {
                throw new Exception("MyFile Read Failed");
            }

            string sLine = "";
            char[] splits = { '=', ':', ';' };
            string[] ss;

            while ((sLine = objReader.ReadLine()) != null)
            {

                // file format (an example, myModel can use whatever kind of specification file that it wants)

                // "Populations: Pop1, Pop2"
                // "Globals: T; Y; Z"
                // "PopVars: P; A; B"
                // "IndVars: ID; Sex; Age"

                ss = sLine.Split(splits,StringSplitOptions.RemoveEmptyEntries);
                
                if (ss[0].StartsWith("Populations"))
                {
                    nPops = ss.Length - 1;
                    for (int j = 1; j < ss.Length; j++)
                    {
                        MyPop mpop = new MyPop();
                        mpop.name = ss[j].Trim();
                        mpop.Nindividuals = 0;
                        mpop.Males = new List<int>();
                        mpop.Females = new List<int>();
                        mpop.myPSvals = new List<double>();
                        mpop.IndList = new List<Individual>();
                        myPops.Add(mpop);
                    }
                    continue;
                }

                if (ss[0].StartsWith("Ind"))
                {
                    for (int j = 1; j < ss.Length; j++)
                    {
                        myISvars.Add(ss[j].Trim());
                    }
                }
                else if (ss[0].StartsWith("Pop"))
                {
                    for (int j = 1; j < ss.Length; j++)
                    {
                        myPSvars.Add(ss[j].Trim());
                    }
                }
                else if (ss[0].StartsWith("Global"))
                {
                    for (int j = 1; j < ss.Length; j++)
                    {
                        myGSvars.Add(ss[j].Trim());
                        myGSvals.Add(0.0);
                    }
                }
            }

            objReader.Close();

            for (int p = 0; p < nPops; p++)
            {
                MyPop mpop = myPops[p];
                for(int j = 0; j < myPSvars.Count; j++)
                    mpop.myPSvals.Add(0.0); // do this initialization now, rather than later, to be sure that myPSvals count = myPSvars count
            }

            // ... insert here code for any initial work that needs to be done
            // ...


            return true;
        }

        // params are 
        //the filename for the current data file (will always be passed as xchangefile.txt by MeMoMa)
        //the iteration number of the metamodel, 
        //the year of the metamodel (i.e., the number of top level loops through the metamodel that have been completed), 
        //and the number of time steps to be run within the Modifier before passing control back to MMM
        public bool Simulate(string filename, int iteration, int year, int numTimeSteps)
        {
            iter = iteration;
            yr = year;
            nTimeSteps = numTimeSteps;

            if (yr == 0 && sysModel)
            {
                // do whatever work is needed to create the initial population
                // ...

                // note: some system models might create population in Initialize(), 
                // but usually not because normally a new population is created with each independent iteration

            }
            else ReadDataFile(filename);

            for (int istep = 0; istep < numTimeSteps; istep++)
            {
                for (int p = 0; p < nPops; p++)
                {
                    MyPop mpop = myPops[p];

                    // now, do whatever it is that myModel does to modify the variables for each individual 
                    // ...

                    // now do anything further (such as tallies across individuals) that is needed to modify Population variables
                    // ...

                } 

                // now, do anything further (such as tallies across populations) that is needed to modify Global variables
                // ...

            }

            // then put the values back into data file
            WriteDataFile(filename);

            return true; // just a flag saying that all was processed OK
        }



        public bool CloseDLL()
        {

// do anything that needs to be cleaned up, writing to output files, closing files, etc.

            return true;
        }


        // Note that although an iteration of a year elapses within Simulate(), 
        //   the incrementing of iteration and year will be handled by MeMoMa when it passes data to the next model
        //   so there shouldn't be any need to be concerned about what myModel puts into these variables in the file.
        // they are there only to maintain file structure consistency with the MeMoMa format of the datafile.
        public void WriteDataFile(string fileLocation)
        {
            //Creator = MyModel ...
            //Iteration = 1, Year = 50, Timesteps = 5
            //GlobalVariables, NumGSVars = 2
            //GS1, GS2
            //1.0000,2.0000
            //PopulationVariables, NumPSVars = 2, Population 1: PopName
            //PS1,PS2
            //22.000000; 11.000000
            //PopulationSize = 100
            //AgeStructure
            //Females: 12;22;33
            //Males: 32;12;11
            //IndividualVariables, NumISVars = 2
            //Name,Index,Age,Sex,Var1,Var2
            //33;0;11688;0;33.00000000;34.00000000
            //35;1;11688;1;33.00000000;34.00000000
            //PopulationVariables, NumPSVars = 2, Population 2: PopName
            //PS1,PS2
            //222.000000; 111.000000
            //IndividualVariables, NumISVars = 2
            //Name,Index,Age,Sex,Var1,Var2
            //33;0;11688;0;33.00000000;34.00000000
            //35;1;11688;1;33.00000000;34.00000000

            StreamWriter writer = new StreamWriter(fileLocation, false);

            writer.WriteLine("MData File Created by MyModel - " + DateTime.Now.ToLongDateString());
            writer.WriteLine("Iteration = " + iter.ToString() + ", Year = " + yr.ToString() + ", Timesteps = " + nTimeSteps.ToString());
            writer.WriteLine("GlobalVariables, NumGSVars = " + myGSvars.Count.ToString());

            if (myGSvars.Count > 0)
            {
                string sGV = myGSvars[0];
                for (int j = 1; j < myGSvars.Count; j++)
                    sGV += "," + myGSvars[j];
                writer.WriteLine(sGV);

                sGV = myGSvals[0].ToString();
                for (int j = 1; j < myGSvars.Count; j++)
                    sGV += ";" + myGSvals[j].ToString();
                writer.WriteLine(sGV);
            }

            for (int p = 0; p < nPops; p++)
            {
                MyPop mpop = myPops[p];

                writer.WriteLine("PopulationVariables, NumPSVars = " + myPSvars.Count.ToString() + ", Population " + (p + 1).ToString() + ": " + mpop.name);

                if (myPSvars.Count > 0)
                {
                    string sPV = myPSvars[0];
                    for (int j = 1; j < myPSvars.Count; j++)
                        sPV += "," + myPSvars[j];
                    writer.WriteLine(sPV);

                    sPV = mpop.myPSvals[0].ToString();
                    for (int j = 1; j < mpop.myPSvals.Count; j++)
                        sPV += ";" + mpop.myPSvals[j].ToString();
                    writer.WriteLine(sPV);
                }

                writer.WriteLine("PopulationSize = " + mpop.Nindividuals.ToString());
                if (mpop.Females.Count > 0 || mpop.Males.Count > 0)
                {
                    writer.WriteLine("AgeStructure");
                    string tally = "Females: ";
                    for (int j = 0; j < mpop.Females.Count; j++) tally += mpop.Females[j].ToString() + ";";
                    writer.WriteLine(tally.Trim(';'));
                    tally = "Males: ";
                    for (int j = 0; j < mpop.Males.Count; j++) tally += mpop.Males[j].ToString() + ";";
                    writer.WriteLine(tally.Trim(';'));
                }

                if(!PopBase)  // Note: pop-based models can skip writing Individual data
                {
                    writer.WriteLine("IndividualVariables, NumISVars = " + myISvars.Count.ToString());

                    string sIV = "Name,Index,Age,Sex"; // Note, these core Individual vars could be made ISvars in myModel instead of handled specially
                        // but be aware that MMM expect numISvars to not include these 4 core vars

                    for (int j = 0; j < myISvars.Count; j++)
                        sIV += "," + myISvars[j];
                    writer.WriteLine(sIV);

                    for (int m = 0; m < mpop.IndList.Count; m++)
                    {
                        string sLine = mpop.IndList[m].name + ";" + m.ToString() + ";" + mpop.IndList[m].age.ToString() + ";" + mpop.IndList[m].sex.ToString();

                        for (int j = 0; j < mpop.IndList[m].myISvals.Count; j++)
                            sLine += ";" + mpop.IndList[m].myISvals[j].ToString();

                        writer.WriteLine(sLine);
                    }
                }
            }
            writer.Close();
        }

        // returns false on error
        private bool ReadDataFile(string fileLocation)
        {
            try
            {
                StreamReader reader = new StreamReader(fileLocation);

                //Creator = MyModel ...
                //Iteration = 1, Year = 50, Timesteps = 5
                reader.ReadLine();
                reader.ReadLine();

                string[] ss;
                char[] delims = { ',', ':', ';', '\t', '=' };
                char[] delims2 = { ':', ';', '\t', '=' }; // don't use commas to separate numbers, EU format problem

                //GlobalVariables, NumGSVars = 2
                //GS1, GS2
                //1.0000,2.0000
                string line = reader.ReadLine();
                ss = line.Split(delims);
                int nGSV = Convert.ToInt32(ss[ss.Length - 1]);

                if (nGSV > 0)
                {
                    line = reader.ReadLine();
                    ss = line.Split(delims); // read GSvar labels
                    List<string> MMGSV = new List<string>();
                    for (int i = 0; i < ss.Length; i++) MMGSV.Add(ss[i].Trim());

                    line = reader.ReadLine();
                    ss = line.Split(delims2); //read GSvar values
                    for (int i = 0; i < ss.Length; i++)
                    {
                        for (int j = 0; j < MMGSV.Count; j++) // find the GSvar in local data set
                        {
                            int dex = myGSvars.IndexOf(MMGSV[j]); // caution: this will be case sensitive
                            if (dex >= 0) myGSvals[dex] = Convert.ToDouble(ss[i]);
                        }
                    }
                }

                //PopulationVariables, NumPSVars = 2, Population 1: PopName
                //PS1,PS2
                //22.000000; 11.000000

                line = reader.ReadLine();
                for (int p = 0; p < nPops; p++)
                {
                    MyPop mpop = myPops[p];

                    if (!line.StartsWith("PopulationVar")) return false; // error handling should be added throughout the code

                    ss = line.Split(delims);
                    int nPSV = Convert.ToInt32(ss[2]);

                    if (nPSV > 0)
                    {
                        line = reader.ReadLine();
                        ss = line.Split(delims); // read PSvar labels
                        List<string> MMPSV = new List<string>();
                        for (int i = 0; i < ss.Length; i++) MMPSV.Add(ss[i].Trim());

                        line = reader.ReadLine();
                        ss = line.Split(delims2); //read PSvar values
                        for (int i = 0; i < ss.Length; i++)
                        {
                            for (int j = 0; j < MMPSV.Count; j++) // find the PSvar in local data set
                            {
                                int dex = myPSvars.IndexOf(MMPSV[j]); // caution: this will be case sensitive
                                if (dex >= 0) mpop.myPSvals[dex] = Convert.ToDouble(ss[i]);
                            }
                        }
                    }

                    //PopulationSize = 100
                    //AgeStructure
                    //Females: 12;22;33
                    //Males: 32;12;11

                    line = reader.ReadLine();
                    while (line != null && !line.StartsWith("PopulationVar")) 
                    {
                        ss = line.Split(delims2);

                        if(line.StartsWith("PopulationSize")) 
                        {
                            mpop.Nindividuals = Convert.ToInt32(ss[1].Trim());
                        }
                        else if (line.StartsWith("Females"))
                        {
                            mpop.Females.Clear();
                            for (int i = 1; i < ss.Length; i++) mpop.Females.Add(Convert.ToInt32(ss[i]));
                        }
                        else if (line.StartsWith("Males"))
                        {
                            mpop.Males.Clear();
                            for (int i = 1; i < ss.Length; i++) mpop.Males.Add(Convert.ToInt32(ss[i]));
                        }
                        else if (!PopBase && line.StartsWith("IndividualVar"))
                        {
                            //IndividualVariables, NumISVars = 2
                            //Name,Index,Age,Sex,Var1,Var2
                            //33;0;11688;0;33.00000000;34.00000000
                            //35;1;11688;1;33.00000000;34.00000000

                            line = reader.ReadLine();
                            ss = line.Split(delims); // read ISvar labels
                            List<string> MMISV = new List<string>();
                            for (int i = 0; i < ss.Length; i++) MMISV.Add(ss[i].Trim());
                            if (MMISV[0] != "Name") return false; // this error should be handled somehow

                            // need to keep track of which individuals are in file and then remove missing ones
                            // because don't want to simply replace IndList, as it may have individual data not shared with MMM
                            List<bool> alive = new List<bool>();
                            int ict = mpop.IndList.Count;
                            for (int i = 0; i < ict; i++)
                            {
                                alive.Add(false); 
                            }
                            
                            line = reader.ReadLine();
                            if (line == null) return true;

                            while (!line.StartsWith("PopulationVar"))
                            {
                                ss = line.Split(delims2); //read values for each individual

                                Individual ind;
                                int id = Convert.ToInt32(ss[0]);
                                int i1;
                                for (i1 = 0; i1 < ict; i1++)
                                {
                                    if (mpop.IndList[i1].name == id) break;
                                }
                                if (i1 >= ict)
                                {
                                    ind = new Individual();
                                    // Note: Model may need to do more when a new individual appears 
                                    // if so, do it here
                                    // e.g., what if anything should be assigned as default values for age, sex, and ISvars?
                                    ind.name = id;
                                }
                                else
                                {
                                    alive[i1] = true;
                                    ind = mpop.IndList[i1];
                                }

                                for (int i = 1; i < ss.Length; i++)
                                {
                                    if (MMISV[i] == "Index") continue;
                                    if (MMISV[i] == "Sex")
                                    {
                                        ind.sex = Convert.ToInt32(ss[i]);
                                    }
                                    else if (MMISV[i] == "Age")
                                    {
                                        ind.age = Convert.ToInt32(ss[i]);
                                    }

                                    else for (int j = 0; j < MMISV.Count; j++) // find the ISvar in local data set
                                    {
                                        int dex = myISvars.IndexOf(MMISV[j]); // caution: this will be case sensitive
                                        if (dex >= 0) ind.myISvals[dex] = Convert.ToDouble(ss[i]);
                                    }
                                }

                                line = reader.ReadLine();
                                
                                if (line.StartsWith("PopulationVar") || line == null) // end of individuals in pop
                                {
                                    for (int i = ict - 1; i >= 0; ict--) if (!alive[ict]) mpop.IndList.RemoveAt(i);
                                }
                            } 
                        }

                        else if((line = reader.ReadLine()) == null) return true; // probably should check for premature end of file
                    } // end of pop

                }
                reader.Close();

            }
            catch
            {
                return false;
            }

            return true;
        }

    }
}
