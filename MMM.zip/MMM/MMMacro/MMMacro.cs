using System;
using System.Collections.Generic;
using System.Text;
using EvaluatorLibrary;
using System.IO;
using MMMCore;
using System.Windows.Forms;

namespace MMMacro
{
    public class MMMacro
    {
        private Macro globalMacro;
        private Macro popMacro;
        private Macro indMacro;

        //private bool inited = false;
        //private bool mapped = false;

        private string macroFile;

        public MMMacro()
        {
        }

        private void makeMMMacro(MMMCore.MDataSet MData, string MacroFile) 
        {
            StreamReader objReader;
            try
            {
                objReader = new StreamReader(MacroFile);
            }
            catch
            {
                throw new Exception("MMMacro File Read Failed");
            }

            List<string> vars = new List<string>();
            List<double> vals = new List<double>();
            List<string> steps = new List<string>();

            string sLine = "";
            char[] splits = { '=', ':', ';' };
            string[] ss;

            sLine = objReader.ReadLine();
            while (sLine != null)
            {
                steps = new List<string>(); // this re-setting was missing before, so macros accumulated
                sLine = sLine.ToUpper();

                if (sLine.StartsWith("SHARED"))
                {
                    bool globalm = false;
                    bool popm = false;
                    bool indm = false;
                    if (sLine.StartsWith("SHAREDG")) globalm = true;
                    if (sLine.StartsWith("SHAREDP")) popm = true;
                    if (sLine.StartsWith("SHAREDI")) indm = true;

                    // note accumulation of vars as move through global, pop, and ind

                    ss = sLine.Split(splits);
                    int nrows = ss.GetUpperBound(0);
                    for (int i = 1; i <= nrows; i++)
                    {
                        string shareVar = ss[i].Trim().ToUpper();
                        if (shareVar != "") 
                        {
                            vars.Add(shareVar);

                            if (popm)
                            {
                                foreach (MMMCore.MPopulation pop in MData.Populations)
                                {
                                    if (pop.GetVarIndex(shareVar) < 0)
                                    {
                                        pop.VarNames.Add(shareVar);
                                        pop.VarTypes.Add(typeof(string));
                                        pop.Vars.Add("");
                                    }
                                }
                            }
                            else if (globalm)
                            {
                                if (MData.GetVarIndex(shareVar) < 0)
                                {
                                    MData.VarNames.Add(shareVar);
                                    MData.VarTypes.Add(typeof(string));
                                    MData.Vars.Add("");
                                }
                            }
                            else if (indm) // added 12 Dec 2015; why wasn't it here before? Is it not needed for some reason?
                            {
                                foreach (MMMCore.MPopulation pop in MData.Populations)
                                {
                                    if (pop.GetIndividualVarIndex(shareVar) < 0)
                                    {
                                        pop.AddIndVar(shareVar, "");
                                    }
                                }
                            }
                        }
                    }

                    sLine = objReader.ReadLine();
                    if (sLine != null && sLine.ToUpper().StartsWith("VALS"))
                    {
                        ss = sLine.Split(splits);
                        nrows = ss.GetUpperBound(0);
                        for (int i = 1; i <= nrows; i++)
                        {
                            string iv = ss[i].Trim();
                            if(iv != "") vals.Add(Convert.ToDouble(iv));
                        }
                        sLine = objReader.ReadLine();
                    }
                    while (sLine != null)
                    {
                        sLine = sLine.ToUpper();
                        if (sLine.StartsWith("SHARED")) break;
                        if (sLine.Trim() != "" && sLine[0] != '*' && sLine[0] != '#') steps.Add(sLine);
                        sLine = objReader.ReadLine();
                    }

                    // added 30 Dec 2016 so that missing Vals becomes -999, rather than defaulting to 0
                    for (int i = vals.Count; i < vars.Count; i++) vals.Add(-999.0);

                    if (globalm && steps.Count > 0) globalMacro = new Macro(vars, vals, steps);
                    if (popm && steps.Count > 0) popMacro = new Macro(vars, vals, steps);
                    if (indm && steps.Count > 0) indMacro = new Macro(vars, vals, steps);
                }

                    // 18 Dec 2014
                else // didn't start with SHARED
                {
                    while (sLine != null)
                    {
                        sLine = sLine.ToUpper();
                        if (sLine.StartsWith("SHARED")) break;
                        if (sLine.Trim() != "" && sLine[0] != '*' && sLine[0] != '#') steps.Add(sLine);
                        sLine = objReader.ReadLine();
                    }
                }
            }

            objReader.Close();

            return;
        }

        private List<int> globalVarIndIndex;
        private List<int> popVarIndIndex;
        private List<int> indVarIndIndex;
        private List<int> globalVarPopIndex;
        private List<int> popVarPopIndex;
        private List<int> globalVarGlIndex;


        public bool Initialize(MMMCore.MDataSet MData, string MacroFile)
        {
            macroFile = MacroFile;

            //if(! inited) 
//                makeMMMacro(MData, MacroFile);  
            // do in Initialize so that get shared vars, but then repeat in DoYear0 at the beginning of each iteration to re-set initial vals

            return true;
        }

        private int GetGlVarIndex(MMMCore.MDataSet MData, string varname)
        {
            int i;
            for (i = 0; i < MData.VarNames.Count; i++)
            {
                if (varname.ToUpper() == MData.VarNames[i].ToUpper()) break;
            }
            if (i == MData.VarNames.Count) return (-1);

            return (i);
        }

        public bool SimYear0(MMMCore.MDataSet MData, int iteration)
        {
            makeMMMacro(MData, macroFile); // need to re-do this each iteration, because it is possible that an initialized value in the macro needs to be re-set
            mapMMMVars(MData); 

            return true;
        }


        private bool mapMMMVars(MMMCore.MDataSet MData)
        {
// note: this will have problems if pops don't all use the same PSVars and ISVars
            globalVarIndIndex = new List<int>();
            popVarIndIndex = new List<int>();
            indVarIndIndex = new List<int>();

            globalVarPopIndex = new List<int>();
            popVarPopIndex = new List<int>();

            globalVarGlIndex = new List<int>();

            List<string> vars = new List<string>();
            List<double> vals = new List<double>();
            List<string> steps = new List<string>();

            bool itervar = false;
            bool yearvar = false;
            bool stepvar = false;
            bool popvar = false;
            int vi;

            MMMCore.MPopulation pop0 = MData.Populations[0];

            if (indMacro != null)
            {
                for (int i = 0; i < indMacro.mVars.Count; i++)
                {
                    if (indMacro.mVars[i] == "Y" || indMacro.mVars[i] == "YEAR") yearvar = true;
                    else if (indMacro.mVars[i] == "R" || indMacro.mVars[i] == "RUN" || indMacro.mVars[i] == "ITERATION") itervar = true;
                    else if (indMacro.mVars[i] == "STEP" || indMacro.mVars[i] == "TIMESTEP") stepvar = true;
                    else if (indMacro.mVars[i] == "P" || indMacro.mVars[i] == "POPULATION") popvar = true;

                    indVarIndIndex.Add(-1); 
                    popVarIndIndex.Add(-1);
                    globalVarIndIndex.Add(-1);

                    // added 10 Dec 2015 -- for speed
                    if (yearvar || itervar || stepvar) continue;

                    // identify where in vars is the index of each IndMacro Var
                    if ((vi = pop0.GetIndividualVarIndex(indMacro.mVars[i])) >= 0)
                    {
                        indVarIndIndex[i] = vi;
                        if (indMacro.mVals[i] != -999.0)
                        {
                            string valstr = indMacro.mVals[i].ToString();
                            foreach (MMMCore.MPopulation mpop in MData.Populations)
                            {
                                foreach (MIndividual ind in mpop.IndList)
                                    ind.Vars[indVarIndIndex[i]] = valstr;
                            }
                        }
                    }

                    else if ((vi = pop0.GetVarIndex(indMacro.mVars[i])) >= 0)
                    {
                        popVarIndIndex[i] = vi;
                        if (indMacro.mVals[i] != -999.0)
                        {
                            string valstr = indMacro.mVals[i].ToString();
                            foreach (MMMCore.MPopulation mpop in MData.Populations)
                                mpop.Vars[vi] = valstr;
                        }
                    }

                    else if ((vi = GetGlVarIndex(MData, indMacro.mVars[i])) >= 0)
                    {
                        globalVarIndIndex[i] = vi;
                        //if (indMacro.mVals[i] != 0.0)
                        if (indMacro.mVals[i] != -999.0) // mmmacro specifies a starting value
                        {
                            MData.SetVarVal(vi, indMacro.mVals[i]); //.ToString());
                        }
                    }

                    //else an internal var to macro
                }
                
                if (!yearvar) // in case used internally in Macro, but not listed as a "shared" var
                {
                    indMacro.mVars.Add("Y");
                    indMacro.mVals.Add(0.0);
                    indMacro.addSpecial("Y");
                    popVarIndIndex.Add(-1);
                    indVarIndIndex.Add(-1);
                    globalVarIndIndex.Add(-1);
                }
                if (!itervar)
                {
                    indMacro.mVars.Add("R");
                    indMacro.mVals.Add(0.0);
                    indMacro.addSpecial("R");
                    indVarIndIndex.Add(-1);
                    popVarIndIndex.Add(-1);
                    globalVarIndIndex.Add(-1);
                }
                if (!stepvar)
                {
                    indMacro.mVars.Add("STEP");
                    indMacro.mVals.Add(0.0);
                    indMacro.addSpecial("STEP");
                    globalMacro.addSynon("TIMESTEP", "STEP");
                    indVarIndIndex.Add(-1);
                    popVarIndIndex.Add(-1);
                    globalVarIndIndex.Add(-1);
                }
                if (!popvar)
                {
                    indMacro.mVars.Add("P");
                    indMacro.mVals.Add(0.0);
                    indMacro.addSpecial("P");
                    globalMacro.addSynon("POPULATION", "P");
                    indVarIndIndex.Add(-1);
                    popVarIndIndex.Add(-1);
                    globalVarIndIndex.Add(-1);
                }
            }

            yearvar = false;
            stepvar = false;
            popvar = false;
            itervar = false;
            if (popMacro != null)
            {
                for (int i = 0; i < popMacro.mVars.Count; i++)
                {
                    if (popMacro.mVars[i] == "Y" || popMacro.mVars[i] == "YEAR") yearvar = true;
                    else if (popMacro.mVars[i] == "R" || popMacro.mVars[i] == "RUN" || popMacro.mVars[i] == "ITERATION") itervar = true;
                    else if (popMacro.mVars[i] == "STEP" || popMacro.mVars[i] == "TIMESTEP") stepvar = true;
                    else if (popMacro.mVars[i] == "P" || popMacro.mVars[i] == "POPULATION") popvar = true;

                    popVarPopIndex.Add(-1);
                    globalVarPopIndex.Add(-1);

                    // added 10 Dec 2015 -- for speed
                    if (yearvar || itervar || stepvar || popvar) continue;

                    // identify where in vars is the index of each popMacro Var
                    if ((vi = pop0.GetVarIndex(popMacro.mVars[i])) >= 0)
                    {
                        popVarPopIndex[i] = vi;

                        if (popMacro.mVals[i] != -999.0)
                        {
                            string valstr = popMacro.mVals[i].ToString();
                            foreach (MMMCore.MPopulation mpop in MData.Populations)
                            {
                                mpop.Vars[vi] = valstr;
                            }
                        }
                    }

                    else if ((vi = GetGlVarIndex(MData, popMacro.mVars[i])) >= 0)
                    {
                        globalVarPopIndex[i] = vi;
                        if (popMacro.mVals[i] != -999.0)
                        {
                            MData.SetVarVal(vi, popMacro.mVals[i]); 
                        }
                    }
                }

                if (!yearvar) // in case used internally in Macro, but not listed as a "shared" var
                {
                    popMacro.mVars.Add("Y");
                    popMacro.addSpecial("Y");
                    popMacro.mVals.Add(0.0);
                    popVarPopIndex.Add(-1);
                    globalVarPopIndex.Add(-1);
                }
                if (!itervar)
                {
                    popMacro.mVars.Add("R");
                    popMacro.mVals.Add(0.0);
                    popMacro.addSpecial("R");
                    popVarPopIndex.Add(-1);
                    globalVarPopIndex.Add(-1);
                }
                if (!stepvar)
                {
                    popMacro.mVars.Add("STEP");
                    popMacro.mVals.Add(0.0);
                    popMacro.addSpecial("STEP");
                    popVarPopIndex.Add(-1);
                    globalVarPopIndex.Add(-1);
                    globalMacro.addSynon("TIMESTEP", "STEP");
                }
                if (!popvar && indMacro != null)
                {
                    indMacro.mVars.Add("P");
                    indMacro.mVals.Add(0.0);
                    indMacro.addSpecial("P");
                    globalMacro.addSynon("POPULATION", "P");

                    indVarIndIndex.Add(-1);
                    popVarIndIndex.Add(-1);
                    globalVarIndIndex.Add(-1);
                }
            }

            yearvar = false;
            stepvar = false;
            popvar = false;
            itervar = false;
            if (globalMacro != null)
            {
                for (int i = 0; i < globalMacro.mVars.Count; i++)
                {
                    if (globalMacro.mVars[i] == "Y" || globalMacro.mVars[i] == "YEAR") yearvar = true;
                    else if (globalMacro.mVars[i] == "R" || globalMacro.mVars[i] == "RUN" || globalMacro.mVars[i] == "ITERATION") itervar = true;
                    else if (globalMacro.mVars[i] == "STEP" || globalMacro.mVars[i] == "TIMESTEP") stepvar = true;
                    else if (globalMacro.mVars[i] == "P" || globalMacro.mVars[i] == "POPULATION") popvar = true;

                    globalVarGlIndex.Add(-1);

                    // added 10 Dec 2015 -- for speed
                    if (yearvar || itervar || stepvar || popvar) continue;

                    // identify where in vars is the index of each globalMacro Var
                    if ((vi = GetGlVarIndex(MData, globalMacro.mVars[i])) >= 0)
                    {
                        globalVarGlIndex[i] = vi;

                        if (globalMacro.mVals[i] != -999.0) // mmmacro specifies a starting value
                        {
                            MData.SetVarVal(vi, globalMacro.mVals[i]);
                        }  // -999.0 as missing, 30 Dec 2016
                    }
                }

                if (!yearvar) // in case used internally in Macro, but not listed as a "shared" var
                {
                    globalMacro.mVars.Add("Y");
                    globalMacro.mVals.Add(0.0);
                    globalMacro.addSpecial("Y");
                    globalVarGlIndex.Add(-1);
                }
                if (!itervar)
                {
                    globalMacro.mVars.Add("R");
                    globalMacro.mVals.Add(0.0);
                    globalMacro.addSpecial("R");
                    globalVarGlIndex.Add(-1);
                }
                if (!stepvar)
                {
                    globalMacro.mVars.Add("STEP");
                    globalMacro.mVals.Add(0.0);
                    globalMacro.addSpecial("STEP");
                    globalVarGlIndex.Add(-1);
                    globalMacro.addSynon("TIMESTEP", "STEP");
                }
                if (!popvar && indMacro != null)
                {
                    indMacro.mVars.Add("P");
                    indMacro.mVals.Add(0.0);
                    indMacro.addSpecial("P");
                    indVarIndIndex.Add(-1);
                    popVarIndIndex.Add(-1);
                    globalVarIndIndex.Add(-1);
                    globalMacro.addSynon("POPULATION", "P");
                }
            }
            
//            mapped = true;

            return true;
        }

        public bool Simulate(MMMCore.MDataSet MData, int iter, int year, int numTimeSteps)
        {
            if (year == 0)
            {
                //makeMMMacro(MData, macroFile);
                //mapMMMVars(MData); 
            }
//            if(! mapped) mapMMMVars(MData); 
                
            for (int istep = 0; istep < numTimeSteps; istep++)
            {
                // globalMacro
                if (globalMacro != null && globalMacro.mVars.Count > 0)
                {
                    for (int i = 0; i < globalMacro.mVars.Count; i++)
                    {
                        if (globalVarGlIndex[i] >= 0) {
                            globalMacro.mVals[i] = MData.GetVarDouble(globalVarGlIndex[i]);
                            //try
                            //{
                            //    globalMacro.mVals[i] = Convert.ToDouble(MData.Vars[globalVarGlIndex[i]]);
                            //}
                            //catch { globalMacro.mVals[i] = 0.0; }
                        }
                        else if (globalMacro.mVars[i] == "Y" || globalMacro.mVars[i] == "YEAR") globalMacro.mVals[i] = (double)(year + 1); // should this be 1-based?
                        else if (globalMacro.mVars[i] == "R" || globalMacro.mVars[i] == "RUN" || globalMacro.mVars[i] == "ITERATION") globalMacro.mVals[i] = (double)(iter + 1);
                        else if (globalMacro.mVars[i] == "STEP" || globalMacro.mVars[i] == "TIMESTEP") globalMacro.mVals[i] = (double)(istep + 1);
                        else if (globalMacro.mVars[i] == "P" || globalMacro.mVars[i] == "POPULATION") globalMacro.mVals[i] = (double)MData.Populations.Count;
                    }

                    globalMacro.RunMacro();

                    for (int i = 0; i < globalMacro.mVars.Count; i++)
                        // hmmm ... wasteful and dangerous to reset values that haven't been changed ...
                        // especially for indMacro, which has all of glMacro and popMacro vars also!
                    {
                        if (globalVarGlIndex[i] >= 0)
                        {
                            MData.SetVarVal(globalVarGlIndex[i], globalMacro.mVals[i]);
                        }
                    }
                }

                // popMacro
                if (popMacro != null)
                {
                    for (int i = 0; i < popMacro.mVars.Count; i++)
                    {
                        if (popMacro.mVars[i] == "Y" || popMacro.mVars[i] == "YEAR") popMacro.mVals[i] = (double)(year + 1); 
                        else if (popMacro.mVars[i] == "R" || popMacro.mVars[i] == "ITERATION" || popMacro.mVars[i] == "RUN") popMacro.mVals[i] = (double)(iter + 1);
                        else if (popMacro.mVars[i] == "STEP" || popMacro.mVars[i] == "TIMESTEP") popMacro.mVals[i] = (double)(istep + 1);
                    }
                }

                if(indMacro != null) for (int i = 0; i < indMacro.mVars.Count; i++)
                {
                    if (indMacro.mVars[i] == "Y" || indMacro.mVars[i] == "YEAR") indMacro.mVals[i] = (double)(year + 1);
                    // is year 0-based or 1-based?
                    // note: a shared pop var called YEAR or Y will over-write the year being passed to this macro
                    // but both can be used simultaneously in Macro, with just one coming from MMM and the other being passed
                    else if (indMacro.mVars[i] == "R" || indMacro.mVars[i] == "RUN" || indMacro.mVars[i] == "ITERATION") indMacro.mVals[i] = (double)(iter + 1);
                    else if (indMacro.mVars[i] == "STEP" || indMacro.mVars[i] == "TIMESTEP") indMacro.mVals[i] = (double)(istep + 1);
                }

                for (int p = 0; p < MData.Populations.Count; p++) 
                {
                    MMMCore.MPopulation pop = MData.Populations[p];
                    if (popMacro != null && popMacro.mVars.Count > 0)
                    {
                        for (int i = 0; i < popMacro.mVars.Count; i++)
                        {
                            if (popVarPopIndex[i] >= 0)
                            {
                                try { popMacro.mVals[i] = Convert.ToDouble(pop.Vars[popVarPopIndex[i]]); }
                                catch { popMacro.mVals[i] = 0.0; }
                            }
                            else if (globalVarPopIndex[i] >= 0)
                            {
                                popMacro.mVals[i] = MData.GetVarDouble(globalVarPopIndex[i]); // do this in the loop because a previous popMacro can change a GVar
                                //try
                                //{
                                //    popMacro.mVals[i] = Convert.ToDouble(MData.Vars[globalVarPopIndex[i]]); // do this in the loop because a previous popMacro can change a GVar
                                //}
                                //catch { popMacro.mVals[i] = 0.0; }
                            }
                            else if (popMacro.mVars[i] == "P" || popMacro.mVars[i] == "POPULATION") popMacro.mVals[i] = (double)(p + 1);
                        }

                        popMacro.RunMacro();

                        for (int i = 0; i < popMacro.mVars.Count; i++)
                        {
                            if (popVarPopIndex[i] >= 0)
                            {
                                string valstr = popMacro.mVals[i].ToString();
                                if (valstr.Length > 16) valstr = valstr.Remove(16); 
                                pop.Vars[popVarPopIndex[i]] = valstr;
                            }
                            else if (globalVarPopIndex[i] >= 0)
                            {
                                MData.SetVarVal(globalVarPopIndex[i], popMacro.mVals[i]);
                            }
                        }
                    }

                    // indMacro
                    if (indMacro == null || indMacro.mVars.Count == 0) continue;

                    for (int i = 0; i < indMacro.mVars.Count; i++)
                    {
                        if (indMacro.mVars[i] == "P" || indMacro.mVars[i] == "POPULATION") indMacro.mVals[i] = (double)(p + 1);
                    }

                    for(int ii = 0; ii < pop.IndList.Count; ii++)
//                    foreach (MIndividual ind in pop.IndList)
                    {
                        MIndividual ind = pop.IndList[ii];

                        for (int j = 0; j < indMacro.mVars.Count; j++)
                        {
                            // do these in here, so that indMacro can change (e.g., increment) a PVar or GVar
                            // do we want to let indMacro do this? or should it always use original GVar even if it changes it?
                            if (indVarIndIndex[j] >= 0)
                            {
                                try
                                {
                                    indMacro.mVals[j] = Convert.ToDouble(ind.Vars[indVarIndIndex[j]]);
                                }
                                catch { indMacro.mVals[j] = 0.0; }
                            }
                            else if (popVarIndIndex[j] >= 0)
                            {
                                try
                                {
                                    indMacro.mVals[j] = Convert.ToDouble(pop.Vars[popVarIndIndex[j]]);
                                }
                                catch { indMacro.mVals[j] = 0.0; }
                            }
                            else if (globalVarIndIndex[j] >= 0)
                            {
                                indMacro.mVals[j] = MData.GetVarDouble(globalVarIndIndex[j]);
                                //try
                                //{
                                //    indMacro.mVals[j] = Convert.ToDouble(MData.Vars[globalVarIndIndex[j]]);
                                //}
                                //catch { indMacro.mVals[j] = 0.0; }
                            }
                        }

                        indMacro.RunMacro();

                        for (int i = 0; i < indMacro.mVars.Count; i++)
                        {
                            if (indVarIndIndex[i] >= 0)
                            {
                                string valstr = indMacro.mVals[i].ToString();
                                if (valstr.Length > 16) valstr = valstr.Remove(16); 
                                ind.Vars[indVarIndIndex[i]] = valstr;
                            }
                            else if (popVarIndIndex[i] >= 0)
                            {
                                string valstr = indMacro.mVals[i].ToString();
                                if (valstr.Length > 16) valstr = valstr.Remove(16); 
                                pop.Vars[popVarIndIndex[i]] = valstr;
                            }
                            else if (globalVarIndIndex[i] >= 0)
                            {
                                MData.SetVarVal(globalVarIndIndex[i], indMacro.mVals[i]);
                            }
                            else if (indMacro.mVars[i] == "P" || indMacro.mVars[i] == "POPULATION")
                            {
                                if (indMacro.mVals[i] != (double)(p + 1)) // changed population! 
                                {
                                    MPopulation newpop = MData.Populations[-1 + (int)indMacro.mVals[i]];
                                    newpop.IndList.Add(ind);
                                    pop.IndList.Remove(ind);
                                    ii--;
                                }
                            }
                        }
                    }
                }
            }

            return true;
        }


        public bool CloseDLL()
        {
// anything else need to be cleared, in case project re-run without calling new MMMacro?
            //mapped = false;
            //inited = false;

            return true;
        }

    
    }
}
