﻿using System;
using System.Windows.Forms;

namespace Outbreak2
{
    public partial class Splash : Form
    {
        public Splash()
        {
            InitializeComponent();

            label1.Text = "Outbreak version " + Outbreak2.O2version;
//            label2.Text = "Released " + Outbreak2.dateCompiled;
        }

        bool exiting = true; // indicates user hit 'x' to exit 
        private void button1_Click(object sender, EventArgs e) // New Project
        {
            exiting = false;
            ProjectFile = null;
            this.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.cbsg.org");
        }

        private void label7_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.czs.org");
        }

        private void label8_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.morrisanimalfoundation.org");
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.czs.org");
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.morrisanimalfoundation.org");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.cbsg.org");
        }

        private void Splash_Load(object sender, EventArgs e)
        {

        }

        private void Splash_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (exiting) Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public string ProjectFile = null;
        private void button4_Click(object sender, EventArgs e) // Recent Project
        {
            frmRecentProjects frmRecent = new frmRecentProjects();
            frmRecent.ShowDialog();
            ProjectFile = frmRecent.ProjectFile;
            exiting = false;
            if(ProjectFile != null && ProjectFile != "")
                this.Close();
        }

        private void button3_Click(object sender, EventArgs e) // Open Project
        {
            OpenFileDialog dlg = new OpenFileDialog();

            dlg.Filter = "Outbreak2 Project Files (*.xml)|*.xml|Outbreak1 OPF Files (*.opf)|*.opf|Outbreak1 OIS Files (*.ois)|*.ois|Infector Files (*.infect)|*.infect";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                ProjectFile = dlg.FileName;
                exiting = false;
                this.Close();
            }
        }

    }
}
