﻿namespace Outbreak2
{
    partial class Outbreak2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbInput = new System.Windows.Forms.TabControl();
            this.tabP = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMaxDaysP = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPropPermanentP = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMinDaysP = new System.Windows.Forms.TextBox();
            this.tabS = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtProbOutsideTransmission = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtProbOutsideEncounter = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtProbTransmission = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtPropPopEncounter = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtDistanceEncounterFunc = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtNEncounter = new System.Windows.Forms.TextBox();
            this.radioSpatialEncounter = new System.Windows.Forms.RadioButton();
            this.radioFixedNEncounter = new System.Windows.Forms.RadioButton();
            this.radioProportionEncounteredPerDay = new System.Windows.Forms.RadioButton();
            this.tabE = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtMaxDaysE = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtMinDaysE = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tabI = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtProbDeath = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtProbReSusceptible = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txtProbRecovery = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtMaxDaysI = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtMinDaysI = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtPropPermanentI = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tabR = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtMaxDaysR = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtMinDaysR = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtPropPermanentR = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.tabV = new System.Windows.Forms.TabPage();
            this.tabC = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsoisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsopfToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitWithoutSavingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noHelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbInput.SuspendLayout();
            this.tabP.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabS.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabE.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabI.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabR.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbInput
            // 
            this.tbInput.Controls.Add(this.tabP);
            this.tbInput.Controls.Add(this.tabS);
            this.tbInput.Controls.Add(this.tabE);
            this.tbInput.Controls.Add(this.tabI);
            this.tbInput.Controls.Add(this.tabR);
            this.tbInput.Controls.Add(this.tabV);
            this.tbInput.Controls.Add(this.tabC);
            this.tbInput.Controls.Add(this.tabPage1);
            this.tbInput.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbInput.Location = new System.Drawing.Point(0, 30);
            this.tbInput.Name = "tbInput";
            this.tbInput.SelectedIndex = 0;
            this.tbInput.Size = new System.Drawing.Size(807, 398);
            this.tbInput.TabIndex = 0;
            // 
            // tabP
            // 
            this.tabP.Controls.Add(this.groupBox5);
            this.tabP.Location = new System.Drawing.Point(4, 22);
            this.tabP.Name = "tabP";
            this.tabP.Padding = new System.Windows.Forms.Padding(3);
            this.tabP.Size = new System.Drawing.Size(799, 372);
            this.tabP.TabIndex = 0;
            this.tabP.Text = "P (pre-susceptible)";
            this.tabP.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.txtMaxDaysP);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.txtPropPermanentP);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.txtMinDaysP);
            this.groupBox5.Location = new System.Drawing.Point(22, 76);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(734, 108);
            this.groupBox5.TabIndex = 12;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Initial acquisition of susceptibility";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(505, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Probability from 0.0 to 1.0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(505, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Integer from 0 to maximum age";
            // 
            // txtMaxDaysP
            // 
            this.txtMaxDaysP.Location = new System.Drawing.Point(385, 77);
            this.txtMaxDaysP.Name = "txtMaxDaysP";
            this.txtMaxDaysP.Size = new System.Drawing.Size(100, 20);
            this.txtMaxDaysP.TabIndex = 2;
            this.txtMaxDaysP.Text = "1";
            this.txtMaxDaysP.Validating += new System.ComponentModel.CancelEventHandler(this.txtMaxDaysP_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "What proportion of individuals never become Susceptible?";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 80);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(337, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "What is the maximum days before an individual becomes Susceptible?";
            // 
            // txtPropPermanentP
            // 
            this.txtPropPermanentP.Location = new System.Drawing.Point(385, 20);
            this.txtPropPermanentP.Name = "txtPropPermanentP";
            this.txtPropPermanentP.Size = new System.Drawing.Size(100, 20);
            this.txtPropPermanentP.TabIndex = 0;
            this.txtPropPermanentP.Text = "0.0";
            this.txtPropPermanentP.Validating += new System.ComponentModel.CancelEventHandler(this.txtPropPermanentP_Validating);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(350, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "What is the minimum days before an individual can become Susceptible?";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(505, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Integer from 0 to maximum age";
            // 
            // txtMinDaysP
            // 
            this.txtMinDaysP.Location = new System.Drawing.Point(385, 49);
            this.txtMinDaysP.Name = "txtMinDaysP";
            this.txtMinDaysP.Size = new System.Drawing.Size(100, 20);
            this.txtMinDaysP.TabIndex = 1;
            this.txtMinDaysP.Text = "0";
            this.txtMinDaysP.Validating += new System.ComponentModel.CancelEventHandler(this.txtMinDaysP_Validating);
            // 
            // tabS
            // 
            this.tabS.Controls.Add(this.groupBox3);
            this.tabS.Controls.Add(this.groupBox2);
            this.tabS.Controls.Add(this.groupBox1);
            this.tabS.Location = new System.Drawing.Point(4, 22);
            this.tabS.Name = "tabS";
            this.tabS.Padding = new System.Windows.Forms.Padding(3);
            this.tabS.Size = new System.Drawing.Size(799, 372);
            this.tabS.TabIndex = 1;
            this.tabS.Text = "S (susceptible)";
            this.tabS.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.txtProbOutsideTransmission);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.txtProbOutsideEncounter);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(22, 290);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(760, 100);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Environmental sources";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(508, 59);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(126, 13);
            this.label12.TabIndex = 14;
            this.label12.Text = "Probability from 0.0 to 1.0";
            // 
            // txtProbOutsideTransmission
            // 
            this.txtProbOutsideTransmission.Location = new System.Drawing.Point(388, 56);
            this.txtProbOutsideTransmission.Name = "txtProbOutsideTransmission";
            this.txtProbOutsideTransmission.Size = new System.Drawing.Size(100, 20);
            this.txtProbOutsideTransmission.TabIndex = 8;
            this.txtProbOutsideTransmission.Text = "0.01";
            this.txtProbOutsideTransmission.Validating += new System.ComponentModel.CancelEventHandler(this.txtProbOutsideTransmission_Validating);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 59);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(372, 13);
            this.label13.TabIndex = 12;
            this.label13.Text = "When an environmental source is encountered, what is the transmission rate?";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(507, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(126, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "Probability from 0.0 to 1.0";
            // 
            // txtProbOutsideEncounter
            // 
            this.txtProbOutsideEncounter.Location = new System.Drawing.Point(387, 25);
            this.txtProbOutsideEncounter.Name = "txtProbOutsideEncounter";
            this.txtProbOutsideEncounter.Size = new System.Drawing.Size(100, 20);
            this.txtProbOutsideEncounter.TabIndex = 7;
            this.txtProbOutsideEncounter.Text = "0.01";
            this.txtProbOutsideEncounter.Validating += new System.ComponentModel.CancelEventHandler(this.txtProbOutsideEncounter_Validating);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 28);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(357, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "What is the average encounter rate per day with outside disease sources?";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txtProbTransmission);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(21, 220);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(760, 61);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Transmission rate";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(507, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(126, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "Probability from 0.0 to 1.0";
            // 
            // txtProbTransmission
            // 
            this.txtProbTransmission.Location = new System.Drawing.Point(387, 25);
            this.txtProbTransmission.Name = "txtProbTransmission";
            this.txtProbTransmission.Size = new System.Drawing.Size(100, 20);
            this.txtProbTransmission.TabIndex = 6;
            this.txtProbTransmission.Text = "0.01";
            this.txtProbTransmission.Validating += new System.ComponentModel.CancelEventHandler(this.txtProbTransmission_Validating);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 28);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(329, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "When an S encounters an I individual, what is the transmission rate?";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtPropPopEncounter);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.txtDistanceEncounterFunc);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.txtNEncounter);
            this.groupBox1.Controls.Add(this.radioSpatialEncounter);
            this.groupBox1.Controls.Add(this.radioFixedNEncounter);
            this.groupBox1.Controls.Add(this.radioProportionEncounteredPerDay);
            this.groupBox1.Location = new System.Drawing.Point(21, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(760, 193);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "How do you want to model encounter rate?";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(96, 44);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(320, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Proportion of the population that an I individual encounters per day";
            // 
            // txtPropPopEncounter
            // 
            this.txtPropPopEncounter.Location = new System.Drawing.Point(23, 41);
            this.txtPropPopEncounter.Name = "txtPropPopEncounter";
            this.txtPropPopEncounter.Size = new System.Drawing.Size(57, 20);
            this.txtPropPopEncounter.TabIndex = 3;
            this.txtPropPopEncounter.Text = "0.01";
            this.txtPropPopEncounter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPropPopEncounter.Validating += new System.ComponentModel.CancelEventHandler(this.txtPropPopEncounter_Validating);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(17, 153);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(48, 13);
            this.label23.TabIndex = 8;
            this.label23.Text = "Function";
            // 
            // txtDistanceEncounterFunc
            // 
            this.txtDistanceEncounterFunc.Enabled = false;
            this.txtDistanceEncounterFunc.Location = new System.Drawing.Point(86, 150);
            this.txtDistanceEncounterFunc.Name = "txtDistanceEncounterFunc";
            this.txtDistanceEncounterFunc.Size = new System.Drawing.Size(369, 20);
            this.txtDistanceEncounterFunc.TabIndex = 5;
            this.txtDistanceEncounterFunc.Text = "=0.10*(D<2)";
            this.txtDistanceEncounterFunc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDistanceEncounterFunc.Validating += new System.ComponentModel.CancelEventHandler(this.txtDistanceEncounterFunc_Validating);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(103, 100);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(291, 13);
            this.label22.TabIndex = 6;
            this.label22.Text = "Number of individuals that an I individual encounters per day";
            // 
            // txtNEncounter
            // 
            this.txtNEncounter.Enabled = false;
            this.txtNEncounter.Location = new System.Drawing.Point(24, 94);
            this.txtNEncounter.Name = "txtNEncounter";
            this.txtNEncounter.Size = new System.Drawing.Size(57, 20);
            this.txtNEncounter.TabIndex = 4;
            this.txtNEncounter.Text = "1";
            this.txtNEncounter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtNEncounter.Validating += new System.ComponentModel.CancelEventHandler(this.txtNEncounter_Validating);
            // 
            // radioSpatialEncounter
            // 
            this.radioSpatialEncounter.AutoSize = true;
            this.radioSpatialEncounter.Location = new System.Drawing.Point(6, 127);
            this.radioSpatialEncounter.Name = "radioSpatialEncounter";
            this.radioSpatialEncounter.Size = new System.Drawing.Size(195, 17);
            this.radioSpatialEncounter.TabIndex = 2;
            this.radioSpatialEncounter.Text = "A function of Euclidean distance (D)";
            this.radioSpatialEncounter.UseVisualStyleBackColor = true;
            this.radioSpatialEncounter.CheckedChanged += new System.EventHandler(this.radioSpatialEncounter_CheckedChanged);
            // 
            // radioFixedNEncounter
            // 
            this.radioFixedNEncounter.AutoSize = true;
            this.radioFixedNEncounter.Location = new System.Drawing.Point(6, 73);
            this.radioFixedNEncounter.Name = "radioFixedNEncounter";
            this.radioFixedNEncounter.Size = new System.Drawing.Size(260, 17);
            this.radioFixedNEncounter.TabIndex = 1;
            this.radioFixedNEncounter.Text = "A fixed number of individuals encountered per day";
            this.radioFixedNEncounter.UseVisualStyleBackColor = true;
            this.radioFixedNEncounter.CheckedChanged += new System.EventHandler(this.radioFixedNEncounter_CheckedChanged);
            // 
            // radioProportionEncounteredPerDay
            // 
            this.radioProportionEncounteredPerDay.AutoSize = true;
            this.radioProportionEncounteredPerDay.Checked = true;
            this.radioProportionEncounteredPerDay.Location = new System.Drawing.Point(6, 20);
            this.radioProportionEncounteredPerDay.Name = "radioProportionEncounteredPerDay";
            this.radioProportionEncounteredPerDay.Size = new System.Drawing.Size(265, 17);
            this.radioProportionEncounteredPerDay.TabIndex = 0;
            this.radioProportionEncounteredPerDay.Text = "A proportion of the population encountered per day";
            this.radioProportionEncounteredPerDay.UseVisualStyleBackColor = true;
            this.radioProportionEncounteredPerDay.CheckedChanged += new System.EventHandler(this.radioProportionEncounteredPerDay_CheckedChanged);
            // 
            // tabE
            // 
            this.tabE.Controls.Add(this.groupBox4);
            this.tabE.Location = new System.Drawing.Point(4, 22);
            this.tabE.Name = "tabE";
            this.tabE.Padding = new System.Windows.Forms.Padding(3);
            this.tabE.Size = new System.Drawing.Size(799, 372);
            this.tabE.TabIndex = 2;
            this.tabE.Text = "E (exposed and infected)";
            this.tabE.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.txtMaxDaysE);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.txtMinDaysE);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Location = new System.Drawing.Point(8, 24);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(760, 100);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Incubation period";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(508, 59);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(151, 13);
            this.label14.TabIndex = 14;
            this.label14.Text = "Integer from 0 to maximum age";
            // 
            // txtMaxDaysE
            // 
            this.txtMaxDaysE.Location = new System.Drawing.Point(388, 56);
            this.txtMaxDaysE.Name = "txtMaxDaysE";
            this.txtMaxDaysE.Size = new System.Drawing.Size(100, 20);
            this.txtMaxDaysE.TabIndex = 10;
            this.txtMaxDaysE.Text = "4";
            this.txtMaxDaysE.Validating += new System.ComponentModel.CancelEventHandler(this.txtMaxDaysE_Validating);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 59);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(331, 13);
            this.label15.TabIndex = 12;
            this.label15.Text = "What is the maximum incubation period (latency) of infection in days?";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(507, 28);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(151, 13);
            this.label16.TabIndex = 11;
            this.label16.Text = "Integer from 0 to maximum age";
            // 
            // txtMinDaysE
            // 
            this.txtMinDaysE.Location = new System.Drawing.Point(387, 25);
            this.txtMinDaysE.Name = "txtMinDaysE";
            this.txtMinDaysE.Size = new System.Drawing.Size(100, 20);
            this.txtMinDaysE.TabIndex = 9;
            this.txtMinDaysE.Text = "2";
            this.txtMinDaysE.Validating += new System.ComponentModel.CancelEventHandler(this.txtMinDaysE_Validating);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(13, 28);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(328, 13);
            this.label17.TabIndex = 9;
            this.label17.Text = "What is the minimum incubation period (latency) of infection in days?";
            // 
            // tabI
            // 
            this.tabI.Controls.Add(this.groupBox8);
            this.tabI.Controls.Add(this.groupBox7);
            this.tabI.Controls.Add(this.groupBox6);
            this.tabI.Location = new System.Drawing.Point(4, 22);
            this.tabI.Name = "tabI";
            this.tabI.Padding = new System.Windows.Forms.Padding(3);
            this.tabI.Size = new System.Drawing.Size(799, 372);
            this.tabI.TabIndex = 3;
            this.tabI.Text = "I (infectious)";
            this.tabI.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label30);
            this.groupBox8.Controls.Add(this.txtProbDeath);
            this.groupBox8.Controls.Add(this.label31);
            this.groupBox8.Controls.Add(this.label26);
            this.groupBox8.Controls.Add(this.txtProbReSusceptible);
            this.groupBox8.Controls.Add(this.label27);
            this.groupBox8.Controls.Add(this.label28);
            this.groupBox8.Controls.Add(this.txtProbRecovery);
            this.groupBox8.Controls.Add(this.label29);
            this.groupBox8.Location = new System.Drawing.Point(13, 235);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(760, 120);
            this.groupBox8.TabIndex = 8;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Disease outcome";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(508, 92);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(121, 13);
            this.label30.TabIndex = 17;
            this.label30.Text = "Calculated automatically";
            // 
            // txtProbDeath
            // 
            this.txtProbDeath.Enabled = false;
            this.txtProbDeath.Location = new System.Drawing.Point(388, 89);
            this.txtProbDeath.Name = "txtProbDeath";
            this.txtProbDeath.Size = new System.Drawing.Size(100, 20);
            this.txtProbDeath.TabIndex = 16;
            this.txtProbDeath.TabStop = false;
            this.txtProbDeath.Text = "0.25";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(14, 92);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(241, 13);
            this.label31.TabIndex = 15;
            this.label31.Text = "What is the probability of dying from the infection?";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(508, 59);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(126, 13);
            this.label26.TabIndex = 14;
            this.label26.Text = "Probability from 0.0 to 1.0";
            // 
            // txtProbReSusceptible
            // 
            this.txtProbReSusceptible.Location = new System.Drawing.Point(388, 56);
            this.txtProbReSusceptible.Name = "txtProbReSusceptible";
            this.txtProbReSusceptible.Size = new System.Drawing.Size(100, 20);
            this.txtProbReSusceptible.TabIndex = 15;
            this.txtProbReSusceptible.Text = "0.50";
            this.txtProbReSusceptible.Validating += new System.ComponentModel.CancelEventHandler(this.txtProbReSusceptible_Validating);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(14, 59);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(256, 13);
            this.label27.TabIndex = 12;
            this.label27.Text = "What is the probabilty of returning to be Susceptible?";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(507, 28);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(126, 13);
            this.label28.TabIndex = 11;
            this.label28.Text = "Probability from 0.0 to 1.0";
            // 
            // txtProbRecovery
            // 
            this.txtProbRecovery.Location = new System.Drawing.Point(387, 25);
            this.txtProbRecovery.Name = "txtProbRecovery";
            this.txtProbRecovery.Size = new System.Drawing.Size(100, 20);
            this.txtProbRecovery.TabIndex = 14;
            this.txtProbRecovery.Text = "0.25";
            this.txtProbRecovery.Validating += new System.ComponentModel.CancelEventHandler(this.txtProbRecovery_Validating);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(13, 28);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(297, 13);
            this.label29.TabIndex = 9;
            this.label29.Text = "What is the probabilty of recovering and becoming Resistant?";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label20);
            this.groupBox7.Controls.Add(this.txtMaxDaysI);
            this.groupBox7.Controls.Add(this.label21);
            this.groupBox7.Controls.Add(this.label24);
            this.groupBox7.Controls.Add(this.txtMinDaysI);
            this.groupBox7.Controls.Add(this.label25);
            this.groupBox7.Location = new System.Drawing.Point(13, 115);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(760, 100);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Infectious period";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(508, 59);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(151, 13);
            this.label20.TabIndex = 14;
            this.label20.Text = "Integer from 0 to maximum age";
            // 
            // txtMaxDaysI
            // 
            this.txtMaxDaysI.Location = new System.Drawing.Point(388, 56);
            this.txtMaxDaysI.Name = "txtMaxDaysI";
            this.txtMaxDaysI.Size = new System.Drawing.Size(100, 20);
            this.txtMaxDaysI.TabIndex = 13;
            this.txtMaxDaysI.Text = "10";
            this.txtMaxDaysI.Validating += new System.ComponentModel.CancelEventHandler(this.txtMaxDaysI_Validating);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(14, 59);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(293, 13);
            this.label21.TabIndex = 12;
            this.label21.Text = "What is the maximum days an I individual remains infectious?";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(507, 28);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(151, 13);
            this.label24.TabIndex = 11;
            this.label24.Text = "Integer from 0 to maximum age";
            // 
            // txtMinDaysI
            // 
            this.txtMinDaysI.Location = new System.Drawing.Point(387, 25);
            this.txtMinDaysI.Name = "txtMinDaysI";
            this.txtMinDaysI.Size = new System.Drawing.Size(100, 20);
            this.txtMinDaysI.TabIndex = 12;
            this.txtMinDaysI.Text = "5";
            this.txtMinDaysI.Validating += new System.ComponentModel.CancelEventHandler(this.txtMinDaysI_Validating);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(13, 28);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(290, 13);
            this.label25.TabIndex = 9;
            this.label25.Text = "What is the minimum days an I individual remains infectious?";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.txtPropPermanentI);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Location = new System.Drawing.Point(13, 27);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(760, 61);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Permanent infections";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(507, 28);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(126, 13);
            this.label18.TabIndex = 11;
            this.label18.Text = "Probability from 0.0 to 1.0";
            // 
            // txtPropPermanentI
            // 
            this.txtPropPermanentI.Location = new System.Drawing.Point(387, 25);
            this.txtPropPermanentI.Name = "txtPropPermanentI";
            this.txtPropPermanentI.Size = new System.Drawing.Size(100, 20);
            this.txtPropPermanentI.TabIndex = 11;
            this.txtPropPermanentI.Text = "0.0";
            this.txtPropPermanentI.Validating += new System.ComponentModel.CancelEventHandler(this.txtPropPermanentI_Validating);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(13, 28);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(293, 13);
            this.label19.TabIndex = 9;
            this.label19.Text = "What proportion of I individuals remain infectious indefinitely?";
            // 
            // tabR
            // 
            this.tabR.Controls.Add(this.groupBox9);
            this.tabR.Controls.Add(this.groupBox10);
            this.tabR.Location = new System.Drawing.Point(4, 22);
            this.tabR.Name = "tabR";
            this.tabR.Padding = new System.Windows.Forms.Padding(3);
            this.tabR.Size = new System.Drawing.Size(799, 372);
            this.tabR.TabIndex = 4;
            this.tabR.Text = "R (recovered and resistant)";
            this.tabR.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label32);
            this.groupBox9.Controls.Add(this.txtMaxDaysR);
            this.groupBox9.Controls.Add(this.label33);
            this.groupBox9.Controls.Add(this.label34);
            this.groupBox9.Controls.Add(this.txtMinDaysR);
            this.groupBox9.Controls.Add(this.label35);
            this.groupBox9.Location = new System.Drawing.Point(13, 123);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(760, 100);
            this.groupBox9.TabIndex = 9;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Duration of resistance  for those without permanent immunity";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(508, 59);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(151, 13);
            this.label32.TabIndex = 14;
            this.label32.Text = "Integer from 0 to maximum age";
            // 
            // txtMaxDaysR
            // 
            this.txtMaxDaysR.Location = new System.Drawing.Point(388, 56);
            this.txtMaxDaysR.Name = "txtMaxDaysR";
            this.txtMaxDaysR.Size = new System.Drawing.Size(100, 20);
            this.txtMaxDaysR.TabIndex = 19;
            this.txtMaxDaysR.Text = "50";
            this.txtMaxDaysR.Validating += new System.ComponentModel.CancelEventHandler(this.txtMaxDaysR_Validating);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(14, 59);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(274, 13);
            this.label33.TabIndex = 12;
            this.label33.Text = "What is the maximum days an R individual has immunity?";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(507, 28);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(151, 13);
            this.label34.TabIndex = 11;
            this.label34.Text = "Integer from 0 to maximum age";
            // 
            // txtMinDaysR
            // 
            this.txtMinDaysR.Location = new System.Drawing.Point(387, 25);
            this.txtMinDaysR.Name = "txtMinDaysR";
            this.txtMinDaysR.Size = new System.Drawing.Size(100, 20);
            this.txtMinDaysR.TabIndex = 18;
            this.txtMinDaysR.Text = "10";
            this.txtMinDaysR.Validating += new System.ComponentModel.CancelEventHandler(this.txtMinDaysR_Validating);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(13, 28);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(286, 13);
            this.label35.TabIndex = 9;
            this.label35.Text = "What is the minimum days an R individual remains immune?";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label36);
            this.groupBox10.Controls.Add(this.txtPropPermanentR);
            this.groupBox10.Controls.Add(this.label37);
            this.groupBox10.Location = new System.Drawing.Point(13, 35);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(760, 61);
            this.groupBox10.TabIndex = 8;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Permanent resistance";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(507, 28);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(126, 13);
            this.label36.TabIndex = 11;
            this.label36.Text = "Probability from 0.0 to 1.0";
            // 
            // txtPropPermanentR
            // 
            this.txtPropPermanentR.Location = new System.Drawing.Point(387, 25);
            this.txtPropPermanentR.Name = "txtPropPermanentR";
            this.txtPropPermanentR.Size = new System.Drawing.Size(100, 20);
            this.txtPropPermanentR.TabIndex = 17;
            this.txtPropPermanentR.Text = "0.1";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(13, 28);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(298, 13);
            this.label37.TabIndex = 9;
            this.label37.Text = "What proportion of R individuals acquire permanent immunity?";
            // 
            // tabV
            // 
            this.tabV.Location = new System.Drawing.Point(4, 22);
            this.tabV.Name = "tabV";
            this.tabV.Padding = new System.Windows.Forms.Padding(3);
            this.tabV.Size = new System.Drawing.Size(799, 372);
            this.tabV.TabIndex = 5;
            this.tabV.Text = "Vaccination";
            this.tabV.UseVisualStyleBackColor = true;
            // 
            // tabC
            // 
            this.tabC.Location = new System.Drawing.Point(4, 22);
            this.tabC.Name = "tabC";
            this.tabC.Padding = new System.Windows.Forms.Padding(3);
            this.tabC.Size = new System.Drawing.Size(799, 372);
            this.tabC.TabIndex = 6;
            this.tabC.Text = "Culling";
            this.tabC.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(799, 372);
            this.tabPage1.TabIndex = 7;
            this.tabPage1.Text = "Demography";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 24);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(807, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.runToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(807, 24);
            this.menuStrip2.TabIndex = 2;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.saveAsoisToolStripMenuItem,
            this.saveAsopfToolStripMenuItem,
            this.loadToolStripMenuItem,
            this.exitWithoutSavingToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // saveAsoisToolStripMenuItem
            // 
            this.saveAsoisToolStripMenuItem.Name = "saveAsoisToolStripMenuItem";
            this.saveAsoisToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.saveAsoisToolStripMenuItem.Text = "Save as .ois";
            // 
            // saveAsopfToolStripMenuItem
            // 
            this.saveAsopfToolStripMenuItem.Name = "saveAsopfToolStripMenuItem";
            this.saveAsopfToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.saveAsopfToolStripMenuItem.Text = "Save as .opf";
            // 
            // exitWithoutSavingToolStripMenuItem
            // 
            this.exitWithoutSavingToolStripMenuItem.Name = "exitWithoutSavingToolStripMenuItem";
            this.exitWithoutSavingToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.exitWithoutSavingToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitWithoutSavingToolStripMenuItem.Text = "Quit";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.noHelpToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // noHelpToolStripMenuItem
            // 
            this.noHelpToolStripMenuItem.Name = "noHelpToolStripMenuItem";
            this.noHelpToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.noHelpToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.noHelpToolStripMenuItem.Text = "No Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // runToolStripMenuItem
            // 
            this.runToolStripMenuItem.Name = "runToolStripMenuItem";
            this.runToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.runToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.runToolStripMenuItem.Text = "Run";
            this.runToolStripMenuItem.Click += new System.EventHandler(this.runToolStripMenuItem_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.saveAsToolStripMenuItem.Text = "SaveAs";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.loadToolStripMenuItem.Text = "Load";
            // 
            // Outbreak2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(807, 428);
            this.Controls.Add(this.tbInput);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Outbreak2";
            this.Text = "Outbreak2";
            this.tbInput.ResumeLayout(false);
            this.tabP.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabS.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabE.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabI.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabR.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tbInput;
        private System.Windows.Forms.TabPage tabP;
        private System.Windows.Forms.TabPage tabS;
        private System.Windows.Forms.TabPage tabE;
        private System.Windows.Forms.TabPage tabI;
        private System.Windows.Forms.TabPage tabR;
        private System.Windows.Forms.TabPage tabV;
        private System.Windows.Forms.TabPage tabC;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPropPermanentP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMaxDaysP;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMinDaysP;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtProbOutsideTransmission;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtProbOutsideEncounter;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtProbTransmission;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtPropPopEncounter;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtDistanceEncounterFunc;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtNEncounter;
        private System.Windows.Forms.RadioButton radioSpatialEncounter;
        private System.Windows.Forms.RadioButton radioFixedNEncounter;
        private System.Windows.Forms.RadioButton radioProportionEncounteredPerDay;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtMaxDaysE;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtMinDaysE;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtProbDeath;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtProbReSusceptible;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtProbRecovery;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtMaxDaysI;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtMinDaysI;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtPropPermanentI;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtMaxDaysR;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtMinDaysR;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtPropPermanentR;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsoisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsopfToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitWithoutSavingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem noHelpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
    }
}

