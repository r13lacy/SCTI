﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Text;
using SCTI;

namespace Outbreak2
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            System.Environment.GetEnvironmentVariables();
            string v = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();

            v = v.Substring(0, v.LastIndexOf("."));
            v = v.Substring(0, v.LastIndexOf("."));

            DateTime tdate = File.GetLastWriteTime(Application.ExecutablePath);
            string exedate = tdate.ToString("yyyyMMdd");

            Outbreak2.O2version = v + "." + exedate; // DateCompiled().ToString("yyyyMMdd");
            //            Outbreak2.dateCompiled = DateCompiled().ToString("yyyyMMdd");
            Outbreak2.userDataFile = Application.LocalUserAppDataPath.Substring(0, Application.LocalUserAppDataPath.LastIndexOf("\\")) + "\\recent.txt";

            bool quietO = false;
            if (args.Length > 0)
            {
                for (int sc = 0; sc < args.Length; sc++)
                {
                    if (args[sc].ToLower().StartsWith("quiet"))
                    {
                        quietO = true;
                        continue;
                    }
                    string ofile = args[sc];
                    Outbreak2 OP = new Outbreak2(ofile, true);
                    for (int i = 0; i < OP.nscenes; i++)
                        OP.Oscenes[i].runO();
                }
                if(!quietO) MessageBox.Show("Outbreak simulations completed.");
            }

            else // use GUI
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                OutbreakHelp.FindReader();

                // use version.txt as a way to see if it is time to show Acknowledgements again
                // vfile won't exist just after upgrade to new version
                try
                {
                    string vfile = Application.LocalUserAppDataPath + "\\version.txt";
                    if (!File.Exists(vfile)) // || File.GetLastWriteTime(vfile) < DateTime.Today.AddDays(-90.0))
                    {
//                        frmAcknowledgements frm = new frmAcknowledgements();
                        frmSCTI2 frm = new frmSCTI2(true);
                        frm.ShowDialog();

                        StreamWriter writer = new StreamWriter(vfile, false);
                        writer.WriteLine(v);
                        writer.Close();
                    }
                    else
                    {
                        int daysSinceOpen = (int)((DateTime.Today - File.GetLastAccessTime(vfile)).TotalDays); // 28 June 2017
                        if (daysSinceOpen > 30)
                        {
                            checkUpdates(false);

                            //                            frmAcknowledgements frmA = new frmAcknowledgements();
                            frmSCTI2 frmA = new frmSCTI2(false);
                            frmA.ShowDialog();
                            File.SetLastAccessTime(vfile, DateTime.Now);
                        }
                    }
                }
                catch
                {
                    MessageBox.Show("Error when trying to access the version.txt file.");
                }

                try
                {
                    Splash frmSplash = new Splash();
                    frmSplash.ShowDialog();

                    try
                    {
                        Application.Run(new frmOutbreak2(frmSplash.ProjectFile));
                    }
                    catch
                    {
                        MessageBox.Show("Error when running Outbreak GUI");
                    }
                }
                catch
                {
                    MessageBox.Show("Error when showing opening screen.");
                }

            }
        }


        // 17 Nov 2017
        public static bool checkUpdates(bool menu)
        {
            try
            {
                WebClient ftpRequest = new WebClient();
                ftpRequest.Credentials = new NetworkCredential("vortex10@vortex10.org", "vor10tex");
                byte[] buf = ftpRequest.DownloadData("ftp://ftp.vortex10.org/OutbreakVersion.txt");

                string v = Encoding.ASCII.GetString(buf, 0, buf.Length);

                ftpRequest.Dispose();

                string[] sUpdate = v.Split('.');
                string[] sCurrent = Outbreak2.O2version.Split('.');   // Application.ProductVersion.Split('.');

                if ((Convert.ToInt32(sUpdate[0]) > Convert.ToInt32(sCurrent[0]))
                    || (Convert.ToInt32(sUpdate[1]) > Convert.ToInt32(sCurrent[1]))
                    || (Convert.ToInt32(sUpdate[2]) > Convert.ToInt32(sCurrent[2])))
                {
                    MessageBox.Show("A newer version of Outbreak is available at www.vortex10.org/Outbreak.aspx !", "Outbreak update check");
                    return true;
                }
            }
            catch
            {
                if(menu) MessageBox.Show("Unable to connect to the web server to check for updates.");
                return false; 
            }

            if(menu) MessageBox.Show("You are using the most current version of Outbreak. Thank you for checking.", "Outbreak update check");

            return false;
        }


        //    private static DateTime DateCompiled()

        //// Assumes that in AssemblyInfo.cs,
        //    // the version is specified as 1.0.* or the like,
        //    // with only 2 numbers specified;
        //    // the next two are generated from the date.
        //    // This routine decodes them.
        //    {
        //        try
        //        {
        //            System.Version v =
        //            System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;

        //            // v.Build is days since Jan. 1, 2000
        //            // v.Revision is seconds since local midnight
        //            // (NEVER daylight saving time)

        //            //DateTime t = new DateTime(
        //            //v.Build * TimeSpan.TicksPerDay +
        //            //v.Revision * TimeSpan.TicksPerSecond
        //            //).AddYears(1999);

        //            DateTime t = new DateTime(
        //            v.Build * TimeSpan.TicksPerDay
        //            ).AddYears(1999);

        //            return t;
        //        }
        //        catch
        //        {
        //            MessageBox.Show("Error in attempt to get version info.");
        //            return new DateTime();
        //        }
        //    }

    }

}
