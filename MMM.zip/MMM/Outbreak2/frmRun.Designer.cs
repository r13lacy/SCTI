﻿namespace Outbreak2
{
    partial class frmRun
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRun));
            this.txtRunIter = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRunYears = new System.Windows.Forms.TextBox();
            this.btnRun = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkOutDaily = new System.Windows.Forms.CheckBox();
            this.chkOutIndividuals = new System.Windows.Forms.CheckBox();
            this.chkOutMM = new System.Windows.Forms.CheckBox();
            this.chkOutIndList = new System.Windows.Forms.CheckBox();
            this.chkOutEpiRates = new System.Windows.Forms.CheckBox();
            this.chkOutYearly = new System.Windows.Forms.CheckBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.label5 = new System.Windows.Forms.Label();
            this.btnResults = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chartSpatialDisplay = new C1.Win.C1Chart.C1Chart();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSpatialDisplayDays = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.cboScenes = new System.Windows.Forms.ComboBox();
            this.chkRunNoDz = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartSpatialDisplay)).BeginInit();
            this.SuspendLayout();
            // 
            // txtRunIter
            // 
            this.txtRunIter.Location = new System.Drawing.Point(264, 53);
            this.txtRunIter.Margin = new System.Windows.Forms.Padding(4);
            this.txtRunIter.Name = "txtRunIter";
            this.txtRunIter.Size = new System.Drawing.Size(84, 22);
            this.txtRunIter.TabIndex = 1;
            this.txtRunIter.Text = "10";
            this.txtRunIter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRunIter.Validating += new System.ComponentModel.CancelEventHandler(this.txtRunIter_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 56);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Number of iterations to repeat";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 81);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(193, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Number of years per iteration";
            // 
            // txtRunYears
            // 
            this.txtRunYears.Location = new System.Drawing.Point(264, 82);
            this.txtRunYears.Margin = new System.Windows.Forms.Padding(4);
            this.txtRunYears.Name = "txtRunYears";
            this.txtRunYears.Size = new System.Drawing.Size(84, 22);
            this.txtRunYears.TabIndex = 2;
            this.txtRunYears.Text = "10";
            this.txtRunYears.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRunYears.Validating += new System.ComponentModel.CancelEventHandler(this.txtRunYears_Validating);
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(67, 418);
            this.btnRun.Margin = new System.Windows.Forms.Padding(4);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(169, 59);
            this.btnRun.TabIndex = 10;
            this.btnRun.Text = "Run!";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(107, 526);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(273, 29);
            this.label4.TabIndex = 10;
            this.label4.Text = "Simulation completed!";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkOutDaily);
            this.groupBox1.Controls.Add(this.chkOutIndividuals);
            this.groupBox1.Controls.Add(this.chkOutMM);
            this.groupBox1.Controls.Add(this.chkOutIndList);
            this.groupBox1.Controls.Add(this.chkOutEpiRates);
            this.groupBox1.Controls.Add(this.chkOutYearly);
            this.groupBox1.Location = new System.Drawing.Point(40, 168);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(378, 240);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Which formats of optional output do you want?";
            // 
            // chkOutDaily
            // 
            this.chkOutDaily.AutoSize = true;
            this.chkOutDaily.Checked = true;
            this.chkOutDaily.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkOutDaily.Location = new System.Drawing.Point(31, 73);
            this.chkOutDaily.Margin = new System.Windows.Forms.Padding(4);
            this.chkOutDaily.Name = "chkOutDaily";
            this.chkOutDaily.Size = new System.Drawing.Size(153, 21);
            this.chkOutDaily.TabIndex = 5;
            this.chkOutDaily.Text = "Daily Summary files";
            this.chkOutDaily.UseVisualStyleBackColor = true;
            this.chkOutDaily.CheckedChanged += new System.EventHandler(this.chkOutDaily_CheckedChanged);
            // 
            // chkOutIndividuals
            // 
            this.chkOutIndividuals.AutoSize = true;
            this.chkOutIndividuals.Location = new System.Drawing.Point(31, 167);
            this.chkOutIndividuals.Margin = new System.Windows.Forms.Padding(4);
            this.chkOutIndividuals.Name = "chkOutIndividuals";
            this.chkOutIndividuals.Size = new System.Drawing.Size(184, 21);
            this.chkOutIndividuals.TabIndex = 8;
            this.chkOutIndividuals.Text = "Complete Individual data";
            this.chkOutIndividuals.UseVisualStyleBackColor = true;
            this.chkOutIndividuals.Visible = false;
            this.chkOutIndividuals.CheckedChanged += new System.EventHandler(this.chkOutIndividuals_CheckedChanged);
            // 
            // chkOutMM
            // 
            this.chkOutMM.AutoSize = true;
            this.chkOutMM.Location = new System.Drawing.Point(31, 203);
            this.chkOutMM.Margin = new System.Windows.Forms.Padding(4);
            this.chkOutMM.Name = "chkOutMM";
            this.chkOutMM.Size = new System.Drawing.Size(271, 21);
            this.chkOutMM.TabIndex = 9;
            this.chkOutMM.Text = "File listing all MM PS and GS variables";
            this.chkOutMM.UseVisualStyleBackColor = true;
            this.chkOutMM.Visible = false;
            this.chkOutMM.CheckedChanged += new System.EventHandler(this.chkOutMM_CheckedChanged);
            // 
            // chkOutIndList
            // 
            this.chkOutIndList.AutoSize = true;
            this.chkOutIndList.Location = new System.Drawing.Point(31, 134);
            this.chkOutIndList.Margin = new System.Windows.Forms.Padding(4);
            this.chkOutIndList.Name = "chkOutIndList";
            this.chkOutIndList.Size = new System.Drawing.Size(139, 21);
            this.chkOutIndList.TabIndex = 7;
            this.chkOutIndList.Text = "Individual list files";
            this.chkOutIndList.UseVisualStyleBackColor = true;
            this.chkOutIndList.CheckedChanged += new System.EventHandler(this.chkOutIndList_CheckedChanged);
            // 
            // chkOutEpiRates
            // 
            this.chkOutEpiRates.AutoSize = true;
            this.chkOutEpiRates.Location = new System.Drawing.Point(31, 103);
            this.chkOutEpiRates.Margin = new System.Windows.Forms.Padding(4);
            this.chkOutEpiRates.Name = "chkOutEpiRates";
            this.chkOutEpiRates.Size = new System.Drawing.Size(148, 21);
            this.chkOutEpiRates.TabIndex = 6;
            this.chkOutEpiRates.Text = "Raw Daily Data file";
            this.chkOutEpiRates.UseVisualStyleBackColor = true;
            this.chkOutEpiRates.CheckedChanged += new System.EventHandler(this.chkOutEpiRates_CheckedChanged);
            // 
            // chkOutYearly
            // 
            this.chkOutYearly.AutoSize = true;
            this.chkOutYearly.Checked = true;
            this.chkOutYearly.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkOutYearly.Location = new System.Drawing.Point(31, 42);
            this.chkOutYearly.Margin = new System.Windows.Forms.Padding(4);
            this.chkOutYearly.Name = "chkOutYearly";
            this.chkOutYearly.Size = new System.Drawing.Size(162, 21);
            this.chkOutYearly.TabIndex = 4;
            this.chkOutYearly.Text = "Yearly Summary files";
            this.chkOutYearly.UseVisualStyleBackColor = true;
            this.chkOutYearly.CheckedChanged += new System.EventHandler(this.chkOutYearly_CheckedChanged);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(160, 485);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(4);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(287, 28);
            this.progressBar1.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 491);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 17);
            this.label5.TabIndex = 13;
            this.label5.Text = "Simulation progress:";
            // 
            // btnResults
            // 
            this.btnResults.Location = new System.Drawing.Point(249, 418);
            this.btnResults.Margin = new System.Windows.Forms.Padding(4);
            this.btnResults.Name = "btnResults";
            this.btnResults.Size = new System.Drawing.Size(169, 59);
            this.btnResults.TabIndex = 11;
            this.btnResults.Text = "Show Results";
            this.btnResults.UseVisualStyleBackColor = true;
            this.btnResults.Click += new System.EventHandler(this.btnResults_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chartSpatialDisplay);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtSpatialDisplayDays);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox2.Location = new System.Drawing.Point(451, 0);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(807, 583);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Spatial display";
            // 
            // chartSpatialDisplay
            // 
            this.chartSpatialDisplay.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.chartSpatialDisplay.Location = new System.Drawing.Point(4, 94);
            this.chartSpatialDisplay.Margin = new System.Windows.Forms.Padding(4);
            this.chartSpatialDisplay.Name = "chartSpatialDisplay";
            this.chartSpatialDisplay.PropBag = resources.GetString("chartSpatialDisplay.PropBag");
            this.chartSpatialDisplay.Size = new System.Drawing.Size(799, 485);
            this.chartSpatialDisplay.TabIndex = 8;
            this.chartSpatialDisplay.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(188, 43);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(224, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "Enter 0 days below to disable plot.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(45, 21);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(723, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Caution: plots can take a lot of computer time, and can freeze up if the display " +
    "cannot keep up with the simulation.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 68);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(308, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Interval in days between plot updates (1 to 365)";
            // 
            // txtSpatialDisplayDays
            // 
            this.txtSpatialDisplayDays.Location = new System.Drawing.Point(328, 63);
            this.txtSpatialDisplayDays.Margin = new System.Windows.Forms.Padding(4);
            this.txtSpatialDisplayDays.Name = "txtSpatialDisplayDays";
            this.txtSpatialDisplayDays.Size = new System.Drawing.Size(84, 22);
            this.txtSpatialDisplayDays.TabIndex = 12;
            this.txtSpatialDisplayDays.Text = "0";
            this.txtSpatialDisplayDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(24, 21);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(68, 17);
            this.label35.TabIndex = 35;
            this.label35.Tag = "Pick the scenario that you want to run.";
            this.label35.Text = "Scenario:";
            // 
            // cboScenes
            // 
            this.cboScenes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboScenes.FormattingEnabled = true;
            this.cboScenes.Location = new System.Drawing.Point(100, 14);
            this.cboScenes.Margin = new System.Windows.Forms.Padding(4);
            this.cboScenes.Name = "cboScenes";
            this.cboScenes.Size = new System.Drawing.Size(315, 24);
            this.cboScenes.TabIndex = 0;
            this.cboScenes.Tag = "Changing the scenario here does not also change which Scenario is being edited on" +
    " the input tabs.";
            this.cboScenes.SelectedIndexChanged += new System.EventHandler(this.cboScenes_SelectedIndexChanged);
            // 
            // chkRunNoDz
            // 
            this.chkRunNoDz.AutoSize = true;
            this.chkRunNoDz.Location = new System.Drawing.Point(40, 125);
            this.chkRunNoDz.Margin = new System.Windows.Forms.Padding(4);
            this.chkRunNoDz.Name = "chkRunNoDz";
            this.chkRunNoDz.Size = new System.Drawing.Size(224, 21);
            this.chkRunNoDz.TabIndex = 3;
            this.chkRunNoDz.Tag = "It is often useful to first run your model with no disease, just to confirm if th" +
    "e demography allows the population to thrive in the absence of disease.";
            this.chkRunNoDz.Text = "Run simulation with no disease";
            this.chkRunNoDz.UseVisualStyleBackColor = true;
            this.chkRunNoDz.CheckedChanged += new System.EventHandler(this.chkRunNoDz_CheckedChanged);
            // 
            // frmRun
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1258, 583);
            this.Controls.Add(this.chkRunNoDz);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.cboScenes);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnResults);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtRunYears);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtRunIter);
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmRun";
            this.Text = "Run Outbreak simulation";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmRun_KeyUp);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartSpatialDisplay)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtRunIter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtRunYears;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkOutIndividuals;
        private System.Windows.Forms.CheckBox chkOutMM;
        private System.Windows.Forms.CheckBox chkOutIndList;
        private System.Windows.Forms.CheckBox chkOutEpiRates;
        private System.Windows.Forms.CheckBox chkOutYearly;
        private System.Windows.Forms.CheckBox chkOutDaily;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnResults;
        private System.Windows.Forms.GroupBox groupBox2;
        private C1.Win.C1Chart.C1Chart chartSpatialDisplay;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSpatialDisplayDays;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox cboScenes;
        private System.Windows.Forms.CheckBox chkRunNoDz;
    }
}