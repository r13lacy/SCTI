﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using SCTI;

namespace Outbreak2
{
    public partial class frmOutbreak2 : Form
    {

        private Outbreak2 OP = new Outbreak2(null, true);
        private OScenario mOS;

        public frmOutbreak2(string ofile)
        {
            InitializeComponent();

            if (ofile != null)
            {
                settingUp = true;
                if (!OP.readOfile(ofile))
                {
                    MessageBox.Show("Error reading :" + ofile);
                    return;
                }
            }

            mOS = OP.Oscenes[0];

            setUpInputTabs();

            settingUp = true;
            fgInitStates[1, 0] = "Juveniles";
            fgInitStates[2, 0] = "Subadults";
            fgInitStates[3, 0] = "Adult Males";
            fgInitStates[4, 0] = "Adult Females";

            fgLifeTable[1, 0] = "Annual Mortality:";
            if (mOS.enterStageMort) fgLifeTable[1, 0] = "Mortality:";

            fgLifeTable[2, 0] = "Juveniles";
            fgLifeTable[3, 0] = "Subadults";
            fgLifeTable[4, 0] = "Adult Males";
            fgLifeTable[5, 0] = "Adult Females";

            fgLifeTable[6, 0] = "Annual Fecundity:";
            fgLifeTable[7, 0] = "Prop. Breeding";
            fgLifeTable[8, 0] = "# Broods / year";
            fgLifeTable[9, 0] = "Brood size";

            fgLifeTable[10, 0] = "Det. lambda (approx.)";

            for (int i = 0; i < 4; i++)
            {
                fgLifeTable[10, i + 1] = mOS.lambda1[i].ToString("0.000");
            }
            fgLifeTable.Rows[1].AllowEditing = false;
            fgLifeTable.Rows[6].AllowEditing = false;
            fgLifeTable.Rows[10].AllowEditing = false;

            fgLifeTable.Rows[1].Style = fgLifeTable.Rows[1].StyleFixedDisplay;
            fgLifeTable.Rows[6].Style = fgLifeTable.Rows[6].StyleFixedDisplay;
            fgLifeTable.Rows[10].Style = fgLifeTable.Rows[10].StyleFixedDisplay;
            ////fgLifeTable.SetCellStyle(1, 0, "Subtotal0");
            //fgLifeTable.SetCellStyle(6, 0, "Subtotal0");
            //fgLifeTable.SetCellStyle(10, 0, "Subtotal0");

            List<string> f = frmRecentProjects.UpdateFileList(OP.OName, ofile);

            openRecentToolStripMenuItem.DropDownItems.Clear();
            for (int i = 0; i < f.Count; i++)
                openRecentToolStripMenuItem.DropDownItems.Add(f[i], null, openRecentToolStripMenuItem_Click);

            //load tooltips
            O2Utils.CreateToolTipsFromTagsForForm(this);

            settingUp = false;
        }


        // later change to return an object, so can test for functions
        private double validateProb(string stext)
        {
            double d = -1;

            if (stext[0] == '=') return d;  // later process func

            try
            {
                d = Convert.ToDouble(stext);
                if (d < 0.0 || d > 1.0)
                {
                    MessageBox.Show("Please enter a value between 0 and 1.");
                    d = -1.0;
                }
            }
            catch
            {
                MessageBox.Show("Please enter a value between 0 and 1.");
            }

            return d;
        }

        private bool testProb(string stext)
        {
            try
            {
                double d = Convert.ToDouble(stext);
                if (d < 0.0 || d > 1.0)
                {
                    MessageBox.Show("Please enter a value between 0 and 1.");
                    return false;
                }
            }
            catch
            {
                MessageBox.Show("Please enter a value between 0 and 1.");
                return false;
            }

            return true;
        }


        private int validateInt(string stext)
        {
            int d = -1;

            try
            {
                d = Convert.ToInt32(stext);
                if (d < 0)
                {
                    MessageBox.Show("Please enter a non-negative integer.");
                    d = -1;
                }
            }
            catch
            {
                MessageBox.Show("Please enter a non-negative integer.");
            }

            return d;
        }

        private bool testInt(string stext)
        {
            try
            {
                int d = Convert.ToInt32(stext);
                if (d < 0)
                {
                    MessageBox.Show("Please enter a non-negative integer.");
                    return false;
                }
            }
            catch
            {
                MessageBox.Show("Please enter a non-negative integer.");
                return false;
            }

            return true;
        }


// P
        private void txtPropPermanentP_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtPropPermanentP.Text)) == null)
                e.Cancel = true;
            else mOS.prPermanentP = oo;
        }

        private void txtPropPopEncounter_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtPropPopEncounter.Text)) == null)
                e.Cancel = true;
            else mOS.prPopEncounter = oo;
        }

        private void txtNEncounter_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtNEncounter.Text)) == null)
                e.Cancel = true;
            else mOS.NEncounter = oo;
        }

        private void txtDistanceEncounterFunc_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtDistanceEncounterFunc.Text)) == null)
                e.Cancel = true;
            else mOS.DistanceEncounterFunc = oo;
        }

        private void txtProbTransmission_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtProbTransmission.Text)) == null)
                e.Cancel = true;
            else mOS.prTransmission = oo;
        }

        private void txtProbOutsideEncounter_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtProbOutsideEncounter.Text)) == null)
                e.Cancel = true;
            else mOS.prOutsideEncounter = oo;
        }

        private void txtProbOutsideTransmission_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtProbOutsideTransmission.Text)) == null)
                e.Cancel = true;
            else mOS.prOutsideTransmission = oo;
        }

        private void txtPropPermanentI_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            double d = validateProb(txtPropPermanentI.Text);
            if (d >= 0.0) mOS.prPermanentI = d;
            else e.Cancel = true;
        }

        private void txtProbRecovery_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtProbRecovery.Text)) == null)
                e.Cancel = true;
            else mOS.prRecovery = oo;

            if (mOS.prRecovery.GetType() == typeof(double) &&mOS.prReSusceptible.GetType() == typeof(double))
               mOS.prDeath = (double)(1.0 - ((double)(mOS.prRecovery) + (double)(mOS.prReSusceptible)));
            else mOS.prDeath = mOS.translateObject("100 - (" + mOS.prRecovery.ToString() + "+" + mOS.prReSusceptible.ToString() + ")");
            txtProbDeath.Text = mOS.prDeath.ToString();
        }

        private void txtProbReSusceptible_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtProbReSusceptible.Text)) == null)
                e.Cancel = true;
            else mOS.prReSusceptible = oo;

            if (mOS.prRecovery.GetType() == typeof(double) && mOS.prReSusceptible.GetType() == typeof(double))
                mOS.prDeath = (double)(1.0 - ((double)(mOS.prRecovery) + (double)(mOS.prReSusceptible)));
            else mOS.prDeath = mOS.translateObject("100 - (" + mOS.prRecovery.ToString() + "+" + mOS.prReSusceptible.ToString() + ")");
            txtProbDeath.Text = mOS.prDeath.ToString();
        }

        private void runToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ActiveControl = txtPropPermanentP;
// need to get focus off of prior control, to force any Validating needed

            frmRun fRun = new frmRun(this, mOS);
            fRun.ShowDialog();

            settingUp = true;
            resetSettings();
            settingUp = false;
        }

        private void resetSettings()
        {
            txtRunYears.Text = mOS.nYears.ToString();
            txtRunIter.Text = mOS.nRuns.ToString();
            chkOutEpiRates.Checked = mOS.outEpiRates;
            chkOutIndividuals.Checked = mOS.outIndividuals;
            chkOutIndList.Checked = mOS.outIndList;
            chkOutMM.Checked = mOS.outMM;
            chkOutYearly.Checked = mOS.outYearly;
            chkOutDaily.Checked = mOS.outDaily;
        }

        public void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (OP.OName != "MyProject")
            {
                OP.saveXML(OP.ProjFolder + OP.OName, false);
            }
            else saveAsToolStripMenuItem_Click(null, null);
        }


        bool settingUp = false; 

        private void setUpInputTabs()
        {
            settingUp = true;

            Text = "Outbreak :: " + OP.ProjFolder + OP.OName + "_" + mOS.SceneName;

            txtOName.Text = OP.OName;
            txtRunDays.Text = mOS.nDays.ToString();
            txtDescription.Text = OP.Description;
            txtDzTag.Text = OP.DzTag;

            txtSceneName.Text = mOS.SceneName;
            txtSceneNotes.Text = mOS.SceneNotes;

            cboScenes.Items.Clear();
            for (int i = 0; i < OP.nscenes; i++)
                cboScenes.Items.Add(OP.Oscenes[i].SceneName);

            cboScenes.SelectedIndex = mOS.scenendx;
            if (OP.nscenes > 1)
            {
                cboScenes.Enabled = true;
                btnDeleteScenario.Enabled = true;
            }
            else
            {
                cboScenes.Enabled = false;
                btnDeleteScenario.Enabled = false;
            }

            txt_PNotes.Text = mOS.PNotes;
            txt_SNotes.Text = mOS.SNotes;
            txt_ENotes.Text = mOS.ENotes;
            txt_INotes.Text = mOS.INotes;
            txt_RNotes.Text = mOS.RNotes;
            txt_VNotes.Text = mOS.VNotes;
            txt_CullNotes.Text = mOS.CullNotes;
            txt_InitNotes.Text = mOS.InitNotes;
            txt_DemogNotes.Text = mOS.DemogNotes;
            txt_SpatialNotes.Text = mOS.SpatialNotes;

            txtPropPermanentP.Text = mOS.prPermanentP.ToString();
            txtDaysP.Text = mOS.DaysP.ToString();
            txtMaternalTransmission.Text = mOS.prMaternalTransmission.ToString();
            chkMaternalImmunity.Checked = mOS.MaternalR;
            txtMaternalImmunityDays.Text = mOS.DaysMaternalR.ToString();
            txtMaternalImmunityDays.Enabled = mOS.MaternalR;

            chkProportionEncountered.Checked = mOS.usePropEncounter;
            chkFixedNEncounter.Checked = mOS.useFixedNEncounter;
            chkSpatialEncounter.Checked = mOS.useDistanceEncounter;
            txtPropPopEncounter.Text = mOS.prPopEncounter.ToString();
            txtNEncounter.Text = mOS.NEncounter.ToString();
            txtDistanceEncounterFunc.Text = mOS.DistanceEncounterFunc.ToString();
            txtProbTransmission.Text = mOS.prTransmission.ToString();
            txtProbOutsideEncounter.Text = mOS.prOutsideEncounter.ToString();
            txtProbOutsideTransmission.Text = mOS.prOutsideTransmission.ToString();

            txtDaysE.Text = mOS.DaysE.ToString();

            txtPropPermanentI.Text = mOS.prPermanentI.ToString();
            txtDaysI.Text = mOS.DaysI.ToString();
            txtProbRecovery.Text = mOS.prRecovery.ToString();
            txtProbReSusceptible.Text = mOS.prReSusceptible.ToString();
            txtProbDeath.Text = mOS.prDeath.ToString();

            txtPropPermanentR.Text = mOS.prPermanentR.ToString();
            txtDaysR.Text = mOS.DaysR.ToString();

            chkVaccNow.Checked = mOS.vaccNow;
            chkVaccInterval.Checked = mOS.useVaccInterval;
            txtVaccDays.Enabled = txtVaccDaysStart.Enabled = chkVaccInterval.Checked;
            chkVaccPrevalence.Checked = mOS.useVaccPrev;
            txtVaccPrev.Enabled = chkVaccPrevalence.Checked;
            txtVaccDays.Text = mOS.vaccDays.ToString();
            txtVaccDaysStart.Text = mOS.vaccDaysStart.ToString();
            txtVaccPrev.Text = mOS.vaccPrev.ToString();
            txtVacc0.Text = mOS.vaccAge0.ToString();
            txtVaccSA.Text = mOS.vaccAgeSA.ToString();
            txtVaccAd.Text = mOS.vaccAgeAd.ToString();
            txtVacc0.Enabled = txtVaccAd.Enabled = txtVaccSA.Enabled = (chkVaccNow.Checked || chkVaccPrevalence.Checked || chkVaccInterval.Checked);
            txtVaccDuration.Enabled = txtVaccEfficacy.Enabled = (chkVaccNow.Checked || chkVaccPrevalence.Checked || chkVaccInterval.Checked);

            chkCullNow.Checked = mOS.cullNow;
            chkCullInterval.Checked = mOS.useCullInterval;
            chkCullPrevalence.Checked = mOS.useCullPrev;
            txtCullDays.Text = mOS.cullDays.ToString();
            txtCullDaysStart.Text = mOS.cullDaysStart.ToString();
            txtCullPrevalence.Text = mOS.cullPrev.ToString();
            txtCullPrevalence.Enabled = chkCullPrevalence.Checked;
            txtCullDays.Enabled = txtCullDaysStart.Enabled = chkCullInterval.Checked;
            txtCullAge0.Text = mOS.cullAge0.ToString();
            txtCullAgeSA.Text = mOS.cullAgeSA.ToString();
            txtCullAgeAd.Text = mOS.cullAgeAd.ToString();
            txtCullAge0.Enabled = txtCullAgeAd.Enabled = txtCullAgeSA.Enabled = (chkCullInterval.Checked || chkCullNow.Checked || chkCullPrevalence.Checked);

            txtInitN.Text = mOS.initN.ToString();
            for (int j = 0; j < 5; j++)
            {
                for (int i = 0; i < 4; i++)
                {
                    fgInitStates[i + 1, j + 1] = mOS.initStates[i,j].ToString();
                }
            }
            radioNcounts.Checked = mOS.useNcount;
            radioNproportions.Checked = !mOS.useNcount;

            if (radioNcounts.Checked) recalcInitN();
            else recalcInits();

            txtJuvDays.Text = mOS.juvDays.ToString();
            txtSADays.Text = mOS.SADays.ToString();
            chkEnterStageMort.Checked = mOS.enterStageMort;

            for (int i = 0; i < 4; i++)
            {
                fgLifeTable[2, i + 1] = mOS.Age0Mort[i].ToString();
                fgLifeTable[3, i + 1] = mOS.SAMort[i].ToString();
                fgLifeTable[4, i + 1] = mOS.AdultMMort[i].ToString();
                fgLifeTable[5, i + 1] = mOS.AdultFMort[i].ToString();

                fgLifeTable[7, i + 1] = mOS.prBreed[i].ToString();
                fgLifeTable[8, i + 1] = mOS.nLitters[i].ToString();
                fgLifeTable[9, i + 1] = mOS.litSize[i].ToString();
            }

            txtBreedDays.Text = mOS.breedDays.ToString();
            txtBreedAge.Text = mOS.brAge.ToString();
            txtBreedAgeDays.Text = mOS.brAgeDays.ToString(); // was missing?
            txtMaxAge.Text = mOS.brMaxAge.ToString();
            txtK.Text = mOS.K.ToString();
            txtKDay.Text = mOS.KDay.ToString();
            if(mOS.maintainK) radioMaintainK.Checked = true;
            else radioKDay.Checked = true;
            txtKDay.Enabled = !mOS.maintainK;

            chkUseSpatial.Checked = mOS.useSpatial;

            txtSpatialXmin.Text = mOS.gridXmin.ToString();
            txtSpatialXmax.Text = mOS.gridXmax.ToString();
            txtSpatialYmin.Text = mOS.gridYmin.ToString();
            txtSpatialYmax.Text = mOS.gridYmax.ToString();

            if(mOS.gridSeed) radioSeedRandom.Checked = true;
            else radioSeedFunctions.Checked = true;
            txtSpatialXFunc.Text = mOS.gridXseed.ToString();
            txtSpatialYFunc.Text = mOS.gridYseed.ToString();

            txtMoveWhen.Text = mOS.moveWhen.ToString();
            txtSpatialMove.Text = mOS.moveDist.ToString();
            txtSpatialMoveXFunc.Text = mOS.moveXrule.ToString();
            txtSpatialMoveYFunc.Text = mOS.moveYrule.ToString();
            
            if (mOS.moveRandom) radioSpatialMoveRandom.Checked = true;
            else if (mOS.moveRules) radioSpatialMoveFuncs.Checked = true;
            else radioSpatialMoveNone.Checked = true;

            if (mOS.gridBoundaryReflects) radioSpatialReflectingBoundary.Checked = true;
            else if (mOS.gridBoundaryAbsorbs) radioSpatialAbsorbingBoundary.Checked = true;
            else radioSpatialNoBoundary.Checked = true;

            resetSettings();

            for (int i = 0; i < Controls.Count; i++)
                O2Utils.CreateToolTipsFromTags(Controls[i]);

            O2Utils.resetTxttoBlack(this);

            settingUp = false;

            return;
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to save your current project before starting a new one?", "Save Warning", MessageBoxButtons.YesNoCancel);

            if (dr == DialogResult.Yes)
            {
                saveToolStripMenuItem_Click(sender, null);
            }
            if (dr == DialogResult.Cancel) return;

            OP = new Outbreak2(null, true);
            mOS = OP.Oscenes[0];
            setUpInputTabs();
        }

        private void exitWithoutSavingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to save your project before exiting?", "Save Warning", MessageBoxButtons.YesNoCancel);

            if (dr == DialogResult.Yes)
            {
                saveToolStripMenuItem_Click(sender, null);
            }

            if (dr != DialogResult.Cancel) Close();
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to save your current project before loading a new one?", "Save Warning", MessageBoxButtons.YesNoCancel);

            if (dr == DialogResult.Yes)
            {
                saveToolStripMenuItem_Click(sender, null);
            }
            if (dr == DialogResult.Cancel) return;

            //O2Utils.resetTxttoBlack(this);

            OpenFileDialog dlg = new OpenFileDialog();

            dlg.Filter = "Outbreak2 Project Files (*.xml)|*.xml|Outbreak1 OPF Files (*.opf)|*.opf|Outbreak1 OIS Files (*.ois)|*.ois|Infector Files (*.infect)|*.infect";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                settingUp = true;
                if (!OP.readOfile(dlg.FileName))
                {
                    MessageBox.Show("Error reading :" + dlg.FileName);
                    settingUp = false;
                    return;
                }

                //Update recent files list with this project
                List<string> f = frmRecentProjects.UpdateFileList(OP.OName, dlg.FileName);

                openRecentToolStripMenuItem.DropDownItems.Clear();
                for (int i = 0; i < f.Count; i++)
                    openRecentToolStripMenuItem.DropDownItems.Add(f[i], null, openRecentToolStripMenuItem_Click);

                mOS = OP.Oscenes[0];
                setUpInputTabs();
            }
        }

        //private List<string> UpdateFileList(string projectName, string projectFile)
        //{
        //    //get existing list, update with this project
        //    string rFile = Application.ExecutablePath.Substring(0, Application.ExecutablePath.LastIndexOf("\\")) + "\\recent.txt";
        //    List<string> f = O2Utils.ReadFileToList(rFile);

        //    if (f == null) f = new List<string>();

        //    string s = projectName + " - " + projectFile;

        //    if (f.Contains(s))
        //        f.Remove(s);

        //    f.Insert(0, s);

        //    //go through and make sure all still exist, remove if they don't
        //    int i = 1;
        //    while (i < f.Count)
        //    {
        //        if (!O2Utils.FileExists(f[i].Substring(f[i].IndexOf(":\\") - 1).Trim()))
        //            f.RemoveAt(i);
        //        else
        //            i++;
        //    }

        //    //Limit to 20
        //    for (i = f.Count - 1; i >= 20; i--)
        //        f.RemoveAt(i);

        //    O2Utils.WriteListToFile(rFile, f);

        //    return f;
        //}


        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();

            dlg.Filter = "Outbreak Project File (*.xml)|*.xml";
            dlg.InitialDirectory = OP.ProjFolder;

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string fn = dlg.FileName;
                string oname = fn.Replace(".xml", "");
                oname = oname.Substring(fn.LastIndexOf('\\') + 1);
                OP.OName = oname;
                OP.saveXML(fn,true);

                txtOName.Text = oname;

                //Update recent files list with this project

                List<string> f = frmRecentProjects.UpdateFileList(oname, fn);

                openRecentToolStripMenuItem.DropDownItems.Clear();
                for (int i = 0; i < f.Count; i++)
                    openRecentToolStripMenuItem.DropDownItems.Add(f[i], null, openRecentToolStripMenuItem_Click);


                if (mOS.runsDone) // copy core results file to the new folder
                {
                    string oldOutFolder = mOS.OutFolder;
                    string outFolder = OP.ProjFolder + oname + "_Results";
                    if (!Directory.Exists(outFolder))
                        Directory.CreateDirectory(outFolder);

                    if (File.Exists(oldOutFolder + "\\" + mOS.SceneName + "_day_stats.txt")) File.Copy(oldOutFolder + "\\" + mOS.SceneName + "_day_stats.txt", outFolder + "\\" + mOS.SceneName + "_day_stats.txt", true);
                    else mOS.runsDone = false;
                    if (File.Exists(oldOutFolder + "\\" + mOS.SceneName + "_year_stats.txt")) File.Copy(oldOutFolder + "\\" + mOS.SceneName + "_year_stats.txt", outFolder + "\\" + mOS.SceneName + "_year_stats.txt", true);
                    else mOS.runsDone = false;
                    if (File.Exists(oldOutFolder + "\\" + mOS.SceneName + "_prev_stats.txt")) File.Copy(oldOutFolder + "\\" + mOS.SceneName + "_prev_stats.txt", outFolder + "\\" + mOS.SceneName + "_prev_stats.txt", true);
                    else mOS.runsDone = false;
                    if (File.Exists(oldOutFolder + "\\" + mOS.SceneName + "_ryN.txt")) File.Copy(oldOutFolder + "\\" + mOS.SceneName + "_ryN.txt", outFolder + "\\" + mOS.SceneName + "_ryN.txt", true);
                }
            }

            Text = "Outbreak :: " + OP.ProjFolder + OP.OName;
        }

        private void radioNcounts_CheckedChanged(object sender, EventArgs e)
        {
            if (radioNcounts.Checked)
            {
                txtInitN.Enabled = false;
                btnRescaleInitProportions.Enabled = false;
            }
            else
            {
                txtInitN.Enabled = true;
                btnRescaleInitProportions.Enabled = true;
            }

            if (settingUp) return;

            mOS.useNcount = radioNcounts.Checked;

            if (radioNcounts.Checked)
            {
                recalcInitN();
            }
            else
            {
//                double tot = 
                    recalcInits();
            
                //for (int j = 0; j < 5; j++)
                //{
                //    for (int i = 0; i < 4; i++)
                //    {
                //        double val = Convert.ToDouble(fgInitStates[i + 1, j + 1]) * 100.0 / tot;
                //        fgInitStates[i + 1, j + 1] = val.ToString("0.00");
                //    }
                //}
            }
        }

        private void txtInitN_TextChanged(object sender, EventArgs e)
        {
            if (settingUp) return;

            mOS.initN = Convert.ToInt32(txtInitN.Text);
            recalcInits();
        }

        private double recalcInits()
        {
            double tot = 0.0;

            for (int j = 0; j < 5; j++)
            {
                for (int i = 0; i < 4; i++)
                {
                    tot += Convert.ToDouble(fgInitStates[i + 1, j + 1]);
                }
            }

            for (int j = 0; j < 5; j++)
            {
                for (int i = 0; i < 4; i++)
                {
                    mOS.initStates[i, j] = (int)(0.5 + (double)mOS.initN * Convert.ToDouble(fgInitStates[i + 1, j + 1]) / tot);
                }
            }

            return tot;
        }

        private void txtInitN_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            //if (validateInt(txtInitN.Text) < 0) e.Cancel = true;
        }

        private void recalcInitN()
        {
            int tN = 0;

            for (int j = 0; j < 5; j++)
            {
                for (int i = 0; i < 4; i++)
                {
                    mOS.initStates[i, j] = (int)(Convert.ToDouble(fgInitStates[i + 1, j + 1]));
                    tN += mOS.initStates[i, j];
                }
            }
            mOS.initN = tN;
            txtInitN.Text = tN.ToString();
        }

        private void fgInitStates_CellChanged(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (settingUp) return;

            if(e != null) fgInitStates.SetCellStyle(e.Row, e.Col, "FirstCustomStyle");

            if (radioNcounts.Checked)
            {
                recalcInitN();
            }
            else
            {
                recalcInits();
            }
        }

        private void chkProportionEncountered_CheckedChanged(object sender, EventArgs e)
        {
            if (chkProportionEncountered.Checked)
            {
                txtPropPopEncounter.Enabled = true;
                //txtNEncounter.Enabled = false;
                //txtDistanceEncounterFunc.Enabled = false;

                mOS.usePropEncounter = true;
                //mOS.useFixedNEncounter = false;
                //mOS.useDistanceEncounter = false;
            }
            else
            {
                txtPropPopEncounter.Enabled = false;
                mOS.usePropEncounter = false;
            }
        }

        private void chkFixedNEncounter_CheckedChanged(object sender, EventArgs e)
        {
            if (chkFixedNEncounter.Checked)
            {
                //                txtPropPopEncounter.Enabled = false;
                txtNEncounter.Enabled = true;
                //                txtDistanceEncounterFunc.Enabled = false;

                //                mOS.usePropEncounter = false;
                mOS.useFixedNEncounter = true;
                //                mOS.useDistanceEncounter = false;
            }
            else
            {
                txtNEncounter.Enabled = false;
                mOS.useFixedNEncounter = false;
            }

        }

        private void chkSpatialEncounter_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSpatialEncounter.Checked)
            {
                //txtPropPopEncounter.Enabled = false;
                //txtNEncounter.Enabled = false;
                txtDistanceEncounterFunc.Enabled = true;

                //mOS.usePropEncounter = false;
                //mOS.useFixedNEncounter = false;
                mOS.useDistanceEncounter = true;

                chkUseSpatial.Checked = true;
            }
            else
            {
                txtDistanceEncounterFunc.Enabled = false;
                mOS.useDistanceEncounter = false;

                if (mOS.useSpatial)
                {
                    if (MessageBox.Show("While turning off spatially defined encounter rates, do you want also to turn off modeling spatial movements?", "Note!", MessageBoxButtons.YesNo)
                        == System.Windows.Forms.DialogResult.Yes) chkUseSpatial.Checked = false;
                }
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAbout frmAbout = new frmAbout();
            frmAbout.ShowDialog();
        }

        private void resetBoundaryRules()
        {
            mOS.gridBoundaryReflects = radioSpatialReflectingBoundary.Checked;
            mOS.gridBoundaryAbsorbs = radioSpatialAbsorbingBoundary.Checked;
        }

        private void radioSpatialNoBoundary_CheckedChanged(object sender, EventArgs e)
        {
            resetBoundaryRules();
            //if (radioSpatialNoBoundary.Checked)
            //{
            //    radioSpatialReflectingBoundary.Checked = false;
            //    radioSpatialAbsorbingBoundary.Checked = false;
            //}
        }

        private void radioSpatialReflectingBoundary_CheckedChanged(object sender, EventArgs e)
        {
            resetBoundaryRules();
            //if (radioSpatialReflectingBoundary.Checked)
            //{
            //    radioSpatialNoBoundary.Checked = false;
            //    radioSpatialAbsorbingBoundary.Checked = false;
            //}
        }

        private void radioSpatialAbsorbingBoundary_CheckedChanged(object sender, EventArgs e)
        {
            resetBoundaryRules();
            //if (radioSpatialAbsorbingBoundary.Checked)
            //{
            //    radioSpatialNoBoundary.Checked = false;
            //    radioSpatialReflectingBoundary.Checked = false;
            //}
        }

        private void resetMovementRules()
        {
            mOS.moveRandom = radioSpatialMoveRandom.Checked;
            mOS.moveRules = radioSpatialMoveFuncs.Checked;
        }

        private void radioSpatialMoveRandom_CheckedChanged(object sender, EventArgs e)
        {
            resetMovementRules();

            if (radioSpatialMoveRandom.Checked)
            {
                txtSpatialMove.Enabled = true;
                txtSpatialMoveXFunc.Enabled = false;
                txtSpatialMoveYFunc.Enabled = false;
                txtMoveWhen.Enabled = true;
            }
        }

        private void radioSpatialMoveFuncs_CheckedChanged(object sender, EventArgs e)
        {
            resetMovementRules();

            if (radioSpatialMoveFuncs.Checked)
            {
                txtSpatialMove.Enabled = false;
                txtSpatialMoveXFunc.Enabled = true;
                txtSpatialMoveYFunc.Enabled = true;
                txtMoveWhen.Enabled = true;
            }
        }

        private void radioSpatialMoveNone_CheckedChanged(object sender, EventArgs e)
        {
            resetMovementRules();

            if (radioSpatialMoveNone.Checked)
            {
                txtSpatialMove.Enabled = false;
                txtSpatialMoveXFunc.Enabled = false;
                txtSpatialMoveYFunc.Enabled = false;
                txtMoveWhen.Enabled = false;
            }
        }

        private void radioSeedRandom_CheckedChanged(object sender, EventArgs e)
        {
            mOS.gridSeed = radioSeedRandom.Checked;

            if (radioSeedRandom.Checked)
            {
                txtSpatialXFunc.Enabled = false;
                txtSpatialYFunc.Enabled = false;
            }
        }

        private void radioSeedFunctions_CheckedChanged(object sender, EventArgs e)
        {
            mOS.gridSeed = radioSeedRandom.Checked;

            if (radioSeedFunctions.Checked)
            {
                txtSpatialXFunc.Enabled = true;
                txtSpatialYFunc.Enabled = true;
                //radioSeedRandom.Checked = false;
            }
        }

        private void txtSpatialXmin_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            int d = validateInt(txtSpatialXmin.Text);
            if (d >= 0)
            {
                mOS.gridXmin = d;
                if (mOS.gridXmax < mOS.gridXmin)
                {
                    mOS.gridXmax = mOS.gridXmin;
                    txtSpatialXmax.Text = mOS.gridXmax.ToString();
                }
            }
            else e.Cancel = true;
        }

        private void txtSpatialXmax_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            int d = validateInt(txtSpatialXmax.Text);
            if (d >= 0)
            {
                mOS.gridXmax = d;
                if (mOS.gridXmax < mOS.gridXmin)
                {
                    mOS.gridXmin = mOS.gridXmax;
                    txtSpatialXmin.Text = mOS.gridXmin.ToString();
                }
            }
            else e.Cancel = true;
        }

        private void txtSpatialYmin_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            int d = validateInt(txtSpatialYmin.Text);
            if (d >= 0)
            {
                mOS.gridYmin = d;
                if (mOS.gridYmax < mOS.gridYmin)
                {
                    mOS.gridYmax = mOS.gridYmin;
                    txtSpatialYmax.Text = mOS.gridYmax.ToString();
                }
            }
            else e.Cancel = true;
        }

        private void txtSpatialYmax_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            int d = validateInt(txtSpatialYmax.Text);
            if (d >= 0)
            {
                mOS.gridYmax = d;
                if (mOS.gridYmax < mOS.gridYmin)
                {
                    mOS.gridYmin = mOS.gridYmax;
                    txtSpatialYmin.Text = mOS.gridYmin.ToString();
                }
            }
            else e.Cancel = true;
        }

        private void txtSpatialXFunc_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtSpatialXFunc.Text)) == null)
                e.Cancel = true;
            else mOS.gridXseed = oo;
        }

        private void txtSpatialYFunc_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtSpatialYFunc.Text)) == null)
                e.Cancel = true;
            else mOS.gridYseed = oo;
        }

        private void txtSpatialMoveXFunc_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtSpatialMoveXFunc.Text)) == null)
                e.Cancel = true;
            else mOS.moveXrule = oo;
        }

        private void txtSpatialMoveYFunc_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtSpatialMoveYFunc.Text)) == null)
                e.Cancel = true;
            else mOS.moveYrule = oo;
        }

        private void txtSpatialMove_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtSpatialMove.Text)) == null)
                e.Cancel = true;
            else mOS.moveDist = oo;
        }

        private void txtVaccDays_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateIntObject(txtVaccDays.Text)) == null)
                e.Cancel = true;
            else mOS.vaccDays = oo;
        }

        private void txtVaccDuration_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateIntObject(txtVaccDuration.Text)) == null)
                e.Cancel = true;
            else mOS.vaccDuration = oo;
        }

        private void txtVaccPrev_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtVaccPrev.Text)) == null)
                e.Cancel = true;
            else mOS.vaccPrev = oo;
        }

        private void txtVacc0_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtVacc0.Text)) == null)
                e.Cancel = true;
            else mOS.vaccAge0 = oo;
        }

        private void txtVaccSA_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtVaccSA.Text)) == null)
                e.Cancel = true;
            else mOS.vaccAgeSA = oo;
        }

        private void txtVaccAd_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtVaccAd.Text)) == null)
                e.Cancel = true;
            else mOS.vaccAgeAd = oo;
        }

        private void txtVaccEfficacy_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtVaccEfficacy.Text)) == null)
                e.Cancel = true;
            else mOS.vaccEfficacy = oo;
        }

        private void chkVaccNow_CheckedChanged(object sender, EventArgs e)
        {
            if (chkVaccNow.Checked)
            {
                mOS.vaccNow = true;
                groupBox13.Enabled = groupBox14.Enabled = true;
                txtVacc0.Enabled = true;
                txtVaccAd.Enabled = true;
                txtVaccSA.Enabled = true;
                txtVaccDuration.Enabled = true;
                txtVaccEfficacy.Enabled = true;
            }
            else
            {
                mOS.vaccNow = false;
                if (!mOS.useVaccPrev && !mOS.useVaccInterval)
                {
                    groupBox13.Enabled = groupBox14.Enabled = false;
                    txtVacc0.Enabled = false;
                    txtVaccAd.Enabled = false;
                    txtVaccSA.Enabled = false;
                    txtVaccDuration.Enabled = false;
                    txtVaccEfficacy.Enabled = false;
                }
            }
        }

        private void chkVaccInterval_CheckedChanged(object sender, EventArgs e)
        {
            if (chkVaccInterval.Checked)
            {
                groupBox13.Enabled = groupBox14.Enabled = true;
                txtVaccDays.Enabled = true;
                txtVaccDaysStart.Enabled = true;
                txtVacc0.Enabled = true;
                txtVaccAd.Enabled = true;
                txtVaccSA.Enabled = true;
                txtVaccDuration.Enabled = true;
                txtVaccEfficacy.Enabled = true;
                mOS.useVaccInterval = true;
            }
            else
            {
                txtVaccDays.Enabled = false;
                txtVaccDaysStart.Enabled = false;
                mOS.useVaccInterval = false;
                if (!mOS.useVaccPrev && ! mOS.vaccNow)
                {
                    groupBox13.Enabled = groupBox14.Enabled = false;
                    txtVacc0.Enabled = false;
                    txtVaccAd.Enabled = false;
                    txtVaccSA.Enabled = false;
                    txtVaccDuration.Enabled = false;
                    txtVaccEfficacy.Enabled = false;
                }
            }
        }

        private void chkVaccPrevalence_CheckedChanged(object sender, EventArgs e)
        {
            if (chkVaccPrevalence.Checked)
            {
                groupBox13.Enabled = groupBox14.Enabled = true;
                txtVaccPrev.Enabled = true;
                txtVacc0.Enabled = true;
                txtVaccAd.Enabled = true;
                txtVaccSA.Enabled = true;
                txtVaccDuration.Enabled = true;
                txtVaccEfficacy.Enabled = true;
                mOS.useVaccPrev = true;
            }
            else
            {
                txtVaccPrev.Enabled = false;
                mOS.useVaccPrev = false;
                if (!mOS.useVaccInterval && !mOS.vaccNow)
                {
                    groupBox13.Enabled = groupBox14.Enabled = false;
                    txtVacc0.Enabled = false;
                    txtVaccAd.Enabled = false;
                    txtVaccSA.Enabled = false;
                    txtVaccDuration.Enabled = false;
                    txtVaccEfficacy.Enabled = false;
                }
            }
        }

        private void chkCullNow_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCullNow.Checked)
            {
                mOS.cullNow = true;
                groupBox22.Enabled = true;
                txtCullAge0.Enabled = true;
                txtCullAgeAd.Enabled = true;
                txtCullAgeSA.Enabled = true;
            }
            else
            {
                mOS.cullNow = false;
                if (!mOS.useCullPrev && !mOS.useCullInterval)
                {
                    groupBox22.Enabled = false;
                    txtCullAge0.Enabled = false;
                    txtCullAgeAd.Enabled = false;
                    txtCullAgeSA.Enabled = false;
                }
            }
        }

        private void chkCullInterval_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCullInterval.Checked)
            {
                groupBox22.Enabled = true;
                txtCullDays.Enabled = true;
                txtCullDaysStart.Enabled = true;
                txtCullAge0.Enabled = true;
                txtCullAgeAd.Enabled = true;
                txtCullAgeSA.Enabled = true;
                mOS.useCullInterval = true;
            }
            else
            {
                txtCullDays.Enabled = false;
                txtCullDaysStart.Enabled = false;
                mOS.useCullInterval = false;
                if (!mOS.useCullPrev && !mOS.cullNow)
                {
                    groupBox22.Enabled = false;
                    txtCullAge0.Enabled = false;
                    txtCullAgeAd.Enabled = false;
                    txtCullAgeSA.Enabled = false;
                }
            }
        }

        private void chkCullPrevalence_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCullPrevalence.Checked)
            {
                groupBox22.Enabled = true;
                txtCullPrevalence.Enabled = true;
                txtCullAge0.Enabled = true;
                txtCullAgeAd.Enabled = true;
                txtCullAgeSA.Enabled = true;
                mOS.useCullPrev = true;
            }
            else
            {
                txtCullPrevalence.Enabled = false;
                mOS.useCullPrev = false;
                if (!mOS.cullNow && !mOS.useCullInterval)
                {
                    groupBox22.Enabled = false;
                    txtCullAge0.Enabled = false;
                    txtCullAgeAd.Enabled = false;
                    txtCullAgeSA.Enabled = false;
                }
            }
        }

        private void txtCullDays_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateIntObject(txtCullDays.Text)) == null)
                e.Cancel = true;
            else mOS.cullDays = oo;
        }

        private void txtCullPrevalence_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtCullPrevalence.Text)) == null)
                e.Cancel = true;
            else mOS.cullPrev = oo;
        }

        private void txtCullAge0_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtCullAge0.Text)) == null)
                e.Cancel = true;
            else mOS.cullAge0 = oo;
        }

        private void txtCullAgeSA_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtCullAgeSA.Text)) == null)
                e.Cancel = true;
            else mOS.cullAgeSA = oo;
        }

        private void txtCullAgeAd_Validating(object sender, CancelEventArgs e)
        {

        }

        private void btnCopyLifeTable_Click(object sender, EventArgs e)
        {
            for (int i = 2; i < 5; i++)
            {
                for (int j = 1; j < 10; j++) fgLifeTable[j, i] = fgLifeTable[j, 1];
            }
        }

        private void txtMoveWhen_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateObject(txtMoveWhen.Text)) == null)
                e.Cancel = true;
            else mOS.moveWhen = oo;
        }

        private void txtBreedAge_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            int d = validateInt(txtBreedAge.Text);
            if (d >= 0)
            {
                mOS.brAge = d;
                mOS.brAgeDays = d * mOS.nDays;
                txtBreedAgeDays.Text = mOS.brAgeDays.ToString();
            }
            else e.Cancel = true;
        }

        private void txtMaxAge_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            int d = validateInt(txtMaxAge.Text);
            if (d >= 0)
            {
                mOS.brMaxAge = d;
            }
            else e.Cancel = true;

            mOS.calcLambda();
            for (int i = 0; i < 4; i++)
            {
                fgLifeTable[10, i + 1] = mOS.lambda1[i].ToString("0.000");
            }
        }

        private void txtKDay_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            int d = validateInt(txtKDay.Text);
            if (d >= 0)
            {
                mOS.KDay = d;
            }
            else e.Cancel = true;

            if (mOS.KDay > mOS.nDays) MessageBox.Show("The day that K is imposed is beyond the end of the year, so that it will never happen!", "Caution!");
        }

        private void txtK_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateIntObject(txtK.Text)) == null)
                e.Cancel = true;
            else mOS.K = oo;
        }

        private void radioMaintainK_CheckedChanged(object sender, EventArgs e)
        {
            if (settingUp) return;
            if (radioMaintainK.Checked)
            {
                txtKDay.Enabled = false;
                mOS.maintainK = true;
            }
        }

        private void radioKDay_CheckedChanged(object sender, EventArgs e)
        {
            if (settingUp) return;
            if (radioKDay.Checked)
            {
                txtKDay.Enabled = true;
                mOS.maintainK = false;
            }
        }

        private void fgLifeTable_CellChanged(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (settingUp) return;

            int r = e.Row;
            int c = e.Col;
            if (r == 10) return; 

            // also change cell to red
            fgLifeTable.SetCellStyle(r, c, "FirstCustomStyle");

            object oo;
            if ((oo = mOS.translateObject(fgLifeTable[r, c])) == null)
                e.Cancel = true;
            else
            {
                if (r == 2) mOS.Age0Mort[c - 1] = oo;
                else if (r == 3) mOS.SAMort[c - 1] = oo;
                else if (r == 4) mOS.AdultMMort[c - 1] = oo;
                else if (r == 5) mOS.AdultFMort[c - 1] = oo;
                else if (r == 7) mOS.prBreed[c - 1] = oo;
                else if (r == 8) mOS.nLitters[c - 1] = oo;
                else if (r == 9) mOS.litSize[c - 1] = oo;
            }

            mOS.calcLambda();
            for (int i = 0; i < 4; i++)
            {
                fgLifeTable[10, i + 1] = mOS.lambda1[i].ToString("0.000");
            }
        }

        private void resultsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!mOS.runsDone)
            {
                MessageBox.Show("No output is available from this session or from prior work stored with this Scenario. Please Run simulations to obtain results.", "No simulation results!");
                return;
            }

            frmGraphResults frmGraphs = new frmGraphResults(mOS);
            frmGraphs.ShowDialog();
        }

        private void frmOutbreak2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason != CloseReason.ApplicationExitCall)
            {
                DialogResult dr = MessageBox.Show("Would you like to save this project before exiting?", "Save Warning", MessageBoxButtons.YesNoCancel);

                if (dr == DialogResult.Cancel)
                    e.Cancel = true;
                else if (dr == DialogResult.Yes)
                {
                    saveToolStripMenuItem_Click(sender, null);
                }
            }
        }

        private void txtVaccDaysStart_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateIntObject(txtVaccDaysStart.Text)) == null)
                e.Cancel = true;
            else mOS.vaccDaysStart = oo;
        }

        private void txtPropPermanentR_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            double d = validateProb(txtPropPermanentR.Text);
            if (d >= 0.0) mOS.prPermanentR = d;
            else e.Cancel = true;
        }

        private void txtRunDays_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            //int d = validateInt(txtRunDays.Text);
            //if (d >= 0)
            //{
            //    mOS.nDays = d;
            //}
            //else e.Cancel = true;

            if (!O2Utils.ValidateTextBox((TextBox)sender)) e.Cancel = true;
            else mOS.nDays = Convert.ToInt32(txtRunDays.Text);

        }

        private void chkMaternalImmunity_CheckedChanged(object sender, EventArgs e)
        {
            if (settingUp) return;

            if (chkMaternalImmunity.Checked)
            {
                txtMaternalImmunityDays.Enabled = true;
                mOS.MaternalR = true;
            }
            else
            {
                txtMaternalImmunityDays.Enabled = false;
                mOS.MaternalR = false;
            }
        }

        private void txtCullDaysStart_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateIntObject(txtCullDaysStart.Text)) == null)
                e.Cancel = true;
            else mOS.cullDaysStart = oo;
        }

        private void txtBreedAgeDays_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            int d = validateInt(txtBreedAgeDays.Text);
            if (d >= 0)
            {
                mOS.brAgeDays = d;
                mOS.brAge = d / mOS.nDays;
                txtBreedAge.Text = mOS.brAge.ToString();
                txtBreedAge.Enabled = (d % mOS.nDays == 0); // a check to see if yearly increment was used
            }
            else e.Cancel = true;

            mOS.calcLambda();
            for (int i = 0; i < 4; i++)
            {
                fgLifeTable[10, i + 1] = mOS.lambda1[i].ToString("0.000");
            }
        }

        private void txtDaysP_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateIntObject(txtDaysP.Text)) == null)
                e.Cancel = true;
            else mOS.DaysP = oo;
        }

        private void txtMaternalImmunityDays_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateIntObject(txtMaternalImmunityDays.Text)) == null)
                e.Cancel = true;
            else mOS.DaysMaternalR = oo;
        }

        private void txtDaysE_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateIntObject(txtDaysE.Text)) == null)
                e.Cancel = true;
            else mOS.DaysE = oo;
        }

        private void txtDaysR_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateIntObject(txtDaysR.Text)) == null)
                e.Cancel = true;
            else mOS.DaysR = oo;
        }

        private void txtDaysI_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateIntObject(txtDaysI.Text)) == null)
                e.Cancel = true;
            else mOS.DaysI = oo;
        }

        private void txtBreedDays_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (!O2Utils.ValidateTextBox((TextBox)sender))
            {
                e.Cancel = true;
                return;
            }

            object oo;
            if ((oo = mOS.translateIntObject(txtBreedDays.Text)) == null)
                e.Cancel = true;
            else mOS.breedDays = oo;

            mOS.calcLambda(); 
            for (int i = 0; i < 4; i++)
            {
                fgLifeTable[10, i + 1] = mOS.lambda1[i].ToString("0.000");
            }
        }

        private void chkOutDaily_CheckedChanged(object sender, EventArgs e)
        {
            if (settingUp) return;

            mOS.outDaily = chkOutDaily.Checked;
        }

        private void chkOutYearly_CheckedChanged(object sender, EventArgs e)
        {
            if (settingUp) return;

            mOS.outYearly = chkOutYearly.Checked;
        }

        private void chkOutIndList_CheckedChanged(object sender, EventArgs e)
        {
            if (settingUp) return;

            mOS.outIndList = chkOutIndList.Checked;
        }

        private void chkOutEpiRates_CheckedChanged(object sender, EventArgs e)
        {
            if (settingUp) return;

            mOS.outEpiRates = chkOutEpiRates.Checked;
        }

        private void chkOutIndividuals_CheckedChanged(object sender, EventArgs e)
        {
            if (settingUp) return;

            mOS.outIndividuals = chkOutIndividuals.Checked;
        }

        private void chkOutMM_CheckedChanged(object sender, EventArgs e)
        {
            if (settingUp) return;

            mOS.outMM = chkOutMM.Checked;
        }

        private void txtRunIter_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (O2Utils.ValidateTextBox((TextBox)sender))
                mOS.nRuns = Convert.ToInt32(txtRunIter.Text);
            else e.Cancel = true;
        }

        private void txtRunYears_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (O2Utils.ValidateTextBox((TextBox)sender))
                mOS.nYears = Convert.ToInt32(txtRunYears.Text);
            else e.Cancel = true;
        }

        private void txtDescription_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            OP.Description = txtDescription.Text;
        }

        private void txtDzTag_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            OP.DzTag = txtDzTag.Text.Trim();
        }

        private void txtOName_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            OP.OName = txtOName.Text.Trim();
        }

        private void frmOutbreak2_Load(object sender, EventArgs e)
        {
        }

        private void txt_RNotes_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            mOS.RNotes = txt_RNotes.Text.Trim();
        }

        private void txt_ENotes_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            mOS.ENotes = txt_ENotes.Text.Trim();
        }

        private void txt_PNotes_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            mOS.PNotes = txt_PNotes.Text.Trim();
        }

        private void txt_SNotes_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            mOS.SNotes = txt_SNotes.Text.Trim();
        }

        private void txt_INotes_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            mOS.INotes = txt_INotes.Text.Trim();
        }

        private void txt_InitNotes_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            mOS.InitNotes = txt_InitNotes.Text.Trim();
        }

        private void txt_DemogNotes_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            mOS.DemogNotes = txt_DemogNotes.Text.Trim();
        }

        private void txt_VNotes_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            mOS.VNotes = txt_VNotes.Text.Trim();
        }

        private void txt_CullNotes_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            mOS.CullNotes = txt_CullNotes.Text.Trim();
        }

        private void txt_SpatialNotes_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            mOS.SpatialNotes = txt_SpatialNotes.Text.Trim();
        }

        private void txtMaternalTransmission_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            object oo;
            if ((oo = mOS.translateObject(txtMaternalTransmission.Text)) == null)
                e.Cancel = true;
            else
            {
                mOS.prMaternalTransmission = oo;
            }
        }

        private void openRecentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to save your current project before loading a new one?", "Save Warning", MessageBoxButtons.YesNoCancel);

            if (dr == DialogResult.Yes)
            {
                saveToolStripMenuItem_Click(sender, null);
            }
            if (dr == DialogResult.Cancel) return;

            string s = ((ToolStripItem)sender).ToString();
            int sndx = s.IndexOf(":\\") - 1;
            if (sndx < 0) return;
            string fn = s.Substring(sndx).Trim();

            if (O2Utils.FileExists(fn))
            {
                settingUp = true;
                if (!OP.readOfile(fn))
                {
                    MessageBox.Show("Error reading :" + fn);
                    settingUp = false;
                    return;
                }

                mOS = OP.Oscenes[0];
                setUpInputTabs();
            }
        }

        private void chkUseSpatial_CheckedChanged(object sender, EventArgs e)
        {
            if (!chkUseSpatial.Checked && mOS.useDistanceEncounter)
            {
                DialogResult res = MessageBox.Show("You disabled spatial modeling, but you defined the encounter probability to be a function of distance! Do you really want to do this?", "Warning!", MessageBoxButtons.YesNo);
                if (res == DialogResult.No)
                {
                    chkUseSpatial.Checked = true;
                    return;
                }
            }
            mOS.useSpatial = chkUseSpatial.Checked;
            groupBox16.Enabled = groupBox17.Enabled = groupBox18.Enabled = groupBox19.Enabled = chkUseSpatial.Checked;
        }

        private void txtSceneNotes_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            mOS.SceneNotes = txtSceneNotes.Text.Trim();
        }

        private void txtSceneName_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            string sname = txtSceneName.Text.Trim();
            for (int i = 0; i < OP.nscenes; i++)
            {
                if(i == mOS.scenendx) continue;
                if (sname == OP.Oscenes[i].SceneName)
                {
                    MessageBox.Show("Cannot give two scenarios the same name");
                    e.Cancel = true;
                    txtSceneName.Text = mOS.SceneName;
                    return;
                }
            }

            mOS.SceneName = sname;

            // update dropdown list
            cboScenes.Items[mOS.scenendx] = sname;

        }

        private void cboScenes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(settingUp) return;

            mOS = OP.Oscenes[cboScenes.SelectedIndex];
            setUpInputTabs();
        }

        private void btnDeleteScenario_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Are you sure that you want to permanently remove the current scenario (" + mOS.SceneName + ")?", "Warning", MessageBoxButtons.YesNo);
            if (res == DialogResult.No) return;

            OP.Oscenes.RemoveAt(mOS.scenendx);
            mOS = OP.Oscenes[0];
            OP.nscenes--;

            for (int i = 0; i < OP.nscenes; i++) OP.Oscenes[i].scenendx = i;

            setUpInputTabs();
        }

        private void btnAddScenarios_Click(object sender, EventArgs e)
        {
            OScenario baseOS = OP.Oscenes[0];

            if (OP.nscenes > 1)
            {
                frmPicker frm = new frmPicker("Select a scenario to use as a base:", OP.Oscenes);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    baseOS = OP.Oscenes[frm.SelectedIndex];
                }
            }

            frmGetValue frmGV = new frmGetValue("Number of Copies", "How many copies of " + baseOS.SceneName + " would you like to make?", "1");
            if (frmGV.ShowDialog() == DialogResult.OK)
            {
                for (int i = 0; i < Convert.ToInt32(frmGV.GetValue); i++)
                {
                    string newname = baseOS.SceneName + "_Copy" + (i+1).ToString();
                    OP.copyScenario(baseOS, newname);
                }
            }

            cboScenes.Items.Clear();
            for (int i = 0; i < OP.nscenes; i++)
                cboScenes.Items.Add(OP.Oscenes[i].SceneName);
            cboScenes.Enabled = true;

            cboScenes.SelectedIndex = 0;
        }

        private void txtJuvDays_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (O2Utils.ValidateTextBox((TextBox)sender))
                mOS.juvDays = Convert.ToInt32(txtJuvDays.Text);
            else e.Cancel = true;

            if (mOS.juvDays != mOS.nDays)
                MessageBox.Show("Note: if Juveniles are defined to be something other than up to 1 year of age, the Juvenile Mortality is still on an annual basis.");

            mOS.calcLambda();
            for (int i = 0; i < 4; i++)
            {
                fgLifeTable[10, i + 1] = mOS.lambda1[i].ToString("0.000");
            }
        }

        private void txtSADays_Validating(object sender, CancelEventArgs e)
        {
            if (settingUp) return;

            if (O2Utils.ValidateTextBox((TextBox)sender))
                mOS.SADays = Convert.ToInt32(txtSADays.Text);
            else e.Cancel = true;

            if (mOS.SADays % mOS.nDays > 0)
                MessageBox.Show("Note: if the Subadult age class is defined to be something other than an integer number of years, the Mortality is still on an annual basis.");

            mOS.calcLambda();
            for (int i = 0; i < 4; i++)
            {
                fgLifeTable[10, i + 1] = mOS.lambda1[i].ToString("0.000");
            }
        }

        private void btnSAD_Click(object sender, EventArgs e)
        {
            settingUp = true; // so that don't recalc with each cell changed
            int t;
            int tSum = 0;
            double PSsum = Convert.ToDouble(fgInitStates[1, 1]) + Convert.ToDouble(fgInitStates[2, 1]) + Convert.ToDouble(fgInitStates[3, 1]) + Convert.ToDouble(fgInitStates[4, 1]);
            fgInitStates[1, 1] = tSum = (int)(0.5 + PSsum * mOS.sadClasses[0]);
            fgInitStates[2, 1] = t = (int)(0.5 + PSsum * mOS.sadClasses[1]);
            tSum += t;
            fgInitStates[4, 1] = t = (int)(0.5 + PSsum * mOS.sadClasses[3]);
            tSum += t;
            fgInitStates[3, 1] = (int)PSsum - tSum; // just to be sure that still adds up to user entered total
            settingUp = false;

            fgInitStates_CellChanged(null, null);
        }

        private void btnRescaleInitProportions_Click(object sender, EventArgs e)
        {
            double tot = 0.0;

            for (int j = 0; j < 5; j++)
            {
                for (int i = 0; i < 4; i++)
                {
                    tot += Convert.ToDouble(fgInitStates[i + 1, j + 1]);
                }
            }

            for (int j = 0; j < 5; j++)
            {
                for (int i = 0; i < 4; i++)
                {
                    double prop = Convert.ToDouble(fgInitStates[i + 1, j + 1]) / tot;
                    fgInitStates[i + 1, j + 1] = 100.0 * prop;

                    mOS.initStates[i, j] = (int)(0.5 + (double)mOS.initN * prop);
                }
            }
        }

        private void chkEnterStageMort_CheckedChanged(object sender, EventArgs e)
        {
            if (settingUp) return;

            mOS.enterStageMort = chkEnterStageMort.Checked;
            if (mOS.enterStageMort) fgLifeTable[1, 0] = "Mortality:";
            else fgLifeTable[1, 0] = "Annual Mortality:";
        }

        private void supportConservationToolStripMenuItem_Click(object sender, EventArgs e)
        {
//            frmAcknowledgements frm = new frmAcknowledgements();
            frmSCTI2 frm = new frmSCTI2(true);
            frm.ShowDialog();
        }

        public void LaunchHelp()
        {
            return; // temporary, until manual is written

            string nameddest = "TableContents";
            try
            {
                if (tbInput.SelectedIndex == 0) nameddest = "General";
                else if (tbInput.SelectedIndex == 1)
                {
                    nameddest = "P";
                }
                else if (tbInput.SelectedIndex == 2)
                {
                    nameddest = "S";
                }
                else if (tbInput.SelectedIndex == 3)
                {
                    nameddest = "E";
                }
                else if (tbInput.SelectedIndex == 4)
                {
                    nameddest = "I";
                }
                else if (tbInput.SelectedIndex == 5)
                {
                    nameddest = "R";
                }
                else if (tbInput.SelectedIndex == 6)
                {
                    nameddest = "V";
                }
                else if (tbInput.SelectedIndex == 7)
                {
                    nameddest = "Removals";
                }
                else if (tbInput.SelectedIndex == 8)
                {
                    nameddest = "InitN";
                }
                else if (tbInput.SelectedIndex == 9)
                {
                    nameddest = "Demog";
                }
                else if (tbInput.SelectedIndex == 10)
                {
                    nameddest = "Spatial";
                }

            }
            catch // let it fall through with ipage = 0 or whatever
            {
            }

            OutbreakHelp.LaunchHelp(nameddest);
        }

        private void manualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Outbreak manual is still in preparation.");
            return; // temporary, until manual is written

            OutbreakHelp.LaunchHelp("TableContents");
        }

        private void noHelpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Help system is not yet avaiable.");
            return; // temporary, until manual is written

            OutbreakHelp.LaunchHelp("TableContents");
        }

        private void userRegistrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRegistration frm = new frmRegistration();
            frm.ShowDialog();
        }

        private void checkForUpdatesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            Program.checkUpdates(true);

            Cursor.Current = Cursors.Default;
        }
    }
}
