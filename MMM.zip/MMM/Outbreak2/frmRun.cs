﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Outbreak2
{
    public partial class frmRun : Form
    {
        frmOutbreak2 m_frmO2;
        OScenario mOS;

        public frmRun(frmOutbreak2 frmO2, OScenario OS)
        {
            InitializeComponent();

            label4.Visible = false;

            m_frmO2 = frmO2;
            mOS = OS;

            cboScenes.Items.Clear();
            for (int i = 0; i < mOS.mOP.nscenes; i++)
                cboScenes.Items.Add(mOS.mOP.Oscenes[i].SceneName);

            cboScenes.SelectedIndex = mOS.scenendx;
            if (mOS.mOP.nscenes > 1)
            {
                cboScenes.Enabled = true;
            }
            else
            {
                cboScenes.Enabled = false;
            }

            setupfrm();

            //load tooltips
            O2Utils.CreateToolTipsFromTagsForForm(this);

        }

        private bool setupfrm()
        {
            // so that settings maintained at least until project is closed
            txtRunYears.Text = mOS.nYears.ToString();
            txtRunIter.Text = mOS.nRuns.ToString();
            chkOutEpiRates.Checked = mOS.outEpiRates;
            chkOutIndividuals.Checked = mOS.outIndividuals;
            chkOutIndList.Checked = mOS.outIndList;
            chkOutMM.Checked = mOS.outMM;
            chkOutYearly.Checked = mOS.outYearly;
            chkOutDaily.Checked = mOS.outDaily;

            btnResults.Enabled = mOS.runsDone;
            groupBox2.Enabled = mOS.useSpatial;

            return true;
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            label4.Visible = false;

            int runs = Convert.ToInt32(txtRunIter.Text);
            int years = Convert.ToInt32(txtRunYears.Text);
            int days = mOS.nDays;

            mOS.nRuns = runs;
            mOS.nYears = years;
            mOS.spatialDisplayDays = Convert.ToInt32(txtSpatialDisplayDays.Text);

            Cursor.Current = Cursors.WaitCursor;

            progressBar1.Maximum = runs;

            bool showingSpatial = (mOS.useSpatial && mOS.spatialDisplayDays > 0);
            chartSpatialDisplay.Visible = showingSpatial;

            if (showingSpatial)
            {
                mOS.startSpatialPlot(chartSpatialDisplay);

//                chartSpatialDisplay.ChartGroups.Group0.ChartType = Chart2DTypeEnum.XYPlot;
//                chartSpatialDisplay.Header.Visible = false;

//                //chartSpatialDisplay.ChartArea.AxisX.ValueLabels.Clear();
//                //chartSpatialDisplay.ChartArea.AxisY.ValueLabels.Clear();

//                chartSpatialDisplay.ChartArea.AxisX.Text = "";
//                chartSpatialDisplay.ChartArea.AxisX.Min = mOS.gridXmin;
//                chartSpatialDisplay.ChartArea.AxisX.Max = mOS.gridXmax;

//                chartSpatialDisplay.ChartArea.AxisY.Text = "";
//                chartSpatialDisplay.ChartArea.AxisY.Min = mOS.gridYmin;
//                chartSpatialDisplay.ChartArea.AxisY.Max = mOS.gridYmax;

//                chartSpatialDisplay.ChartArea.AxisX.AnnoMethod = AnnotationMethodEnum.Values;
//                chartSpatialDisplay.ChartArea.AxisY.AnnoMethod = AnnotationMethodEnum.Values;

//                chartSpatialDisplay.Footer.Visible = true;

//                chartSpatialDisplay.ChartGroups.Group0.ChartData.SeriesList.Clear();
//                for (int j = 0; j < 6; j++)
//                {
//                    C1.Win.C1Chart.ChartDataSeries ds = new C1.Win.C1Chart.ChartDataSeries();

//                    if (j == 3)
//                    {
//                        ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Cross;
//                    }
//                    else ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Circle;
//                    ds.SymbolStyle.Color = ColorList[j];
//                    ds.SymbolStyle.Size = 3;
//                    ds.LineStyle.Pattern = LinePatternEnum.None;
//                    if (j == 0) ds.Label = "P";
//                    else if (j == 1) ds.Label = "S";
//                    else if (j == 2) ds.Label = "E";
//                    else if (j == 3) ds.Label = "I";
//                    else if (j == 4) ds.Label = "R";
//                    else if (j == 5) ds.Label = "V";
////                    else if (j == 6) ds.Label = "D";
//                    ds.LegendEntry = true;

//                    chartSpatialDisplay.ChartGroups.Group0.ChartData.SeriesList.Add(ds);
//                    chartSpatialDisplay.Legend.Visible = true;

//                    chartSpatialDisplay.Update();
//                }
            }

            mOS.startRuns(runs, years, days);

            for (int r = 1; r <= runs; r++)
            {
                progressBar1.Value = r;
                mOS.Iter = r;
                mOS.runO(years, days, showingSpatial);
            }
            mOS.endRun();

            Cursor.Current = Cursors.Default;

            label4.Visible = true;

            btnResults.Enabled = mOS.runsDone;
        }

        //public void spatialPlotPoints(int year, int day)
        //{
        //    chartSpatialDisplay.ChartGroups.Group0.ChartData.SeriesList.Clear();
        //    for (int j = 0; j < 7; j++)
        //    {
        //        C1.Win.C1Chart.ChartDataSeries ds = new C1.Win.C1Chart.ChartDataSeries();

        //        ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Circle;
        //        ds.SymbolStyle.Color = ColorList[j];
        //        ds.SymbolStyle.Size = 3;
        //        ds.LineStyle.Pattern = LinePatternEnum.None;

        //        for (int i = 0; i < mOS.OIndivids.Count; i++) // this nesting probably isn't the fastest ...
        //        {
        //            OIndividual oind = mOS.OIndivids[i];
        //            if (oind.iDz != j) continue;

        //            ds.X.Add(oind.X);
        //            ds.Y.Add(oind.Y);
        //        }

        //        chartSpatialDisplay.ChartGroups.Group0.ChartData.SeriesList.Add(ds);
        //    }
        //}

        private void chkOutYearly_CheckedChanged(object sender, EventArgs e)
        {
            mOS.outYearly = chkOutYearly.Checked;
        }

        private void chkOutEpiRates_CheckedChanged(object sender, EventArgs e)
        {
            mOS.outEpiRates = chkOutEpiRates.Checked;
        }

        private void chkOutIndList_CheckedChanged(object sender, EventArgs e)
        {
            mOS.outIndList = chkOutIndList.Checked;
        }

        private void chkOutIndividuals_CheckedChanged(object sender, EventArgs e)
        {
            mOS.outIndividuals = chkOutIndividuals.Checked;
        }

        private void chkOutMM_CheckedChanged(object sender, EventArgs e)
        {
            mOS.outMM = chkOutMM.Checked;
        }

        private void chkOutDaily_CheckedChanged(object sender, EventArgs e)
        {
            mOS.outDaily = chkOutDaily.Checked;
        }

        private void txtRunIter_Validating(object sender, CancelEventArgs e)
        {
            mOS.nRuns = Convert.ToInt32(txtRunIter.Text);
        }

        private void txtRunYears_Validating(object sender, CancelEventArgs e)
        {
            mOS.nYears = Convert.ToInt32(txtRunYears.Text);
        }

        private void btnResults_Click(object sender, EventArgs e)
        {
            if (!mOS.runsDone)
            {
                MessageBox.Show("No output is available yet from this session or from prior work stored with this Project. Please Run simulations to obtain results.", "No simulation results!");
                return;
            }

            frmGraphResults frmGraphs = new frmGraphResults(mOS);
            frmGraphs.ShowDialog();
        }

        private void cboScenes_SelectedIndexChanged(object sender, EventArgs e)
        {
            mOS = mOS.mOP.Oscenes[cboScenes.SelectedIndex];
            setupfrm();
        }

        private void chkRunNoDz_CheckedChanged(object sender, EventArgs e)
        {
            mOS.mOP.doDz = !chkRunNoDz.Checked;
        }

        private void frmRun_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;

            OutbreakHelp.LaunchHelp("Run");
        }
    }
}
