﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;
using C1.Win.C1Chart;
using C1.Win.C1FlexGrid;

namespace Outbreak2
{
    public class OGraphs
    {
        int nyears;
        int ndays;
        int nruns;
        OScenario mOS;
        public bool stacked = false;
        public bool graphSE = false;
        public bool graphSD = false;
        public bool counts = true;

        public OGraphs(OScenario OS)
        {
            mOS = OS;
            nyears = mOS.nYears;
            nruns = mOS.nRuns;
            ndays = mOS.nDays;
        }

        // for Dz states
        private System.Drawing.Color[] ColorList = {
            System.Drawing.Color.Blue,  //P
            System.Drawing.Color.Green,  //.Lime,  //S
            System.Drawing.Color.DarkOrange,     //.Cyan,  //E
            System.Drawing.Color.Red,   //I
            System.Drawing.Color.Magenta,  //R
            System.Drawing.Color.Purple,  //V
            System.Drawing.Color.Pink,  // new infections
            System.Drawing.Color.Black, // Deaths
            System.Drawing.Color.MediumBlue,
            System.Drawing.Color.MediumSpringGreen,
            System.Drawing.Color.Orange,
            System.Drawing.Color.HotPink
        };

        // for Demog

        public void makeDzStateGraph(C1Chart chartDz)
        {
            List<double> xdata = new List<double>();
            List<List<double>> ydata = new List<List<double>>();
            List<string> ylabels = new List<string>();

            for (int i = 0; i <= nyears; i++)
            {
                xdata.Add((double)i);
            }

            for (int j = 0; j < 6; j++)
            {
                List<double> y1 = new List<double>();
                for (int i = 0; i <= nyears; i++)
                {
                    y1.Add(mOS.sYDz[i, j]);
                }
                ydata.Add(y1);
            }

            ylabels.Add("P");
            ylabels.Add("S");
            ylabels.Add("E");
            ylabels.Add("I");
            ylabels.Add("R");
            ylabels.Add("V");

            DoPlot(chartDz, "Disease Dynamics", "Year", "", 0.0, 0.0, xdata, ydata, ylabels);

        }

        public void makeDzStateGraph(C1Chart chartDz, bool[] istates, bool[] istages, C1FlexGrid fg)
        {
            List<double> xdata = new List<double>();
            List<List<double>> ydata = new List<List<double>>();
            List<string> ylabels = new List<string>();
            List<int> LineThick = new List<int>();
            List<int> LineColor = new List<int>();

            for (int i = 0; i <= nyears; i++)
            {
                xdata.Add((double)i);
            }

            for (int j = 0; j < 6; j++)
            {
                List<double> y1 = new List<double>();
                if (istates[j])
                {
                    for (int i = 0; i <= nyears; i++)
                    {
                        double sum = 0.0;
                        for (int k = 0; k < 4; k++)
                        {
                            if (istages[k]) sum += mOS.sYStates[i, k, j];
                        }
                        if (counts)
                            y1.Add(sum);
                        else y1.Add(sum / mOS.sYN[i]);
                    }
                    ylabels.Add(((DiseaseState)j).ToString());
                }
                else ylabels.Add(null);

                ydata.Add(y1);
                LineThick.Add(3);
                LineColor.Add(j);
            }

// for newCases
            List<double> ynew = new List<double>();
            if (istates[6])
            {
                for (int i = 0; i <= nyears; i++)
                {
                    double sum = mOS.sYNew[i];
                    if (counts)
                        ynew.Add(sum);
                    else ynew.Add(sum / mOS.sYN[i]);
                }
                ylabels.Add("New Infections");
            }
            else ylabels.Add(null);
            ydata.Add(ynew);
            LineThick.Add(3);
            LineColor.Add(6);

            // for Deaths
            List<double> ydead = new List<double>();
            if (istates[7])
            {
                for (int i = 0; i <= nyears; i++)
                {
                    double sum = mOS.sYNewDeaths[i];
                    if (counts)
                        ydead.Add(sum);
                    else ydead.Add(sum / mOS.sYN[i]);
                }
                ylabels.Add("Deaths");
            }
            else ylabels.Add(null);
            ydata.Add(ydead);
            LineThick.Add(3);
            LineColor.Add(7);

            if (fg != null)
            {
                fg.Cols.Count = nyears + 2;
                for (int c = 1; c <= nyears + 1; c++)
                {
                    fg.Cols[c].TextAlign = TextAlignEnum.RightCenter;
                    fg.Cols[c].Width = 50;
                    fg[0, c] = "Year" + (c - 1).ToString();
                }
                fg[1, 0] = "P-Presusceptible";
                fg[2, 0] = "S-Susceptible";
                fg[3, 0] = "E-Exposed";
                fg[4, 0] = "I-Infectious";
                fg[5, 0] = "R-Resistant";
                fg[6, 0] = "V-Vaccinated";
                fg[7, 0] = "TotalN";
                fg[8, 0] = "NewInfections";
                fg[9, 0] = "DiseaseDeaths";

                for (int j = 0; j < 6; j++)
                {
                    if (istates[j])
                    {
                        fg.Rows[j + 1].Visible = true;
                        if (counts)
                        {
                            for (int i = 0; i <= nyears; i++) fg[j + 1, i + 1] = (ydata[j][i]).ToString("0.00");
                        }
                        else
                        {
                            for (int i = 0; i <= nyears; i++) fg[j + 1, i + 1] = (ydata[j][i]).ToString("0.0000");
                        }
                    }
                    else fg.Rows[j + 1].Visible = false;
                }
                for (int i = 0; i <= nyears; i++) fg[7, i + 1] = mOS.sYN[i].ToString("0");

                if (istates[6])
                {
                    fg.Rows[8].Visible = true;
                    if (counts)
                    {
                        for (int i = 0; i <= nyears; i++) fg[8, i + 1] = (ydata[6][i]).ToString("0.00");
                    }
                    else
                    {
                        for (int i = 0; i <= nyears; i++) fg[8, i + 1] = (ydata[6][i]).ToString("0.0000");
                    }
                }
                else fg.Rows[8].Visible = false;

                if (istates[7])
                {
                    fg.Rows[9].Visible = true;
                    if (counts)
                    {
                        for (int i = 0; i <= nyears; i++) fg[9, i + 1] = (ydata[7][i]).ToString("0.00");
                    }
                    else
                    {
                        for (int i = 0; i <= nyears; i++) fg[9, i + 1] = (ydata[7][i]).ToString("0.0000");
                    }
                }
                else fg.Rows[9].Visible = false;
            }

            if (graphSD)
            {
                for (int j = 0; j < 8; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istates[j])
                    {
                        if (j < 6)
                        {
                            for (int i = 0; i <= nyears; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sYDz[i, j] + mOS.ssYDz[i, j]);
                                else
                                    y1.Add(mOS.sYDz[i, j] / mOS.sYN[i] + mOS.ssYDz[i, j] / mOS.sYN[i]);
                            }
                        }
                        else if (j == 6)
                        {
                            for (int i = 0; i <= nyears; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sYNew[i] + mOS.ssYNew[i]);
                                else
                                    y1.Add(mOS.sYNew[i] / mOS.sYN[i] + mOS.ssYNew[i] / mOS.sYN[i]);
                            }
                        }
                        else if (j == 7)
                        {
                            for (int i = 0; i <= nyears; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sYNewDeaths[i] + mOS.ssYNewDeaths[i]);
                                else
                                    y1.Add(mOS.sYNewDeaths[i] / mOS.sYN[i] + mOS.ssYNewDeaths[i] / mOS.sYN[i]);
                            }
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }

                for (int j = 0; j < 8; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istates[j])
                    {
                        if (j < 6)
                        {
                            for (int i = 0; i <= nyears; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sYDz[i, j] - mOS.ssYDz[i, j]);
                                else
                                    y1.Add(mOS.sYDz[i, j] / mOS.sYN[i] - mOS.ssYDz[i, j] / mOS.sYN[i]);
                            }
                        }
                        else if (j == 6)
                        {
                            for (int i = 0; i <= nyears; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sYNew[i] - mOS.ssYNew[i]);
                                else
                                    y1.Add(mOS.sYNew[i] / mOS.sYN[i] - mOS.ssYNew[i] / mOS.sYN[i]);
                            }
                        }
                        else 
                        {
                            for (int i = 0; i <= nyears; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sYNewDeaths[i] - mOS.ssYNewDeaths[i]);
                                else
                                    y1.Add(mOS.sYNewDeaths[i] / mOS.sYN[i] - mOS.ssYNewDeaths[i] / mOS.sYN[i]);
                            }
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }
            }

            else if (graphSE)
            {
                for (int j = 0; j < 8; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istates[j])
                    {
                        if (j < 6)
                        {
                            for (int i = 0; i <= nyears; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sYDz[i, j] + mOS.ssYDz[i, j] / Math.Sqrt(nruns));
                                else
                                    y1.Add(mOS.sYDz[i, j] / mOS.sYN[i] + mOS.ssYDz[i, j] / (Math.Sqrt(nruns) * mOS.sYN[i]));
                            }
                        }
                        else if (j == 6)
                        {
                            for (int i = 0; i <= nyears; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sYNew[i] + mOS.ssYNew[i] / Math.Sqrt(nruns));
                                else
                                    y1.Add(mOS.sYNew[i] / mOS.sYN[i] + mOS.ssYNew[i] / (Math.Sqrt(nruns) * mOS.sYN[i]));
                            }
                        }
                        else if (j == 7)
                        {
                            for (int i = 0; i <= nyears; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sYNewDeaths[i] + mOS.ssYNewDeaths[i] / Math.Sqrt(nruns));
                                else
                                    y1.Add(mOS.sYNewDeaths[i] / mOS.sYN[i] + mOS.ssYNewDeaths[i] / (Math.Sqrt(nruns) * mOS.sYN[i]));
                            }
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }

                for (int j = 0; j < 8; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istates[j])
                    {
                        if (j < 6)
                        {
                            for (int i = 0; i <= nyears; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sYDz[i, j] - mOS.ssYDz[i, j] / Math.Sqrt(nruns));
                                else
                                    y1.Add(mOS.sYDz[i, j] / mOS.sYN[i] - mOS.ssYDz[i, j] / (Math.Sqrt(nruns) * mOS.sYN[i]));
                            }
                        }
                        else if(j == 6)
                        {
                            for (int i = 0; i <= nyears; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sYNew[i] - mOS.ssYNew[i] / Math.Sqrt(nruns));
                                else
                                    y1.Add(mOS.sYNew[i] / mOS.sYN[i] - mOS.ssYNew[i] / (Math.Sqrt(nruns) * mOS.sYN[i]));
                            }
                        }
                        else if (j == 7)
                        {
                            for (int i = 0; i <= nyears; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sYNewDeaths[i] - mOS.ssYNewDeaths[i] / Math.Sqrt(nruns));
                                else
                                    y1.Add(mOS.sYNewDeaths[i] / mOS.sYN[i] - mOS.ssYNewDeaths[i] / (Math.Sqrt(nruns) * mOS.sYN[i]));
                            }
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }
            }

            double ymax = 1.0;
            if (counts)
            {
                ymax = ListMax(ydata);
                if (stacked)
                {
                    for (int i = 0; i <= nyears; i++)
                    {
                        double d1 = 0.0;
                        for (int j = 0; j < 6; j++)
                        {
                            d1 += mOS.sYDz[i, j];
                        }

                        if (d1 > ymax) ymax = d1;
                    }
                }
            }

            Color[] colors = new Color[LineColor.Count];
            for (int i = 0; i < LineColor.Count; i++) colors[i] = ColorList[LineColor[i]];

            DoPlot(chartDz, "Disease Dynamics", "Year", "", 0.0, ymax, xdata, ydata, ylabels, colors, LineThick);

        }

        public void makeDzYearGraph(C1Chart chartDz, bool[] istates, bool[] istages, int yr, C1FlexGrid fg)
        {
            List<double> xdata = new List<double>();
            List<List<double>> ydata = new List<List<double>>();
            List<string> ylabels = new List<string>();
            List<int> LineThick = new List<int>();
            List<int> LineColor = new List<int>();

            double[] dayN = new double[ndays + 1];

            for (int i = 1; i <= ndays; i++)
            {
                xdata.Add((double)i);
                double tsum = 0.0;
                for (int j = 0; j < 6; j++)
                {
                    tsum += mOS.sDDz[yr, i, j];
                }
                dayN[i] = tsum;
            }

            for (int j = 0; j < 8; j++)
            {
                List<double> y1 = new List<double>();
                if (istates[j])
                {
                    if (j < 6)
                    {
                        for (int i = 1; i <= ndays; i++)
                        {
                            double sum = 0.0;
                            for (int k = 0; k < 4; k++)
                            {
                                if (istages[k]) sum += mOS.sDStates[yr, i, k, j];
                            }
                            if (counts) y1.Add(sum);
                            else y1.Add(sum / dayN[i]);
                        }
                        ylabels.Add(((DiseaseState)j).ToString());
                    }
                    else if(j == 6)
                    {
                        for (int i = 1; i <= ndays; i++)
                        {
                            double sum = mOS.sDNewCases[yr, i];
                            if (counts) y1.Add(sum);
                            else y1.Add(sum / dayN[i]);
                        }
                        ylabels.Add("New Infections");
                    }
                    else if (j == 7)
                    {
                        for (int i = 1; i <= ndays; i++)
                        {
                            double sum = mOS.sDNewDeaths[yr, i];
                            if (counts) y1.Add(sum);
                            else y1.Add(sum / dayN[i]);
                        }
                        ylabels.Add("Deaths");
                    }
                }
                else ylabels.Add(null);

                ydata.Add(y1);
                LineThick.Add(3);
                LineColor.Add(j);
            }

            if (fg != null)
            {
                fg.Cols.Count = ndays + 1;
                for (int c = 1; c <= ndays; c++)
                {
                    fg.Cols[c].TextAlign = TextAlignEnum.RightCenter;
                    fg.Cols[c].Width = 50;
                    fg[0, c] = "Day" + c.ToString();
                }
                fg[1, 0] = "P-Presusceptible";
                fg[2, 0] = "S-Susceptible";
                fg[3, 0] = "E-Exposed";
                fg[4, 0] = "I-Infectious";
                fg[5, 0] = "R-Resistant";
                fg[6, 0] = "V-Vaccinated";
                fg[7, 0] = "TotalN";
                fg[8, 0] = "NewInfections";
                fg[9, 0] = "DiseaseDeaths";

                for (int j = 0; j < 6; j++)
                {
                    if (istates[j])
                    {
                        fg.Rows[j + 1].Visible = true;
                        if (counts)
                        {
                            for (int i = 1; i <= ndays; i++) fg[j + 1, i] = (ydata[j][i - 1]).ToString("0.00");
                        }
                        else
                        {
                            for (int i = 1; i <= ndays; i++) fg[j + 1, i] = (ydata[j][i - 1]).ToString("0.0000");
                        }
                    }
                    else fg.Rows[j + 1].Visible = false;
                }
                for (int i = 1; i <= ndays; i++) fg[7, i] = dayN[i].ToString("0");
                if (istates[6])
                {
                    fg.Rows[8].Visible = true;
                    if (counts)
                    {
                        for (int i = 1; i <= ndays; i++) fg[8, i] = (ydata[6][i - 1]).ToString("0.00");
                    }
                    else
                    {
                        for (int i = 1; i <= ndays; i++) fg[8, i] = (ydata[6][i - 1]).ToString("0.0000");
                    }
                }
                else fg.Rows[8].Visible = false;
                if (istates[7])
                {
                    fg.Rows[9].Visible = true;
                    if (counts)
                    {
                        for (int i = 1; i <= ndays; i++) fg[9, i] = (ydata[7][i - 1]).ToString("0.00");
                    }
                    else
                    {
                        for (int i = 1; i <= ndays; i++) fg[9, i] = (ydata[7][i - 1]).ToString("0.0000");
                    }
                }
                else fg.Rows[9].Visible = false;
            }

            if (graphSD)
            {
                for (int j = 0; j < 8; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istates[j])
                    {
                        if (j < 6)
                        {
                            for (int i = 1; i <= ndays; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sDDz[yr, i, j] + mOS.ssDDz[yr, i, j]);
                                else
                                    y1.Add(mOS.sDDz[yr, i, j] / dayN[i] + mOS.ssDDz[yr, i, j] / dayN[i]);
                            }
                        }
                        else if(j == 6)
                        {
                            for (int i = 1; i <= ndays; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sDNewCases[yr, i] + mOS.ssDNewCases[yr, i]);
                                else
                                    y1.Add(mOS.sDNewCases[yr, i] / dayN[i] + mOS.ssDNewCases[yr, i] / dayN[i]);
                            }
                        }
                        else if (j == 7)
                        {
                            for (int i = 1; i <= ndays; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sDNewDeaths[yr, i] + mOS.ssDNewDeaths[yr, i]);
                                else
                                    y1.Add(mOS.sDNewDeaths[yr, i] / dayN[i] + mOS.ssDNewDeaths[yr, i] / dayN[i]);
                            }
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }

                for (int j = 0; j < 8; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istates[j])
                    {
                        if (j < 6)
                        {
                            for (int i = 1; i <= ndays; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sDDz[yr, i, j] - mOS.ssDDz[yr, i, j]);
                                else
                                    y1.Add(mOS.sDDz[yr, i, j] / dayN[i] - mOS.ssDDz[yr, i, j] / dayN[i]);
                            }
                        }
                        else if(j == 6)
                        {
                            for (int i = 1; i <= ndays; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sDNewCases[yr, i] - mOS.ssDNewCases[yr, i]);
                                else
                                    y1.Add(mOS.sDNewCases[yr, i] / dayN[i] - mOS.ssDNewCases[yr, i] / dayN[i]);
                            }
                        }
                        else if (j == 7)
                        {
                            for (int i = 1; i <= ndays; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sDNewDeaths[yr, i] - mOS.ssDNewDeaths[yr, i]);
                                else
                                    y1.Add(mOS.sDNewDeaths[yr, i] / dayN[i] - mOS.ssDNewDeaths[yr, i] / dayN[i]);
                            }
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }
            }

            else if (graphSE)
            {
                for (int j = 0; j < 8; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istates[j])
                    {
                        if (j < 6)
                        {
                            for (int i = 1; i <= ndays; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sDDz[yr, i, j] + mOS.ssDDz[yr, i, j] / Math.Sqrt(nruns));
                                else
                                    y1.Add(mOS.sDDz[yr, i, j] / dayN[i] + mOS.ssDDz[yr, i, j] / (Math.Sqrt(nruns) * dayN[i]));
                            }
                        }
                        else if(j == 6)
                        {
                            for (int i = 1; i <= ndays; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sDNewCases[yr, i] + mOS.ssDNewCases[yr, i] / Math.Sqrt(nruns));
                                else
                                    y1.Add(mOS.sDNewCases[yr, i] / dayN[i] + mOS.ssDNewCases[yr, i] / (Math.Sqrt(nruns) * dayN[i]));
                            }
                        }
                        else if (j == 7)
                        {
                            for (int i = 1; i <= ndays; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sDNewDeaths[yr, i] + mOS.ssDNewDeaths[yr, i] / Math.Sqrt(nruns));
                                else
                                    y1.Add(mOS.sDNewDeaths[yr, i] / dayN[i] + mOS.ssDNewDeaths[yr, i] / (Math.Sqrt(nruns) * dayN[i]));
                            }
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }

                for (int j = 0; j < 8; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istates[j])
                    {
                        if (j < 6)
                        {
                            for (int i = 1; i <= ndays; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sDDz[yr, i, j] - mOS.ssDDz[yr, i, j] / Math.Sqrt(nruns));
                                else
                                    y1.Add(mOS.sDDz[yr, i, j] / dayN[i] - mOS.ssDDz[yr, i, j] / (Math.Sqrt(nruns) * dayN[i]));
                            }
                        }
                        else if(j == 6)
                        {
                            for (int i = 1; i <= ndays; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sDNewCases[yr, i] - mOS.ssDNewCases[yr, i] / Math.Sqrt(nruns));
                                else
                                    y1.Add(mOS.sDNewCases[yr, i] / dayN[i] - mOS.ssDNewCases[yr, i] / (Math.Sqrt(nruns) * dayN[i]));
                            }
                        }
                        else if (j == 7)
                        {
                            for (int i = 1; i <= ndays; i++)
                            {
                                if (counts)
                                    y1.Add(mOS.sDNewDeaths[yr, i] - mOS.ssDNewDeaths[yr, i] / Math.Sqrt(nruns));
                                else
                                    y1.Add(mOS.sDNewDeaths[yr, i] / dayN[i] - mOS.ssDNewDeaths[yr, i] / (Math.Sqrt(nruns) * dayN[i]));
                            }
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }
            }

            double ymax = 1.0;
            if (counts)
            {
                ymax = ListMax(ydata);
                if (stacked)
                {
                    ymax = ListMax(dayN.ToList());
                }
            }

            Color[] colors = new Color[LineColor.Count];
            for (int i = 0; i < LineColor.Count; i++) colors[i] = ColorList[LineColor[i]];

            DoPlot(chartDz, "Disease Dynamics", "Day", "", 0.0, ymax, xdata, ydata, ylabels, colors, LineThick);
        }

        
        public void makeStageGraph(C1Chart chartDemog)
        {
            List<double> xdata = new List<double>();
            List<List<double>> ydata = new List<List<double>>();
            List<string> ylabels = new List<string>();

            for (int i = 0; i <= nyears; i++)
            {
                xdata.Add((double)i);
            }

            for (int j = 0; j < 4; j++)
            {
                List<double> y1 = new List<double>();
                for (int i = 0; i <= nyears; i++)
                {
                    y1.Add(mOS.sYStages[i, j]);
                }
                ydata.Add(y1);
            }

            ylabels.Add("Juveniles");
            ylabels.Add("SubAdults");
            ylabels.Add("Adult Males");
            ylabels.Add("Adult Females");

            DoPlot(chartDemog, "Demographic Dynamics", "Year", "", 0.0, 0.0, xdata, ydata, ylabels);
        }

        // why couldn't SD/SE lines be added if not showing all stages (in earlier code)?
        public void makeDemogGraph(C1Chart chartDemog, bool[] istates, bool[] istages, C1FlexGrid fg)
        {
            List<double> xdata = new List<double>();
            List<List<double>> ydata = new List<List<double>>();
            List<string> ylabels = new List<string>();
            List<int> LineThick = new List<int>();
            List<int> LineColor = new List<int>();

            for (int i = 0; i <= nyears; i++)
            {
                xdata.Add((double)i);
            }

            for (int j = 0; j < 4; j++)
            {
                List<double> y1 = new List<double>();
                if (istages[j])
                {
                    for (int i = 0; i <= nyears; i++)
                    {
                        double sum = 0.0;
                        for (int k = 0; k < 6; k++)
                        {
                            if (istates[k]) sum += mOS.sYStates[i, j, k];
                        }
                        if (counts)
                            y1.Add(sum);
                        else y1.Add(sum / mOS.sYN[i]);
                    }
                    ylabels.Add(((DemogStage)j).ToString());
                }
                else ylabels.Add(null);

                ydata.Add(y1);
                LineThick.Add(3);
                LineColor.Add(j);
            }

            if (fg != null)
            {
                fg.Cols.Count = nyears + 2;
                for (int c = 1; c <= nyears + 1; c++)
                {
                    fg.Cols[c].TextAlign = TextAlignEnum.RightCenter;
                    fg.Cols[c].Width = 50;
                    fg[0, c] = "Year" + (c - 1).ToString();
                }
                fg[1, 0] = "Juveniles";
                fg[2, 0] = "SubAdults";
                fg[3, 0] = "AdultMales";
                fg[4, 0] = "AdultFemales";
                fg[5, 0] = "TotalN";

                for (int j = 0; j < 4; j++)
                {
                    if (istages[j])
                    {
                        fg.Rows[j + 1].Visible = true;
                        if (counts)
                        {
                            for (int i = 0; i <= nyears; i++) fg[j + 1, i + 1] = (ydata[j][i]).ToString("0.00");
                        }
                        else
                        {
                            for (int i = 0; i <= nyears; i++) fg[j + 1, i + 1] = (ydata[j][i]).ToString("0.0000");
                        }
                    }
                    else fg.Rows[j + 1].Visible = false;
                }
                for (int i = 0; i <= nyears; i++) fg[5, i + 1] = mOS.sYN[i].ToString("0");
            }

            if (graphSD)
            {
                for (int j = 0; j < 4; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istages[j])
                    {
                        for (int i = 0; i <= nyears; i++)
                        {
                            if (counts)
                                y1.Add(mOS.sYStages[i, j] + mOS.ssYStages[i, j]);
                            else
                                y1.Add(mOS.sYStages[i, j] / mOS.sYN[i] + mOS.ssYStages[i, j] / mOS.sYN[i]);
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }

                for (int j = 0; j < 4; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istages[j])
                    {
                        for (int i = 0; i <= nyears; i++)
                        {
                            if (counts)
                                y1.Add(mOS.sYStages[i, j] - mOS.ssYStages[i, j]);
                            else
                                y1.Add(mOS.sYStages[i, j] / mOS.sYN[i] - mOS.ssYStages[i, j] / mOS.sYN[i]);
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }
            }

            else if (graphSE)
            {
                for (int j = 0; j < 4; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istages[j])
                    {
                        for (int i = 0; i <= nyears; i++)
                        {
                            if (counts)
                                y1.Add(mOS.sYStages[i, j] + mOS.ssYStages[i, j] / Math.Sqrt(nruns));
                            else
                                y1.Add(mOS.sYStages[i, j] / mOS.sYN[i] + mOS.ssYStages[i, j] / (Math.Sqrt(nruns) * mOS.sYN[i]));
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }

                for (int j = 0; j < 4; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istages[j])
                    {
                        for (int i = 0; i <= nyears; i++)
                        {
                            if (counts)
                                y1.Add(mOS.sYStages[i, j] - mOS.ssYStages[i, j] / Math.Sqrt(nruns));
                            else
                                y1.Add(mOS.sYStages[i, j] / mOS.sYN[i] - mOS.ssYStages[i, j] / (Math.Sqrt(nruns) * mOS.sYN[i]));
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }
            }

            double ymax = 1.0;
            if (counts)
            {
                ymax = ListMax(ydata);
                if (stacked)
                {
                    for (int i = 0; i <= nyears; i++)
                    {
                        double d1 = 0.0;
                        for (int j = 0; j < 4; j++)
                        {
                            d1 += mOS.sYStages[i, j];
                        }

                        if (d1 > ymax) ymax = d1;
                    }
                }
            }

            Color[] colors = new Color[LineColor.Count];
            for (int i = 0; i < LineColor.Count; i++) colors[i] = ColorList[LineColor[i]];

            DoPlot(chartDemog, "Demographic Dynamics", "Year", "", 0.0, ymax, xdata, ydata, ylabels, colors, LineThick);

        }

        public void makeDemogYearGraph(C1Chart chartDemog, bool[] istates, bool[] istages, int yr, C1FlexGrid fg)
        {
            List<double> xdata = new List<double>();
            List<List<double>> ydata = new List<List<double>>();
            List<string> ylabels = new List<string>();
            List<int> LineThick = new List<int>();
            List<int> LineColor = new List<int>();

            double[] dayN = new double[ndays + 1];

            for (int i = 1; i <= ndays; i++)
            {
                xdata.Add((double)i);
                double tsum = 0.0;
                for (int j = 0; j < 4; j++)
                {
                    tsum += mOS.sDStages[yr, i, j];
                }
                dayN[i] = tsum;
            }

            for (int j = 0; j < 4; j++)
            {
                List<double> y1 = new List<double>();
                if (istages[j])
                {
                    for (int i = 1; i <= ndays; i++)
                    {
                        double sum = 0.0;
                        for (int k = 0; k < 6; k++)
                        {
                            if (istates[k]) sum += mOS.sDStates[yr, i, j, k];
                        }
                        if (counts) y1.Add(sum);
                        else y1.Add(sum / dayN[i]);
                    }
                    ylabels.Add(((DemogStage)j).ToString());
                }
                else ylabels.Add(null);

                ydata.Add(y1);
                LineThick.Add(3);
                LineColor.Add(j);
            }

            if (fg != null)
            {
                fg.Cols.Count = ndays + 1;
                for (int c = 1; c <= ndays; c++)
                {
                    fg.Cols[c].TextAlign = TextAlignEnum.RightCenter;
                    fg.Cols[c].Width = 50;
                    fg[0, c] = "Day" + c.ToString();
                }
                fg[1, 0] = "Juveniles";
                fg[2, 0] = "SubAdults";
                fg[3, 0] = "AdultMales";
                fg[4, 0] = "AdultFemales";
                fg[5, 0] = "TotalN";

                for (int j = 0; j < 4; j++)
                {
                    if (istages[j])
                    {
                        fg.Rows[j + 1].Visible = true;
                        if (counts)
                        {
                            for (int i = 1; i <= ndays; i++) fg[j + 1, i] = (ydata[j][i - 1]).ToString("0.00");
                        }
                        else
                        {
                            for (int i = 1; i <= ndays; i++) fg[j + 1, i] = (ydata[j][i - 1]).ToString("0.0000");
                        }
                    }
                    else fg.Rows[j + 1].Visible = false;
                }
                for (int i = 1; i <= ndays; i++) fg[5, i] = dayN[i].ToString("0");
            }

            if (graphSD)
            {
                for (int j = 0; j < 4; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istages[j])
                    {
                        for (int i = 1; i <= ndays; i++)
                        {
                            if (counts)
                                y1.Add(mOS.sDStages[yr, i, j] + mOS.ssDStages[yr, i, j]);
                            else
                                y1.Add(mOS.sDStages[yr, i, j] / dayN[i] + mOS.ssDStages[yr, i, j] / dayN[i]);
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }

                for (int j = 0; j < 4; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istages[j])
                    {
                        for (int i = 1; i <= ndays; i++)
                        {
                            if (counts)
                                y1.Add(mOS.sDStages[yr, i, j] - mOS.ssDStages[yr, i, j]);
                            else
                                y1.Add(mOS.sDStages[yr, i, j] / dayN[i] - mOS.ssDStages[yr, i, j] / dayN[i]);
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }
            }

            else if (graphSE)
            {
                for (int j = 0; j < 4; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istages[j])
                    {
                        for (int i = 1; i <= ndays; i++)
                        {
                            if (counts)
                                y1.Add(mOS.sDStages[yr, i, j] + mOS.ssDStages[yr, i, j] / Math.Sqrt(nruns));
                            else
                                y1.Add(mOS.sDStages[yr, i, j] / dayN[i] + mOS.ssDStages[yr, i, j] / (Math.Sqrt(nruns) * dayN[i]));
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }

                for (int j = 0; j < 4; j++)
                {
                    List<double> y1 = new List<double>();
                    if (istages[j])
                    {
                        for (int i = 1; i <= ndays; i++)
                        {
                            if (counts)
                                y1.Add(mOS.sDStages[yr, i, j] - mOS.ssDStages[yr, i, j] / Math.Sqrt(nruns));
                            else
                                y1.Add(mOS.sDStages[yr, i, j] / dayN[i] - mOS.ssDStages[yr, i, j] / (Math.Sqrt(nruns) * dayN[i]));
                        }
                    }
                    ylabels.Add(null);
                    ydata.Add(y1);
                    LineThick.Add(1);
                    LineColor.Add(j);
                }
            }

            double ymax = 1.0;
            if (counts)
            {
                ymax = ListMax(ydata);
                if (stacked)
                {
                    ymax = ListMax(dayN.ToList());
                }
            }

            Color[] colors = new Color[LineColor.Count];
            for (int i = 0; i < LineColor.Count; i++) colors[i] = ColorList[LineColor[i]];

            DoPlot(chartDemog, "Demographic Dynamics", "Day", "", 0.0, ymax, xdata, ydata, ylabels, colors, LineThick);
        }


        public void makePie(C1Chart chartPie, double P, double S, double E, double I, double R, double V)
        {
            chartPie.ChartGroups.Group0.ChartData.SeriesList.Clear();

            C1.Win.C1Chart.ChartDataSeries ds1 = new C1.Win.C1Chart.ChartDataSeries();
            ds1.Label = "P";
            ds1.X.Add(1);
            ds1.Y.Add(P);
            ds1.FillStyle.Color1 = ColorList[0];

            C1.Win.C1Chart.ChartDataSeries ds2 = new C1.Win.C1Chart.ChartDataSeries();
            ds2.Label = "S";
            ds2.X.Add(1);
            ds2.Y.Add(S);
            ds2.FillStyle.Color1 = ColorList[1];

            C1.Win.C1Chart.ChartDataSeries ds3 = new C1.Win.C1Chart.ChartDataSeries();
            ds3.Label = "E";
            ds3.X.Add(1);
            ds3.Y.Add(E);
            ds3.FillStyle.Color1 = ColorList[2];

            C1.Win.C1Chart.ChartDataSeries ds4 = new C1.Win.C1Chart.ChartDataSeries();
            ds4.Label = "I";
            ds4.X.Add(1);
            ds4.Y.Add(I);
            ds4.FillStyle.Color1 = ColorList[3];

            C1.Win.C1Chart.ChartDataSeries ds5 = new C1.Win.C1Chart.ChartDataSeries();
            ds5.Label = "R";
            ds5.X.Add(1);
            ds5.Y.Add(R);
            ds5.FillStyle.Color1 = ColorList[4];

            C1.Win.C1Chart.ChartDataSeries ds6 = new C1.Win.C1Chart.ChartDataSeries();
            ds6.Label = "V";
            ds6.X.Add(1);
            ds6.Y.Add(V);
            ds6.FillStyle.Color1 = ColorList[5];

            chartPie.ChartGroups.Group0.ChartData.SeriesList.Add(ds6);
            chartPie.ChartGroups.Group0.ChartData.SeriesList.Add(ds5);
            chartPie.ChartGroups.Group0.ChartData.SeriesList.Add(ds4);
            chartPie.ChartGroups.Group0.ChartData.SeriesList.Add(ds3);
            chartPie.ChartGroups.Group0.ChartData.SeriesList.Add(ds2);
            chartPie.ChartGroups.Group0.ChartData.SeriesList.Add(ds1);

            chartPie.ChartGroups.Group0.LegendReversed = true;
        }


        // Prevalence
        public void makePrevGraph(C1Chart chartPrev)
        {
            List<double> xdata = new List<double>();
            List<List<double>> ydata = new List<List<double>>();
            List<string> ylabels = new List<string>();

            for (int i = 0; i <= nyears; i++)
            {
                xdata.Add((double)i);
            }

            List<double> y1;
            for (int j = 1; j <= nruns; j++)
            {
                y1 = new List<double>();
                for (int i = 0; i <= nyears; i++)
                {
                    y1.Add(mOS.yPrev[i, j]);
                }
                ydata.Add(y1);
            }
            y1 = new List<double>();
            for (int i = 0; i <= nyears; i++)
            {
                y1.Add(mOS.syPrev[i]);
            }
            ydata.Add(y1);

            Color[] ColorGrey = new Color[nruns + 1];
            List<int> lineThick = new List<int>();
            for (int i = 0; i < nruns; i++)
            {
                ColorGrey[i] = Color.LightGray;
                lineThick.Add(1);
                ylabels.Add(null);
            }
            ylabels[0] = "Iterations";
            ColorGrey[nruns] = Color.Black;
            lineThick.Add(3);
            ylabels.Add("Mean");

            DoPlot(chartPrev, "Disease Prevalence", "Year", "", 0.0, 0.0, xdata, ydata, ylabels, ColorGrey, lineThick);

        }

        // N
        public void makeNGraph(C1Chart chartPrev)
        {
            List<double> xdata = new List<double>();
            List<List<double>> ydata = new List<List<double>>();
            List<string> ylabels = new List<string>();

            for (int i = 0; i <= nyears; i++)
            {
                xdata.Add((double)i);
            }

            List<double> y1;
            for (int j = 1; j <= nruns; j++)
            {
                y1 = new List<double>();
                for (int i = 0; i <= nyears; i++)
                {
                    y1.Add(mOS.ryN[j,i]);
                }
                ydata.Add(y1);
            }

            y1 = new List<double>();
            for (int i = 0; i <= nyears; i++)
            {
                y1.Add(mOS.sYN[i]);
            }
            ydata.Add(y1);

            Color[] ColorGrey = new Color[nruns + 1];
            List<int> lineThick = new List<int>();
            for (int i = 0; i < nruns; i++)
            {
                ColorGrey[i] = Color.LightGray;
                lineThick.Add(1);
                ylabels.Add(null);
            }
            ylabels[0] = "Iterations";
            ColorGrey[nruns] = Color.Black;
            lineThick.Add(3);
            ylabels.Add("Mean");

            DoPlot(chartPrev, "Population Size", "Year", "", 0.0, 0.0, xdata, ydata, ylabels, ColorGrey, lineThick);
        }

        // PE 
        public void makePEGraph(C1Chart chartPrev)
        {
            List<double> xdata = new List<double>();
            List<List<double>> ydata = new List<List<double>>();
            List<string> ylabels = new List<string>();

            for (int i = 0; i <= nyears; i++)
            {
                xdata.Add((double)i);
            }

            List<double> y1 = new List<double>();
            for (int i = 0; i <= nyears; i++)
            {
                y1.Add(calcPE(i));
            }
            ydata.Add(y1);

            Color[] ColorGrey = new Color[1];
            List<int> lineThick = new List<int>();
            ColorGrey[0] = Color.Black;
            lineThick.Add(3);
            ylabels.Add("Prob. Extinction");

            DoPlot(chartPrev, "Probability Extinct", "Year", "", 0.0, 0.0, xdata, ydata, ylabels, ColorGrey, lineThick);
        }

        private double calcPE(int yr)
        {
            double pe = 0;

//            if (mOS.ryN == null || mOS.ryN.GetLength(0) == 0 || mOS.ryN.GetLength(1) == 0) return -1.0;

            for (int i = 1; i <= nruns; i++) if (mOS.ryN[i, yr] == 0) pe += 1.0;
            pe /= (double)nruns;

            return pe;
        }

        // QE-terminal 
        public void makeQETGraph(C1Chart chartPrev)
        {
            List<double> xdata = new List<double>();
            List<List<double>> ydata = new List<List<double>>();
            List<string> ylabels = new List<string>();

            List<double> y1 = calcQuasiTerm();
            ydata.Add(y1);

            for (int i = 0; i < y1.Count; i++)
            {
                xdata.Add((double)i);
            }

            Color[] ColorGrey = new Color[1];
            List<int> lineThick = new List<int>();
            ColorGrey[0] = Color.Black;
            lineThick.Add(3);
            ylabels.Add("Quasi-Extinction");

            DoPlot(chartPrev, "Terminal Quasi-Extinction", "N threshold", "", 0.0, 0.0, xdata, ydata, ylabels, ColorGrey, lineThick);
        }

        // QE-interval 
        public void makeQEIGraph(C1Chart chartPrev)
        {
            List<double> xdata = new List<double>();
            List<List<double>> ydata = new List<List<double>>();
            List<string> ylabels = new List<string>();

            List<double> y1 = calcQuasiInterval();
            ydata.Add(y1);

            for (int i = 0; i < y1.Count; i++)
            {
                xdata.Add((double)i);
            }

            Color[] ColorGrey = new Color[1];
            List<int> lineThick = new List<int>();
            ColorGrey[0] = Color.Black;
            lineThick.Add(3);
            ylabels.Add("Quasi-Extinction");

            DoPlot(chartPrev, "Interval Quasi-Extinction", "N threshold", "", 0.0, 0.0, xdata, ydata, ylabels, ColorGrey, lineThick);
        }

        private List<double> calcQuasiInterval()
        {
            List<double> qList;

//            if (mOS.ryN == null || mOS.ryN.GetLength(0) == 0 || mOS.ryN.GetLength(1) == 0) return null;

            List<int> minsList = new List<int>();
            for (int i = 0; i < mOS.ryN.GetLength(0); i++)
            {
                int minN = mOS.ryN[i,0];
                for (int j = 1; j <= mOS.nYears; j++) if (minN > mOS.ryN[i,j]) minN = mOS.ryN[i,j];
                minsList.Add(minN); // a list of min N for each run
            }

            qList = cumFreqDistN(minsList);

            return qList;
        }

        public List<double> calcQuasiTerm()
        {
            List<double> qList;

            //            if (mOS.ryN == null || mOS.ryN.GetLength(0) == 0 || mOS.ryN.GetLength(1) == 0) return null;

            List<int> nList = new List<int>();
            for (int i = 0; i < mOS.nRuns; i++) nList.Add(mOS.ryN[i,nyears]);

            qList = cumFreqDistN(nList);

            return qList;
        }

        // returns a cumulative frequency distribution
        public static List<double> cumFreqDistN(List<int> nlist)
        {
            List<double> nFreq = new List<double>();
            if (nlist == null || nlist.Count == 0) return nFreq;

            int nct = nlist.Count;

            for (int i = 0; i < nct; i++)
            {
                while (nlist[i] >= nFreq.Count) nFreq.Add(0.0);
                nFreq[nlist[i]] += 1.0;
            }

            for (int n = 1; n < nFreq.Count; n++)
            {
                nFreq[n] += nFreq[n - 1];
            }
            for (int n = 0; n < nFreq.Count; n++)
            {
                nFreq[n] /= (double)nct;
            }

            return nFreq;
        }

        
        public void DoPlot(C1Chart chart, string title, string xTitle, string yTitle,
            double yMin, double yMax, List<double> xData, List<List<double>> yData, List<string> yLabels, Color[] listColors, List<int> lineThickness)
        {
            if (xData.Count == 0 || yData.Count == 0) return;

            chart.Visible = true;

            if(!stacked) chart.ChartGroups.Group0.ChartType = Chart2DTypeEnum.XYPlot;
            else chart.ChartGroups.Group0.ChartType = Chart2DTypeEnum.Area;

            chart.Header.Text = title;
            chart.Header.Visible = true;

            chart.ChartGroups.Group0.ChartData.SeriesList.Clear();
            chart.ChartGroups.Group1.ChartData.SeriesList.Clear();
            chart.ChartArea.AxisX.ValueLabels.Clear();

            chart.ChartArea.AxisX.Text = xTitle;
            chart.ChartArea.AxisX.AutoMax = false;
            chart.ChartArea.AxisX.AutoMin = false;
            chart.ChartArea.AxisX.Min = ListMin(xData);
            chart.ChartArea.AxisX.Max = ListMax(xData);

            chart.ChartGroups.Group0.Stacked = stacked;
            //if (counts) chart.ChartGroups.Group0.Is100Percent = false;
            //else chart.ChartGroups.Group0.Is100Percent = true;

            if (yMax == 0.0)
            {
                yMax = ListMax(yData);
            }

            chart.ChartArea.AxisY.Text = yTitle;
            chart.ChartArea.AxisY.Min = yMin;
            chart.ChartArea.AxisY.Max = yMax;

            for (int i = 0; i < yData.Count; i++)
            {
                if (yData[i].Count == 0) continue;

                C1.Win.C1Chart.ChartDataSeries ds = new C1.Win.C1Chart.ChartDataSeries();
                chart.ChartGroups.Group0.ChartData.SeriesList.Add(ds);

                ////Dealing with missing values
                ////Missing values should be specified as -9999 in the datga
                //chart.ChartGroups.Group0.ChartData.Hole = -9999;
                for (int j = 0; j < chart.ChartGroups.Group0.ChartData.SeriesList.Count; j++)
                    chart.ChartGroups.Group0.ChartData.SeriesList[j].Display = SeriesDisplayEnum.ExcludeHoles;

                ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.None;
                ds.LineStyle.Pattern = LinePatternEnum.Solid;
                if (lineThickness == null) ds.LineStyle.Thickness = 2;
                else ds.LineStyle.Thickness = lineThickness[i % lineThickness.Count];
                ds.LineStyle.Color = listColors[i % listColors.Length];

                if (yLabels != null) {
                    if (i < yLabels.Count && yLabels[i] != null && yLabels[i] != "") ds.Label = yLabels[i];
                    else ds.LegendEntry = false;
                }

                for (int j = 0; j < xData.Count; j++)
                {
                    ds.X.Add(xData[j]);
                    ds.Y.Add(yData[i][j]);
                }

            }

            chart.ChartArea.AxisX.AnnoMethod = AnnotationMethodEnum.Values;

            //legend
            if (yLabels == null)
                chart.Legend.Visible = false;
            else
            {
                chart.Legend.Visible = true;
            }
        }


        public void DoPlot(C1Chart chart, string title, string xTitle, string yTitle,
            double yMin, double yMax, List<double> xData, List<List<double>> yData, List<string> yLabels)
        {
            DoPlot(chart, title, xTitle, yTitle, yMin, yMax, xData, yData, yLabels, ColorList, null);
        }

        public static double ListMax(List<double> list)
        {
            if (list == null || list.Count == 0) return 0;

            double d = list[0];

            for (int i = 1; i < list.Count; i++)
                d = Math.Max(d, list[i]);

            return d;
        }

        public static double ListMax(List<List<double>> list)
        {
            if (list == null) return 0;

            double d = -999.0;

            for (int i = 0; i < list.Count; i++)
                for (int j = 0; j < list[i].Count; j++)
                    d = Math.Max(d, list[i][j]);

            return d;
        }

        public static int ListMax(List<List<int>> list)
        {
            if (list == null) return 0;

            int d = -999;

            for (int i = 0; i < list.Count; i++)
                for (int j = 0; j < list[i].Count; j++)
                    d = Math.Max(d, list[i][j]);

            return d;
        }
        public static double ListMin(List<double> list)
        {
            if (list == null || list.Count == 0) return 0;

            double d = list[0];

            for (int i = 1; i < list.Count; i++)
                d = Math.Min(d, list[i]);

            return d;
        }

        public static double ListMin(List<List<double>> list)
        {
            if (list == null || list.Count == 0) return 0;

            double d = 999.0;

            for (int i = 0; i < list.Count; i++)
                for (int j = 0; j < list[i].Count; j++)
                    d = Math.Min(d, list[i][j]);

            return d;
        }

        public bool saveGraph(C1Chart chart)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "PNG Files" + " (*.png)|*.png|JPG Files" + " (*.jpg)|*.jpg|WMF Files" + " (*.wmf)|*.wmf|BMP Files" + " (*.bmp)|*.bmp";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if(dlg.FileName.ToLower().EndsWith("png"))
                        chart.SaveImage(dlg.FileName, System.Drawing.Imaging.ImageFormat.Png);
                    else if (dlg.FileName.ToLower().EndsWith("jpg"))
                        chart.SaveImage(dlg.FileName, System.Drawing.Imaging.ImageFormat.Jpeg);
                    else if (dlg.FileName.ToLower().EndsWith("wmf"))
                        chart.SaveImage(dlg.FileName, System.Drawing.Imaging.ImageFormat.Wmf);
                    else //if (dlg.FileName.ToLower().EndsWith("bmp"))
                        chart.SaveImage(dlg.FileName, System.Drawing.Imaging.ImageFormat.Bmp);
                }
                catch
                {
                    MessageBox.Show("Failure to save the graph.");
                }
            }
            return true;
        }

        public void ExportTable(C1.Win.C1FlexGrid.C1FlexGrid fg)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "TXT " + "Files" + " (*.txt)|*.txt|CSV " + "Files" + " (*.csv)|*.csv|" + "Excel Files" + " (*.xls)|*.xls";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                if (dlg.FileName.EndsWith("txt"))
                    fg.SaveGrid(dlg.FileName, C1.Win.C1FlexGrid.FileFormatEnum.TextTab, C1.Win.C1FlexGrid.FileFlags.IncludeFixedCells | C1.Win.C1FlexGrid.FileFlags.VisibleOnly);
                else if (dlg.FileName.EndsWith("xls"))
                    fg.SaveExcel(dlg.FileName, C1.Win.C1FlexGrid.FileFlags.IncludeFixedCells | C1.Win.C1FlexGrid.FileFlags.VisibleOnly);
                else
                    fg.SaveGrid(dlg.FileName, C1.Win.C1FlexGrid.FileFormatEnum.TextComma, C1.Win.C1FlexGrid.FileFlags.IncludeFixedCells | C1.Win.C1FlexGrid.FileFlags.VisibleOnly);
            }
        }
    }

}
