﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.XPath;

namespace Outbreak2
{
    public partial class Outbreak2 : Form
    {
        public double prPermanentP = 0.0;
        public int minDaysP = 0;
        public int maxDaysP = 1;

        public bool usePropEncounter = true;
        public bool useFixedNEncounter = false;
        public bool useDistanceEncounter = false;
        public double prPopEncounter = 0.01;
        public int NEncounter = 1;
        public string DistanceEncounterFunc = "=0.10*(D<2)";
        public double prTransmission = 0.01;
        public double prOutsideEncounter = 0.01;
        public double prOutsideTranmission = 0.01;

        public int minDaysE = 1;
        public int maxDaysE = 2;

        public double prPermanentI = 0.01;
        public int minDaysI = 1;
        public int maxDaysI = 2;
        public double prRecovery = 0.50;
        public double prReSusceptible = 0.25;
        public double prDeath = 0.25;

        public double prPermanentR = 0.1;
        public int minDaysR = 1;
        public int maxDaysR = 2;


        public Outbreak2()
        {
            InitializeComponent();
        }

        private double validateProb(string stext)
        {
            double d = -1;

            try
            {
                d = Convert.ToDouble(stext);
                if (d < 0.0 || d > 1.0)
                {
                    MessageBox.Show("Please enter a value between 0 and 1.");
                    d = -1.0;
                }
            }
            catch
            {
                MessageBox.Show("Please enter a value between 0 and 1.");
            }

            return d;
        }

        private bool testProb(string stext)
        {
            try
            {
                double d = Convert.ToDouble(stext);
                if (d < 0.0 || d > 1.0)
                {
                    MessageBox.Show("Please enter a value between 0 and 1.");
                    return false;
                }
            }
            catch
            {
                MessageBox.Show("Please enter a value between 0 and 1.");
                return false;
            }

            return true;
        }


        private int validateInt(string stext)
        {
            int d = -1;

            try
            {
                d = Convert.ToInt32(stext);
                if (d < 0)
                {
                    MessageBox.Show("Please enter a non-negative integer.");
                    d = -1;
                }
            }
            catch
            {
                MessageBox.Show("Please enter a non-negative integer.");
            }

            return d;
        }

        private bool testInt(string stext)
        {
            try
            {
                int d = Convert.ToInt32(stext);
                if (d < 0)
                {
                    MessageBox.Show("Please enter a non-negative integer.");
                    return false;
                }
            }
            catch
            {
                MessageBox.Show("Please enter a non-negative integer.");
                return false;
            }

            return true;
        }


// P
        private void txtPropPermanentP_Validating(object sender, CancelEventArgs e)
        {
            double d = validateProb(txtPropPermanentP.Text);
            if (d >= 0.0) prPermanentP = d;
            else e.Cancel = true;
        }

        private void txtMinDaysP_Validating(object sender, CancelEventArgs e)
        {
            int d = validateInt(txtMinDaysP.Text);
            if (d >= 0)
            {
                minDaysP = d;
                if (maxDaysP < minDaysP)
                {
                    maxDaysP = minDaysP;
                    txtMaxDaysP.Text = maxDaysP.ToString();
                }
            }
            else e.Cancel = true;
        }

        private void txtMaxDaysP_Validating(object sender, CancelEventArgs e)
        {
            int d = validateInt(txtMaxDaysP.Text);
            if (d >= 0)
            {
                maxDaysP = d;
                if (maxDaysP < minDaysP)
                {
                    minDaysP = maxDaysP;
                    txtMinDaysP.Text = minDaysP.ToString();
                }
            }
            else e.Cancel = true;
        }


// S
        private void txtPropPopEncounter_Validating(object sender, CancelEventArgs e)
        {
            double d = validateProb(txtPropPopEncounter.Text);
            if (d >= 0.0) prPopEncounter = d;
            else e.Cancel = true;
        }

        private void txtNEncounter_Validating(object sender, CancelEventArgs e)
        {
            int d = validateInt(txtNEncounter.Text);
            if (d >= 0) NEncounter = d;
            else e.Cancel = true;
        }

        private void txtDistanceEncounterFunc_Validating(object sender, CancelEventArgs e)
        {
            // do function validation
        }

        private void radioProportionEncounteredPerDay_CheckedChanged(object sender, EventArgs e)
        {
            if (radioProportionEncounteredPerDay.Checked)
            {
                txtPropPopEncounter.Enabled = true;
                txtNEncounter.Enabled = false;
                txtDistanceEncounterFunc.Enabled = false;
            }
        }

        private void radioFixedNEncounter_CheckedChanged(object sender, EventArgs e)
        {
            if (radioFixedNEncounter.Checked)
            {
                txtPropPopEncounter.Enabled = false;
                txtNEncounter.Enabled = true;
                txtDistanceEncounterFunc.Enabled = false;
            }
        }

        private void radioSpatialEncounter_CheckedChanged(object sender, EventArgs e)
        {
            if (radioSpatialEncounter.Checked)
            {
                txtPropPopEncounter.Enabled = false;
                txtNEncounter.Enabled = false;
                txtDistanceEncounterFunc.Enabled = true;
            }
        }

        private void txtProbTransmission_Validating(object sender, CancelEventArgs e)
        {
            double d = validateProb(txtProbTransmission.Text);
            if (d >= 0.0) prTransmission = d;
            else e.Cancel = true;
        }

        private void txtProbOutsideEncounter_Validating(object sender, CancelEventArgs e)
        {
            double d = validateProb(txtProbOutsideEncounter.Text);
            if (d >= 0.0) prOutsideEncounter = d;
            else e.Cancel = true;
        }

        private void txtProbOutsideTransmission_Validating(object sender, CancelEventArgs e)
        {
            double d = validateProb(txtProbOutsideTransmission.Text);
            if (d >= 0.0) prOutsideTranmission = d;
            else e.Cancel = true;
        }

// E
        private void txtMinDaysE_Validating(object sender, CancelEventArgs e)
        {
            int d = validateInt(txtMinDaysE.Text);
            if (d >= 0)
            {
                minDaysE = d;
                if (maxDaysE < minDaysE)
                {
                    maxDaysE = minDaysE;
                    txtMaxDaysE.Text = maxDaysE.ToString();
                }
            }
            else e.Cancel = true;
        }

        private void txtMaxDaysE_Validating(object sender, CancelEventArgs e)
        {
            int d = validateInt(txtMaxDaysE.Text);
            if (d >= 0) 
            { 
                maxDaysE = d;
                if (maxDaysE < minDaysE)
                {
                    minDaysE = maxDaysE;
                    txtMinDaysE.Text = minDaysE.ToString();
                }
            }
            else e.Cancel = true;
        }


// I
        private void txtMinDaysI_Validating(object sender, CancelEventArgs e)
        {
            int d = validateInt(txtMinDaysI.Text);
            if (d >= 0)
            {
                minDaysI = d;
                if (maxDaysI < minDaysI)
                {
                    maxDaysI = minDaysI;
                    txtMaxDaysI.Text = maxDaysI.ToString();
                }
            }
            else e.Cancel = true;
        }

        private void txtMaxDaysI_Validating(object sender, CancelEventArgs e)
        {
            int d = validateInt(txtMaxDaysI.Text);
            if (d >= 0)
            {
                maxDaysI = d;
                if (maxDaysI < minDaysI)
                {
                    minDaysI = maxDaysI;
                    txtMinDaysI.Text = minDaysI.ToString();
                }
            }
            else e.Cancel = true;
        }
        private void txtPropPermanentI_Validating(object sender, CancelEventArgs e)
        {
            double d = validateProb(txtPropPermanentI.Text);
            if (d >= 0.0) prPermanentI = d;
            else e.Cancel = true;
        }

        private void txtProbRecovery_Validating(object sender, CancelEventArgs e)
        {
            double d = validateProb(txtProbRecovery.Text);
            if (d >= 0.0)
            {
                prRecovery = d;
                if (prReSusceptible + prRecovery > 1.0)
                {
                    prReSusceptible = 1.0 - prRecovery;
                    txtProbReSusceptible.Text = prReSusceptible.ToString("0.00000");
                }
                prDeath = 1.0 - (prRecovery + prReSusceptible);
                txtProbDeath.Text = prDeath.ToString("0.00000");
            }
            else e.Cancel = true;
        }

        private void txtProbReSusceptible_Validating(object sender, CancelEventArgs e)
        {
            double d = validateProb(txtProbReSusceptible.Text);
            if (d >= 0.0)
            {
                prReSusceptible = d;
                if (prReSusceptible + prRecovery > 1.0)
                {
                    prRecovery = 1.0 - prReSusceptible;
                    txtProbRecovery.Text = prRecovery.ToString("0.00000");
                }
                prDeath = 1.0 - (prRecovery + prReSusceptible);
                txtProbDeath.Text = prDeath.ToString("0.00000");
            }
            else e.Cancel = true;
        }


// R

        private void txtMinDaysR_Validating(object sender, CancelEventArgs e)
        {
            int d = validateInt(txtMinDaysR.Text);
            if (d >= 0)
            {
                minDaysR = d;
                if (maxDaysR < minDaysR)
                {
                    maxDaysR = minDaysR;
                    txtMaxDaysR.Text = maxDaysR.ToString();
                }
            }
            else e.Cancel = true;
        }

        private void txtMaxDaysR_Validating(object sender, CancelEventArgs e)
        {
            int d = validateInt(txtMaxDaysR.Text);
            if (d >= 0)
            {
                maxDaysR = d;
                if (maxDaysR < minDaysR)
                {
                    minDaysR = maxDaysR;
                    txtMinDaysR.Text = minDaysR.ToString();
                }
            }
            else e.Cancel = true;
        }

        private void runToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // run the simulation!
        }


        public string O2version = "2.0.0";
        public string OName = "MyProject";
        public string Description = "";


        private bool saveXML(string filename)
        {
            if (filename == null || filename.Trim() == "") filename = "Outbreak.xml";

            //create the project settings file in the working folder
            XmlDocument doc = new XmlDocument();

            //add top node and name as attrib
            XmlElement nTop = doc.CreateElement("OutbreakProject");
            doc.AppendChild(nTop);
            XmlAttribute att = doc.CreateAttribute("Version");
            att.Value = O2version;

            nTop.Attributes.Append(att);

            XmlElement n = doc.CreateElement("Name");
            n.InnerText = OName;
            nTop.AppendChild(n);

            n = doc.CreateElement("Description");
            n.InnerText = Description;
            nTop.AppendChild(n);

            n = doc.CreateElement("Pre-susceptible");
            nTop.AppendChild(n);

            XmlElement nn = doc.CreateElement("probPermanentP");
            nn.InnerText = prPermanentP.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("minDaysP");
            nn.InnerText = minDaysP.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("maxDaysP");
            nn.InnerText = maxDaysP.ToString();
            n.AppendChild(nn);

            n = doc.CreateElement("Susceptible");
            nTop.AppendChild(n);

            nn = doc.CreateElement("usePropEncounter");
            nn.InnerText = usePropEncounter.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("propPopEncounter");
            nn.InnerText = prPopEncounter.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("useFixedNEncounter");
            nn.InnerText = useFixedNEncounter.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("NEncounter");
            nn.InnerText = NEncounter.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("useDistanceEncounter");
            nn.InnerText = useDistanceEncounter.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("DistanceEncounterFunc");
            nn.InnerText = DistanceEncounterFunc.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("probTransmission");
            nn.InnerText = prTransmission.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("probOutsideEncounter");
            nn.InnerText = prOutsideEncounter.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("probOutsideTranmission");
            nn.InnerText = prOutsideTranmission.ToString();
            n.AppendChild(nn);

            n = doc.CreateElement("Exposed");
            nTop.AppendChild(n);

            nn = doc.CreateElement("minDaysE");
            nn.InnerText = minDaysE.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("maxDaysE");
            nn.InnerText = maxDaysE.ToString();
            n.AppendChild(nn);

            n = doc.CreateElement("Infectious");
            nTop.AppendChild(n);

            nn = doc.CreateElement("probPermanentI");
            nn.InnerText = prPermanentI.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("minDaysI");
            nn.InnerText = minDaysI.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("maxDaysI");
            nn.InnerText = maxDaysI.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("probRecovery");
            nn.InnerText = prRecovery.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("probReSusceptible");
            nn.InnerText = prReSusceptible.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("probDeath");
            nn.InnerText = prDeath.ToString();
            n.AppendChild(nn);

            n = doc.CreateElement("Resistant");
            nTop.AppendChild(n);

            nn = doc.CreateElement("probPermanentR");
            nn.InnerText = prPermanentR.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("minDaysR");
            nn.InnerText = minDaysR.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("maxDaysR");
            nn.InnerText = maxDaysR.ToString();
            n.AppendChild(nn);


            try
            {
                doc.Save(filename);
            }
            catch
            {
                return false; // this can happen if the user doesn't have admin rights to save the file to the folder.
            }

            return true;
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveXML(null);
        }

    
    }
}
