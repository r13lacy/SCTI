using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Outbreak2
{
    public partial class frmRecentProjects : Form
    {
        public string ProjectFile = "";

        public frmRecentProjects()
        {
            InitializeComponent();

            List<string> f = GetFileList();

            if (f == null || f.Count == 0)
                btnOK.Enabled = false;
            else
            {
                for (int i = 0; i < f.Count; i++)
                    if (O2Utils.FileExists(f[i].Substring(f[i].IndexOf(":\\") - 1).Trim()))
                        lstProjects.Items.Add(f[i]);

                lstProjects.SelectedIndex = 0;
            }
        }
        
        public static List<string> GetFileList()
        {
            return O2Utils.ReadFileToList(Outbreak2.userDataFile); //Application.LocalUserAppDataPath.Substring(0, Application.LocalUserAppDataPath.LastIndexOf("\\")) + "\\recent.txt");
        }

        public static List<string> UpdateFileList(string projectName, string projectFile)
        {
            //get existing list, update with this project
//            string rFile = Application.LocalUserAppDataPath.Substring(0, Application.LocalUserAppDataPath.LastIndexOf("\\")) + "\\recent.txt";
            List<string> f = O2Utils.ReadFileToList(Outbreak2.userDataFile);

            if (f == null) f = new List<string>();

            if (projectFile == null && projectFile != "") return f;

            string s = projectName + " - " + projectFile;

            if (f.Contains(s))
                f.Remove(s);

            f.Insert(0, s);

            //go through and make sure all still exist, remove if they don't
            int i = 1;
            while (i < f.Count)
            {
                if (!O2Utils.FileExists(f[i].Substring(f[i].IndexOf(":\\") - 1).Trim()))
                    f.RemoveAt(i);
                else
                    i++;
            }

            //Limit to 20
            for (i = f.Count - 1; i >= 20; i--)
                f.RemoveAt(i);

            O2Utils.WriteListToFile(Outbreak2.userDataFile, f);

            return f;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (lstProjects.SelectedIndex < 0)
                this.DialogResult = DialogResult.Cancel;
            else
            {
                string s = lstProjects.SelectedItem.ToString();

                ProjectFile = s.Substring(s.IndexOf(":\\") - 1).Trim();
                this.DialogResult = DialogResult.OK;
            }
        }

        private void lstProjects_DoubleClick(object sender, EventArgs e)
        {
            btnOK_Click(this, null);
        }

    }
}