﻿namespace Outbreak2
{
    partial class frmDzGraph
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDzGraph));
            this.tabDzResults = new System.Windows.Forms.TabControl();
            this.tbpGraphical = new System.Windows.Forms.TabPage();
            this.DzChart = new C1.Win.C1Chart.C1Chart();
            this.tbpTabular = new System.Windows.Forms.TabPage();
            this.btnDzTableExport = new System.Windows.Forms.Button();
            this.fgDzData = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioDzGraphFreq = new System.Windows.Forms.RadioButton();
            this.radioDzGraphCounts = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioDzGraphRuns = new System.Windows.Forms.RadioButton();
            this.radioDzGraphSD = new System.Windows.Forms.RadioButton();
            this.radioDzGraphStacked = new System.Windows.Forms.RadioButton();
            this.radioDzGraphSE = new System.Windows.Forms.RadioButton();
            this.radioDzGraphMeans = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chkDzGraphV = new System.Windows.Forms.CheckBox();
            this.chkDzGraphDeaths = new System.Windows.Forms.CheckBox();
            this.chkDzGraphNew = new System.Windows.Forms.CheckBox();
            this.chkDzGraphR = new System.Windows.Forms.CheckBox();
            this.chkDzGraphI = new System.Windows.Forms.CheckBox();
            this.chkDzGraphE = new System.Windows.Forms.CheckBox();
            this.chkDzGraphS = new System.Windows.Forms.CheckBox();
            this.chkDzGraphP = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.chkDzGraphAF = new System.Windows.Forms.CheckBox();
            this.chkDzGraphAM = new System.Windows.Forms.CheckBox();
            this.chkDzGraphSA = new System.Windows.Forms.CheckBox();
            this.chkDzGraphJ = new System.Windows.Forms.CheckBox();
            this.listboxDzGraphTime = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.tabDzResults.SuspendLayout();
            this.tbpGraphical.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DzChart)).BeginInit();
            this.tbpTabular.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDzData)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabDzResults
            // 
            this.tabDzResults.Controls.Add(this.tbpGraphical);
            this.tabDzResults.Controls.Add(this.tbpTabular);
            this.tabDzResults.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabDzResults.Location = new System.Drawing.Point(0, 0);
            this.tabDzResults.Margin = new System.Windows.Forms.Padding(4);
            this.tabDzResults.Name = "tabDzResults";
            this.tabDzResults.SelectedIndex = 0;
            this.tabDzResults.Size = new System.Drawing.Size(1365, 407);
            this.tabDzResults.TabIndex = 0;
            // 
            // tbpGraphical
            // 
            this.tbpGraphical.Controls.Add(this.DzChart);
            this.tbpGraphical.Location = new System.Drawing.Point(4, 25);
            this.tbpGraphical.Margin = new System.Windows.Forms.Padding(4);
            this.tbpGraphical.Name = "tbpGraphical";
            this.tbpGraphical.Padding = new System.Windows.Forms.Padding(4);
            this.tbpGraphical.Size = new System.Drawing.Size(1357, 378);
            this.tbpGraphical.TabIndex = 0;
            this.tbpGraphical.Text = "Graphical Display";
            this.tbpGraphical.UseVisualStyleBackColor = true;
            // 
            // DzChart
            // 
            this.DzChart.BackColor = System.Drawing.Color.White;
            this.DzChart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DzChart.Location = new System.Drawing.Point(4, 4);
            this.DzChart.Margin = new System.Windows.Forms.Padding(4);
            this.DzChart.Name = "DzChart";
            this.DzChart.PropBag = resources.GetString("DzChart.PropBag");
            this.DzChart.Size = new System.Drawing.Size(1349, 370);
            this.DzChart.TabIndex = 0;
            this.DzChart.DoubleClick += new System.EventHandler(this.DzChart_DoubleClick);
            // 
            // tbpTabular
            // 
            this.tbpTabular.Controls.Add(this.btnDzTableExport);
            this.tbpTabular.Controls.Add(this.fgDzData);
            this.tbpTabular.Location = new System.Drawing.Point(4, 25);
            this.tbpTabular.Margin = new System.Windows.Forms.Padding(4);
            this.tbpTabular.Name = "tbpTabular";
            this.tbpTabular.Padding = new System.Windows.Forms.Padding(4);
            this.tbpTabular.Size = new System.Drawing.Size(1357, 378);
            this.tbpTabular.TabIndex = 1;
            this.tbpTabular.Text = "Tabular Display";
            this.tbpTabular.UseVisualStyleBackColor = true;
            // 
            // btnDzTableExport
            // 
            this.btnDzTableExport.Location = new System.Drawing.Point(17, 215);
            this.btnDzTableExport.Margin = new System.Windows.Forms.Padding(4);
            this.btnDzTableExport.Name = "btnDzTableExport";
            this.btnDzTableExport.Size = new System.Drawing.Size(100, 28);
            this.btnDzTableExport.TabIndex = 1;
            this.btnDzTableExport.Text = "Export Table";
            this.btnDzTableExport.UseVisualStyleBackColor = true;
            this.btnDzTableExport.Click += new System.EventHandler(this.btnDzTableExport_Click);
            // 
            // fgDzData
            // 
            this.fgDzData.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.Rows;
            this.fgDzData.AllowEditing = false;
            this.fgDzData.ColumnInfo = resources.GetString("fgDzData.ColumnInfo");
            this.fgDzData.Dock = System.Windows.Forms.DockStyle.Top;
            this.fgDzData.Location = new System.Drawing.Point(4, 4);
            this.fgDzData.Margin = new System.Windows.Forms.Padding(4);
            this.fgDzData.Name = "fgDzData";
            this.fgDzData.Rows.Count = 10;
            this.fgDzData.Rows.DefaultSize = 19;
            this.fgDzData.Size = new System.Drawing.Size(1349, 195);
            this.fgDzData.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioDzGraphFreq);
            this.groupBox1.Controls.Add(this.radioDzGraphCounts);
            this.groupBox1.Location = new System.Drawing.Point(16, 500);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(611, 38);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Graph Type";
            // 
            // radioDzGraphFreq
            // 
            this.radioDzGraphFreq.AutoSize = true;
            this.radioDzGraphFreq.Location = new System.Drawing.Point(289, 14);
            this.radioDzGraphFreq.Margin = new System.Windows.Forms.Padding(4);
            this.radioDzGraphFreq.Name = "radioDzGraphFreq";
            this.radioDzGraphFreq.Size = new System.Drawing.Size(107, 21);
            this.radioDzGraphFreq.TabIndex = 1;
            this.radioDzGraphFreq.Text = "Frequencies";
            this.radioDzGraphFreq.UseVisualStyleBackColor = true;
            // 
            // radioDzGraphCounts
            // 
            this.radioDzGraphCounts.AutoSize = true;
            this.radioDzGraphCounts.Checked = true;
            this.radioDzGraphCounts.Location = new System.Drawing.Point(132, 14);
            this.radioDzGraphCounts.Margin = new System.Windows.Forms.Padding(4);
            this.radioDzGraphCounts.Name = "radioDzGraphCounts";
            this.radioDzGraphCounts.Size = new System.Drawing.Size(73, 21);
            this.radioDzGraphCounts.TabIndex = 0;
            this.radioDzGraphCounts.TabStop = true;
            this.radioDzGraphCounts.Text = "Counts";
            this.radioDzGraphCounts.UseVisualStyleBackColor = true;
            this.radioDzGraphCounts.CheckedChanged += new System.EventHandler(this.radioDzGraphCounts_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioDzGraphRuns);
            this.groupBox2.Controls.Add(this.radioDzGraphSD);
            this.groupBox2.Controls.Add(this.radioDzGraphStacked);
            this.groupBox2.Controls.Add(this.radioDzGraphSE);
            this.groupBox2.Controls.Add(this.radioDzGraphMeans);
            this.groupBox2.Location = new System.Drawing.Point(17, 544);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(609, 80);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Graph Appearance";
            // 
            // radioDzGraphRuns
            // 
            this.radioDzGraphRuns.AutoSize = true;
            this.radioDzGraphRuns.Location = new System.Drawing.Point(288, 52);
            this.radioDzGraphRuns.Margin = new System.Windows.Forms.Padding(4);
            this.radioDzGraphRuns.Name = "radioDzGraphRuns";
            this.radioDzGraphRuns.Size = new System.Drawing.Size(116, 21);
            this.radioDzGraphRuns.TabIndex = 4;
            this.radioDzGraphRuns.Text = "Each Iteration";
            this.radioDzGraphRuns.UseVisualStyleBackColor = true;
            this.radioDzGraphRuns.Visible = false;
            // 
            // radioDzGraphSD
            // 
            this.radioDzGraphSD.AutoSize = true;
            this.radioDzGraphSD.Location = new System.Drawing.Point(383, 23);
            this.radioDzGraphSD.Margin = new System.Windows.Forms.Padding(4);
            this.radioDzGraphSD.Name = "radioDzGraphSD";
            this.radioDzGraphSD.Size = new System.Drawing.Size(115, 21);
            this.radioDzGraphSD.TabIndex = 3;
            this.radioDzGraphSD.Text = "Means +/- SD";
            this.radioDzGraphSD.UseVisualStyleBackColor = true;
            this.radioDzGraphSD.CheckedChanged += new System.EventHandler(this.radioDzGraphSD_CheckedChanged);
            // 
            // radioDzGraphStacked
            // 
            this.radioDzGraphStacked.AutoSize = true;
            this.radioDzGraphStacked.Location = new System.Drawing.Point(31, 52);
            this.radioDzGraphStacked.Margin = new System.Windows.Forms.Padding(4);
            this.radioDzGraphStacked.Name = "radioDzGraphStacked";
            this.radioDzGraphStacked.Size = new System.Drawing.Size(118, 21);
            this.radioDzGraphStacked.TabIndex = 2;
            this.radioDzGraphStacked.Text = "Stacked Lines";
            this.radioDzGraphStacked.UseVisualStyleBackColor = true;
            this.radioDzGraphStacked.CheckedChanged += new System.EventHandler(this.radioDzGraphStacked_CheckedChanged);
            // 
            // radioDzGraphSE
            // 
            this.radioDzGraphSE.AutoSize = true;
            this.radioDzGraphSE.Location = new System.Drawing.Point(188, 23);
            this.radioDzGraphSE.Margin = new System.Windows.Forms.Padding(4);
            this.radioDzGraphSE.Name = "radioDzGraphSE";
            this.radioDzGraphSE.Size = new System.Drawing.Size(114, 21);
            this.radioDzGraphSE.TabIndex = 1;
            this.radioDzGraphSE.Text = "Means +/- SE";
            this.radioDzGraphSE.UseVisualStyleBackColor = true;
            this.radioDzGraphSE.CheckedChanged += new System.EventHandler(this.radioDzGraphSE_CheckedChanged);
            // 
            // radioDzGraphMeans
            // 
            this.radioDzGraphMeans.AutoSize = true;
            this.radioDzGraphMeans.Checked = true;
            this.radioDzGraphMeans.Location = new System.Drawing.Point(31, 23);
            this.radioDzGraphMeans.Margin = new System.Windows.Forms.Padding(4);
            this.radioDzGraphMeans.Name = "radioDzGraphMeans";
            this.radioDzGraphMeans.Size = new System.Drawing.Size(71, 21);
            this.radioDzGraphMeans.TabIndex = 0;
            this.radioDzGraphMeans.TabStop = true;
            this.radioDzGraphMeans.Text = "Means";
            this.radioDzGraphMeans.UseVisualStyleBackColor = true;
            this.radioDzGraphMeans.CheckedChanged += new System.EventHandler(this.radioDzGraphMeans_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.chkDzGraphV);
            this.groupBox3.Controls.Add(this.chkDzGraphDeaths);
            this.groupBox3.Controls.Add(this.chkDzGraphNew);
            this.groupBox3.Controls.Add(this.chkDzGraphR);
            this.groupBox3.Controls.Add(this.chkDzGraphI);
            this.groupBox3.Controls.Add(this.chkDzGraphE);
            this.groupBox3.Controls.Add(this.chkDzGraphS);
            this.groupBox3.Controls.Add(this.chkDzGraphP);
            this.groupBox3.Location = new System.Drawing.Point(671, 416);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(679, 102);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Disease States to be drawn as lines on the graph";
            // 
            // chkDzGraphV
            // 
            this.chkDzGraphV.AutoSize = true;
            this.chkDzGraphV.Checked = true;
            this.chkDzGraphV.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDzGraphV.Location = new System.Drawing.Point(313, 76);
            this.chkDzGraphV.Margin = new System.Windows.Forms.Padding(4);
            this.chkDzGraphV.Name = "chkDzGraphV";
            this.chkDzGraphV.Size = new System.Drawing.Size(122, 21);
            this.chkDzGraphV.TabIndex = 7;
            this.chkDzGraphV.Text = "V - Vaccinated";
            this.chkDzGraphV.UseVisualStyleBackColor = true;
            this.chkDzGraphV.CheckedChanged += new System.EventHandler(this.chkDzGraphV_CheckedChanged);
            // 
            // chkDzGraphDeaths
            // 
            this.chkDzGraphDeaths.AutoSize = true;
            this.chkDzGraphDeaths.Location = new System.Drawing.Point(471, 48);
            this.chkDzGraphDeaths.Margin = new System.Windows.Forms.Padding(4);
            this.chkDzGraphDeaths.Name = "chkDzGraphDeaths";
            this.chkDzGraphDeaths.Size = new System.Drawing.Size(204, 21);
            this.chkDzGraphDeaths.TabIndex = 6;
            this.chkDzGraphDeaths.Text = "Disease Deaths (all stages)";
            this.chkDzGraphDeaths.UseVisualStyleBackColor = true;
            this.chkDzGraphDeaths.CheckedChanged += new System.EventHandler(this.chkDzGraphDeaths_CheckedChanged);
            // 
            // chkDzGraphNew
            // 
            this.chkDzGraphNew.AutoSize = true;
            this.chkDzGraphNew.Location = new System.Drawing.Point(471, 20);
            this.chkDzGraphNew.Margin = new System.Windows.Forms.Padding(4);
            this.chkDzGraphNew.Name = "chkDzGraphNew";
            this.chkDzGraphNew.Size = new System.Drawing.Size(195, 21);
            this.chkDzGraphNew.TabIndex = 5;
            this.chkDzGraphNew.Text = "New Infections (all stages)";
            this.chkDzGraphNew.UseVisualStyleBackColor = true;
            this.chkDzGraphNew.CheckedChanged += new System.EventHandler(this.chkDzGraphNew_CheckedChanged);
            // 
            // chkDzGraphR
            // 
            this.chkDzGraphR.AutoSize = true;
            this.chkDzGraphR.Checked = true;
            this.chkDzGraphR.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDzGraphR.Location = new System.Drawing.Point(313, 48);
            this.chkDzGraphR.Margin = new System.Windows.Forms.Padding(4);
            this.chkDzGraphR.Name = "chkDzGraphR";
            this.chkDzGraphR.Size = new System.Drawing.Size(112, 21);
            this.chkDzGraphR.TabIndex = 4;
            this.chkDzGraphR.Text = "R - Resistant";
            this.chkDzGraphR.UseVisualStyleBackColor = true;
            this.chkDzGraphR.CheckedChanged += new System.EventHandler(this.chkDzGraphR_CheckedChanged);
            // 
            // chkDzGraphI
            // 
            this.chkDzGraphI.AutoSize = true;
            this.chkDzGraphI.Checked = true;
            this.chkDzGraphI.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDzGraphI.Location = new System.Drawing.Point(313, 21);
            this.chkDzGraphI.Margin = new System.Windows.Forms.Padding(4);
            this.chkDzGraphI.Name = "chkDzGraphI";
            this.chkDzGraphI.Size = new System.Drawing.Size(106, 21);
            this.chkDzGraphI.TabIndex = 3;
            this.chkDzGraphI.Text = "I - Infectious";
            this.chkDzGraphI.UseVisualStyleBackColor = true;
            this.chkDzGraphI.CheckedChanged += new System.EventHandler(this.chkDzGraphI_CheckedChanged);
            // 
            // chkDzGraphE
            // 
            this.chkDzGraphE.AutoSize = true;
            this.chkDzGraphE.Checked = true;
            this.chkDzGraphE.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDzGraphE.Location = new System.Drawing.Point(65, 76);
            this.chkDzGraphE.Margin = new System.Windows.Forms.Padding(4);
            this.chkDzGraphE.Name = "chkDzGraphE";
            this.chkDzGraphE.Size = new System.Drawing.Size(106, 21);
            this.chkDzGraphE.TabIndex = 2;
            this.chkDzGraphE.Text = "E - Exposed";
            this.chkDzGraphE.UseVisualStyleBackColor = true;
            this.chkDzGraphE.CheckedChanged += new System.EventHandler(this.chkDzGraphE_CheckedChanged);
            // 
            // chkDzGraphS
            // 
            this.chkDzGraphS.AutoSize = true;
            this.chkDzGraphS.Checked = true;
            this.chkDzGraphS.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDzGraphS.Location = new System.Drawing.Point(65, 48);
            this.chkDzGraphS.Margin = new System.Windows.Forms.Padding(4);
            this.chkDzGraphS.Name = "chkDzGraphS";
            this.chkDzGraphS.Size = new System.Drawing.Size(125, 21);
            this.chkDzGraphS.TabIndex = 1;
            this.chkDzGraphS.Text = "S - Susceptible";
            this.chkDzGraphS.UseVisualStyleBackColor = true;
            this.chkDzGraphS.CheckedChanged += new System.EventHandler(this.chkDzGraphS_CheckedChanged);
            // 
            // chkDzGraphP
            // 
            this.chkDzGraphP.AutoSize = true;
            this.chkDzGraphP.Checked = true;
            this.chkDzGraphP.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDzGraphP.Location = new System.Drawing.Point(65, 21);
            this.chkDzGraphP.Margin = new System.Windows.Forms.Padding(4);
            this.chkDzGraphP.Name = "chkDzGraphP";
            this.chkDzGraphP.Size = new System.Drawing.Size(150, 21);
            this.chkDzGraphP.TabIndex = 0;
            this.chkDzGraphP.Text = "P - Pre-susceptible";
            this.chkDzGraphP.UseVisualStyleBackColor = true;
            this.chkDzGraphP.CheckedChanged += new System.EventHandler(this.chkDzGraphP_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.chkDzGraphAF);
            this.groupBox4.Controls.Add(this.chkDzGraphAM);
            this.groupBox4.Controls.Add(this.chkDzGraphSA);
            this.groupBox4.Controls.Add(this.chkDzGraphJ);
            this.groupBox4.Location = new System.Drawing.Point(671, 526);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(679, 92);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Age and Sex Stages to be included in the graph";
            // 
            // chkDzGraphAF
            // 
            this.chkDzGraphAF.AutoSize = true;
            this.chkDzGraphAF.Checked = true;
            this.chkDzGraphAF.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDzGraphAF.Location = new System.Drawing.Point(316, 53);
            this.chkDzGraphAF.Margin = new System.Windows.Forms.Padding(4);
            this.chkDzGraphAF.Name = "chkDzGraphAF";
            this.chkDzGraphAF.Size = new System.Drawing.Size(119, 21);
            this.chkDzGraphAF.TabIndex = 3;
            this.chkDzGraphAF.Text = "Adult Females";
            this.chkDzGraphAF.UseVisualStyleBackColor = true;
            this.chkDzGraphAF.CheckedChanged += new System.EventHandler(this.chkDzGraphAF_CheckedChanged);
            // 
            // chkDzGraphAM
            // 
            this.chkDzGraphAM.AutoSize = true;
            this.chkDzGraphAM.Checked = true;
            this.chkDzGraphAM.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDzGraphAM.Location = new System.Drawing.Point(316, 25);
            this.chkDzGraphAM.Margin = new System.Windows.Forms.Padding(4);
            this.chkDzGraphAM.Name = "chkDzGraphAM";
            this.chkDzGraphAM.Size = new System.Drawing.Size(103, 21);
            this.chkDzGraphAM.TabIndex = 2;
            this.chkDzGraphAM.Text = "Adult Males";
            this.chkDzGraphAM.UseVisualStyleBackColor = true;
            this.chkDzGraphAM.CheckedChanged += new System.EventHandler(this.chkDzGraphAM_CheckedChanged);
            // 
            // chkDzGraphSA
            // 
            this.chkDzGraphSA.AutoSize = true;
            this.chkDzGraphSA.Checked = true;
            this.chkDzGraphSA.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDzGraphSA.Location = new System.Drawing.Point(65, 53);
            this.chkDzGraphSA.Margin = new System.Windows.Forms.Padding(4);
            this.chkDzGraphSA.Name = "chkDzGraphSA";
            this.chkDzGraphSA.Size = new System.Drawing.Size(99, 21);
            this.chkDzGraphSA.TabIndex = 1;
            this.chkDzGraphSA.Text = "Sub-Adults";
            this.chkDzGraphSA.UseVisualStyleBackColor = true;
            this.chkDzGraphSA.CheckedChanged += new System.EventHandler(this.chkDzGraphSA_CheckedChanged);
            // 
            // chkDzGraphJ
            // 
            this.chkDzGraphJ.AutoSize = true;
            this.chkDzGraphJ.Checked = true;
            this.chkDzGraphJ.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDzGraphJ.Location = new System.Drawing.Point(65, 25);
            this.chkDzGraphJ.Margin = new System.Windows.Forms.Padding(4);
            this.chkDzGraphJ.Name = "chkDzGraphJ";
            this.chkDzGraphJ.Size = new System.Drawing.Size(89, 21);
            this.chkDzGraphJ.TabIndex = 0;
            this.chkDzGraphJ.Text = "Juveniles";
            this.chkDzGraphJ.UseVisualStyleBackColor = true;
            this.chkDzGraphJ.CheckedChanged += new System.EventHandler(this.chkDzGraphJ_CheckedChanged);
            // 
            // listboxDzGraphTime
            // 
            this.listboxDzGraphTime.FormattingEnabled = true;
            this.listboxDzGraphTime.ItemHeight = 16;
            this.listboxDzGraphTime.Location = new System.Drawing.Point(29, 411);
            this.listboxDzGraphTime.Margin = new System.Windows.Forms.Padding(4);
            this.listboxDzGraphTime.Name = "listboxDzGraphTime";
            this.listboxDzGraphTime.Size = new System.Drawing.Size(165, 84);
            this.listboxDzGraphTime.TabIndex = 5;
            this.listboxDzGraphTime.SelectedIndexChanged += new System.EventHandler(this.listboxDzGraphTime_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(249, 426);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 28);
            this.button1.TabIndex = 6;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(419, 426);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 28);
            this.button2.TabIndex = 7;
            this.button2.Text = "saveGraph";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btnSaveGraph_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(527, 426);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 28);
            this.button3.TabIndex = 8;
            this.button3.Text = "printGraph";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.btnPrintGraph_Click);
            // 
            // frmDzGraph
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1365, 633);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listboxDzGraphTime);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tabDzResults);
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmDzGraph";
            this.Text = "Disease Dynamics -- double-click on graph to open graph Properties";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmDzGraph_KeyUp);
            this.tabDzResults.ResumeLayout(false);
            this.tbpGraphical.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DzChart)).EndInit();
            this.tbpTabular.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgDzData)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabDzResults;
        private System.Windows.Forms.TabPage tbpGraphical;
        private System.Windows.Forms.TabPage tbpTabular;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ListBox listboxDzGraphTime;
        private System.Windows.Forms.Button button1;
        private C1.Win.C1Chart.C1Chart DzChart;
        private System.Windows.Forms.RadioButton radioDzGraphFreq;
        private System.Windows.Forms.RadioButton radioDzGraphCounts;
        private System.Windows.Forms.RadioButton radioDzGraphRuns;
        private System.Windows.Forms.RadioButton radioDzGraphSD;
        private System.Windows.Forms.RadioButton radioDzGraphStacked;
        private System.Windows.Forms.RadioButton radioDzGraphSE;
        private System.Windows.Forms.RadioButton radioDzGraphMeans;
        private System.Windows.Forms.CheckBox chkDzGraphR;
        private System.Windows.Forms.CheckBox chkDzGraphI;
        private System.Windows.Forms.CheckBox chkDzGraphE;
        private System.Windows.Forms.CheckBox chkDzGraphS;
        private System.Windows.Forms.CheckBox chkDzGraphP;
        private System.Windows.Forms.CheckBox chkDzGraphAF;
        private System.Windows.Forms.CheckBox chkDzGraphAM;
        private System.Windows.Forms.CheckBox chkDzGraphSA;
        private System.Windows.Forms.CheckBox chkDzGraphJ;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnDzTableExport;
        private System.Windows.Forms.CheckBox chkDzGraphNew;
        private C1.Win.C1FlexGrid.C1FlexGrid fgDzData;
        private System.Windows.Forms.CheckBox chkDzGraphDeaths;
        private System.Windows.Forms.CheckBox chkDzGraphV;
    }
}