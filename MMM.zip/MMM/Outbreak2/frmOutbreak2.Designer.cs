﻿namespace Outbreak2
{
    partial class frmOutbreak2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOutbreak2));
            this.tbInput = new System.Windows.Forms.TabControl();
            this.tabSettings = new System.Windows.Forms.TabPage();
            this.btnDeleteScenario = new System.Windows.Forms.Button();
            this.btnAddScenarios = new System.Windows.Forms.Button();
            this.label35 = new System.Windows.Forms.Label();
            this.cboScenes = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txtSceneNotes = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtSceneName = new System.Windows.Forms.TextBox();
            this.label92 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.txtOName = new System.Windows.Forms.TextBox();
            this.label119 = new System.Windows.Forms.Label();
            this.txtRunDays = new System.Windows.Forms.TextBox();
            this.label120 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.label117 = new System.Windows.Forms.Label();
            this.txtDzTag = new System.Windows.Forms.TextBox();
            this.label115 = new System.Windows.Forms.Label();
            this.txtRunYears = new System.Windows.Forms.TextBox();
            this.label116 = new System.Windows.Forms.Label();
            this.txtRunIter = new System.Windows.Forms.TextBox();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.chkOutDaily = new System.Windows.Forms.CheckBox();
            this.chkOutIndividuals = new System.Windows.Forms.CheckBox();
            this.chkOutMM = new System.Windows.Forms.CheckBox();
            this.chkOutIndList = new System.Windows.Forms.CheckBox();
            this.chkOutEpiRates = new System.Windows.Forms.CheckBox();
            this.chkOutYearly = new System.Windows.Forms.CheckBox();
            this.tabP = new System.Windows.Forms.TabPage();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtMaternalTransmission = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_PNotes = new System.Windows.Forms.TextBox();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.txtMaternalImmunityDays = new System.Windows.Forms.TextBox();
            this.chkMaternalImmunity = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label104 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.txtDaysP = new System.Windows.Forms.TextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPropPermanentP = new System.Windows.Forms.TextBox();
            this.tabS = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_SNotes = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtProbOutsideTransmission = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtProbOutsideEncounter = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtProbTransmission = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label123 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.chkSpatialEncounter = new System.Windows.Forms.CheckBox();
            this.chkFixedNEncounter = new System.Windows.Forms.CheckBox();
            this.chkProportionEncountered = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtPropPopEncounter = new System.Windows.Forms.TextBox();
            this.txtDistanceEncounterFunc = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtNEncounter = new System.Windows.Forms.TextBox();
            this.tabE = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_ENotes = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.txtDaysE = new System.Windows.Forms.TextBox();
            this.tabI = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_INotes = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtProbDeath = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtProbReSusceptible = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txtProbRecovery = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.txtDaysI = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtPropPermanentI = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tabR = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_RNotes = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.txtDaysR = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtPropPermanentR = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.tabV = new System.Windows.Forms.TabPage();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_VNotes = new System.Windows.Forms.TextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.txtVaccDuration = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.txtVaccEfficacy = new System.Windows.Forms.TextBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.txtVaccAd = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.txtVaccSA = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.txtVacc0 = new System.Windows.Forms.TextBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label91 = new System.Windows.Forms.Label();
            this.txtVaccDaysStart = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtVaccDays = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.txtVaccPrev = new System.Windows.Forms.TextBox();
            this.chkVaccPrevalence = new System.Windows.Forms.CheckBox();
            this.chkVaccInterval = new System.Windows.Forms.CheckBox();
            this.chkVaccNow = new System.Windows.Forms.CheckBox();
            this.tabC = new System.Windows.Forms.TabPage();
            this.label20 = new System.Windows.Forms.Label();
            this.txt_CullNotes = new System.Windows.Forms.TextBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.txtCullAgeAd = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.txtCullAgeSA = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.txtCullAge0 = new System.Windows.Forms.TextBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.label99 = new System.Windows.Forms.Label();
            this.txtCullDaysStart = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.txtCullDays = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.txtCullPrevalence = new System.Windows.Forms.TextBox();
            this.chkCullPrevalence = new System.Windows.Forms.CheckBox();
            this.chkCullInterval = new System.Windows.Forms.CheckBox();
            this.chkCullNow = new System.Windows.Forms.CheckBox();
            this.tabInitN = new System.Windows.Forms.TabPage();
            this.label52 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.txtSADays = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtJuvDays = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_InitNotes = new System.Windows.Forms.TextBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.btnRescaleInitProportions = new System.Windows.Forms.Button();
            this.btnSAD = new System.Windows.Forms.Button();
            this.fgInitStates = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.radioNproportions = new System.Windows.Forms.RadioButton();
            this.radioNcounts = new System.Windows.Forms.RadioButton();
            this.label38 = new System.Windows.Forms.Label();
            this.txtInitN = new System.Windows.Forms.TextBox();
            this.tabDemog = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_DemogNotes = new System.Windows.Forms.TextBox();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.label84 = new System.Windows.Forms.Label();
            this.txtK = new System.Windows.Forms.TextBox();
            this.txtKDay = new System.Windows.Forms.TextBox();
            this.radioKDay = new System.Windows.Forms.RadioButton();
            this.radioMaintainK = new System.Windows.Forms.RadioButton();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.chkEnterStageMort = new System.Windows.Forms.CheckBox();
            this.fgLifeTable = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnCopyLifeTable = new System.Windows.Forms.Button();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.label113 = new System.Windows.Forms.Label();
            this.txtBreedDays = new System.Windows.Forms.TextBox();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.txtBreedAgeDays = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.txtMaxAge = new System.Windows.Forms.TextBox();
            this.txtBreedAge = new System.Windows.Forms.TextBox();
            this.tabSpatial = new System.Windows.Forms.TabPage();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.chkUseSpatial = new System.Windows.Forms.CheckBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txt_SpatialNotes = new System.Windows.Forms.TextBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.radioSpatialAbsorbingBoundary = new System.Windows.Forms.RadioButton();
            this.radioSpatialReflectingBoundary = new System.Windows.Forms.RadioButton();
            this.radioSpatialNoBoundary = new System.Windows.Forms.RadioButton();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.label89 = new System.Windows.Forms.Label();
            this.txtMoveWhen = new System.Windows.Forms.TextBox();
            this.txtSpatialMove = new System.Windows.Forms.TextBox();
            this.radioSpatialMoveRandom = new System.Windows.Forms.RadioButton();
            this.label62 = new System.Windows.Forms.Label();
            this.txtSpatialMoveYFunc = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.txtSpatialMoveXFunc = new System.Windows.Forms.TextBox();
            this.radioSpatialMoveFuncs = new System.Windows.Forms.RadioButton();
            this.radioSpatialMoveNone = new System.Windows.Forms.RadioButton();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.label60 = new System.Windows.Forms.Label();
            this.txtSpatialYFunc = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.txtSpatialXFunc = new System.Windows.Forms.TextBox();
            this.radioSeedFunctions = new System.Windows.Forms.RadioButton();
            this.radioSeedRandom = new System.Windows.Forms.RadioButton();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.label57 = new System.Windows.Forms.Label();
            this.txtSpatialYmax = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.txtSpatialYmin = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.txtSpatialXmax = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.txtSpatialXmin = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openRecentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitWithoutSavingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noHelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.supportConservationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userRegistrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resultsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkForUpdatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbInput.SuspendLayout();
            this.tabSettings.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.tabP.SuspendLayout();
            this.groupBox29.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabS.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabE.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabI.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabR.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tabV.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.tabC.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.tabInitN.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgInitStates)).BeginInit();
            this.tabDemog.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.groupBox25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgLifeTable)).BeginInit();
            this.groupBox23.SuspendLayout();
            this.tabSpatial.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbInput
            // 
            this.tbInput.Controls.Add(this.tabSettings);
            this.tbInput.Controls.Add(this.tabP);
            this.tbInput.Controls.Add(this.tabS);
            this.tbInput.Controls.Add(this.tabE);
            this.tbInput.Controls.Add(this.tabI);
            this.tbInput.Controls.Add(this.tabR);
            this.tbInput.Controls.Add(this.tabV);
            this.tbInput.Controls.Add(this.tabC);
            this.tbInput.Controls.Add(this.tabInitN);
            this.tbInput.Controls.Add(this.tabDemog);
            this.tbInput.Controls.Add(this.tabSpatial);
            this.tbInput.Dock = System.Windows.Forms.DockStyle.Top;
            this.tbInput.Location = new System.Drawing.Point(0, 52);
            this.tbInput.Margin = new System.Windows.Forms.Padding(4);
            this.tbInput.Name = "tbInput";
            this.tbInput.SelectedIndex = 0;
            this.tbInput.Size = new System.Drawing.Size(1232, 552);
            this.tbInput.TabIndex = 0;
            // 
            // tabSettings
            // 
            this.tabSettings.AutoScroll = true;
            this.tabSettings.Controls.Add(this.btnDeleteScenario);
            this.tabSettings.Controls.Add(this.btnAddScenarios);
            this.tabSettings.Controls.Add(this.label35);
            this.tabSettings.Controls.Add(this.cboScenes);
            this.tabSettings.Controls.Add(this.label34);
            this.tabSettings.Controls.Add(this.txtSceneNotes);
            this.tabSettings.Controls.Add(this.label33);
            this.tabSettings.Controls.Add(this.txtSceneName);
            this.tabSettings.Controls.Add(this.label92);
            this.tabSettings.Controls.Add(this.label121);
            this.tabSettings.Controls.Add(this.txtOName);
            this.tabSettings.Controls.Add(this.label119);
            this.tabSettings.Controls.Add(this.txtRunDays);
            this.tabSettings.Controls.Add(this.label120);
            this.tabSettings.Controls.Add(this.label118);
            this.tabSettings.Controls.Add(this.txtDescription);
            this.tabSettings.Controls.Add(this.label117);
            this.tabSettings.Controls.Add(this.txtDzTag);
            this.tabSettings.Controls.Add(this.label115);
            this.tabSettings.Controls.Add(this.txtRunYears);
            this.tabSettings.Controls.Add(this.label116);
            this.tabSettings.Controls.Add(this.txtRunIter);
            this.tabSettings.Controls.Add(this.groupBox28);
            this.tabSettings.Location = new System.Drawing.Point(4, 25);
            this.tabSettings.Margin = new System.Windows.Forms.Padding(4);
            this.tabSettings.Name = "tabSettings";
            this.tabSettings.Size = new System.Drawing.Size(1224, 523);
            this.tabSettings.TabIndex = 10;
            this.tabSettings.Text = "General Settings";
            this.tabSettings.UseVisualStyleBackColor = true;
            // 
            // btnDeleteScenario
            // 
            this.btnDeleteScenario.Location = new System.Drawing.Point(550, 152);
            this.btnDeleteScenario.Margin = new System.Windows.Forms.Padding(4);
            this.btnDeleteScenario.Name = "btnDeleteScenario";
            this.btnDeleteScenario.Size = new System.Drawing.Size(134, 27);
            this.btnDeleteScenario.TabIndex = 35;
            this.btnDeleteScenario.TabStop = false;
            this.btnDeleteScenario.Text = "Delete scenario";
            this.btnDeleteScenario.UseVisualStyleBackColor = true;
            this.btnDeleteScenario.Click += new System.EventHandler(this.btnDeleteScenario_Click);
            // 
            // btnAddScenarios
            // 
            this.btnAddScenarios.Location = new System.Drawing.Point(257, 152);
            this.btnAddScenarios.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddScenarios.Name = "btnAddScenarios";
            this.btnAddScenarios.Size = new System.Drawing.Size(157, 27);
            this.btnAddScenarios.TabIndex = 34;
            this.btnAddScenarios.TabStop = false;
            this.btnAddScenarios.Text = "Add new scenario(s)";
            this.btnAddScenarios.UseVisualStyleBackColor = true;
            this.btnAddScenarios.Click += new System.EventHandler(this.btnAddScenarios_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(30, 190);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(219, 17);
            this.label35.TabIndex = 33;
            this.label35.Tag = "";
            this.label35.Text = "Select which Scenario to work on:";
            // 
            // cboScenes
            // 
            this.cboScenes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboScenes.FormattingEnabled = true;
            this.cboScenes.Location = new System.Drawing.Point(257, 187);
            this.cboScenes.Margin = new System.Windows.Forms.Padding(4);
            this.cboScenes.Name = "cboScenes";
            this.cboScenes.Size = new System.Drawing.Size(428, 24);
            this.cboScenes.TabIndex = 4;
            this.cboScenes.Tag = "Use this dropdown list to select the Scenario that you want to work on.";
            this.cboScenes.SelectedIndexChanged += new System.EventHandler(this.cboScenes_SelectedIndexChanged);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(30, 251);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(139, 17);
            this.label34.TabIndex = 31;
            this.label34.Text = "Scenario Description";
            // 
            // txtSceneNotes
            // 
            this.txtSceneNotes.Location = new System.Drawing.Point(170, 251);
            this.txtSceneNotes.Margin = new System.Windows.Forms.Padding(4);
            this.txtSceneNotes.Multiline = true;
            this.txtSceneNotes.Name = "txtSceneNotes";
            this.txtSceneNotes.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtSceneNotes.Size = new System.Drawing.Size(522, 95);
            this.txtSceneNotes.TabIndex = 6;
            this.txtSceneNotes.Tag = "";
            this.txtSceneNotes.Validating += new System.ComponentModel.CancelEventHandler(this.txtSceneNotes_Validating);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(30, 223);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(103, 17);
            this.label33.TabIndex = 28;
            this.label33.Tag = "Scenario Name can anything that would be a valid filename. Don\'t use any special " +
    "characters within the name.";
            this.label33.Text = "Scenario name";
            // 
            // txtSceneName
            // 
            this.txtSceneName.Location = new System.Drawing.Point(170, 221);
            this.txtSceneName.Margin = new System.Windows.Forms.Padding(4);
            this.txtSceneName.Name = "txtSceneName";
            this.txtSceneName.Size = new System.Drawing.Size(515, 22);
            this.txtSceneName.TabIndex = 5;
            this.txtSceneName.Tag = "string,empty";
            this.txtSceneName.Text = "Scenario1";
            this.txtSceneName.Validating += new System.ComponentModel.CancelEventHandler(this.txtSceneName_Validating);
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(302, 14);
            this.label92.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(394, 17);
            this.label92.TabIndex = 26;
            this.label92.Text = "(Normally, the Project Name will be the same as the filename)";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(31, 14);
            this.label121.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(91, 17);
            this.label121.TabIndex = 25;
            this.label121.Tag = "Don\'t use any special characters within the name.";
            this.label121.Text = "Project name";
            // 
            // txtOName
            // 
            this.txtOName.Location = new System.Drawing.Point(130, 10);
            this.txtOName.Margin = new System.Windows.Forms.Padding(4);
            this.txtOName.Name = "txtOName";
            this.txtOName.Size = new System.Drawing.Size(172, 22);
            this.txtOName.TabIndex = 0;
            this.txtOName.Tag = "string,empty";
            this.txtOName.Text = "MyOProject";
            this.txtOName.Validating += new System.ComponentModel.CancelEventHandler(this.txtOName_Validating);
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(31, 420);
            this.label119.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(243, 17);
            this.label119.TabIndex = 23;
            this.label119.Tag = "Outbreak works on a daily time step, and reports data on a yearly basis, but you " +
    "can define a \"day\" and a \"year\" to mean anything that you want.";
            this.label119.Text = "Number of time steps (days) per year";
            // 
            // txtRunDays
            // 
            this.txtRunDays.Location = new System.Drawing.Point(301, 416);
            this.txtRunDays.Margin = new System.Windows.Forms.Padding(4);
            this.txtRunDays.Name = "txtRunDays";
            this.txtRunDays.Size = new System.Drawing.Size(61, 22);
            this.txtRunDays.TabIndex = 9;
            this.txtRunDays.Tag = "int,1";
            this.txtRunDays.Text = "365";
            this.txtRunDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRunDays.Validating += new System.ComponentModel.CancelEventHandler(this.txtRunDays_Validating);
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(283, 40);
            this.label120.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(302, 17);
            this.label120.TabIndex = 21;
            this.label120.Text = "(Give a short name or tag to label the disease)";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(31, 68);
            this.label118.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(127, 17);
            this.label118.TabIndex = 20;
            this.label118.Text = "Project Description";
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(171, 64);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDescription.Size = new System.Drawing.Size(522, 71);
            this.txtDescription.TabIndex = 3;
            this.txtDescription.Tag = "";
            this.txtDescription.Validating += new System.ComponentModel.CancelEventHandler(this.txtDescription_Validating);
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(31, 40);
            this.label117.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(103, 17);
            this.label117.TabIndex = 18;
            this.label117.Tag = "This label will be used in output files.";
            this.label117.Text = "Disease (label)";
            // 
            // txtDzTag
            // 
            this.txtDzTag.Location = new System.Drawing.Point(171, 38);
            this.txtDzTag.Margin = new System.Windows.Forms.Padding(4);
            this.txtDzTag.Name = "txtDzTag";
            this.txtDzTag.Size = new System.Drawing.Size(112, 22);
            this.txtDzTag.TabIndex = 2;
            this.txtDzTag.Tag = "string";
            this.txtDzTag.Text = "DZ";
            this.txtDzTag.Validating += new System.ComponentModel.CancelEventHandler(this.txtDzTag_Validating);
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(31, 391);
            this.label115.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(193, 17);
            this.label115.TabIndex = 16;
            this.label115.Tag = "These simulation settings can be adjusted also on the Run page.";
            this.label115.Text = "Number of years per iteration";
            // 
            // txtRunYears
            // 
            this.txtRunYears.Location = new System.Drawing.Point(299, 384);
            this.txtRunYears.Margin = new System.Windows.Forms.Padding(4);
            this.txtRunYears.Name = "txtRunYears";
            this.txtRunYears.Size = new System.Drawing.Size(64, 22);
            this.txtRunYears.TabIndex = 8;
            this.txtRunYears.Tag = "int,1";
            this.txtRunYears.Text = "10";
            this.txtRunYears.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRunYears.Validating += new System.ComponentModel.CancelEventHandler(this.txtRunYears_Validating);
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(31, 364);
            this.label116.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(197, 17);
            this.label116.TabIndex = 14;
            this.label116.Tag = "When you first test a model, you might want to start with just one or a few itera" +
    "tions.";
            this.label116.Text = "Number of iterations to repeat";
            // 
            // txtRunIter
            // 
            this.txtRunIter.Location = new System.Drawing.Point(299, 355);
            this.txtRunIter.Margin = new System.Windows.Forms.Padding(4);
            this.txtRunIter.Name = "txtRunIter";
            this.txtRunIter.Size = new System.Drawing.Size(64, 22);
            this.txtRunIter.TabIndex = 7;
            this.txtRunIter.Tag = "int,1";
            this.txtRunIter.Text = "10";
            this.txtRunIter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRunIter.Validating += new System.ComponentModel.CancelEventHandler(this.txtRunIter_Validating);
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.chkOutDaily);
            this.groupBox28.Controls.Add(this.chkOutIndividuals);
            this.groupBox28.Controls.Add(this.chkOutMM);
            this.groupBox28.Controls.Add(this.chkOutIndList);
            this.groupBox28.Controls.Add(this.chkOutEpiRates);
            this.groupBox28.Controls.Add(this.chkOutYearly);
            this.groupBox28.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox28.Location = new System.Drawing.Point(914, 0);
            this.groupBox28.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox28.Size = new System.Drawing.Size(310, 523);
            this.groupBox28.TabIndex = 12;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "Which formats of optional output do you want?";
            // 
            // chkOutDaily
            // 
            this.chkOutDaily.AutoSize = true;
            this.chkOutDaily.Checked = true;
            this.chkOutDaily.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkOutDaily.Location = new System.Drawing.Point(11, 73);
            this.chkOutDaily.Margin = new System.Windows.Forms.Padding(4);
            this.chkOutDaily.Name = "chkOutDaily";
            this.chkOutDaily.Size = new System.Drawing.Size(153, 21);
            this.chkOutDaily.TabIndex = 5;
            this.chkOutDaily.TabStop = false;
            this.chkOutDaily.Text = "Daily Summary files";
            this.chkOutDaily.UseVisualStyleBackColor = true;
            this.chkOutDaily.CheckedChanged += new System.EventHandler(this.chkOutDaily_CheckedChanged);
            // 
            // chkOutIndividuals
            // 
            this.chkOutIndividuals.AutoSize = true;
            this.chkOutIndividuals.Location = new System.Drawing.Point(11, 171);
            this.chkOutIndividuals.Margin = new System.Windows.Forms.Padding(4);
            this.chkOutIndividuals.Name = "chkOutIndividuals";
            this.chkOutIndividuals.Size = new System.Drawing.Size(297, 21);
            this.chkOutIndividuals.TabIndex = 4;
            this.chkOutIndividuals.TabStop = false;
            this.chkOutIndividuals.Text = "All Individuals (Living or Dead) annual files";
            this.chkOutIndividuals.UseVisualStyleBackColor = true;
            this.chkOutIndividuals.Visible = false;
            this.chkOutIndividuals.CheckedChanged += new System.EventHandler(this.chkOutIndividuals_CheckedChanged);
            // 
            // chkOutMM
            // 
            this.chkOutMM.AutoSize = true;
            this.chkOutMM.Location = new System.Drawing.Point(11, 203);
            this.chkOutMM.Margin = new System.Windows.Forms.Padding(4);
            this.chkOutMM.Name = "chkOutMM";
            this.chkOutMM.Size = new System.Drawing.Size(271, 21);
            this.chkOutMM.TabIndex = 3;
            this.chkOutMM.TabStop = false;
            this.chkOutMM.Text = "File listing all MM PS and GS variables";
            this.chkOutMM.UseVisualStyleBackColor = true;
            this.chkOutMM.Visible = false;
            this.chkOutMM.CheckedChanged += new System.EventHandler(this.chkOutMM_CheckedChanged);
            // 
            // chkOutIndList
            // 
            this.chkOutIndList.AutoSize = true;
            this.chkOutIndList.Location = new System.Drawing.Point(11, 139);
            this.chkOutIndList.Margin = new System.Windows.Forms.Padding(4);
            this.chkOutIndList.Name = "chkOutIndList";
            this.chkOutIndList.Size = new System.Drawing.Size(139, 21);
            this.chkOutIndList.TabIndex = 2;
            this.chkOutIndList.TabStop = false;
            this.chkOutIndList.Text = "Individual list files";
            this.chkOutIndList.UseVisualStyleBackColor = true;
            this.chkOutIndList.CheckedChanged += new System.EventHandler(this.chkOutIndList_CheckedChanged);
            // 
            // chkOutEpiRates
            // 
            this.chkOutEpiRates.AutoSize = true;
            this.chkOutEpiRates.Location = new System.Drawing.Point(11, 106);
            this.chkOutEpiRates.Margin = new System.Windows.Forms.Padding(4);
            this.chkOutEpiRates.Name = "chkOutEpiRates";
            this.chkOutEpiRates.Size = new System.Drawing.Size(148, 21);
            this.chkOutEpiRates.TabIndex = 1;
            this.chkOutEpiRates.TabStop = false;
            this.chkOutEpiRates.Text = "Raw Daily Data file";
            this.chkOutEpiRates.UseVisualStyleBackColor = true;
            this.chkOutEpiRates.CheckedChanged += new System.EventHandler(this.chkOutEpiRates_CheckedChanged);
            // 
            // chkOutYearly
            // 
            this.chkOutYearly.AutoSize = true;
            this.chkOutYearly.Checked = true;
            this.chkOutYearly.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkOutYearly.Location = new System.Drawing.Point(11, 42);
            this.chkOutYearly.Margin = new System.Windows.Forms.Padding(4);
            this.chkOutYearly.Name = "chkOutYearly";
            this.chkOutYearly.Size = new System.Drawing.Size(162, 21);
            this.chkOutYearly.TabIndex = 0;
            this.chkOutYearly.TabStop = false;
            this.chkOutYearly.Text = "Yearly Summary files";
            this.chkOutYearly.UseVisualStyleBackColor = true;
            this.chkOutYearly.CheckedChanged += new System.EventHandler(this.chkOutYearly_CheckedChanged);
            // 
            // tabP
            // 
            this.tabP.AutoScroll = true;
            this.tabP.Controls.Add(this.groupBox29);
            this.tabP.Controls.Add(this.label5);
            this.tabP.Controls.Add(this.txt_PNotes);
            this.tabP.Controls.Add(this.groupBox27);
            this.tabP.Controls.Add(this.groupBox5);
            this.tabP.Location = new System.Drawing.Point(4, 25);
            this.tabP.Margin = new System.Windows.Forms.Padding(4);
            this.tabP.Name = "tabP";
            this.tabP.Padding = new System.Windows.Forms.Padding(4);
            this.tabP.Size = new System.Drawing.Size(1224, 523);
            this.tabP.TabIndex = 0;
            this.tabP.Text = "P (pre-susceptible)";
            this.tabP.UseVisualStyleBackColor = true;
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.label23);
            this.groupBox29.Controls.Add(this.txtMaternalTransmission);
            this.groupBox29.Controls.Add(this.label24);
            this.groupBox29.Location = new System.Drawing.Point(4, 170);
            this.groupBox29.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox29.Size = new System.Drawing.Size(792, 81);
            this.groupBox29.TabIndex = 17;
            this.groupBox29.TabStop = false;
            this.groupBox29.Text = "Maternal-offspring transmission";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(418, 44);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(180, 17);
            this.label23.TabIndex = 11;
            this.label23.Text = "(Probability from 0.0 to 1.0)";
            // 
            // txtMaternalTransmission
            // 
            this.txtMaternalTransmission.Location = new System.Drawing.Point(418, 19);
            this.txtMaternalTransmission.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaternalTransmission.Name = "txtMaternalTransmission";
            this.txtMaternalTransmission.Size = new System.Drawing.Size(361, 22);
            this.txtMaternalTransmission.TabIndex = 12;
            this.txtMaternalTransmission.Tag = "fun,0,1";
            this.txtMaternalTransmission.Text = "0.0";
            this.txtMaternalTransmission.Validating += new System.ComponentModel.CancelEventHandler(this.txtMaternalTransmission_Validating);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(17, 24);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(380, 17);
            this.label24.TabIndex = 9;
            this.label24.Text = "What is the transmission rate from an I mother to newborn?";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(836, 8);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 17);
            this.label5.TabIndex = 26;
            this.label5.Tag = "Enter any notes for this input section.";
            this.label5.Text = "Section Notes";
            // 
            // txt_PNotes
            // 
            this.txt_PNotes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_PNotes.Location = new System.Drawing.Point(810, 29);
            this.txt_PNotes.Margin = new System.Windows.Forms.Padding(4);
            this.txt_PNotes.Multiline = true;
            this.txt_PNotes.Name = "txt_PNotes";
            this.txt_PNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_PNotes.Size = new System.Drawing.Size(200, 346);
            this.txt_PNotes.TabIndex = 15;
            this.txt_PNotes.Tag = "string";
            this.txt_PNotes.Validating += new System.ComponentModel.CancelEventHandler(this.txt_PNotes_Validating);
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.label105);
            this.groupBox27.Controls.Add(this.label106);
            this.groupBox27.Controls.Add(this.txtMaternalImmunityDays);
            this.groupBox27.Controls.Add(this.chkMaternalImmunity);
            this.groupBox27.Location = new System.Drawing.Point(4, 259);
            this.groupBox27.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox27.Size = new System.Drawing.Size(792, 116);
            this.groupBox27.TabIndex = 18;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "Maternally derived immunity";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(35, 58);
            this.label105.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(483, 17);
            this.label105.TabIndex = 17;
            this.label105.Text = "  for how many days does maternally derived immunity protect an offspring?";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(526, 80);
            this.label106.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(206, 17);
            this.label106.TabIndex = 18;
            this.label106.Text = "(Integer or distribution function)";
            // 
            // txtMaternalImmunityDays
            // 
            this.txtMaternalImmunityDays.Location = new System.Drawing.Point(529, 54);
            this.txtMaternalImmunityDays.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaternalImmunityDays.Name = "txtMaternalImmunityDays";
            this.txtMaternalImmunityDays.Size = new System.Drawing.Size(250, 22);
            this.txtMaternalImmunityDays.TabIndex = 14;
            this.txtMaternalImmunityDays.Tag = "fun,0";
            this.txtMaternalImmunityDays.Text = "0";
            this.txtMaternalImmunityDays.Validating += new System.ComponentModel.CancelEventHandler(this.txtMaternalImmunityDays_Validating);
            // 
            // chkMaternalImmunity
            // 
            this.chkMaternalImmunity.AutoSize = true;
            this.chkMaternalImmunity.Location = new System.Drawing.Point(19, 30);
            this.chkMaternalImmunity.Margin = new System.Windows.Forms.Padding(4);
            this.chkMaternalImmunity.Name = "chkMaternalImmunity";
            this.chkMaternalImmunity.Size = new System.Drawing.Size(420, 21);
            this.chkMaternalImmunity.TabIndex = 13;
            this.chkMaternalImmunity.Text = "Do Resistant females pass immunity to their offspring at birth?";
            this.chkMaternalImmunity.UseVisualStyleBackColor = true;
            this.chkMaternalImmunity.CheckedChanged += new System.EventHandler(this.chkMaternalImmunity_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label104);
            this.groupBox5.Controls.Add(this.label102);
            this.groupBox5.Controls.Add(this.label103);
            this.groupBox5.Controls.Add(this.txtDaysP);
            this.groupBox5.Controls.Add(this.label93);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(this.txtPropPermanentP);
            this.groupBox5.Location = new System.Drawing.Point(4, 4);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(792, 158);
            this.groupBox5.TabIndex = 16;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Initial acquisition of susceptibility";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(355, 137);
            this.label104.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(423, 17);
            this.label104.TabIndex = 16;
            this.label104.Text = "(\"=IUNIFORM(min;max)\" for a uniform distribution from min to max)";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(16, 89);
            this.label102.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(372, 17);
            this.label102.TabIndex = 14;
            this.label102.Text = "  for how many days to they remain P before becoming S?";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(395, 113);
            this.label103.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(206, 17);
            this.label103.TabIndex = 15;
            this.label103.Text = "(Integer or distribution function)";
            // 
            // txtDaysP
            // 
            this.txtDaysP.Location = new System.Drawing.Point(398, 84);
            this.txtDaysP.Margin = new System.Windows.Forms.Padding(4);
            this.txtDaysP.Name = "txtDaysP";
            this.txtDaysP.Size = new System.Drawing.Size(383, 22);
            this.txtDaysP.TabIndex = 11;
            this.txtDaysP.Tag = "fun,0";
            this.txtDaysP.Text = "0";
            this.txtDaysP.Validating += new System.ComponentModel.CancelEventHandler(this.txtDaysP_Validating);
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(15, 66);
            this.label93.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(327, 17);
            this.label93.TabIndex = 12;
            this.label93.Text = "Of those individuals that do become Susceptible ...";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(395, 51);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "(Probability from 0.0 to 1.0)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(375, 17);
            this.label1.TabIndex = 3;
            this.label1.Tag = "These are individuals that are born with innate resistance.";
            this.label1.Text = "What proportion of individuals never become Susceptible?";
            // 
            // txtPropPermanentP
            // 
            this.txtPropPermanentP.Location = new System.Drawing.Point(398, 25);
            this.txtPropPermanentP.Margin = new System.Windows.Forms.Padding(4);
            this.txtPropPermanentP.Name = "txtPropPermanentP";
            this.txtPropPermanentP.Size = new System.Drawing.Size(381, 22);
            this.txtPropPermanentP.TabIndex = 10;
            this.txtPropPermanentP.Tag = "fun,0,1";
            this.txtPropPermanentP.Text = "0.0";
            this.txtPropPermanentP.Validating += new System.ComponentModel.CancelEventHandler(this.txtPropPermanentP_Validating);
            // 
            // tabS
            // 
            this.tabS.AutoScroll = true;
            this.tabS.Controls.Add(this.label6);
            this.tabS.Controls.Add(this.txt_SNotes);
            this.tabS.Controls.Add(this.groupBox3);
            this.tabS.Controls.Add(this.groupBox2);
            this.tabS.Controls.Add(this.groupBox1);
            this.tabS.Location = new System.Drawing.Point(4, 25);
            this.tabS.Margin = new System.Windows.Forms.Padding(4);
            this.tabS.Name = "tabS";
            this.tabS.Padding = new System.Windows.Forms.Padding(4);
            this.tabS.Size = new System.Drawing.Size(1224, 523);
            this.tabS.TabIndex = 1;
            this.tabS.Text = "S (susceptible)";
            this.tabS.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(821, 5);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 17);
            this.label6.TabIndex = 26;
            this.label6.Tag = "Enter any notes for this input section.";
            this.label6.Text = "Section Notes";
            // 
            // txt_SNotes
            // 
            this.txt_SNotes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_SNotes.Location = new System.Drawing.Point(824, 26);
            this.txt_SNotes.Margin = new System.Windows.Forms.Padding(4);
            this.txt_SNotes.Multiline = true;
            this.txt_SNotes.Name = "txt_SNotes";
            this.txt_SNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_SNotes.Size = new System.Drawing.Size(180, 431);
            this.txt_SNotes.TabIndex = 24;
            this.txt_SNotes.Tag = "string";
            this.txt_SNotes.Validating += new System.ComponentModel.CancelEventHandler(this.txt_SNotes_Validating);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.txtProbOutsideTransmission);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.txtProbOutsideEncounter);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(4, 278);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(809, 121);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Environmental sources";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(516, 95);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(180, 17);
            this.label12.TabIndex = 14;
            this.label12.Text = "(Probability from 0.0 to 1.0)";
            // 
            // txtProbOutsideTransmission
            // 
            this.txtProbOutsideTransmission.Location = new System.Drawing.Point(517, 69);
            this.txtProbOutsideTransmission.Margin = new System.Windows.Forms.Padding(4);
            this.txtProbOutsideTransmission.Name = "txtProbOutsideTransmission";
            this.txtProbOutsideTransmission.Size = new System.Drawing.Size(278, 22);
            this.txtProbOutsideTransmission.TabIndex = 23;
            this.txtProbOutsideTransmission.Tag = "fun,0,1";
            this.txtProbOutsideTransmission.Text = "0.0";
            this.txtProbOutsideTransmission.Validating += new System.ComponentModel.CancelEventHandler(this.txtProbOutsideTransmission_Validating);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 73);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(498, 17);
            this.label13.TabIndex = 12;
            this.label13.Text = "When an environmental source is encountered, what is the transmission rate?";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(513, 48);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(180, 17);
            this.label10.TabIndex = 11;
            this.label10.Text = "(Probability from 0.0 to 1.0)";
            // 
            // txtProbOutsideEncounter
            // 
            this.txtProbOutsideEncounter.Location = new System.Drawing.Point(508, 23);
            this.txtProbOutsideEncounter.Margin = new System.Windows.Forms.Padding(4);
            this.txtProbOutsideEncounter.Name = "txtProbOutsideEncounter";
            this.txtProbOutsideEncounter.Size = new System.Drawing.Size(287, 22);
            this.txtProbOutsideEncounter.TabIndex = 22;
            this.txtProbOutsideEncounter.Tag = "fun,0,1";
            this.txtProbOutsideEncounter.Text = "0.0";
            this.txtProbOutsideEncounter.Validating += new System.ComponentModel.CancelEventHandler(this.txtProbOutsideEncounter_Validating);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(17, 28);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(477, 17);
            this.label11.TabIndex = 9;
            this.label11.Text = "What is the average encounter rate per day with outside disease sources?";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txtProbTransmission);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(4, 210);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(809, 60);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Transmission rate";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(516, 39);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(180, 17);
            this.label8.TabIndex = 11;
            this.label8.Text = "(Probability from 0.0 to 1.0)";
            // 
            // txtProbTransmission
            // 
            this.txtProbTransmission.Location = new System.Drawing.Point(474, 15);
            this.txtProbTransmission.Margin = new System.Windows.Forms.Padding(4);
            this.txtProbTransmission.Name = "txtProbTransmission";
            this.txtProbTransmission.Size = new System.Drawing.Size(307, 22);
            this.txtProbTransmission.TabIndex = 21;
            this.txtProbTransmission.Tag = "fun,0,1";
            this.txtProbTransmission.Text = "0.0";
            this.txtProbTransmission.Validating += new System.ComponentModel.CancelEventHandler(this.txtProbTransmission_Validating);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 24);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(438, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "When an I encounters an S individual, what is the transmission rate?";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label123);
            this.groupBox1.Controls.Add(this.label68);
            this.groupBox1.Controls.Add(this.label70);
            this.groupBox1.Controls.Add(this.label71);
            this.groupBox1.Controls.Add(this.label67);
            this.groupBox1.Controls.Add(this.label66);
            this.groupBox1.Controls.Add(this.label43);
            this.groupBox1.Controls.Add(this.chkSpatialEncounter);
            this.groupBox1.Controls.Add(this.chkFixedNEncounter);
            this.groupBox1.Controls.Add(this.chkProportionEncountered);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtPropPopEncounter);
            this.groupBox1.Controls.Add(this.txtDistanceEncounterFunc);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.txtNEncounter);
            this.groupBox1.Location = new System.Drawing.Point(4, 4);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(809, 206);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "How do you want to model encounter rate?";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label123.Location = new System.Drawing.Point(17, 162);
            this.label123.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(585, 17);
            this.label123.TabIndex = 28;
            this.label123.Text = "Note: When used in functions, X and Y coordinates are symbolized XCOORD and YCOOR" +
    "D";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(612, 185);
            this.label68.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(192, 17);
            this.label68.TabIndex = 20;
            this.label68.Text = "(CONTACT = connected X,Y)";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(370, 185);
            this.label70.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(244, 17);
            this.label70.TabIndex = 19;
            this.label70.Text = "(CONNECTS = # X,Y,diagonal steps )";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(17, 185);
            this.label71.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(185, 17);
            this.label71.TabIndex = 18;
            this.label71.Text = "(SAME = same X,Y location)";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(207, 185);
            this.label67.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(155, 17);
            this.label67.TabIndex = 16;
            this.label67.Text = "(STEPS = # X,Y steps )";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(620, 168);
            this.label66.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(184, 17);
            this.label66.TabIndex = 15;
            this.label66.Text = "(DIST = Euclidean distance)";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(516, 72);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(180, 17);
            this.label43.TabIndex = 14;
            this.label43.Text = "(Probability from 0.0 to 1.0)";
            // 
            // chkSpatialEncounter
            // 
            this.chkSpatialEncounter.AutoSize = true;
            this.chkSpatialEncounter.Location = new System.Drawing.Point(8, 133);
            this.chkSpatialEncounter.Margin = new System.Windows.Forms.Padding(4);
            this.chkSpatialEncounter.Name = "chkSpatialEncounter";
            this.chkSpatialEncounter.Size = new System.Drawing.Size(166, 21);
            this.chkSpatialEncounter.TabIndex = 20;
            this.chkSpatialEncounter.Tag = "With spatially defined encounters, you will need also to specify Spatial Settings" +
    ".";
            this.chkSpatialEncounter.Text = "A function of distance";
            this.chkSpatialEncounter.UseVisualStyleBackColor = true;
            this.chkSpatialEncounter.CheckedChanged += new System.EventHandler(this.chkSpatialEncounter_CheckedChanged);
            // 
            // chkFixedNEncounter
            // 
            this.chkFixedNEncounter.AutoSize = true;
            this.chkFixedNEncounter.Location = new System.Drawing.Point(8, 78);
            this.chkFixedNEncounter.Margin = new System.Windows.Forms.Padding(4);
            this.chkFixedNEncounter.Name = "chkFixedNEncounter";
            this.chkFixedNEncounter.Size = new System.Drawing.Size(373, 21);
            this.chkFixedNEncounter.TabIndex = 18;
            this.chkFixedNEncounter.Tag = "Note that only the encounters with S individuals can transmit the infection.";
            this.chkFixedNEncounter.Text = "A specified number of individuals encountered per day";
            this.chkFixedNEncounter.UseVisualStyleBackColor = true;
            this.chkFixedNEncounter.CheckedChanged += new System.EventHandler(this.chkFixedNEncounter_CheckedChanged);
            // 
            // chkProportionEncountered
            // 
            this.chkProportionEncountered.AutoSize = true;
            this.chkProportionEncountered.Checked = true;
            this.chkProportionEncountered.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkProportionEncountered.Location = new System.Drawing.Point(8, 22);
            this.chkProportionEncountered.Margin = new System.Windows.Forms.Padding(4);
            this.chkProportionEncountered.Name = "chkProportionEncountered";
            this.chkProportionEncountered.Size = new System.Drawing.Size(354, 21);
            this.chkProportionEncountered.TabIndex = 16;
            this.chkProportionEncountered.Tag = "Transmission can occur at any combination of the three mechanisms that define enc" +
    "ounter rates.";
            this.chkProportionEncountered.Text = "A proportion of the population encountered per day";
            this.chkProportionEncountered.UseVisualStyleBackColor = true;
            this.chkProportionEncountered.CheckedChanged += new System.EventHandler(this.chkProportionEncountered_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(68, 49);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(429, 17);
            this.label7.TabIndex = 10;
            this.label7.Tag = "The relevant value is the proportion of S individuals encountered each day, but O" +
    "utbreak assumes that encounter rates are the same for all states.";
            this.label7.Text = "Proportion of the population that an I individual encounters per day";
            // 
            // txtPropPopEncounter
            // 
            this.txtPropPopEncounter.Location = new System.Drawing.Point(516, 46);
            this.txtPropPopEncounter.Margin = new System.Windows.Forms.Padding(4);
            this.txtPropPopEncounter.Name = "txtPropPopEncounter";
            this.txtPropPopEncounter.Size = new System.Drawing.Size(288, 22);
            this.txtPropPopEncounter.TabIndex = 17;
            this.txtPropPopEncounter.Tag = "fun,0,1";
            this.txtPropPopEncounter.Text = "0.0";
            this.txtPropPopEncounter.Validating += new System.ComponentModel.CancelEventHandler(this.txtPropPopEncounter_Validating);
            // 
            // txtDistanceEncounterFunc
            // 
            this.txtDistanceEncounterFunc.Enabled = false;
            this.txtDistanceEncounterFunc.Location = new System.Drawing.Point(188, 134);
            this.txtDistanceEncounterFunc.Margin = new System.Windows.Forms.Padding(4);
            this.txtDistanceEncounterFunc.Name = "txtDistanceEncounterFunc";
            this.txtDistanceEncounterFunc.Size = new System.Drawing.Size(491, 22);
            this.txtDistanceEncounterFunc.TabIndex = 5;
            this.txtDistanceEncounterFunc.Tag = "fun";
            this.txtDistanceEncounterFunc.Text = "=0.1*(DIST<4)";
            this.txtDistanceEncounterFunc.Validating += new System.ComponentModel.CancelEventHandler(this.txtDistanceEncounterFunc_Validating);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(68, 107);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(389, 17);
            this.label22.TabIndex = 6;
            this.label22.Tag = "Non-integral values will be treated probabilistically.";
            this.label22.Text = "Number of individuals that an I individual encounters per day";
            // 
            // txtNEncounter
            // 
            this.txtNEncounter.Enabled = false;
            this.txtNEncounter.Location = new System.Drawing.Point(519, 105);
            this.txtNEncounter.Margin = new System.Windows.Forms.Padding(4);
            this.txtNEncounter.Name = "txtNEncounter";
            this.txtNEncounter.Size = new System.Drawing.Size(285, 22);
            this.txtNEncounter.TabIndex = 19;
            this.txtNEncounter.Tag = "fun,0";
            this.txtNEncounter.Text = "0";
            this.txtNEncounter.Validating += new System.ComponentModel.CancelEventHandler(this.txtNEncounter_Validating);
            // 
            // tabE
            // 
            this.tabE.AutoScroll = true;
            this.tabE.Controls.Add(this.label3);
            this.tabE.Controls.Add(this.txt_ENotes);
            this.tabE.Controls.Add(this.groupBox4);
            this.tabE.Location = new System.Drawing.Point(4, 25);
            this.tabE.Margin = new System.Windows.Forms.Padding(4);
            this.tabE.Name = "tabE";
            this.tabE.Padding = new System.Windows.Forms.Padding(4);
            this.tabE.Size = new System.Drawing.Size(1224, 523);
            this.tabE.TabIndex = 2;
            this.tabE.Text = "E (exposed and infected)";
            this.tabE.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(793, 2);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 17);
            this.label3.TabIndex = 24;
            this.label3.Tag = "Enter any notes for this input section.";
            this.label3.Text = "Section Notes";
            // 
            // txt_ENotes
            // 
            this.txt_ENotes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ENotes.Location = new System.Drawing.Point(783, 23);
            this.txt_ENotes.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ENotes.Multiline = true;
            this.txt_ENotes.Name = "txt_ENotes";
            this.txt_ENotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_ENotes.Size = new System.Drawing.Size(434, 264);
            this.txt_ENotes.TabIndex = 23;
            this.txt_ENotes.Tag = "string";
            this.txt_ENotes.Validating += new System.ComponentModel.CancelEventHandler(this.txt_ENotes_Validating);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label107);
            this.groupBox4.Controls.Add(this.label108);
            this.groupBox4.Controls.Add(this.txtDaysE);
            this.groupBox4.Location = new System.Drawing.Point(4, 4);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(771, 123);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Incubation period";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(17, 54);
            this.label107.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(404, 17);
            this.label107.TabIndex = 17;
            this.label107.Tag = "This is the time that an individual is in state E before transiting to state I";
            this.label107.Text = "What is the duration of the incubation period (latency) in days?";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(442, 85);
            this.label108.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(206, 17);
            this.label108.TabIndex = 18;
            this.label108.Text = "(Integer or distribution function)";
            // 
            // txtDaysE
            // 
            this.txtDaysE.Location = new System.Drawing.Point(432, 49);
            this.txtDaysE.Margin = new System.Windows.Forms.Padding(4);
            this.txtDaysE.Name = "txtDaysE";
            this.txtDaysE.Size = new System.Drawing.Size(327, 22);
            this.txtDaysE.TabIndex = 16;
            this.txtDaysE.Tag = "fun,0";
            this.txtDaysE.Text = "0";
            this.txtDaysE.Validating += new System.ComponentModel.CancelEventHandler(this.txtDaysE_Validating);
            // 
            // tabI
            // 
            this.tabI.AutoScroll = true;
            this.tabI.Controls.Add(this.label14);
            this.tabI.Controls.Add(this.txt_INotes);
            this.tabI.Controls.Add(this.groupBox8);
            this.tabI.Controls.Add(this.groupBox7);
            this.tabI.Controls.Add(this.groupBox6);
            this.tabI.Location = new System.Drawing.Point(4, 25);
            this.tabI.Margin = new System.Windows.Forms.Padding(4);
            this.tabI.Name = "tabI";
            this.tabI.Padding = new System.Windows.Forms.Padding(4);
            this.tabI.Size = new System.Drawing.Size(1224, 523);
            this.tabI.TabIndex = 3;
            this.tabI.Text = "I (infectious)";
            this.tabI.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(747, 10);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 17);
            this.label14.TabIndex = 26;
            this.label14.Tag = "Enter any notes for this input section.";
            this.label14.Text = "Section Notes";
            // 
            // txt_INotes
            // 
            this.txt_INotes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_INotes.Location = new System.Drawing.Point(733, 31);
            this.txt_INotes.Margin = new System.Windows.Forms.Padding(4);
            this.txt_INotes.Multiline = true;
            this.txt_INotes.Name = "txt_INotes";
            this.txt_INotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_INotes.Size = new System.Drawing.Size(482, 352);
            this.txt_INotes.TabIndex = 25;
            this.txt_INotes.Tag = "string";
            this.txt_INotes.Validating += new System.ComponentModel.CancelEventHandler(this.txt_INotes_Validating);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label30);
            this.groupBox8.Controls.Add(this.txtProbDeath);
            this.groupBox8.Controls.Add(this.label31);
            this.groupBox8.Controls.Add(this.label26);
            this.groupBox8.Controls.Add(this.txtProbReSusceptible);
            this.groupBox8.Controls.Add(this.label27);
            this.groupBox8.Controls.Add(this.label28);
            this.groupBox8.Controls.Add(this.txtProbRecovery);
            this.groupBox8.Controls.Add(this.label29);
            this.groupBox8.Location = new System.Drawing.Point(4, 202);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(712, 181);
            this.groupBox8.TabIndex = 8;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Disease outcome";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(432, 156);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(170, 17);
            this.label30.TabIndex = 17;
            this.label30.Tag = "The probabilities of these three fates must add to one, so you do not enter the l" +
    "ast value.";
            this.label30.Text = "(Calculated automatically)";
            // 
            // txtProbDeath
            // 
            this.txtProbDeath.Enabled = false;
            this.txtProbDeath.Location = new System.Drawing.Point(435, 131);
            this.txtProbDeath.Margin = new System.Windows.Forms.Padding(4);
            this.txtProbDeath.Name = "txtProbDeath";
            this.txtProbDeath.Size = new System.Drawing.Size(269, 22);
            this.txtProbDeath.TabIndex = 16;
            this.txtProbDeath.TabStop = false;
            this.txtProbDeath.Text = "0.25";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(19, 134);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(323, 17);
            this.label31.TabIndex = 15;
            this.label31.Text = "What is the probability of dying from the infection?";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(432, 102);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(180, 17);
            this.label26.TabIndex = 14;
            this.label26.Text = "(Probability from 0.0 to 1.0)";
            // 
            // txtProbReSusceptible
            // 
            this.txtProbReSusceptible.Location = new System.Drawing.Point(435, 79);
            this.txtProbReSusceptible.Margin = new System.Windows.Forms.Padding(4);
            this.txtProbReSusceptible.Name = "txtProbReSusceptible";
            this.txtProbReSusceptible.Size = new System.Drawing.Size(269, 22);
            this.txtProbReSusceptible.TabIndex = 15;
            this.txtProbReSusceptible.Tag = "fun,0,1";
            this.txtProbReSusceptible.Text = "0.50";
            this.txtProbReSusceptible.Validating += new System.ComponentModel.CancelEventHandler(this.txtProbReSusceptible_Validating);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(19, 83);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(343, 17);
            this.label27.TabIndex = 12;
            this.label27.Text = "What is the probabilty of returning to be Susceptible?";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(432, 52);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(180, 17);
            this.label28.TabIndex = 11;
            this.label28.Text = "(Probability from 0.0 to 1.0)";
            // 
            // txtProbRecovery
            // 
            this.txtProbRecovery.Location = new System.Drawing.Point(435, 26);
            this.txtProbRecovery.Margin = new System.Windows.Forms.Padding(4);
            this.txtProbRecovery.Name = "txtProbRecovery";
            this.txtProbRecovery.Size = new System.Drawing.Size(269, 22);
            this.txtProbRecovery.TabIndex = 14;
            this.txtProbRecovery.Tag = "fun,0,1";
            this.txtProbRecovery.Text = "0.25";
            this.txtProbRecovery.Validating += new System.ComponentModel.CancelEventHandler(this.txtProbRecovery_Validating);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(17, 29);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(396, 17);
            this.label29.TabIndex = 9;
            this.label29.Text = "What is the probabilty of recovering and becoming Resistant?";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label64);
            this.groupBox7.Controls.Add(this.label109);
            this.groupBox7.Controls.Add(this.label110);
            this.groupBox7.Controls.Add(this.txtDaysI);
            this.groupBox7.Location = new System.Drawing.Point(4, 79);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(712, 123);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Infectious period";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(17, 36);
            this.label64.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(360, 17);
            this.label64.TabIndex = 22;
            this.label64.Text = "Of those individuals that are not Infectious indefinitely ...";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(70, 64);
            this.label109.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(340, 17);
            this.label109.TabIndex = 20;
            this.label109.Tag = "After this many days, the infected individual will have one of the three fates be" +
    "low.";
            this.label109.Text = "What is the duration of the infectious period in days?";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(432, 85);
            this.label110.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(206, 17);
            this.label110.TabIndex = 21;
            this.label110.Text = "(Integer or distribution function)";
            // 
            // txtDaysI
            // 
            this.txtDaysI.Location = new System.Drawing.Point(435, 59);
            this.txtDaysI.Margin = new System.Windows.Forms.Padding(4);
            this.txtDaysI.Name = "txtDaysI";
            this.txtDaysI.Size = new System.Drawing.Size(269, 22);
            this.txtDaysI.TabIndex = 12;
            this.txtDaysI.Tag = "fun,0";
            this.txtDaysI.Text = "0";
            this.txtDaysI.Validating += new System.ComponentModel.CancelEventHandler(this.txtDaysI_Validating);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.txtPropPermanentI);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Location = new System.Drawing.Point(4, 4);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(712, 75);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Permanent infections";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(432, 54);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(180, 17);
            this.label18.TabIndex = 11;
            this.label18.Text = "(Probability from 0.0 to 1.0)";
            // 
            // txtPropPermanentI
            // 
            this.txtPropPermanentI.Location = new System.Drawing.Point(435, 24);
            this.txtPropPermanentI.Margin = new System.Windows.Forms.Padding(4);
            this.txtPropPermanentI.Name = "txtPropPermanentI";
            this.txtPropPermanentI.Size = new System.Drawing.Size(269, 22);
            this.txtPropPermanentI.TabIndex = 11;
            this.txtPropPermanentI.Tag = "fun,0,1";
            this.txtPropPermanentI.Text = "0.0";
            this.txtPropPermanentI.Validating += new System.ComponentModel.CancelEventHandler(this.txtPropPermanentI_Validating);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(17, 27);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(393, 17);
            this.label19.TabIndex = 9;
            this.label19.Tag = "These individuals never die from the disease or clear the infection, but instead " +
    "live with it always in their system.";
            this.label19.Text = "What proportion of I individuals remain infectious indefinitely?";
            // 
            // tabR
            // 
            this.tabR.AutoScroll = true;
            this.tabR.Controls.Add(this.label4);
            this.tabR.Controls.Add(this.txt_RNotes);
            this.tabR.Controls.Add(this.groupBox9);
            this.tabR.Controls.Add(this.groupBox10);
            this.tabR.Location = new System.Drawing.Point(4, 25);
            this.tabR.Margin = new System.Windows.Forms.Padding(4);
            this.tabR.Name = "tabR";
            this.tabR.Padding = new System.Windows.Forms.Padding(4);
            this.tabR.Size = new System.Drawing.Size(1224, 523);
            this.tabR.TabIndex = 4;
            this.tabR.Text = "R (recovered and resistant)";
            this.tabR.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(725, 14);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 17);
            this.label4.TabIndex = 24;
            this.label4.Tag = "Enter any notes for this input section.";
            this.label4.Text = "Section Notes";
            // 
            // txt_RNotes
            // 
            this.txt_RNotes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_RNotes.Location = new System.Drawing.Point(713, 35);
            this.txt_RNotes.Margin = new System.Windows.Forms.Padding(4);
            this.txt_RNotes.Multiline = true;
            this.txt_RNotes.Name = "txt_RNotes";
            this.txt_RNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_RNotes.Size = new System.Drawing.Size(288, 264);
            this.txt_RNotes.TabIndex = 23;
            this.txt_RNotes.Tag = "string";
            this.txt_RNotes.Validating += new System.ComponentModel.CancelEventHandler(this.txt_RNotes_Validating);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label111);
            this.groupBox9.Controls.Add(this.label112);
            this.groupBox9.Controls.Add(this.txtDaysR);
            this.groupBox9.Location = new System.Drawing.Point(4, 79);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox9.Size = new System.Drawing.Size(701, 123);
            this.groupBox9.TabIndex = 9;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Duration of resistance for those without permanent immunity";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(19, 53);
            this.label111.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(267, 17);
            this.label111.TabIndex = 21;
            this.label111.Text = "What is the duration of immunity in days?";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(303, 83);
            this.label112.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(206, 17);
            this.label112.TabIndex = 22;
            this.label112.Text = "(Integer or distribution function)";
            // 
            // txtDaysR
            // 
            this.txtDaysR.Location = new System.Drawing.Point(306, 48);
            this.txtDaysR.Margin = new System.Windows.Forms.Padding(4);
            this.txtDaysR.Name = "txtDaysR";
            this.txtDaysR.Size = new System.Drawing.Size(384, 22);
            this.txtDaysR.TabIndex = 20;
            this.txtDaysR.Tag = "fun,0";
            this.txtDaysR.Text = "0";
            this.txtDaysR.Validating += new System.ComponentModel.CancelEventHandler(this.txtDaysR_Validating);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label36);
            this.groupBox10.Controls.Add(this.txtPropPermanentR);
            this.groupBox10.Controls.Add(this.label37);
            this.groupBox10.Location = new System.Drawing.Point(4, 4);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox10.Size = new System.Drawing.Size(701, 75);
            this.groupBox10.TabIndex = 8;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Permanent resistance";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(422, 54);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(180, 17);
            this.label36.TabIndex = 11;
            this.label36.Text = "(Probability from 0.0 to 1.0)";
            // 
            // txtPropPermanentR
            // 
            this.txtPropPermanentR.Location = new System.Drawing.Point(425, 31);
            this.txtPropPermanentR.Margin = new System.Windows.Forms.Padding(4);
            this.txtPropPermanentR.Name = "txtPropPermanentR";
            this.txtPropPermanentR.Size = new System.Drawing.Size(201, 22);
            this.txtPropPermanentR.TabIndex = 17;
            this.txtPropPermanentR.Tag = "fun,0,1";
            this.txtPropPermanentR.Text = "0.1";
            this.txtPropPermanentR.Validating += new System.ComponentModel.CancelEventHandler(this.txtPropPermanentR_Validating);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(17, 34);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(400, 17);
            this.label37.TabIndex = 9;
            this.label37.Text = "What proportion of R individuals acquire permanent immunity?";
            // 
            // tabV
            // 
            this.tabV.AutoScroll = true;
            this.tabV.Controls.Add(this.label17);
            this.tabV.Controls.Add(this.txt_VNotes);
            this.tabV.Controls.Add(this.groupBox14);
            this.tabV.Controls.Add(this.groupBox13);
            this.tabV.Controls.Add(this.groupBox12);
            this.tabV.Location = new System.Drawing.Point(4, 25);
            this.tabV.Margin = new System.Windows.Forms.Padding(4);
            this.tabV.Name = "tabV";
            this.tabV.Padding = new System.Windows.Forms.Padding(4);
            this.tabV.Size = new System.Drawing.Size(1224, 523);
            this.tabV.TabIndex = 5;
            this.tabV.Text = "Vaccination";
            this.tabV.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(720, 12);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(96, 17);
            this.label17.TabIndex = 26;
            this.label17.Tag = "Enter any notes for this input section.";
            this.label17.Text = "Section Notes";
            // 
            // txt_VNotes
            // 
            this.txt_VNotes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_VNotes.Location = new System.Drawing.Point(703, 33);
            this.txt_VNotes.Margin = new System.Windows.Forms.Padding(4);
            this.txt_VNotes.Multiline = true;
            this.txt_VNotes.Name = "txt_VNotes";
            this.txt_VNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_VNotes.Size = new System.Drawing.Size(496, 412);
            this.txt_VNotes.TabIndex = 10;
            this.txt_VNotes.Tag = "string";
            this.txt_VNotes.Validating += new System.ComponentModel.CancelEventHandler(this.txt_VNotes_Validating);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.label25);
            this.groupBox14.Controls.Add(this.label53);
            this.groupBox14.Controls.Add(this.txtVaccDuration);
            this.groupBox14.Controls.Add(this.label50);
            this.groupBox14.Controls.Add(this.label51);
            this.groupBox14.Controls.Add(this.txtVaccEfficacy);
            this.groupBox14.Enabled = false;
            this.groupBox14.Location = new System.Drawing.Point(4, 312);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox14.Size = new System.Drawing.Size(691, 133);
            this.groupBox14.TabIndex = 2;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Efficacy and Duration";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(356, 105);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(282, 17);
            this.label25.TabIndex = 12;
            this.label25.Text = "(Enter 0 or a very big number if permanent)";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(24, 84);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(239, 17);
            this.label53.TabIndex = 10;
            this.label53.Tag = "This can be a value sampled from a distribution, if there is a range of days of e" +
    "ffectiveness.";
            this.label53.Text = "Days the vaccine remains effective =";
            // 
            // txtVaccDuration
            // 
            this.txtVaccDuration.Location = new System.Drawing.Point(359, 79);
            this.txtVaccDuration.Margin = new System.Windows.Forms.Padding(4);
            this.txtVaccDuration.Name = "txtVaccDuration";
            this.txtVaccDuration.Size = new System.Drawing.Size(300, 22);
            this.txtVaccDuration.TabIndex = 10;
            this.txtVaccDuration.Tag = "fun,0";
            this.txtVaccDuration.Text = "300";
            this.txtVaccDuration.Validating += new System.ComponentModel.CancelEventHandler(this.txtVaccDuration_Validating);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(356, 50);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(156, 17);
            this.label50.TabIndex = 8;
            this.label50.Text = "(Probability from 0 to 1)";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(24, 28);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(306, 17);
            this.label51.TabIndex = 7;
            this.label51.Text = "Efficacy (likelihood that protection is attained) =";
            // 
            // txtVaccEfficacy
            // 
            this.txtVaccEfficacy.Location = new System.Drawing.Point(359, 24);
            this.txtVaccEfficacy.Margin = new System.Windows.Forms.Padding(4);
            this.txtVaccEfficacy.Name = "txtVaccEfficacy";
            this.txtVaccEfficacy.Size = new System.Drawing.Size(300, 22);
            this.txtVaccEfficacy.TabIndex = 9;
            this.txtVaccEfficacy.Tag = "fun,0,1";
            this.txtVaccEfficacy.Text = "0.75";
            this.txtVaccEfficacy.Validating += new System.ComponentModel.CancelEventHandler(this.txtVaccEfficacy_Validating);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label48);
            this.groupBox13.Controls.Add(this.label49);
            this.groupBox13.Controls.Add(this.txtVaccAd);
            this.groupBox13.Controls.Add(this.label46);
            this.groupBox13.Controls.Add(this.label47);
            this.groupBox13.Controls.Add(this.txtVaccSA);
            this.groupBox13.Controls.Add(this.label44);
            this.groupBox13.Controls.Add(this.label45);
            this.groupBox13.Controls.Add(this.txtVacc0);
            this.groupBox13.Enabled = false;
            this.groupBox13.Location = new System.Drawing.Point(4, 182);
            this.groupBox13.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox13.Size = new System.Drawing.Size(691, 130);
            this.groupBox13.TabIndex = 1;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "What proportion of each age class  do you vaccinate?";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(445, 98);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(126, 17);
            this.label48.TabIndex = 14;
            this.label48.Text = "(Value from 0 to 1)";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(24, 98);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(44, 17);
            this.label49.TabIndex = 13;
            this.label49.Tag = "Adults are individuals that have reached breeding age.";
            this.label49.Text = "Adult:";
            // 
            // txtVaccAd
            // 
            this.txtVaccAd.Location = new System.Drawing.Point(149, 95);
            this.txtVaccAd.Margin = new System.Windows.Forms.Padding(4);
            this.txtVaccAd.Name = "txtVaccAd";
            this.txtVaccAd.Size = new System.Drawing.Size(285, 22);
            this.txtVaccAd.TabIndex = 8;
            this.txtVaccAd.Tag = "fun,0,1";
            this.txtVaccAd.Text = "0.25";
            this.txtVaccAd.Validating += new System.ComponentModel.CancelEventHandler(this.txtVaccAd_Validating);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(445, 63);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(126, 17);
            this.label46.TabIndex = 11;
            this.label46.Text = "(Value from 0 to 1)";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(24, 64);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(73, 17);
            this.label47.TabIndex = 10;
            this.label47.Tag = "\"Subadults\" are those 1 year or older, but not yet breeding age.";
            this.label47.Text = "Sub-adult:";
            // 
            // txtVaccSA
            // 
            this.txtVaccSA.Location = new System.Drawing.Point(149, 60);
            this.txtVaccSA.Margin = new System.Windows.Forms.Padding(4);
            this.txtVaccSA.Name = "txtVaccSA";
            this.txtVaccSA.Size = new System.Drawing.Size(285, 22);
            this.txtVaccSA.TabIndex = 7;
            this.txtVaccSA.Tag = "fun,0,1";
            this.txtVaccSA.Text = "0.25";
            this.txtVaccSA.Validating += new System.ComponentModel.CancelEventHandler(this.txtVaccSA_Validating);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(445, 30);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(126, 17);
            this.label44.TabIndex = 8;
            this.label44.Text = "(Value from 0 to 1)";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(24, 31);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(64, 17);
            this.label45.TabIndex = 7;
            this.label45.Tag = "\"Juvenile\" is defined as an individual less than 1 year of age.";
            this.label45.Text = "Juvenile:";
            // 
            // txtVacc0
            // 
            this.txtVacc0.Location = new System.Drawing.Point(149, 27);
            this.txtVacc0.Margin = new System.Windows.Forms.Padding(4);
            this.txtVacc0.Name = "txtVacc0";
            this.txtVacc0.Size = new System.Drawing.Size(285, 22);
            this.txtVacc0.TabIndex = 6;
            this.txtVacc0.Tag = "fun,0,1";
            this.txtVacc0.Text = "0.25";
            this.txtVacc0.Validating += new System.ComponentModel.CancelEventHandler(this.txtVacc0_Validating);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label91);
            this.groupBox12.Controls.Add(this.txtVaccDaysStart);
            this.groupBox12.Controls.Add(this.label42);
            this.groupBox12.Controls.Add(this.txtVaccDays);
            this.groupBox12.Controls.Add(this.label40);
            this.groupBox12.Controls.Add(this.label39);
            this.groupBox12.Controls.Add(this.txtVaccPrev);
            this.groupBox12.Controls.Add(this.chkVaccPrevalence);
            this.groupBox12.Controls.Add(this.chkVaccInterval);
            this.groupBox12.Controls.Add(this.chkVaccNow);
            this.groupBox12.Location = new System.Drawing.Point(4, 4);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox12.Size = new System.Drawing.Size(691, 178);
            this.groupBox12.TabIndex = 0;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "When do you want to vaccinate?";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(356, 79);
            this.label91.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(100, 17);
            this.label91.TabIndex = 10;
            this.label91.Text = "Starting at day";
            // 
            // txtVaccDaysStart
            // 
            this.txtVaccDaysStart.Enabled = false;
            this.txtVaccDaysStart.Location = new System.Drawing.Point(464, 76);
            this.txtVaccDaysStart.Margin = new System.Windows.Forms.Padding(4);
            this.txtVaccDaysStart.Name = "txtVaccDaysStart";
            this.txtVaccDaysStart.Size = new System.Drawing.Size(195, 22);
            this.txtVaccDaysStart.TabIndex = 3;
            this.txtVaccDaysStart.Tag = "fun,1";
            this.txtVaccDaysStart.Text = "365";
            this.txtVaccDaysStart.Validating += new System.ComponentModel.CancelEventHandler(this.txtVaccDaysStart_Validating);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(14, 79);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(115, 17);
            this.label42.TabIndex = 7;
            this.label42.Text = "Interval in days =";
            // 
            // txtVaccDays
            // 
            this.txtVaccDays.Enabled = false;
            this.txtVaccDays.Location = new System.Drawing.Point(139, 76);
            this.txtVaccDays.Margin = new System.Windows.Forms.Padding(4);
            this.txtVaccDays.Name = "txtVaccDays";
            this.txtVaccDays.Size = new System.Drawing.Size(204, 22);
            this.txtVaccDays.TabIndex = 2;
            this.txtVaccDays.Tag = "fun,1";
            this.txtVaccDays.Text = "365";
            this.txtVaccDays.Validating += new System.ComponentModel.CancelEventHandler(this.txtVaccDays_Validating);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(445, 140);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(164, 17);
            this.label40.TabIndex = 5;
            this.label40.Text = "(P or Prev = Prevalence)";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(79, 140);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(79, 17);
            this.label39.TabIndex = 4;
            this.label39.Tag = "The default function is just an example: in this case, vaccinations are implement" +
    "ed when prevalence exceeds 10%.";
            this.label39.Text = "Condition =";
            // 
            // txtVaccPrev
            // 
            this.txtVaccPrev.Enabled = false;
            this.txtVaccPrev.Location = new System.Drawing.Point(204, 137);
            this.txtVaccPrev.Margin = new System.Windows.Forms.Padding(4);
            this.txtVaccPrev.Name = "txtVaccPrev";
            this.txtVaccPrev.Size = new System.Drawing.Size(231, 22);
            this.txtVaccPrev.TabIndex = 5;
            this.txtVaccPrev.Tag = "fun";
            this.txtVaccPrev.Text = "=PREV>0.1";
            this.txtVaccPrev.Validating += new System.ComponentModel.CancelEventHandler(this.txtVaccPrev_Validating);
            // 
            // chkVaccPrevalence
            // 
            this.chkVaccPrevalence.AutoSize = true;
            this.chkVaccPrevalence.Location = new System.Drawing.Point(16, 112);
            this.chkVaccPrevalence.Margin = new System.Windows.Forms.Padding(4);
            this.chkVaccPrevalence.Name = "chkVaccPrevalence";
            this.chkVaccPrevalence.Size = new System.Drawing.Size(243, 21);
            this.chkVaccPrevalence.TabIndex = 4;
            this.chkVaccPrevalence.Text = "Vaccinate when a condition is met";
            this.chkVaccPrevalence.UseVisualStyleBackColor = true;
            this.chkVaccPrevalence.CheckedChanged += new System.EventHandler(this.chkVaccPrevalence_CheckedChanged);
            // 
            // chkVaccInterval
            // 
            this.chkVaccInterval.AutoSize = true;
            this.chkVaccInterval.Location = new System.Drawing.Point(16, 54);
            this.chkVaccInterval.Margin = new System.Windows.Forms.Padding(4);
            this.chkVaccInterval.Name = "chkVaccInterval";
            this.chkVaccInterval.Size = new System.Drawing.Size(260, 21);
            this.chkVaccInterval.TabIndex = 1;
            this.chkVaccInterval.Text = "Vaccinate at a specified time interval";
            this.chkVaccInterval.UseVisualStyleBackColor = true;
            this.chkVaccInterval.CheckedChanged += new System.EventHandler(this.chkVaccInterval_CheckedChanged);
            // 
            // chkVaccNow
            // 
            this.chkVaccNow.AutoSize = true;
            this.chkVaccNow.Location = new System.Drawing.Point(16, 25);
            this.chkVaccNow.Margin = new System.Windows.Forms.Padding(4);
            this.chkVaccNow.Name = "chkVaccNow";
            this.chkVaccNow.Size = new System.Drawing.Size(375, 21);
            this.chkVaccNow.TabIndex = 0;
            this.chkVaccNow.Text = "Vaccinate now (simulation is paused or not yet started)";
            this.chkVaccNow.UseVisualStyleBackColor = true;
            this.chkVaccNow.CheckedChanged += new System.EventHandler(this.chkVaccNow_CheckedChanged);
            // 
            // tabC
            // 
            this.tabC.AutoScroll = true;
            this.tabC.Controls.Add(this.label20);
            this.tabC.Controls.Add(this.txt_CullNotes);
            this.tabC.Controls.Add(this.groupBox22);
            this.tabC.Controls.Add(this.groupBox21);
            this.tabC.Location = new System.Drawing.Point(4, 25);
            this.tabC.Margin = new System.Windows.Forms.Padding(4);
            this.tabC.Name = "tabC";
            this.tabC.Padding = new System.Windows.Forms.Padding(4);
            this.tabC.Size = new System.Drawing.Size(1224, 523);
            this.tabC.TabIndex = 6;
            this.tabC.Text = "Removals";
            this.tabC.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(677, 8);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(96, 17);
            this.label20.TabIndex = 28;
            this.label20.Tag = "Enter any notes for this input section.";
            this.label20.Text = "Section Notes";
            // 
            // txt_CullNotes
            // 
            this.txt_CullNotes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_CullNotes.Location = new System.Drawing.Point(664, 29);
            this.txt_CullNotes.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CullNotes.Multiline = true;
            this.txt_CullNotes.Name = "txt_CullNotes";
            this.txt_CullNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_CullNotes.Size = new System.Drawing.Size(329, 412);
            this.txt_CullNotes.TabIndex = 9;
            this.txt_CullNotes.Tag = "string";
            this.txt_CullNotes.Validating += new System.ComponentModel.CancelEventHandler(this.txt_CullNotes_Validating);
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.label78);
            this.groupBox22.Controls.Add(this.label79);
            this.groupBox22.Controls.Add(this.txtCullAgeAd);
            this.groupBox22.Controls.Add(this.label80);
            this.groupBox22.Controls.Add(this.label81);
            this.groupBox22.Controls.Add(this.txtCullAgeSA);
            this.groupBox22.Controls.Add(this.label82);
            this.groupBox22.Controls.Add(this.label83);
            this.groupBox22.Controls.Add(this.txtCullAge0);
            this.groupBox22.Enabled = false;
            this.groupBox22.Location = new System.Drawing.Point(4, 182);
            this.groupBox22.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox22.Size = new System.Drawing.Size(652, 130);
            this.groupBox22.TabIndex = 2;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "What proportion of each age class  do you remove?";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(445, 95);
            this.label78.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(126, 17);
            this.label78.TabIndex = 14;
            this.label78.Text = "(Value from 0 to 1)";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(24, 98);
            this.label79.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(44, 17);
            this.label79.TabIndex = 13;
            this.label79.Text = "Adult:";
            // 
            // txtCullAgeAd
            // 
            this.txtCullAgeAd.Location = new System.Drawing.Point(149, 95);
            this.txtCullAgeAd.Margin = new System.Windows.Forms.Padding(4);
            this.txtCullAgeAd.Name = "txtCullAgeAd";
            this.txtCullAgeAd.Size = new System.Drawing.Size(285, 22);
            this.txtCullAgeAd.TabIndex = 8;
            this.txtCullAgeAd.Tag = "fun,0,1";
            this.txtCullAgeAd.Text = "0.25";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(445, 62);
            this.label80.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(126, 17);
            this.label80.TabIndex = 11;
            this.label80.Text = "(Value from 0 to 1)";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(24, 64);
            this.label81.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(73, 17);
            this.label81.TabIndex = 10;
            this.label81.Text = "Sub-adult:";
            // 
            // txtCullAgeSA
            // 
            this.txtCullAgeSA.Location = new System.Drawing.Point(149, 60);
            this.txtCullAgeSA.Margin = new System.Windows.Forms.Padding(4);
            this.txtCullAgeSA.Name = "txtCullAgeSA";
            this.txtCullAgeSA.Size = new System.Drawing.Size(285, 22);
            this.txtCullAgeSA.TabIndex = 7;
            this.txtCullAgeSA.Tag = "23";
            this.txtCullAgeSA.Text = "0.25";
            this.txtCullAgeSA.Validating += new System.ComponentModel.CancelEventHandler(this.txtCullAgeSA_Validating);
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(445, 31);
            this.label82.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(126, 17);
            this.label82.TabIndex = 8;
            this.label82.Text = "(Value from 0 to 1)";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(24, 31);
            this.label83.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(64, 17);
            this.label83.TabIndex = 7;
            this.label83.Text = "Juvenile:";
            // 
            // txtCullAge0
            // 
            this.txtCullAge0.Location = new System.Drawing.Point(149, 27);
            this.txtCullAge0.Margin = new System.Windows.Forms.Padding(4);
            this.txtCullAge0.Name = "txtCullAge0";
            this.txtCullAge0.Size = new System.Drawing.Size(285, 22);
            this.txtCullAge0.TabIndex = 6;
            this.txtCullAge0.Tag = "fun,0,1";
            this.txtCullAge0.Text = "0.25";
            this.txtCullAge0.Validating += new System.ComponentModel.CancelEventHandler(this.txtCullAge0_Validating);
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.label99);
            this.groupBox21.Controls.Add(this.txtCullDaysStart);
            this.groupBox21.Controls.Add(this.label75);
            this.groupBox21.Controls.Add(this.txtCullDays);
            this.groupBox21.Controls.Add(this.label76);
            this.groupBox21.Controls.Add(this.label77);
            this.groupBox21.Controls.Add(this.txtCullPrevalence);
            this.groupBox21.Controls.Add(this.chkCullPrevalence);
            this.groupBox21.Controls.Add(this.chkCullInterval);
            this.groupBox21.Controls.Add(this.chkCullNow);
            this.groupBox21.Location = new System.Drawing.Point(4, 4);
            this.groupBox21.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox21.Size = new System.Drawing.Size(652, 178);
            this.groupBox21.TabIndex = 1;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "When do you want to remove animals?";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(393, 81);
            this.label99.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(100, 17);
            this.label99.TabIndex = 13;
            this.label99.Text = "Starting at day";
            // 
            // txtCullDaysStart
            // 
            this.txtCullDaysStart.Enabled = false;
            this.txtCullDaysStart.Location = new System.Drawing.Point(501, 76);
            this.txtCullDaysStart.Margin = new System.Windows.Forms.Padding(4);
            this.txtCullDaysStart.Name = "txtCullDaysStart";
            this.txtCullDaysStart.Size = new System.Drawing.Size(137, 22);
            this.txtCullDaysStart.TabIndex = 3;
            this.txtCullDaysStart.Tag = "fun,1";
            this.txtCullDaysStart.Text = "365";
            this.txtCullDaysStart.Validating += new System.ComponentModel.CancelEventHandler(this.txtCullDaysStart_Validating);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(79, 81);
            this.label75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(115, 17);
            this.label75.TabIndex = 7;
            this.label75.Text = "Interval in days =";
            // 
            // txtCullDays
            // 
            this.txtCullDays.Enabled = false;
            this.txtCullDays.Location = new System.Drawing.Point(204, 78);
            this.txtCullDays.Margin = new System.Windows.Forms.Padding(4);
            this.txtCullDays.Name = "txtCullDays";
            this.txtCullDays.Size = new System.Drawing.Size(177, 22);
            this.txtCullDays.TabIndex = 2;
            this.txtCullDays.Tag = "fun,1";
            this.txtCullDays.Text = "365";
            this.txtCullDays.Validating += new System.ComponentModel.CancelEventHandler(this.txtCullDays_Validating);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(445, 140);
            this.label76.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(172, 17);
            this.label76.TabIndex = 5;
            this.label76.Text = "(P or PREV = Prevalence)";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(79, 140);
            this.label77.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(79, 17);
            this.label77.TabIndex = 4;
            this.label77.Text = "Condition =";
            // 
            // txtCullPrevalence
            // 
            this.txtCullPrevalence.Enabled = false;
            this.txtCullPrevalence.Location = new System.Drawing.Point(204, 137);
            this.txtCullPrevalence.Margin = new System.Windows.Forms.Padding(4);
            this.txtCullPrevalence.Name = "txtCullPrevalence";
            this.txtCullPrevalence.Size = new System.Drawing.Size(231, 22);
            this.txtCullPrevalence.TabIndex = 5;
            this.txtCullPrevalence.Tag = "fun";
            this.txtCullPrevalence.Text = "=PREV>0.1";
            this.txtCullPrevalence.Validating += new System.ComponentModel.CancelEventHandler(this.txtCullPrevalence_Validating);
            // 
            // chkCullPrevalence
            // 
            this.chkCullPrevalence.AutoSize = true;
            this.chkCullPrevalence.Location = new System.Drawing.Point(16, 112);
            this.chkCullPrevalence.Margin = new System.Windows.Forms.Padding(4);
            this.chkCullPrevalence.Name = "chkCullPrevalence";
            this.chkCullPrevalence.Size = new System.Drawing.Size(385, 21);
            this.chkCullPrevalence.TabIndex = 4;
            this.chkCullPrevalence.Text = "Remove (at most once per year) when a condition is met";
            this.chkCullPrevalence.UseVisualStyleBackColor = true;
            this.chkCullPrevalence.CheckedChanged += new System.EventHandler(this.chkCullPrevalence_CheckedChanged);
            // 
            // chkCullInterval
            // 
            this.chkCullInterval.AutoSize = true;
            this.chkCullInterval.Location = new System.Drawing.Point(16, 54);
            this.chkCullInterval.Margin = new System.Windows.Forms.Padding(4);
            this.chkCullInterval.Name = "chkCullInterval";
            this.chkCullInterval.Size = new System.Drawing.Size(250, 21);
            this.chkCullInterval.TabIndex = 1;
            this.chkCullInterval.Text = "Remove at a specified time interval";
            this.chkCullInterval.UseVisualStyleBackColor = true;
            this.chkCullInterval.CheckedChanged += new System.EventHandler(this.chkCullInterval_CheckedChanged);
            // 
            // chkCullNow
            // 
            this.chkCullNow.AutoSize = true;
            this.chkCullNow.Location = new System.Drawing.Point(16, 25);
            this.chkCullNow.Margin = new System.Windows.Forms.Padding(4);
            this.chkCullNow.Name = "chkCullNow";
            this.chkCullNow.Size = new System.Drawing.Size(365, 21);
            this.chkCullNow.TabIndex = 0;
            this.chkCullNow.Text = "Remove now (simulation is paused or not yet started)";
            this.chkCullNow.UseVisualStyleBackColor = true;
            this.chkCullNow.CheckedChanged += new System.EventHandler(this.chkCullNow_CheckedChanged);
            // 
            // tabInitN
            // 
            this.tabInitN.AutoScroll = true;
            this.tabInitN.Controls.Add(this.label52);
            this.tabInitN.Controls.Add(this.label41);
            this.tabInitN.Controls.Add(this.txtSADays);
            this.tabInitN.Controls.Add(this.label32);
            this.tabInitN.Controls.Add(this.txtJuvDays);
            this.tabInitN.Controls.Add(this.label16);
            this.tabInitN.Controls.Add(this.txt_InitNotes);
            this.tabInitN.Controls.Add(this.groupBox11);
            this.tabInitN.Controls.Add(this.label38);
            this.tabInitN.Controls.Add(this.txtInitN);
            this.tabInitN.Location = new System.Drawing.Point(4, 25);
            this.tabInitN.Margin = new System.Windows.Forms.Padding(4);
            this.tabInitN.Name = "tabInitN";
            this.tabInitN.Size = new System.Drawing.Size(1224, 523);
            this.tabInitN.TabIndex = 8;
            this.tabInitN.Text = "Initial Population";
            this.tabInitN.UseVisualStyleBackColor = true;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(556, 306);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(168, 17);
            this.label52.TabIndex = 31;
            this.label52.Tag = "Changing the definition of adults will affect demographic rates and output tallie" +
    "s";
            this.label52.Text = "<= Adults are age (days) ";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(284, 306);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(204, 17);
            this.label41.TabIndex = 30;
            this.label41.Tag = "Changing the definition of \"Subadults\" will affect demographic rates and output t" +
    "allies";
            this.label41.Text = "<= Subadults are age (days) < ";
            // 
            // txtSADays
            // 
            this.txtSADays.Location = new System.Drawing.Point(496, 303);
            this.txtSADays.Margin = new System.Windows.Forms.Padding(4);
            this.txtSADays.Name = "txtSADays";
            this.txtSADays.Size = new System.Drawing.Size(52, 22);
            this.txtSADays.TabIndex = 6;
            this.txtSADays.Tag = "int,0";
            this.txtSADays.Text = "0";
            this.txtSADays.Validating += new System.ComponentModel.CancelEventHandler(this.txtSADays_Validating);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(33, 306);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(180, 17);
            this.label32.TabIndex = 28;
            this.label32.Tag = "Changing the definition of \"Juvenile\" will affect demographic rates and output ta" +
    "llies";
            this.label32.Text = "Juveniles are age (days) < ";
            // 
            // txtJuvDays
            // 
            this.txtJuvDays.Location = new System.Drawing.Point(224, 304);
            this.txtJuvDays.Margin = new System.Windows.Forms.Padding(4);
            this.txtJuvDays.Name = "txtJuvDays";
            this.txtJuvDays.Size = new System.Drawing.Size(52, 22);
            this.txtJuvDays.TabIndex = 5;
            this.txtJuvDays.Tag = "int,0";
            this.txtJuvDays.Text = "365";
            this.txtJuvDays.Validating += new System.ComponentModel.CancelEventHandler(this.txtJuvDays_Validating);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(738, 4);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(96, 17);
            this.label16.TabIndex = 26;
            this.label16.Tag = "Enter any notes for this input section.";
            this.label16.Text = "Section Notes";
            // 
            // txt_InitNotes
            // 
            this.txt_InitNotes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_InitNotes.Location = new System.Drawing.Point(725, 25);
            this.txt_InitNotes.Margin = new System.Windows.Forms.Padding(4);
            this.txt_InitNotes.Multiline = true;
            this.txt_InitNotes.Name = "txt_InitNotes";
            this.txt_InitNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_InitNotes.Size = new System.Drawing.Size(276, 305);
            this.txt_InitNotes.TabIndex = 7;
            this.txt_InitNotes.Tag = "string";
            this.txt_InitNotes.Validating += new System.ComponentModel.CancelEventHandler(this.txt_InitNotes_Validating);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.btnRescaleInitProportions);
            this.groupBox11.Controls.Add(this.btnSAD);
            this.groupBox11.Controls.Add(this.fgInitStates);
            this.groupBox11.Controls.Add(this.radioNproportions);
            this.groupBox11.Controls.Add(this.radioNcounts);
            this.groupBox11.Location = new System.Drawing.Point(28, 57);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(689, 242);
            this.groupBox11.TabIndex = 11;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Initial distribution of disease states";
            // 
            // btnRescaleInitProportions
            // 
            this.btnRescaleInitProportions.Enabled = false;
            this.btnRescaleInitProportions.Location = new System.Drawing.Point(32, 212);
            this.btnRescaleInitProportions.Margin = new System.Windows.Forms.Padding(4);
            this.btnRescaleInitProportions.Name = "btnRescaleInitProportions";
            this.btnRescaleInitProportions.Size = new System.Drawing.Size(294, 27);
            this.btnRescaleInitProportions.TabIndex = 3;
            this.btnRescaleInitProportions.TabStop = false;
            this.btnRescaleInitProportions.Tag = "";
            this.btnRescaleInitProportions.Text = "Scale proportions to 100.";
            this.btnRescaleInitProportions.UseVisualStyleBackColor = true;
            this.btnRescaleInitProportions.Click += new System.EventHandler(this.btnRescaleInitProportions_Click);
            // 
            // btnSAD
            // 
            this.btnSAD.Location = new System.Drawing.Point(341, 212);
            this.btnSAD.Margin = new System.Windows.Forms.Padding(4);
            this.btnSAD.Name = "btnSAD";
            this.btnSAD.Size = new System.Drawing.Size(294, 27);
            this.btnSAD.TabIndex = 4;
            this.btnSAD.TabStop = false;
            this.btnSAD.Tag = "Stable Age Distribution will be only approximate.";
            this.btnSAD.Text = "Re-distribute P/S to stable age distribution";
            this.btnSAD.UseVisualStyleBackColor = true;
            this.btnSAD.Click += new System.EventHandler(this.btnSAD_Click);
            // 
            // fgInitStates
            // 
            this.fgInitStates.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.fgInitStates.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.fgInitStates.ColumnInfo = resources.GetString("fgInitStates.ColumnInfo");
            this.fgInitStates.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.fgInitStates.Location = new System.Drawing.Point(32, 82);
            this.fgInitStates.Margin = new System.Windows.Forms.Padding(4);
            this.fgInitStates.Name = "fgInitStates";
            this.fgInitStates.Rows.Count = 5;
            this.fgInitStates.Rows.DefaultSize = 21;
            this.fgInitStates.Size = new System.Drawing.Size(637, 127);
            this.fgInitStates.StyleInfo = resources.GetString("fgInitStates.StyleInfo");
            this.fgInitStates.TabIndex = 2;
            this.fgInitStates.CellChanged += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgInitStates_CellChanged);
            // 
            // radioNproportions
            // 
            this.radioNproportions.AutoSize = true;
            this.radioNproportions.Location = new System.Drawing.Point(150, 36);
            this.radioNproportions.Margin = new System.Windows.Forms.Padding(4);
            this.radioNproportions.Name = "radioNproportions";
            this.radioNproportions.Size = new System.Drawing.Size(250, 21);
            this.radioNproportions.TabIndex = 1;
            this.radioNproportions.Text = "Enter relative proportions of total N";
            this.radioNproportions.UseVisualStyleBackColor = true;
            // 
            // radioNcounts
            // 
            this.radioNcounts.AutoSize = true;
            this.radioNcounts.Checked = true;
            this.radioNcounts.Location = new System.Drawing.Point(32, 36);
            this.radioNcounts.Margin = new System.Windows.Forms.Padding(4);
            this.radioNcounts.Name = "radioNcounts";
            this.radioNcounts.Size = new System.Drawing.Size(109, 21);
            this.radioNcounts.TabIndex = 1;
            this.radioNcounts.TabStop = true;
            this.radioNcounts.Text = "Enter counts";
            this.radioNcounts.UseVisualStyleBackColor = true;
            this.radioNcounts.CheckedChanged += new System.EventHandler(this.radioNcounts_CheckedChanged);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(24, 25);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(142, 17);
            this.label38.TabIndex = 10;
            this.label38.Tag = "If you enter counts below, then the total N is calculated for you.";
            this.label38.Text = "Initial Population Size";
            // 
            // txtInitN
            // 
            this.txtInitN.Enabled = false;
            this.txtInitN.Location = new System.Drawing.Point(195, 21);
            this.txtInitN.Margin = new System.Windows.Forms.Padding(4);
            this.txtInitN.Name = "txtInitN";
            this.txtInitN.Size = new System.Drawing.Size(52, 22);
            this.txtInitN.TabIndex = 0;
            this.txtInitN.Tag = "int,0";
            this.txtInitN.Text = "0";
            this.txtInitN.TextChanged += new System.EventHandler(this.txtInitN_TextChanged);
            this.txtInitN.Validating += new System.ComponentModel.CancelEventHandler(this.txtInitN_Validating);
            // 
            // tabDemog
            // 
            this.tabDemog.AutoScroll = true;
            this.tabDemog.Controls.Add(this.label15);
            this.tabDemog.Controls.Add(this.txt_DemogNotes);
            this.tabDemog.Controls.Add(this.groupBox26);
            this.tabDemog.Controls.Add(this.groupBox25);
            this.tabDemog.Controls.Add(this.groupBox24);
            this.tabDemog.Controls.Add(this.groupBox23);
            this.tabDemog.Location = new System.Drawing.Point(4, 25);
            this.tabDemog.Margin = new System.Windows.Forms.Padding(4);
            this.tabDemog.Name = "tabDemog";
            this.tabDemog.Size = new System.Drawing.Size(1224, 523);
            this.tabDemog.TabIndex = 7;
            this.tabDemog.Text = "Demography";
            this.tabDemog.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(636, 8);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(96, 17);
            this.label15.TabIndex = 26;
            this.label15.Tag = "Enter any notes for this input section.";
            this.label15.Text = "Section Notes";
            // 
            // txt_DemogNotes
            // 
            this.txt_DemogNotes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_DemogNotes.Location = new System.Drawing.Point(623, 29);
            this.txt_DemogNotes.Margin = new System.Windows.Forms.Padding(4);
            this.txt_DemogNotes.Multiline = true;
            this.txt_DemogNotes.Name = "txt_DemogNotes";
            this.txt_DemogNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_DemogNotes.Size = new System.Drawing.Size(676, 462);
            this.txt_DemogNotes.TabIndex = 11;
            this.txt_DemogNotes.Tag = "string";
            this.txt_DemogNotes.Validating += new System.ComponentModel.CancelEventHandler(this.txt_DemogNotes_Validating);
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.label84);
            this.groupBox26.Controls.Add(this.txtK);
            this.groupBox26.Controls.Add(this.txtKDay);
            this.groupBox26.Controls.Add(this.radioKDay);
            this.groupBox26.Controls.Add(this.radioMaintainK);
            this.groupBox26.Location = new System.Drawing.Point(0, 434);
            this.groupBox26.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox26.Size = new System.Drawing.Size(615, 60);
            this.groupBox26.TabIndex = 13;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Carrying capacity (K)";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(156, 16);
            this.label84.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(117, 17);
            this.label84.TabIndex = 6;
            this.label84.Text = "Carrying capacity";
            // 
            // txtK
            // 
            this.txtK.Location = new System.Drawing.Point(292, 11);
            this.txtK.Margin = new System.Windows.Forms.Padding(4);
            this.txtK.Name = "txtK";
            this.txtK.Size = new System.Drawing.Size(228, 22);
            this.txtK.TabIndex = 7;
            this.txtK.Tag = "fun,0";
            this.txtK.Validating += new System.ComponentModel.CancelEventHandler(this.txtK_Validating);
            // 
            // txtKDay
            // 
            this.txtKDay.Location = new System.Drawing.Point(533, 32);
            this.txtKDay.Margin = new System.Windows.Forms.Padding(4);
            this.txtKDay.Name = "txtKDay";
            this.txtKDay.Size = new System.Drawing.Size(67, 22);
            this.txtKDay.TabIndex = 10;
            this.txtKDay.Tag = "int,0";
            this.txtKDay.Validating += new System.ComponentModel.CancelEventHandler(this.txtKDay_Validating);
            // 
            // radioKDay
            // 
            this.radioKDay.AutoSize = true;
            this.radioKDay.Location = new System.Drawing.Point(307, 38);
            this.radioKDay.Margin = new System.Windows.Forms.Padding(4);
            this.radioKDay.Name = "radioKDay";
            this.radioKDay.Size = new System.Drawing.Size(216, 21);
            this.radioKDay.TabIndex = 9;
            this.radioKDay.TabStop = true;
            this.radioKDay.Text = "Apply K once per year on day";
            this.radioKDay.UseVisualStyleBackColor = true;
            this.radioKDay.CheckedChanged += new System.EventHandler(this.radioKDay_CheckedChanged);
            // 
            // radioMaintainK
            // 
            this.radioMaintainK.AutoSize = true;
            this.radioMaintainK.Location = new System.Drawing.Point(12, 36);
            this.radioMaintainK.Margin = new System.Windows.Forms.Padding(4);
            this.radioMaintainK.Name = "radioMaintainK";
            this.radioMaintainK.Size = new System.Drawing.Size(250, 21);
            this.radioMaintainK.TabIndex = 8;
            this.radioMaintainK.TabStop = true;
            this.radioMaintainK.Text = "Maintain K for each day of the year";
            this.radioMaintainK.UseVisualStyleBackColor = true;
            this.radioMaintainK.CheckedChanged += new System.EventHandler(this.radioMaintainK_CheckedChanged);
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.chkEnterStageMort);
            this.groupBox25.Controls.Add(this.fgLifeTable);
            this.groupBox25.Controls.Add(this.btnCopyLifeTable);
            this.groupBox25.Location = new System.Drawing.Point(0, 91);
            this.groupBox25.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox25.Size = new System.Drawing.Size(615, 335);
            this.groupBox25.TabIndex = 12;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Life Table rates";
            // 
            // chkEnterStageMort
            // 
            this.chkEnterStageMort.AutoSize = true;
            this.chkEnterStageMort.Location = new System.Drawing.Point(45, 23);
            this.chkEnterStageMort.Margin = new System.Windows.Forms.Padding(4);
            this.chkEnterStageMort.Name = "chkEnterStageMort";
            this.chkEnterStageMort.Size = new System.Drawing.Size(535, 21);
            this.chkEnterStageMort.TabIndex = 4;
            this.chkEnterStageMort.Tag = "If the J and SA stages are not 1 year in duration, you might want to enter the mo" +
    "rtalities for that stage duration, rather than on an annual basis.";
            this.chkEnterStageMort.Text = "Enter Juvenile and Subadult mortalities as stage-based rather than annual rates";
            this.chkEnterStageMort.UseVisualStyleBackColor = true;
            this.chkEnterStageMort.CheckedChanged += new System.EventHandler(this.chkEnterStageMort_CheckedChanged);
            // 
            // fgLifeTable
            // 
            this.fgLifeTable.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.fgLifeTable.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.fgLifeTable.ColumnInfo = resources.GetString("fgLifeTable.ColumnInfo");
            this.fgLifeTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.fgLifeTable.Location = new System.Drawing.Point(8, 54);
            this.fgLifeTable.Margin = new System.Windows.Forms.Padding(4);
            this.fgLifeTable.Name = "fgLifeTable";
            this.fgLifeTable.Rows.Count = 11;
            this.fgLifeTable.Rows.DefaultSize = 21;
            this.fgLifeTable.Size = new System.Drawing.Size(591, 235);
            this.fgLifeTable.StyleInfo = resources.GetString("fgLifeTable.StyleInfo");
            this.fgLifeTable.TabIndex = 5;
            this.fgLifeTable.CellChanged += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgLifeTable_CellChanged);
            // 
            // btnCopyLifeTable
            // 
            this.btnCopyLifeTable.Location = new System.Drawing.Point(169, 297);
            this.btnCopyLifeTable.Margin = new System.Windows.Forms.Padding(4);
            this.btnCopyLifeTable.Name = "btnCopyLifeTable";
            this.btnCopyLifeTable.Size = new System.Drawing.Size(263, 28);
            this.btnCopyLifeTable.TabIndex = 6;
            this.btnCopyLifeTable.TabStop = false;
            this.btnCopyLifeTable.Tag = "Different rates for S, E, I, and R can be entered to specify indirect effects of " +
    "the disease.";
            this.btnCopyLifeTable.Text = "Copy rates from S to all disease states";
            this.btnCopyLifeTable.UseVisualStyleBackColor = true;
            this.btnCopyLifeTable.Click += new System.EventHandler(this.btnCopyLifeTable_Click);
            // 
            // groupBox24
            // 
            this.groupBox24.Location = new System.Drawing.Point(1013, 226);
            this.groupBox24.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox24.Size = new System.Drawing.Size(11, 10);
            this.groupBox24.TabIndex = 1;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "groupBox24";
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.label113);
            this.groupBox23.Controls.Add(this.txtBreedDays);
            this.groupBox23.Controls.Add(this.label101);
            this.groupBox23.Controls.Add(this.label100);
            this.groupBox23.Controls.Add(this.txtBreedAgeDays);
            this.groupBox23.Controls.Add(this.label86);
            this.groupBox23.Controls.Add(this.label85);
            this.groupBox23.Controls.Add(this.txtMaxAge);
            this.groupBox23.Controls.Add(this.txtBreedAge);
            this.groupBox23.Location = new System.Drawing.Point(0, 0);
            this.groupBox23.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox23.Size = new System.Drawing.Size(615, 90);
            this.groupBox23.TabIndex = 0;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Timing of breeding";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(9, 68);
            this.label113.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(360, 17);
            this.label113.TabIndex = 20;
            this.label113.Tag = "Enter a day or distribution function.";
            this.label113.Text = "On what day(s) during the year are offspring produced?";
            // 
            // txtBreedDays
            // 
            this.txtBreedDays.Location = new System.Drawing.Point(375, 65);
            this.txtBreedDays.Margin = new System.Windows.Forms.Padding(4);
            this.txtBreedDays.Name = "txtBreedDays";
            this.txtBreedDays.Size = new System.Drawing.Size(233, 22);
            this.txtBreedDays.TabIndex = 3;
            this.txtBreedDays.Tag = "fun,0";
            this.txtBreedDays.Text = "0";
            this.txtBreedDays.Validating += new System.ComponentModel.CancelEventHandler(this.txtBreedDays_Validating);
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(491, 26);
            this.label101.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(38, 17);
            this.label101.TabIndex = 12;
            this.label101.Tag = "If you enter first age of breeding as days, the age in years will be calculated f" +
    "or you.";
            this.label101.Text = "days";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(369, 24);
            this.label100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(64, 17);
            this.label100.TabIndex = 11;
            this.label100.Tag = "If you enter first age of breeding as years, the age in days will be calculated f" +
    "or you.";
            this.label100.Text = "years, or";
            // 
            // txtBreedAgeDays
            // 
            this.txtBreedAgeDays.Location = new System.Drawing.Point(439, 22);
            this.txtBreedAgeDays.Margin = new System.Windows.Forms.Padding(4);
            this.txtBreedAgeDays.Name = "txtBreedAgeDays";
            this.txtBreedAgeDays.Size = new System.Drawing.Size(49, 22);
            this.txtBreedAgeDays.TabIndex = 1;
            this.txtBreedAgeDays.Tag = "int,0";
            this.txtBreedAgeDays.Validating += new System.ComponentModel.CancelEventHandler(this.txtBreedAgeDays_Validating);
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(12, 47);
            this.label86.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(98, 17);
            this.label86.TabIndex = 5;
            this.label86.Text = "Maximum age:";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(12, 22);
            this.label85.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(267, 17);
            this.label85.TabIndex = 4;
            this.label85.Text = "Age at which first offspring are produced:";
            // 
            // txtMaxAge
            // 
            this.txtMaxAge.Location = new System.Drawing.Point(110, 43);
            this.txtMaxAge.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaxAge.Name = "txtMaxAge";
            this.txtMaxAge.Size = new System.Drawing.Size(58, 22);
            this.txtMaxAge.TabIndex = 2;
            this.txtMaxAge.Tag = "int,1";
            this.txtMaxAge.Validating += new System.ComponentModel.CancelEventHandler(this.txtMaxAge_Validating);
            // 
            // txtBreedAge
            // 
            this.txtBreedAge.Location = new System.Drawing.Point(300, 19);
            this.txtBreedAge.Margin = new System.Windows.Forms.Padding(4);
            this.txtBreedAge.Name = "txtBreedAge";
            this.txtBreedAge.Size = new System.Drawing.Size(61, 22);
            this.txtBreedAge.TabIndex = 0;
            this.txtBreedAge.Tag = "int,0";
            this.txtBreedAge.Validating += new System.ComponentModel.CancelEventHandler(this.txtBreedAge_Validating);
            // 
            // tabSpatial
            // 
            this.tabSpatial.AutoScroll = true;
            this.tabSpatial.Controls.Add(this.groupBox15);
            this.tabSpatial.Location = new System.Drawing.Point(4, 25);
            this.tabSpatial.Margin = new System.Windows.Forms.Padding(4);
            this.tabSpatial.Name = "tabSpatial";
            this.tabSpatial.Size = new System.Drawing.Size(1224, 523);
            this.tabSpatial.TabIndex = 9;
            this.tabSpatial.Text = "Spatial Settings";
            this.tabSpatial.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.chkUseSpatial);
            this.groupBox15.Controls.Add(this.label21);
            this.groupBox15.Controls.Add(this.txt_SpatialNotes);
            this.groupBox15.Controls.Add(this.groupBox19);
            this.groupBox15.Controls.Add(this.groupBox18);
            this.groupBox15.Controls.Add(this.groupBox17);
            this.groupBox15.Controls.Add(this.groupBox16);
            this.groupBox15.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox15.Location = new System.Drawing.Point(0, 0);
            this.groupBox15.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox15.Size = new System.Drawing.Size(1224, 457);
            this.groupBox15.TabIndex = 0;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Define coordinates for spatially based transmission (optional)";
            // 
            // chkUseSpatial
            // 
            this.chkUseSpatial.AutoSize = true;
            this.chkUseSpatial.Location = new System.Drawing.Point(12, 23);
            this.chkUseSpatial.Margin = new System.Windows.Forms.Padding(4);
            this.chkUseSpatial.Name = "chkUseSpatial";
            this.chkUseSpatial.Size = new System.Drawing.Size(389, 21);
            this.chkUseSpatial.TabIndex = 0;
            this.chkUseSpatial.Text = "Do you want to model the spatial locations of individuals?";
            this.chkUseSpatial.UseVisualStyleBackColor = true;
            this.chkUseSpatial.CheckedChanged += new System.EventHandler(this.chkUseSpatial_CheckedChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(764, 17);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 17);
            this.label21.TabIndex = 28;
            this.label21.Tag = "Enter any notes for this input section.";
            this.label21.Text = "Section Notes";
            // 
            // txt_SpatialNotes
            // 
            this.txt_SpatialNotes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_SpatialNotes.Location = new System.Drawing.Point(752, 38);
            this.txt_SpatialNotes.Margin = new System.Windows.Forms.Padding(4);
            this.txt_SpatialNotes.Multiline = true;
            this.txt_SpatialNotes.Name = "txt_SpatialNotes";
            this.txt_SpatialNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_SpatialNotes.Size = new System.Drawing.Size(464, 410);
            this.txt_SpatialNotes.TabIndex = 19;
            this.txt_SpatialNotes.Tag = "string";
            this.txt_SpatialNotes.Validating += new System.ComponentModel.CancelEventHandler(this.txt_SpatialNotes_Validating);
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.radioSpatialAbsorbingBoundary);
            this.groupBox19.Controls.Add(this.radioSpatialReflectingBoundary);
            this.groupBox19.Controls.Add(this.radioSpatialNoBoundary);
            this.groupBox19.Enabled = false;
            this.groupBox19.Location = new System.Drawing.Point(4, 402);
            this.groupBox19.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox19.Size = new System.Drawing.Size(740, 51);
            this.groupBox19.TabIndex = 5;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Boundary rules";
            // 
            // radioSpatialAbsorbingBoundary
            // 
            this.radioSpatialAbsorbingBoundary.AutoSize = true;
            this.radioSpatialAbsorbingBoundary.Location = new System.Drawing.Point(413, 22);
            this.radioSpatialAbsorbingBoundary.Margin = new System.Windows.Forms.Padding(4);
            this.radioSpatialAbsorbingBoundary.Name = "radioSpatialAbsorbingBoundary";
            this.radioSpatialAbsorbingBoundary.Size = new System.Drawing.Size(196, 21);
            this.radioSpatialAbsorbingBoundary.TabIndex = 18;
            this.radioSpatialAbsorbingBoundary.TabStop = true;
            this.radioSpatialAbsorbingBoundary.Tag = "With this option, individuals that hit the edge of the grid don\'t move any farthe" +
    "r in that time step.";
            this.radioSpatialAbsorbingBoundary.Text = "Absorbing grid boundaries";
            this.radioSpatialAbsorbingBoundary.UseVisualStyleBackColor = true;
            this.radioSpatialAbsorbingBoundary.CheckedChanged += new System.EventHandler(this.radioSpatialAbsorbingBoundary_CheckedChanged);
            // 
            // radioSpatialReflectingBoundary
            // 
            this.radioSpatialReflectingBoundary.AutoSize = true;
            this.radioSpatialReflectingBoundary.Location = new System.Drawing.Point(188, 22);
            this.radioSpatialReflectingBoundary.Margin = new System.Windows.Forms.Padding(4);
            this.radioSpatialReflectingBoundary.Name = "radioSpatialReflectingBoundary";
            this.radioSpatialReflectingBoundary.Size = new System.Drawing.Size(195, 21);
            this.radioSpatialReflectingBoundary.TabIndex = 17;
            this.radioSpatialReflectingBoundary.TabStop = true;
            this.radioSpatialReflectingBoundary.Tag = "With this option, individuals that reach the edge of the grid will bounce back.";
            this.radioSpatialReflectingBoundary.Text = "Reflecting grid boundaries";
            this.radioSpatialReflectingBoundary.UseVisualStyleBackColor = true;
            this.radioSpatialReflectingBoundary.CheckedChanged += new System.EventHandler(this.radioSpatialReflectingBoundary_CheckedChanged);
            // 
            // radioSpatialNoBoundary
            // 
            this.radioSpatialNoBoundary.AutoSize = true;
            this.radioSpatialNoBoundary.Checked = true;
            this.radioSpatialNoBoundary.Location = new System.Drawing.Point(19, 20);
            this.radioSpatialNoBoundary.Margin = new System.Windows.Forms.Padding(4);
            this.radioSpatialNoBoundary.Name = "radioSpatialNoBoundary";
            this.radioSpatialNoBoundary.Size = new System.Drawing.Size(150, 21);
            this.radioSpatialNoBoundary.TabIndex = 16;
            this.radioSpatialNoBoundary.TabStop = true;
            this.radioSpatialNoBoundary.Tag = "This choice allows individuals to keep moving out in an ever-expanding grid. ";
            this.radioSpatialNoBoundary.Text = "No grid boundaries";
            this.radioSpatialNoBoundary.UseVisualStyleBackColor = true;
            this.radioSpatialNoBoundary.CheckedChanged += new System.EventHandler(this.radioSpatialNoBoundary_CheckedChanged);
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.label89);
            this.groupBox18.Controls.Add(this.txtMoveWhen);
            this.groupBox18.Controls.Add(this.txtSpatialMove);
            this.groupBox18.Controls.Add(this.radioSpatialMoveRandom);
            this.groupBox18.Controls.Add(this.label62);
            this.groupBox18.Controls.Add(this.txtSpatialMoveYFunc);
            this.groupBox18.Controls.Add(this.label63);
            this.groupBox18.Controls.Add(this.txtSpatialMoveXFunc);
            this.groupBox18.Controls.Add(this.radioSpatialMoveFuncs);
            this.groupBox18.Controls.Add(this.radioSpatialMoveNone);
            this.groupBox18.Enabled = false;
            this.groupBox18.Location = new System.Drawing.Point(4, 232);
            this.groupBox18.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox18.Size = new System.Drawing.Size(740, 170);
            this.groupBox18.TabIndex = 4;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Daily movement rules";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(29, 139);
            this.label89.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(276, 17);
            this.label89.TabIndex = 26;
            this.label89.Text = "Move when the following condition occurs: ";
            // 
            // txtMoveWhen
            // 
            this.txtMoveWhen.Enabled = false;
            this.txtMoveWhen.Location = new System.Drawing.Point(299, 136);
            this.txtMoveWhen.Margin = new System.Windows.Forms.Padding(4);
            this.txtMoveWhen.Name = "txtMoveWhen";
            this.txtMoveWhen.Size = new System.Drawing.Size(422, 22);
            this.txtMoveWhen.TabIndex = 15;
            this.txtMoveWhen.Tag = "fun";
            this.txtMoveWhen.Text = "=(DAY%30=0)AND(S=\'M\')";
            this.txtMoveWhen.Validating += new System.ComponentModel.CancelEventHandler(this.txtMoveWhen_Validating);
            // 
            // txtSpatialMove
            // 
            this.txtSpatialMove.Enabled = false;
            this.txtSpatialMove.Location = new System.Drawing.Point(316, 46);
            this.txtSpatialMove.Margin = new System.Windows.Forms.Padding(4);
            this.txtSpatialMove.Name = "txtSpatialMove";
            this.txtSpatialMove.Size = new System.Drawing.Size(405, 22);
            this.txtSpatialMove.TabIndex = 11;
            this.txtSpatialMove.Tag = "fun";
            this.txtSpatialMove.Text = "=IUNIFORM(0;10)";
            this.txtSpatialMove.Validating += new System.ComponentModel.CancelEventHandler(this.txtSpatialMove_Validating);
            // 
            // radioSpatialMoveRandom
            // 
            this.radioSpatialMoveRandom.AutoSize = true;
            this.radioSpatialMoveRandom.Location = new System.Drawing.Point(27, 47);
            this.radioSpatialMoveRandom.Margin = new System.Windows.Forms.Padding(4);
            this.radioSpatialMoveRandom.Name = "radioSpatialMoveRandom";
            this.radioSpatialMoveRandom.Size = new System.Drawing.Size(282, 21);
            this.radioSpatialMoveRandom.TabIndex = 10;
            this.radioSpatialMoveRandom.TabStop = true;
            this.radioSpatialMoveRandom.Text = "Move in a random direction for distance:";
            this.radioSpatialMoveRandom.UseVisualStyleBackColor = true;
            this.radioSpatialMoveRandom.CheckedChanged += new System.EventHandler(this.radioSpatialMoveRandom_CheckedChanged);
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(231, 107);
            this.label62.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(99, 17);
            this.label62.TabIndex = 19;
            this.label62.Tag = "Caution: When used in functions, X and Y coordinates are symbolized XCOORD and YC" +
    "OORD, not as X and Y";
            this.label62.Text = "New YCOORD";
            // 
            // txtSpatialMoveYFunc
            // 
            this.txtSpatialMoveYFunc.Enabled = false;
            this.txtSpatialMoveYFunc.Location = new System.Drawing.Point(337, 104);
            this.txtSpatialMoveYFunc.Margin = new System.Windows.Forms.Padding(4);
            this.txtSpatialMoveYFunc.Name = "txtSpatialMoveYFunc";
            this.txtSpatialMoveYFunc.Size = new System.Drawing.Size(384, 22);
            this.txtSpatialMoveYFunc.TabIndex = 14;
            this.txtSpatialMoveYFunc.Tag = "fun";
            this.txtSpatialMoveYFunc.Text = "=YCOORD+5*NRAND";
            this.txtSpatialMoveYFunc.Validating += new System.ComponentModel.CancelEventHandler(this.txtSpatialMoveYFunc_Validating);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(229, 79);
            this.label63.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(99, 17);
            this.label63.TabIndex = 17;
            this.label63.Tag = "Caution: When used in functions, X and Y coordinates are symbolized XCOORD and YC" +
    "OORD, not as X and Y";
            this.label63.Text = "New XCOORD";
            // 
            // txtSpatialMoveXFunc
            // 
            this.txtSpatialMoveXFunc.Enabled = false;
            this.txtSpatialMoveXFunc.Location = new System.Drawing.Point(337, 76);
            this.txtSpatialMoveXFunc.Margin = new System.Windows.Forms.Padding(4);
            this.txtSpatialMoveXFunc.Name = "txtSpatialMoveXFunc";
            this.txtSpatialMoveXFunc.Size = new System.Drawing.Size(384, 22);
            this.txtSpatialMoveXFunc.TabIndex = 13;
            this.txtSpatialMoveXFunc.Tag = "fun";
            this.txtSpatialMoveXFunc.Text = "=XCOORD+5*NRAND";
            this.txtSpatialMoveXFunc.Validating += new System.ComponentModel.CancelEventHandler(this.txtSpatialMoveXFunc_Validating);
            // 
            // radioSpatialMoveFuncs
            // 
            this.radioSpatialMoveFuncs.AutoSize = true;
            this.radioSpatialMoveFuncs.Location = new System.Drawing.Point(27, 76);
            this.radioSpatialMoveFuncs.Margin = new System.Windows.Forms.Padding(4);
            this.radioSpatialMoveFuncs.Name = "radioSpatialMoveFuncs";
            this.radioSpatialMoveFuncs.Size = new System.Drawing.Size(187, 21);
            this.radioSpatialMoveFuncs.TabIndex = 12;
            this.radioSpatialMoveFuncs.TabStop = true;
            this.radioSpatialMoveFuncs.Text = "Movement rule functions:";
            this.radioSpatialMoveFuncs.UseVisualStyleBackColor = true;
            this.radioSpatialMoveFuncs.CheckedChanged += new System.EventHandler(this.radioSpatialMoveFuncs_CheckedChanged);
            // 
            // radioSpatialMoveNone
            // 
            this.radioSpatialMoveNone.AutoSize = true;
            this.radioSpatialMoveNone.Checked = true;
            this.radioSpatialMoveNone.Location = new System.Drawing.Point(29, 23);
            this.radioSpatialMoveNone.Margin = new System.Windows.Forms.Padding(4);
            this.radioSpatialMoveNone.Name = "radioSpatialMoveNone";
            this.radioSpatialMoveNone.Size = new System.Drawing.Size(116, 21);
            this.radioSpatialMoveNone.TabIndex = 9;
            this.radioSpatialMoveNone.TabStop = true;
            this.radioSpatialMoveNone.Tag = "If \"no movement\" is chosen, then the rest of the values in this Movement Rules se" +
    "ction are ignored.";
            this.radioSpatialMoveNone.Text = "No movement";
            this.radioSpatialMoveNone.UseVisualStyleBackColor = true;
            this.radioSpatialMoveNone.CheckedChanged += new System.EventHandler(this.radioSpatialMoveNone_CheckedChanged);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.label60);
            this.groupBox17.Controls.Add(this.txtSpatialYFunc);
            this.groupBox17.Controls.Add(this.label61);
            this.groupBox17.Controls.Add(this.txtSpatialXFunc);
            this.groupBox17.Controls.Add(this.radioSeedFunctions);
            this.groupBox17.Controls.Add(this.radioSeedRandom);
            this.groupBox17.Enabled = false;
            this.groupBox17.Location = new System.Drawing.Point(4, 134);
            this.groupBox17.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox17.Size = new System.Drawing.Size(740, 97);
            this.groupBox17.TabIndex = 3;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Initial seeding of individuals";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(183, 66);
            this.label60.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(89, 17);
            this.label60.TabIndex = 13;
            this.label60.Text = "Y-coordinate";
            // 
            // txtSpatialYFunc
            // 
            this.txtSpatialYFunc.Enabled = false;
            this.txtSpatialYFunc.Location = new System.Drawing.Point(280, 64);
            this.txtSpatialYFunc.Margin = new System.Windows.Forms.Padding(4);
            this.txtSpatialYFunc.Name = "txtSpatialYFunc";
            this.txtSpatialYFunc.Size = new System.Drawing.Size(396, 22);
            this.txtSpatialYFunc.TabIndex = 8;
            this.txtSpatialYFunc.Tag = "fun";
            this.txtSpatialYFunc.Text = "=50+10*NRAND";
            this.txtSpatialYFunc.Validating += new System.ComponentModel.CancelEventHandler(this.txtSpatialYFunc_Validating);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(184, 37);
            this.label61.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(89, 17);
            this.label61.TabIndex = 11;
            this.label61.Text = "X-coordinate";
            // 
            // txtSpatialXFunc
            // 
            this.txtSpatialXFunc.Enabled = false;
            this.txtSpatialXFunc.Location = new System.Drawing.Point(280, 34);
            this.txtSpatialXFunc.Margin = new System.Windows.Forms.Padding(4);
            this.txtSpatialXFunc.Name = "txtSpatialXFunc";
            this.txtSpatialXFunc.Size = new System.Drawing.Size(396, 22);
            this.txtSpatialXFunc.TabIndex = 7;
            this.txtSpatialXFunc.Tag = "fun";
            this.txtSpatialXFunc.Text = "=50+10*NRAND";
            this.txtSpatialXFunc.Validating += new System.ComponentModel.CancelEventHandler(this.txtSpatialXFunc_Validating);
            // 
            // radioSeedFunctions
            // 
            this.radioSeedFunctions.AutoSize = true;
            this.radioSeedFunctions.Location = new System.Drawing.Point(25, 49);
            this.radioSeedFunctions.Margin = new System.Windows.Forms.Padding(4);
            this.radioSeedFunctions.Name = "radioSeedFunctions";
            this.radioSeedFunctions.Size = new System.Drawing.Size(155, 21);
            this.radioSeedFunctions.TabIndex = 6;
            this.radioSeedFunctions.TabStop = true;
            this.radioSeedFunctions.Tag = "If you seed locations with functions, you will probably want to sample from a dis" +
    "tribution. ";
            this.radioSeedFunctions.Text = "Seed with functions:";
            this.radioSeedFunctions.UseVisualStyleBackColor = true;
            this.radioSeedFunctions.CheckedChanged += new System.EventHandler(this.radioSeedFunctions_CheckedChanged);
            // 
            // radioSeedRandom
            // 
            this.radioSeedRandom.AutoSize = true;
            this.radioSeedRandom.Checked = true;
            this.radioSeedRandom.Location = new System.Drawing.Point(25, 21);
            this.radioSeedRandom.Margin = new System.Windows.Forms.Padding(4);
            this.radioSeedRandom.Name = "radioSeedRandom";
            this.radioSeedRandom.Size = new System.Drawing.Size(124, 21);
            this.radioSeedRandom.TabIndex = 5;
            this.radioSeedRandom.TabStop = true;
            this.radioSeedRandom.Text = "Seed randomly";
            this.radioSeedRandom.UseVisualStyleBackColor = true;
            this.radioSeedRandom.CheckedChanged += new System.EventHandler(this.radioSeedRandom_CheckedChanged);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.label57);
            this.groupBox16.Controls.Add(this.txtSpatialYmax);
            this.groupBox16.Controls.Add(this.label58);
            this.groupBox16.Controls.Add(this.label59);
            this.groupBox16.Controls.Add(this.txtSpatialYmin);
            this.groupBox16.Controls.Add(this.label56);
            this.groupBox16.Controls.Add(this.txtSpatialXmax);
            this.groupBox16.Controls.Add(this.label55);
            this.groupBox16.Controls.Add(this.label54);
            this.groupBox16.Controls.Add(this.txtSpatialXmin);
            this.groupBox16.Enabled = false;
            this.groupBox16.Location = new System.Drawing.Point(4, 54);
            this.groupBox16.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox16.Size = new System.Drawing.Size(740, 80);
            this.groupBox16.TabIndex = 2;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Define initial grid";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(341, 55);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(66, 17);
            this.label57.TabIndex = 9;
            this.label57.Text = "Maximum";
            // 
            // txtSpatialYmax
            // 
            this.txtSpatialYmax.Location = new System.Drawing.Point(420, 51);
            this.txtSpatialYmax.Margin = new System.Windows.Forms.Padding(4);
            this.txtSpatialYmax.Name = "txtSpatialYmax";
            this.txtSpatialYmax.Size = new System.Drawing.Size(72, 22);
            this.txtSpatialYmax.TabIndex = 4;
            this.txtSpatialYmax.Tag = "int,0";
            this.txtSpatialYmax.Text = "100";
            this.txtSpatialYmax.Validating += new System.ComponentModel.CancelEventHandler(this.txtSpatialYmax_Validating);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(160, 55);
            this.label58.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(63, 17);
            this.label58.TabIndex = 7;
            this.label58.Text = "Minimum";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(21, 55);
            this.label59.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(89, 17);
            this.label59.TabIndex = 6;
            this.label59.Text = "Y dimension:";
            // 
            // txtSpatialYmin
            // 
            this.txtSpatialYmin.Location = new System.Drawing.Point(239, 51);
            this.txtSpatialYmin.Margin = new System.Windows.Forms.Padding(4);
            this.txtSpatialYmin.Name = "txtSpatialYmin";
            this.txtSpatialYmin.Size = new System.Drawing.Size(72, 22);
            this.txtSpatialYmin.TabIndex = 3;
            this.txtSpatialYmin.Tag = "int,0";
            this.txtSpatialYmin.Text = "0";
            this.txtSpatialYmin.Validating += new System.ComponentModel.CancelEventHandler(this.txtSpatialYmin_Validating);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(341, 27);
            this.label56.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(66, 17);
            this.label56.TabIndex = 4;
            this.label56.Text = "Maximum";
            // 
            // txtSpatialXmax
            // 
            this.txtSpatialXmax.Location = new System.Drawing.Point(420, 22);
            this.txtSpatialXmax.Margin = new System.Windows.Forms.Padding(4);
            this.txtSpatialXmax.Name = "txtSpatialXmax";
            this.txtSpatialXmax.Size = new System.Drawing.Size(72, 22);
            this.txtSpatialXmax.TabIndex = 2;
            this.txtSpatialXmax.Tag = "int,0";
            this.txtSpatialXmax.Text = "100";
            this.txtSpatialXmax.Validating += new System.ComponentModel.CancelEventHandler(this.txtSpatialXmax_Validating);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(160, 27);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(63, 17);
            this.label55.TabIndex = 2;
            this.label55.Text = "Minimum";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(21, 27);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(89, 17);
            this.label54.TabIndex = 1;
            this.label54.Text = "X dimension:";
            // 
            // txtSpatialXmin
            // 
            this.txtSpatialXmin.Location = new System.Drawing.Point(239, 22);
            this.txtSpatialXmin.Margin = new System.Windows.Forms.Padding(4);
            this.txtSpatialXmin.Name = "txtSpatialXmin";
            this.txtSpatialXmin.Size = new System.Drawing.Size(72, 22);
            this.txtSpatialXmin.TabIndex = 1;
            this.txtSpatialXmin.Tag = "int,0";
            this.txtSpatialXmin.Text = "0";
            this.txtSpatialXmin.Validating += new System.ComponentModel.CancelEventHandler(this.txtSpatialXmin_Validating);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Location = new System.Drawing.Point(0, 28);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1232, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuStrip2
            // 
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.runToolStripMenuItem,
            this.resultsToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip2.Size = new System.Drawing.Size(1232, 28);
            this.menuStrip2.TabIndex = 2;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadToolStripMenuItem,
            this.openRecentToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.clearToolStripMenuItem,
            this.exitWithoutSavingToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Tag = "You can load input values from a saved project, or start fresh to create a new pr" +
    "oject.";
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.loadToolStripMenuItem.Text = "Load input file";
            this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // openRecentToolStripMenuItem
            // 
            this.openRecentToolStripMenuItem.Name = "openRecentToolStripMenuItem";
            this.openRecentToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openRecentToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.openRecentToolStripMenuItem.Text = "Open Recent";
            this.openRecentToolStripMenuItem.Click += new System.EventHandler(this.openRecentToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.saveAsToolStripMenuItem.Text = "SaveAs";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.clearToolStripMenuItem.Text = "Clear input";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click);
            // 
            // exitWithoutSavingToolStripMenuItem
            // 
            this.exitWithoutSavingToolStripMenuItem.Name = "exitWithoutSavingToolStripMenuItem";
            this.exitWithoutSavingToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.exitWithoutSavingToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.exitWithoutSavingToolStripMenuItem.Text = "Quit";
            this.exitWithoutSavingToolStripMenuItem.Click += new System.EventHandler(this.exitWithoutSavingToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.noHelpToolStripMenuItem,
            this.manualToolStripMenuItem,
            this.aboutToolStripMenuItem,
            this.supportConservationToolStripMenuItem,
            this.userRegistrationToolStripMenuItem,
            this.checkForUpdatesToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.helpToolStripMenuItem.Tag = "Someday, a manual and context-sensitive help will be available.";
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // noHelpToolStripMenuItem
            // 
            this.noHelpToolStripMenuItem.Name = "noHelpToolStripMenuItem";
            this.noHelpToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.noHelpToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.noHelpToolStripMenuItem.Text = "Help";
            this.noHelpToolStripMenuItem.Click += new System.EventHandler(this.noHelpToolStripMenuItem_Click);
            // 
            // manualToolStripMenuItem
            // 
            this.manualToolStripMenuItem.Name = "manualToolStripMenuItem";
            this.manualToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.manualToolStripMenuItem.Text = "Manual";
            this.manualToolStripMenuItem.Click += new System.EventHandler(this.manualToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // supportConservationToolStripMenuItem
            // 
            this.supportConservationToolStripMenuItem.Name = "supportConservationToolStripMenuItem";
            this.supportConservationToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.supportConservationToolStripMenuItem.Text = "Support Conservation!";
            this.supportConservationToolStripMenuItem.Click += new System.EventHandler(this.supportConservationToolStripMenuItem_Click);
            // 
            // userRegistrationToolStripMenuItem
            // 
            this.userRegistrationToolStripMenuItem.Name = "userRegistrationToolStripMenuItem";
            this.userRegistrationToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.userRegistrationToolStripMenuItem.Text = "User Registration";
            this.userRegistrationToolStripMenuItem.Click += new System.EventHandler(this.userRegistrationToolStripMenuItem_Click);
            // 
            // runToolStripMenuItem
            // 
            this.runToolStripMenuItem.Name = "runToolStripMenuItem";
            this.runToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.runToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.runToolStripMenuItem.Tag = "Generate results!";
            this.runToolStripMenuItem.Text = "Run";
            this.runToolStripMenuItem.Click += new System.EventHandler(this.runToolStripMenuItem_Click);
            // 
            // resultsToolStripMenuItem
            // 
            this.resultsToolStripMenuItem.Name = "resultsToolStripMenuItem";
            this.resultsToolStripMenuItem.Size = new System.Drawing.Size(67, 24);
            this.resultsToolStripMenuItem.Text = "Results";
            this.resultsToolStripMenuItem.ToolTipText = "View Results from simulation runs";
            this.resultsToolStripMenuItem.Click += new System.EventHandler(this.resultsToolStripMenuItem_Click);
            // 
            // checkForUpdatesToolStripMenuItem
            // 
            this.checkForUpdatesToolStripMenuItem.Name = "checkForUpdatesToolStripMenuItem";
            this.checkForUpdatesToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.checkForUpdatesToolStripMenuItem.Text = "Check for Updates";
            this.checkForUpdatesToolStripMenuItem.Click += new System.EventHandler(this.checkForUpdatesToolStripMenuItem_Click);
            // 
            // frmOutbreak2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1232, 605);
            this.Controls.Add(this.tbInput);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmOutbreak2";
            this.Text = "Outbreak";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmOutbreak2_FormClosing);
            this.Load += new System.EventHandler(this.frmOutbreak2_Load);
            this.tbInput.ResumeLayout(false);
            this.tabSettings.ResumeLayout(false);
            this.tabSettings.PerformLayout();
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            this.tabP.ResumeLayout(false);
            this.tabP.PerformLayout();
            this.groupBox29.ResumeLayout(false);
            this.groupBox29.PerformLayout();
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabS.ResumeLayout(false);
            this.tabS.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabE.ResumeLayout(false);
            this.tabE.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabI.ResumeLayout(false);
            this.tabI.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabR.ResumeLayout(false);
            this.tabR.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tabV.ResumeLayout(false);
            this.tabV.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.tabC.ResumeLayout(false);
            this.tabC.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.tabInitN.ResumeLayout(false);
            this.tabInitN.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgInitStates)).EndInit();
            this.tabDemog.ResumeLayout(false);
            this.tabDemog.PerformLayout();
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgLifeTable)).EndInit();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.tabSpatial.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tbInput;
        private System.Windows.Forms.TabPage tabP;
        private System.Windows.Forms.TabPage tabS;
        private System.Windows.Forms.TabPage tabE;
        private System.Windows.Forms.TabPage tabI;
        private System.Windows.Forms.TabPage tabR;
        private System.Windows.Forms.TabPage tabV;
        private System.Windows.Forms.TabPage tabC;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPropPermanentP;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtProbOutsideTransmission;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtProbOutsideEncounter;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtProbTransmission;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtPropPopEncounter;
        private System.Windows.Forms.TextBox txtDistanceEncounterFunc;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtNEncounter;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtProbDeath;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtProbReSusceptible;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtProbRecovery;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtPropPermanentI;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtPropPermanentR;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TabPage tabDemog;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitWithoutSavingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem noHelpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.TabPage tabInitN;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtInitN;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.RadioButton radioNproportions;
        private System.Windows.Forms.RadioButton radioNcounts;
        private System.Windows.Forms.CheckBox chkFixedNEncounter;
        private System.Windows.Forms.CheckBox chkProportionEncountered;
        private System.Windows.Forms.CheckBox chkSpatialEncounter;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtVaccDays;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtVaccPrev;
        private System.Windows.Forms.CheckBox chkVaccPrevalence;
        private System.Windows.Forms.CheckBox chkVaccInterval;
        private System.Windows.Forms.CheckBox chkVaccNow;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtVaccAd;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtVaccSA;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txtVacc0;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtVaccDuration;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txtVaccEfficacy;
        private System.Windows.Forms.TabPage tabSpatial;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txtSpatialYFunc;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txtSpatialXFunc;
        private System.Windows.Forms.RadioButton radioSeedFunctions;
        private System.Windows.Forms.RadioButton radioSeedRandom;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox txtSpatialYmax;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox txtSpatialYmin;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txtSpatialXmax;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtSpatialXmin;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.RadioButton radioSpatialAbsorbingBoundary;
        private System.Windows.Forms.RadioButton radioSpatialReflectingBoundary;
        private System.Windows.Forms.RadioButton radioSpatialNoBoundary;
        private System.Windows.Forms.TextBox txtSpatialMove;
        private System.Windows.Forms.RadioButton radioSpatialMoveRandom;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txtSpatialMoveYFunc;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox txtSpatialMoveXFunc;
        private System.Windows.Forms.RadioButton radioSpatialMoveFuncs;
        private System.Windows.Forms.RadioButton radioSpatialMoveNone;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox txtCullAgeAd;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox txtCullAgeSA;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox txtCullAge0;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox txtCullDays;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox txtCullPrevalence;
        private System.Windows.Forms.CheckBox chkCullPrevalence;
        private System.Windows.Forms.CheckBox chkCullInterval;
        private System.Windows.Forms.CheckBox chkCullNow;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.TextBox txtKDay;
        private System.Windows.Forms.RadioButton radioKDay;
        private System.Windows.Forms.RadioButton radioMaintainK;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox txtMaxAge;
        private System.Windows.Forms.TextBox txtBreedAge;
        private System.Windows.Forms.Button btnCopyLifeTable;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox txtK;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.TextBox txtMoveWhen;
        private System.Windows.Forms.ToolStripMenuItem resultsToolStripMenuItem;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.TextBox txtVaccDaysStart;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.CheckBox chkMaternalImmunity;
        private System.Windows.Forms.Label label93;
        private C1.Win.C1FlexGrid.C1FlexGrid fgInitStates;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.TextBox txtCullDaysStart;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.TextBox txtBreedAgeDays;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.TextBox txtDaysP;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.TextBox txtMaternalImmunityDays;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.TextBox txtDaysE;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.TextBox txtDaysI;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.TextBox txtDaysR;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.TextBox txtBreedDays;
        private System.Windows.Forms.TabPage tabSettings;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.CheckBox chkOutDaily;
        private System.Windows.Forms.CheckBox chkOutIndividuals;
        private System.Windows.Forms.CheckBox chkOutMM;
        private System.Windows.Forms.CheckBox chkOutIndList;
        private System.Windows.Forms.CheckBox chkOutEpiRates;
        private System.Windows.Forms.CheckBox chkOutYearly;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.TextBox txtDzTag;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.TextBox txtRunYears;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.TextBox txtRunIter;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.TextBox txtRunDays;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.TextBox txtOName;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_ENotes;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_RNotes;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_PNotes;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_SNotes;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_INotes;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txt_InitNotes;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_DemogNotes;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_VNotes;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txt_CullNotes;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txt_SpatialNotes;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtMaternalTransmission;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ToolStripMenuItem openRecentToolStripMenuItem;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.CheckBox chkUseSpatial;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtSceneName;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtSceneNotes;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox cboScenes;
        private System.Windows.Forms.Button btnDeleteScenario;
        private System.Windows.Forms.Button btnAddScenarios;
        private C1.Win.C1FlexGrid.C1FlexGrid fgLifeTable;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtSADays;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtJuvDays;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Button btnSAD;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Button btnRescaleInitProportions;
        private System.Windows.Forms.CheckBox chkEnterStageMort;
        private System.Windows.Forms.ToolStripMenuItem supportConservationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manualToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userRegistrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem checkForUpdatesToolStripMenuItem;
    }
}

