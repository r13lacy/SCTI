﻿using System;
using System.Windows.Forms;

namespace Outbreak2
{
    public partial class frmRegistration : Form
    {
        public frmRegistration()
        {
            InitializeComponent();

            lblRegistration1.Text = "If you have not already done so, please consider registering as a user of Outbreak."
                + "\r\n\nUser registration is optional, but it allows us to understand better how Outbreak is being used, so that we can better serve your needs with program enhancements and user support."
                + "\r\nIt also allows us to notify you (if you so indicate on the registration form) when there are major upgrades to Outbreak."
                + "\r\n\nNo information that you provide in the registration is made available to any other organization for any purpose.";
            lblRegistration2.Text = "Click on the following link to go to the User Registration webpage:";
            linkRegistration.Text = "http://www.vortex10.org/UserRegistration.aspx";

        }

        private void linkRegistration_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(linkRegistration.Text);
        }
    }
}
