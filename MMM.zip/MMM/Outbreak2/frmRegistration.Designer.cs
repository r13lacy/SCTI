﻿namespace Outbreak2
{
    partial class frmRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRegistration1 = new System.Windows.Forms.Label();
            this.linkRegistration = new System.Windows.Forms.LinkLabel();
            this.lblRegistration2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblRegistration1
            // 
            this.lblRegistration1.AutoSize = true;
            this.lblRegistration1.Location = new System.Drawing.Point(29, 23);
            this.lblRegistration1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRegistration1.MaximumSize = new System.Drawing.Size(507, 0);
            this.lblRegistration1.Name = "lblRegistration1";
            this.lblRegistration1.Size = new System.Drawing.Size(46, 17);
            this.lblRegistration1.TabIndex = 10;
            this.lblRegistration1.Text = "label1";
            // 
            // linkRegistration
            // 
            this.linkRegistration.AutoSize = true;
            this.linkRegistration.Location = new System.Drawing.Point(80, 244);
            this.linkRegistration.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkRegistration.Name = "linkRegistration";
            this.linkRegistration.Size = new System.Drawing.Size(297, 17);
            this.linkRegistration.TabIndex = 9;
            this.linkRegistration.TabStop = true;
            this.linkRegistration.Text = "http://www.vortex10.org/UserRegistration.aspx";
            this.linkRegistration.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkRegistration_LinkClicked);
            // 
            // lblRegistration2
            // 
            this.lblRegistration2.AutoSize = true;
            this.lblRegistration2.Location = new System.Drawing.Point(29, 208);
            this.lblRegistration2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRegistration2.MaximumSize = new System.Drawing.Size(507, 0);
            this.lblRegistration2.Name = "lblRegistration2";
            this.lblRegistration2.Size = new System.Drawing.Size(46, 17);
            this.lblRegistration2.TabIndex = 8;
            this.lblRegistration2.Text = "label1";
            // 
            // frmRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 284);
            this.Controls.Add(this.lblRegistration1);
            this.Controls.Add(this.linkRegistration);
            this.Controls.Add(this.lblRegistration2);
            this.Name = "frmRegistration";
            this.Text = "frmRegistration";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRegistration1;
        private System.Windows.Forms.LinkLabel linkRegistration;
        private System.Windows.Forms.Label lblRegistration2;
    }
}