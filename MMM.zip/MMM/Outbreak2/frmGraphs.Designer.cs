﻿namespace Outbreak2
{
    partial class frmGraphResults
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGraphResults));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cboPrevNgraphs = new System.Windows.Forms.ComboBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lblPieNs = new System.Windows.Forms.Label();
            this.chartPrevalence = new C1.Win.C1Chart.C1Chart();
            this.chartPie = new C1.Win.C1Chart.C1Chart();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.chartDemogSummary = new C1.Win.C1Chart.C1Chart();
            this.chartDiseaseSummary = new C1.Win.C1Chart.C1Chart();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartPrevalence)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartPie)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartDemogSummary)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartDiseaseSummary)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cboPrevNgraphs);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.lblPieNs);
            this.groupBox1.Controls.Add(this.chartPrevalence);
            this.groupBox1.Controls.Add(this.chartPie);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(13, 12, 13, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(1348, 327);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Population Summary Information";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1175, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "Selected graph:";
            // 
            // cboPrevNgraphs
            // 
            this.cboPrevNgraphs.FormattingEnabled = true;
            this.cboPrevNgraphs.Items.AddRange(new object[] {
            "Prevalence",
            "Population Size",
            "Prob. Extinction",
            "Quasi-Extinction (term.)",
            "Quasi-Extinction (int.)"});
            this.cboPrevNgraphs.Location = new System.Drawing.Point(1177, 44);
            this.cboPrevNgraphs.Margin = new System.Windows.Forms.Padding(4);
            this.cboPrevNgraphs.Name = "cboPrevNgraphs";
            this.cboPrevNgraphs.Size = new System.Drawing.Size(160, 24);
            this.cboPrevNgraphs.TabIndex = 7;
            this.cboPrevNgraphs.SelectedIndexChanged += new System.EventHandler(this.cboPrevNgraphs_SelectedIndexChanged);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(537, 247);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 28);
            this.button4.TabIndex = 6;
            this.button4.Text = "Save Graph";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(537, 283);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 28);
            this.button3.TabIndex = 5;
            this.button3.Text = "Print Graph";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1232, 247);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 28);
            this.button2.TabIndex = 4;
            this.button2.Text = "Save Graph";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1232, 283);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 28);
            this.button1.TabIndex = 3;
            this.button1.Text = "Print Graph";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblPieNs
            // 
            this.lblPieNs.AutoSize = true;
            this.lblPieNs.Location = new System.Drawing.Point(36, 87);
            this.lblPieNs.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPieNs.Name = "lblPieNs";
            this.lblPieNs.Size = new System.Drawing.Size(50, 102);
            this.lblPieNs.TabIndex = 2;
            this.lblPieNs.Text = "P = 5\r\nS = 35\r\nE = 10\r\nI = 8\r\nR = 22\r\nV = 10";
            // 
            // chartPrevalence
            // 
            this.chartPrevalence.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartPrevalence.Location = new System.Drawing.Point(659, 19);
            this.chartPrevalence.Margin = new System.Windows.Forms.Padding(4);
            this.chartPrevalence.Name = "chartPrevalence";
            this.chartPrevalence.PropBag = resources.GetString("chartPrevalence.PropBag");
            this.chartPrevalence.Size = new System.Drawing.Size(685, 304);
            this.chartPrevalence.TabIndex = 1;
            this.chartPrevalence.TabStop = false;
            this.chartPrevalence.DoubleClick += new System.EventHandler(this.chartPrevalence_DoubleClick);
            // 
            // chartPie
            // 
            this.chartPie.Dock = System.Windows.Forms.DockStyle.Left;
            this.chartPie.Location = new System.Drawing.Point(4, 19);
            this.chartPie.Margin = new System.Windows.Forms.Padding(4);
            this.chartPie.Name = "chartPie";
            this.chartPie.PropBag = resources.GetString("chartPie.PropBag");
            this.chartPie.Size = new System.Drawing.Size(655, 304);
            this.chartPie.TabIndex = 0;
            this.chartPie.TabStop = false;
            this.chartPie.DoubleClick += new System.EventHandler(this.chartPie_DoubleClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.chartDemogSummary);
            this.groupBox2.Controls.Add(this.chartDiseaseSummary);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(0, 327);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(13, 12, 13, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(1348, 322);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Population Dynamics -- click on Details to see daily data and access more options" +
    "";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(537, 31);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(100, 28);
            this.button6.TabIndex = 3;
            this.button6.Text = "Details";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(1232, 31);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 28);
            this.button5.TabIndex = 2;
            this.button5.Text = "Details";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // chartDemogSummary
            // 
            this.chartDemogSummary.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartDemogSummary.Location = new System.Drawing.Point(659, 19);
            this.chartDemogSummary.Margin = new System.Windows.Forms.Padding(4);
            this.chartDemogSummary.Name = "chartDemogSummary";
            this.chartDemogSummary.PropBag = resources.GetString("chartDemogSummary.PropBag");
            this.chartDemogSummary.Size = new System.Drawing.Size(685, 299);
            this.chartDemogSummary.TabIndex = 1;
            this.chartDemogSummary.TabStop = false;
            this.chartDemogSummary.DoubleClick += new System.EventHandler(this.chartDemogSummary_DoubleClick);
            // 
            // chartDiseaseSummary
            // 
            this.chartDiseaseSummary.Dock = System.Windows.Forms.DockStyle.Left;
            this.chartDiseaseSummary.Location = new System.Drawing.Point(4, 19);
            this.chartDiseaseSummary.Margin = new System.Windows.Forms.Padding(4);
            this.chartDiseaseSummary.Name = "chartDiseaseSummary";
            this.chartDiseaseSummary.PropBag = resources.GetString("chartDiseaseSummary.PropBag");
            this.chartDiseaseSummary.Size = new System.Drawing.Size(655, 299);
            this.chartDiseaseSummary.TabIndex = 0;
            this.chartDiseaseSummary.TabStop = false;
            this.chartDiseaseSummary.DoubleClick += new System.EventHandler(this.chartDiseaseSummary_DoubleClick);
            // 
            // frmGraphResults
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1348, 652);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmGraphResults";
            this.Text = "Simulation Results  -- double-click on any graph to open graph Properties";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmGraphResults_KeyUp);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartPrevalence)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartPie)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartDemogSummary)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartDiseaseSummary)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private C1.Win.C1Chart.C1Chart chartPie;
        private System.Windows.Forms.GroupBox groupBox2;
        private C1.Win.C1Chart.C1Chart chartPrevalence;
        private C1.Win.C1Chart.C1Chart chartDemogSummary;
        private C1.Win.C1Chart.C1Chart chartDiseaseSummary;
        private System.Windows.Forms.Label lblPieNs;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox cboPrevNgraphs;
        private System.Windows.Forms.Label label1;
    }
}