﻿using System;
using System.Windows.Forms;

namespace Outbreak2
{
    public partial class frmDzGraph : Form
    {
        OScenario mOS;
        OGraphs mOG;
        bool[] iStates = new bool[8];
        bool[] iStages = new bool[4];
        private bool stacked = false;
        private bool graphSE = false;
        private bool graphSD = false;
        private bool counts = true;

        public frmDzGraph(OScenario OS, OGraphs OG)
        {
            InitializeComponent();

            mOS = OS;
            mOG = OG;

            listboxDzGraphTime.Items.Clear();
            listboxDzGraphTime.Items.Add("Annual Summary");
            for (int i = 1; i <= mOS.nYears; i++) listboxDzGraphTime.Items.Add("Year " + i.ToString());

            for (int i = 0; i < 6; i++) iStates[i] = true;
            iStates[6] = false;
            iStates[7] = false;
            for (int i = 0; i < 4; i++) iStages[i] = true;

            listboxDzGraphTime.SelectedIndex = 0;

            O2Utils.CreateToolTipsFromTagsForForm(this);
        }

        private void makeDzGraph(bool updateTable)
        {
            mOG.stacked = stacked;
            mOG.graphSE = graphSE;
            mOG.graphSD = graphSD;
            mOG.counts = counts;

            if (listboxDzGraphTime.SelectedIndex == 0)
            {
                mOG.makeDzStateGraph(DzChart, iStates, iStages, (updateTable ? fgDzData : null));
            }
            else mOG.makeDzYearGraph(DzChart, iStates, iStages, listboxDzGraphTime.SelectedIndex, (updateTable ? fgDzData : null));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            makeDzGraph(true);
        }

        private void listboxDzGraphTime_SelectedIndexChanged(object sender, EventArgs e)
        {
            makeDzGraph(true);
        }

        private void radioDzGraphMeans_CheckedChanged(object sender, EventArgs e)
        {
            if (radioDzGraphMeans.Checked)
            {
                graphSD = false;
                graphSE = false;
                stacked = false;

                makeDzGraph(false);
            }
        }

        private void radioDzGraphCounts_CheckedChanged(object sender, EventArgs e)
        {
            counts = radioDzGraphCounts.Checked;
            makeDzGraph(true);
        }

        private void chkDzGraphP_CheckedChanged(object sender, EventArgs e)
        {
            iStates[0] = chkDzGraphP.Checked;
            makeDzGraph(true);
        }

        private void resetDzGraphSettings()
        {
            radioDzGraphSE.Enabled = true;
            radioDzGraphSD.Enabled = true;
            if (!iStages[0] || !iStages[1] || !iStages[2] || !iStages[3])
            {
                radioDzGraphSD.Enabled = false;
                radioDzGraphSE.Enabled = false;
                if (graphSE || graphSD) radioDzGraphMeans.Checked = true;
            }
        }

        private void chkDzGraphS_CheckedChanged(object sender, EventArgs e)
        {
            iStates[1] = chkDzGraphS.Checked;
            makeDzGraph(true);
        }

        private void chkDzGraphE_CheckedChanged(object sender, EventArgs e)
        {
            iStates[2] = chkDzGraphE.Checked;
            makeDzGraph(true);
        }

        private void chkDzGraphI_CheckedChanged(object sender, EventArgs e)
        {
            iStates[3] = chkDzGraphI.Checked;
            makeDzGraph(true);
        }

        private void chkDzGraphR_CheckedChanged(object sender, EventArgs e)
        {
            iStates[4] = chkDzGraphR.Checked;
            makeDzGraph(true);
        }

        private void chkDzGraphJ_CheckedChanged(object sender, EventArgs e)
        {
            iStages[0] = chkDzGraphJ.Checked;
            resetDzGraphSettings();
            makeDzGraph(true);
        }

        private void chkDzGraphSA_CheckedChanged(object sender, EventArgs e)
        {
            iStages[1] = chkDzGraphSA.Checked;
            resetDzGraphSettings();
            makeDzGraph(true);
        }

        private void chkDzGraphAM_CheckedChanged(object sender, EventArgs e)
        {
            iStages[2] = chkDzGraphAM.Checked;
            resetDzGraphSettings();
            makeDzGraph(true);
        }

        private void chkDzGraphAF_CheckedChanged(object sender, EventArgs e)
        {
            iStages[3] = chkDzGraphAF.Checked;
            resetDzGraphSettings();
            makeDzGraph(true);
        }

        private void radioDzGraphStacked_CheckedChanged(object sender, EventArgs e)
        {
            if (radioDzGraphStacked.Checked)
            {
                graphSD = false;
                graphSE = false;
                stacked = true;
                makeDzGraph(false);
            }
        }

        private void radioDzGraphSE_CheckedChanged(object sender, EventArgs e)
        {
            if (radioDzGraphSE.Checked)
            {
                graphSD = false;
                graphSE = true;
                stacked = false;
                makeDzGraph(false);
            }
        }

        private void radioDzGraphSD_CheckedChanged(object sender, EventArgs e)
        {
            if (radioDzGraphSD.Checked)
            {
                graphSD = true;
                graphSE = false;
                stacked = false;
                makeDzGraph(false);
            }
        }

        private void DzChart_DoubleClick(object sender, EventArgs e)
        {
            DzChart.ShowProperties();
        }

        private void btnPrintGraph_Click(object sender, EventArgs e)
        {
            DzChart.PrintChart();
        }

        private void btnSaveGraph_Click(object sender, EventArgs e)
        {
            mOG.saveGraph(DzChart);
        }

        private void btnDzTableExport_Click(object sender, EventArgs e)
        {
            mOG.ExportTable(fgDzData);
        }

        private void chkDzGraphNew_CheckedChanged(object sender, EventArgs e)
        {
            iStates[6] = chkDzGraphNew.Checked;
            makeDzGraph(true);
        }

        private void chkDzGraphDeaths_CheckedChanged(object sender, EventArgs e)
        {
            iStates[7] = chkDzGraphDeaths.Checked;
            makeDzGraph(true);
        }

        private void chkDzGraphV_CheckedChanged(object sender, EventArgs e)
        {
            iStates[5] = chkDzGraphV.Checked;
            makeDzGraph(true);
        }

        private void frmDzGraph_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            OutbreakHelp.LaunchHelp("DZGraph");
        }

    }
}
