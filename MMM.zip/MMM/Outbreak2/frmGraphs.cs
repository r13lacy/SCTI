﻿using System;
using System.Windows.Forms;

namespace Outbreak2
{
    public partial class frmGraphResults : Form
    {
        int nyears;
        int ndays;
        int nruns;
        OScenario mOS;
        OGraphs OG;

        public frmGraphResults(OScenario OS)
        {
            InitializeComponent();

            mOS = OS;
            nruns = mOS.nRuns;
            nyears = mOS.nYears;
            ndays = mOS.nDays;

            OG = new OGraphs(mOS);

            double P = mOS.sYDz[nyears, 0];
            double S = mOS.sYDz[nyears, 1];
            double E = mOS.sYDz[nyears, 2];
            double I = mOS.sYDz[nyears, 3];
            double R = mOS.sYDz[nyears, 4];
            double V = mOS.sYDz[nyears, 5];

            OG.makePie(chartPie, P, S, E, I, R, V);
            lblPieNs.Text = "P = " + P.ToString("0.0") + "\nS = " + S.ToString("0.0") + "\nE = " + E.ToString("0.0") + "\nI = " + I.ToString("0.0") + "\nR = " + R.ToString("0.0") + "\nV = " + V.ToString("0.0");
            OG.makeDzStateGraph(chartDiseaseSummary);
            OG.makeStageGraph(chartDemogSummary);
            cboPrevNgraphs.SelectedIndex = 0;

            //load tooltips
            O2Utils.CreateToolTipsFromTagsForForm(this);
        }

        private void chartDiseaseSummary_DoubleClick(object sender, EventArgs e)
        {
            chartDiseaseSummary.ShowProperties();
        }

        private void chartDemogSummary_DoubleClick(object sender, EventArgs e)
        {
            chartDemogSummary.ShowProperties();
        }

        private void chartPie_DoubleClick(object sender, EventArgs e)
        {
            chartPie.ShowProperties();
        }

        private void chartPrevalence_DoubleClick(object sender, EventArgs e)
        {
            chartPrevalence.ShowProperties();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            chartPie.PrintChart();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OG.saveGraph(chartPie);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OG.saveGraph(chartPrevalence);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            chartPrevalence.PrintChart();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmDemogGraph frmDemogGraph = new frmDemogGraph(mOS, OG);
            frmDemogGraph.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            frmDzGraph frmDzGraph = new frmDzGraph(mOS, OG);
            frmDzGraph.ShowDialog();
        }

        private void cboPrevNgraphs_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboPrevNgraphs.SelectedIndex < 0) return;

            if (cboPrevNgraphs.SelectedIndex == 0) OG.makePrevGraph(chartPrevalence);
            else if (cboPrevNgraphs.SelectedIndex == 1) OG.makeNGraph(chartPrevalence);
            else if (cboPrevNgraphs.SelectedIndex == 2) OG.makePEGraph(chartPrevalence);
            else if (cboPrevNgraphs.SelectedIndex == 3) OG.makeQETGraph(chartPrevalence);
            else if (cboPrevNgraphs.SelectedIndex == 4) OG.makeQEIGraph(chartPrevalence);
        }

        private void frmGraphResults_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            OutbreakHelp.LaunchHelp("GraphResults");
        }

    }
}
