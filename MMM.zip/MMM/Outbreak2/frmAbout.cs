﻿using System;
using System.Windows.Forms;

namespace Outbreak2
{
    public partial class frmAbout : Form
    {
        public frmAbout()
        {
            InitializeComponent();

            label2.Text = "Version " + Outbreak2.O2version; // + "\n\rReleased " + Outbreak2.dateCompiled;
        }

    }
}
