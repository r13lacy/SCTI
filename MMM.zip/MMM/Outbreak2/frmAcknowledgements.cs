﻿using System.Windows.Forms;

namespace Outbreak2
{
    public partial class frmAcknowledgements : Form
    {
        public frmAcknowledgements()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            Close();
        }
    }
}
