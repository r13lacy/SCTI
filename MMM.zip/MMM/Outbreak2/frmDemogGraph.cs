﻿using System;
using System.Windows.Forms;

namespace Outbreak2
{
    public partial class frmDemogGraph : Form
    {
        OScenario mOS;
        OGraphs mOG;
        bool[] iStates = new bool[6];
        bool[] iStages = new bool[4];
        private bool stacked = false;
        private bool graphSE = false;
        private bool graphSD = false;
        private bool counts = true;

        public frmDemogGraph(OScenario OS, OGraphs OG)
        {
            InitializeComponent();

            mOS = OS;
            mOG = OG;

            listboxDzGraphTime.Items.Clear();
            listboxDzGraphTime.Items.Add("Annual Summary");
            for (int i = 1; i <= mOS.nYears; i++) listboxDzGraphTime.Items.Add("Year " + i.ToString());

            for (int i = 0; i < 6; i++) iStates[i] = true;
            for (int i = 0; i < 4; i++) iStages[i] = true;

            listboxDzGraphTime.SelectedIndex = 0;

            //load tooltips
            O2Utils.CreateToolTipsFromTagsForForm(this);
        }

        private void makeDemogGraph(bool updateTable)
        {
            mOG.stacked = stacked;
            mOG.graphSE = graphSE;
            mOG.graphSD = graphSD;
            mOG.counts = counts;

            if (listboxDzGraphTime.SelectedIndex == 0)
            {
                mOG.makeDemogGraph(DzChart, iStates, iStages, (updateTable ? fgDzData : null));
            }
            else mOG.makeDemogYearGraph(DzChart, iStates, iStages, listboxDzGraphTime.SelectedIndex, (updateTable ? fgDzData : null));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            makeDemogGraph(true);
        }

        private void listboxDzGraphTime_SelectedIndexChanged(object sender, EventArgs e)
        {
            makeDemogGraph(true);
        }

        private void radioDzGraphMeans_CheckedChanged(object sender, EventArgs e)
        {
            if (radioDzGraphMeans.Checked)
            {
                graphSD = false;
                graphSE = false;
                stacked = false;

                makeDemogGraph(false);
            }
        }

        private void radioDzGraphCounts_CheckedChanged(object sender, EventArgs e)
        {
            counts = radioDzGraphCounts.Checked;
            makeDemogGraph(true);
        }

        private void chkDzGraphP_CheckedChanged(object sender, EventArgs e)
        {
            iStates[0] = chkDzGraphP.Checked;
            makeDemogGraph(true);
        }

        private void resetDzGraphSettings()
        {
            radioDzGraphSE.Enabled = true;
            radioDzGraphSD.Enabled = true;
            if (!iStages[0] || !iStages[1] || !iStages[2] || !iStages[3])
            {
                radioDzGraphSD.Enabled = false;
                radioDzGraphSE.Enabled = false;
                if (graphSE || graphSD) radioDzGraphMeans.Checked = true;
            }
        }

        private void chkDzGraphS_CheckedChanged(object sender, EventArgs e)
        {
            iStates[1] = chkDzGraphS.Checked;
            makeDemogGraph(true);
        }

        private void chkDzGraphE_CheckedChanged(object sender, EventArgs e)
        {
            iStates[2] = chkDzGraphE.Checked;
            makeDemogGraph(true);
        }

        private void chkDzGraphI_CheckedChanged(object sender, EventArgs e)
        {
            iStates[3] = chkDzGraphI.Checked;
            makeDemogGraph(true);
        }

        private void chkDzGraphR_CheckedChanged(object sender, EventArgs e)
        {
            iStates[4] = chkDzGraphR.Checked;
            makeDemogGraph(true);
        }

        private void chkDzGraphJ_CheckedChanged(object sender, EventArgs e)
        {
            iStages[0] = chkDzGraphJ.Checked;
            makeDemogGraph(true);
        }

        private void chkDzGraphSA_CheckedChanged(object sender, EventArgs e)
        {
            iStages[1] = chkDzGraphSA.Checked;
            makeDemogGraph(true);
        }

        private void chkDzGraphAM_CheckedChanged(object sender, EventArgs e)
        {
            iStages[2] = chkDzGraphAM.Checked;
            makeDemogGraph(true);
        }

        private void chkDzGraphAF_CheckedChanged(object sender, EventArgs e)
        {
            iStages[3] = chkDzGraphAF.Checked;
            makeDemogGraph(true);
        }

        private void radioDzGraphStacked_CheckedChanged(object sender, EventArgs e)
        {
            if (radioDzGraphStacked.Checked)
            {
                graphSD = false;
                graphSE = false;
                stacked = true;
                makeDemogGraph(false);
            }
        }

        private void radioDzGraphSE_CheckedChanged(object sender, EventArgs e)
        {
            if (radioDzGraphSE.Checked)
            {
                graphSD = false;
                graphSE = true;
                stacked = false;
                makeDemogGraph(false);
            }
        }

        private void radioDemogGraphSD_CheckedChanged(object sender, EventArgs e)
        {
            if (radioDzGraphSD.Checked)
            {
                graphSD = true;
                graphSE = false;
                stacked = false;
                makeDemogGraph(false);
            }
        }

        private void DzChart_DoubleClick(object sender, EventArgs e)
        {
            DzChart.ShowProperties();
        }

        private void btnPrintGraph_Click(object sender, EventArgs e)
        {
            DzChart.PrintChart();
        }

        private void btnSaveGraph_Click(object sender, EventArgs e)
        {
            mOG.saveGraph(DzChart);
        }

        private void btnDzTableExport_Click(object sender, EventArgs e)
        {
            mOG.ExportTable(fgDzData);
        }

        private void chkDzGraphV_CheckedChanged(object sender, EventArgs e)
        {
            iStates[5] = chkDzGraphV.Checked;
            makeDemogGraph(true);
        }

        private void frmDemogGraph_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            OutbreakHelp.LaunchHelp("DemogGraph");
        }

    }
}
