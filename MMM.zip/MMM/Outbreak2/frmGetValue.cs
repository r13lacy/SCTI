using System.ComponentModel;
using System.Windows.Forms;

namespace Outbreak2
{
    public partial class frmGetValue : Form
    {
        public frmGetValue(string caption, string question, string defaultVal)
        {
            InitializeComponent();

            this.Text = caption;
            lblQuestion.Text = question;
            txtAnswer.Text = defaultVal;

            txtAnswer.Left = lblQuestion.Right + 20;
            this.Width = txtAnswer.Right + 20;

            btnOK.Left = this.Width - btnOK.Width - 20;
            btnCancel.Left = btnOK.Left - btnCancel.Width - 8;

            O2Utils.CreateToolTipsFromTagsForForm(this);
        }

        public string GetValue { get { return txtAnswer.Text.Trim(); } }

        private void txtAnswer_Validating(object sender, CancelEventArgs e)
        {
            if (!O2Utils.ValidateTextBox((TextBox)sender)) e.Cancel = true;
        }
    }
}