using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Outbreak2
{
    public partial class frmPicker : Form
    {

        //public frmPicker(string instructions, List<string> list)
        //{
        //    InitializeComponent();

        //    lblText.Text = instructions;

        //    for (int i = 0; i < list.Count; i++)
        //        lstMain.Items.Add(list[i]);

        //    lstMain.SelectedIndex = 0;

        //    O2Utils.CreateToolTipsFromTagsForForm(this);

        //}

        //public frmPicker(string instructions, string[] list)
        //{
        //    InitializeComponent();

        //    lblText.Text = instructions;

        //    for (int i = 0; i < list.Length; i++)
        //        lstMain.Items.Add(list[i]);

        //    lstMain.SelectedIndex = 0;

        //}

        //public frmPicker(string instructions, List<object> list)
        //{
        //    InitializeComponent();

        //    lblText.Text = instructions;

        //    for (int i = 0; i < list.Count; i++)
        //        lstMain.Items.Add(list[i]);

        //    lstMain.SelectedIndex = 0;

        //}

        public frmPicker(string instructions, List<OScenario> list)
        {
            InitializeComponent();

            lblText.Text = instructions;

            for (int i = 0; i < list.Count; i++)
                lstMain.Items.Add(list[i].SceneName);

            lstMain.SelectedIndex = 0;

        }

        public int SelectedIndex { get { return lstMain.SelectedIndex; } }
        public object SelectedItem { get { return lstMain.SelectedItem; } }

        private void lstMain_DoubleClick(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }


    }
}