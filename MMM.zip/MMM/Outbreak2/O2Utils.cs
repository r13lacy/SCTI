using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using C1.Win.C1FlexGrid;
using System.IO;

namespace Outbreak2
{
    public class O2Utils // was derived from JPUtils used in Vortex
    {
        public static bool WriteListToFile(string fileName, List<string> list)
        {
            try
            {
                StreamWriter r = new StreamWriter(fileName);
                for (int i = 0; i < list.Count; i++)
                    r.WriteLine(list[i]);

                r.Close();

                return true;
            }
            catch
            {
                MessageBox.Show("Unable to write data to file: " + fileName);
                return false;
            }

        }

        public static List<string> ReadFileToList(string fileName)
        {
            return ReadFileToList(fileName, false);
        }

        public static List<string> ReadFileToList(string fileName, bool trim)
        {
            if (!File.Exists(fileName))
                return null;

            StreamReader objReader = new StreamReader(fileName);

            string sLine = "";
            List<string> arrText = new List<string>();

            while (sLine != null)
            {
                sLine = objReader.ReadLine();
                if (sLine != null)
                {
                    if (trim)
                        arrText.Add(sLine.Trim());
                    else
                        arrText.Add(sLine);
                }
            }
            objReader.Close();

            return arrText;
        }

        //public static bool ReadFileToTextBox(string fileName, TextBox txt)
        //{
        //    if (!File.Exists(fileName))
        //        return false;

        //    StreamReader objReader = new StreamReader(fileName);

        //    txt.Text = objReader.ReadToEnd();

        //    objReader.Close();

        //    return true;
        //}

        //public static bool SaveTextBoxToFile(TextBox txt)
        //{
        //    SaveFileDialog s = new SaveFileDialog();
        //    s.Filter = "Text Files (*.txt)|*.txt";

        //    if (s.ShowDialog() == DialogResult.OK)
        //        return SaveTextBoxToFile(s.FileName, txt);
        //    else
        //        return false;
        //}

        //public static bool SaveTextBoxToFile(string fileName, TextBox txt)
        //{
        //    try
        //    {
        //        StreamWriter r = new StreamWriter(fileName);

        //        r.Write(txt.Text);

        //        r.Close();

        //        return true;
        //    }
        //    catch
        //    {
        //        return false;
        //    }
        //}

        //public static void PrintTextBox(TextBox txt, PrintDialog dlg)
        //{
        //    frmPrintPreview frm = new frmPrintPreview(txt);
        //    frm.ShowDialog();

        //    //if (dlg.ShowDialog() == DialogResult.OK)
        //    //{
        //    //    C1.C1Preview.C1PrintDocument doc = new C1.C1Preview.C1PrintDocument();
        //    //    doc.StartDoc();
        //    //    doc.RenderBlockText(txt.Text);
        //    //    doc.Print(dlg.PrinterSettings, true);

        //    //}
        //}


        //public static void SaveRichTextBox(RichTextBox rtf)
        //{
        //    SaveFileDialog s = new SaveFileDialog();
        //    s.Filter = "RTF Files (*.rtf)|*.rtf|Text Files (*.txt)|*.txt";

        //    if (s.ShowDialog() == DialogResult.OK)
        //    {
        //        if (s.Filter.EndsWith(".rtf"))
        //            rtf.SaveFile(s.FileName, RichTextBoxStreamType.RichText);
        //        else //if (dlg.Filter.EndsWith(".txt"))
        //            rtf.SaveFile(s.FileName, RichTextBoxStreamType.PlainText);
        //    }
        //}


        //public static void PrintRichTextBox(RichTextBox rtf)
        //{

        //    frmPrintPreview frm = new frmPrintPreview(rtf);
        //    frm.ShowDialog();

        //    //if (dlg.ShowDialog() == DialogResult.OK)
        //    //{
        //    //    C1.C1Preview.C1PrintDocument doc = new C1.C1Preview.C1PrintDocument();
        //    //    doc.StartDoc();
        //    //    doc.RenderBlockRichText(rtf.Rtf);
        //    //    doc.Print(dlg.PrinterSettings, true);

        //    //}
        //}

        public static void SaveChartToImageFile(C1.Win.C1Chart.C1Chart chart)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "JPEG File (*.jpg) | *.jpg|PNG File (*.png) | *.png|WMF File (*.wmf) | *.wmf|Tiff File (*.tiff) | *.tiff|Gif File (*.gif) | *.gif";
            //             dlg.Filter = "JPEG (*.jpg)|*.jpg|Bitmap (*.bmp)|*.bmp|PNG (*.png)|*.png";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                System.Drawing.Imaging.ImageFormat f;

                if (dlg.Filter.EndsWith(".jpg"))
                    f = System.Drawing.Imaging.ImageFormat.Jpeg;
                else if (dlg.Filter.EndsWith(".png"))
                    f = System.Drawing.Imaging.ImageFormat.Png;
                else if (dlg.Filter.EndsWith(".wmf"))
                    f = System.Drawing.Imaging.ImageFormat.Wmf;
                else if (dlg.Filter.EndsWith(".tiff"))
                    f = System.Drawing.Imaging.ImageFormat.Tiff;
                else if (dlg.Filter.EndsWith(".gif"))
                    f = System.Drawing.Imaging.ImageFormat.Gif;
                else
                    f = System.Drawing.Imaging.ImageFormat.Bmp;

                chart.SaveImage(dlg.FileName, f);
            }

        }

        public static void SaveChartToImageFile(string fileName, C1.Win.C1Chart.C1Chart chart)
        {
            System.Drawing.Imaging.ImageFormat f;

            if (fileName.EndsWith(".jpg") || fileName.EndsWith(".JPG") || fileName.EndsWith(".jpeg"))
                f = System.Drawing.Imaging.ImageFormat.Jpeg;
            else if (fileName.EndsWith(".png") || fileName.EndsWith(".PNG"))
                f = System.Drawing.Imaging.ImageFormat.Png;
            else if (fileName.EndsWith(".wmf") || fileName.EndsWith(".WMF"))
                f = System.Drawing.Imaging.ImageFormat.Wmf;
            else if (fileName.EndsWith(".gif") || fileName.EndsWith(".GIF"))
                f = System.Drawing.Imaging.ImageFormat.Gif;
            else if (fileName.EndsWith(".tiff") || fileName.EndsWith(".TIFF"))
                f = System.Drawing.Imaging.ImageFormat.Tiff;
            else
                f = System.Drawing.Imaging.ImageFormat.Bmp;

            chart.SaveImage(fileName, f);


        }

        public static void PrintChart(C1.Win.C1Chart.C1Chart chart)
        {
            chart.PrintChart();
        }

        //public static void PrintGrid(C1.Win.C1FlexGrid.C1FlexGrid fg)
        //{
        //    fg.PrintGrid("Outbreak Grid");

        //}

        public static bool FileExists(string fileName)
        {
            return File.Exists(fileName);
        }

        public static bool IsInt(string s)
        {
            try
            {
                int i = Convert.ToInt32(s);

                //that worked, make sure it wasn't a double
                return !s.Contains(".");
            }
            catch
            {
                return false;
            }

        }

        public static bool IsDouble(string s)
        {
            try
            {
                double d = Convert.ToDouble(s); // note: this is going to be slow (because catch is slow), so use sparingly!

                return true;
            }
            catch
            {
                return false;
            }
        }

        // tests if the object is something that can be converted to a double
        public static bool IsNumb(object o)
        {
            Type type = o.GetType();
            if (type == typeof(double)
                || type == typeof(int)
                || type == typeof(decimal)
                || type == typeof(float)
                || type == typeof(bool)
                || type == typeof(long)
                || type == typeof(short)
                || type == typeof(char)
                || type == typeof(ulong)
                || type == typeof(ushort)
                || type == typeof(byte)
                || type == typeof(sbyte)
                || type == typeof(DateTime)
                || type == typeof(uint)) return true;

            if (type == typeof(string)) return (IsDouble((string)o)); // this can be slow, because it relies on a catch

            return false;
        }


        public static bool ValidateTextBox(TextBox txt)
        {
            if (txt.Modified) txt.ForeColor = System.Drawing.Color.Red;

            if (txt.Tag == null)
                return true;

            //the validate String contains type,min,max or also type,min, or if a string, type,empty means it can't be empty
            string val = txt.Text.Trim();
            string vString = txt.Tag.ToString().Trim();

            if (vString == "")
                return true;

            string[] s = vString.Split(',');

            if (s[0] == "string")
            {
                if (s.Length > 1 && s[1] == "empty" && val.Trim() == "")
                {
                    MessageBox.Show("Field cannot be empty!", "Error!");
                    return false;
                }
                else
                    return true;
            }
            else if (s[0] == "int" || s[0] == "Int")
            {
                if (!IsInt(val) || Convert.ToInt32(val) < Convert.ToInt32(s[1]) || (s.Length > 2 && Convert.ToInt32(val) > Convert.ToInt32(s[2])))
                {
                    if (s.Length > 2)
                        MessageBox.Show("Please enter an Integer between " + s[1] + " and " + s[2] + ".", "Error!");
                    else
                        MessageBox.Show("Please enter an Integer greater than or equal to " + s[1] + ".", "Error!");

                    return false;
                }
                else
                    return true;
            }
            else if (s[0] == "double" || s[0] == "Double")
            {
                if (!IsDouble(val) || (s.Length > 1 && Convert.ToDouble(val) < Convert.ToDouble(s[1])) || (s.Length > 2 && Convert.ToDouble(val) > Convert.ToDouble(s[2])))
                {
                    if (s.Length > 2)
                        MessageBox.Show("Please enter an decimal value between " + s[1] + " and " + s[2] + ".", "Error!");
                    else
                        MessageBox.Show("Please enter an decimal value greater than or equal to " + s[1] + ".", "Error!");

                    return false;
                }
                else
                    return true;
            }
            else if (s[0] == "fun" || s[0] == "Fun")
            {
                //if (val == "") return true; // empty function strings get handled OK within the dll?

                if (val.StartsWith("="))
                {
                    return true;  //   TODO  where should bad functions be trapped?
                }
                else
                {
                    // if a number, test the value, otherwise assume it is a function; let fun be blank, because not all input boxes are needed
                    //if (val == "" || (IsDouble(val) && 
                    if ((IsDouble(val) &&
                        ((s.Length > 1 && Convert.ToDouble(val) < Convert.ToDouble(s[1])) || (s.Length > 2 && Convert.ToDouble(val) > Convert.ToDouble(s[2])))))
                    {
                        if (s.Length > 2)
                            MessageBox.Show("Please enter a decimal or a function that evaluates to a value between " + s[1] + " and " + s[2] + ".", "Error!");
                        else if (s.Length > 1)
                            MessageBox.Show("Please enter a decimal or a function that evaluates to a value greater than or equal to " + s[1] + ".", "Error!");
                        else
                            MessageBox.Show("Please enter a decimal or a function.", "Error!");

                        return false;
                    }
                    //treat as a double if not starting with equals
                    //if (!IsDouble(val) || (s.Length > 1 && Convert.ToDouble(val) < Convert.ToDouble(s[1])) || (s.Length > 2 && Convert.ToDouble(val) > Convert.ToDouble(s[2])))
                    //{
                    //    if (s.Length > 2)
                    //        MessageBox.Show("Please enter a decimal or a function that evaluates to a value between " + s[1] + " and " + s[2] + ".", "Error!");
                    //    else if (s.Length > 1)
                    //        MessageBox.Show("Please enter a decimal or a function that evaluates to a value greater than or equal to " + s[1] + ".", "Error!");
                    //    else
                    //        MessageBox.Show("Please enter a decimal or a function.", "Error!");

                    //    return false;
                    //}
                    else
                        return true;
                }
            }
            else
            {
                //not sure why it would end up here, MessageBox
                MessageBox.Show("An item is trying to be validated and an error has occured. Talk to Bob.");
                return true;
            }

        }


        //public static void ExportFlexGrid(C1FlexGrid fg)
        //{
        //    SaveFileDialog dlg = new SaveFileDialog();
        //    dlg.Filter = "Semi-colon delimited text (*.txt)|*.txt|Comma Separated Values (*.csv)|*.csv|Excel (*.xls)|*.xls";

        //    if (dlg.ShowDialog() == DialogResult.OK)
        //    {
        //        if (dlg.FileName.EndsWith("txt", true, null))
        //        {
        //            string cs = fg.ClipSeparators;
        //            fg.ClipSeparators = ";" + "\r";
        //            fg.SaveGrid(dlg.FileName, FileFormatEnum.TextCustom, FileFlags.VisibleOnly | FileFlags.IncludeFixedCells);
        //            fg.ClipSeparators = cs;
        //        }
        //        else if (dlg.FileName.EndsWith("csv", true, null))
        //        {
        //            fg.SaveGrid(dlg.FileName, FileFormatEnum.TextComma, FileFlags.VisibleOnly | FileFlags.IncludeFixedCells);
        //        }
        //        else if (dlg.FileName.EndsWith("xls", true, null))
        //        {
        //            fg.SaveExcel(dlg.FileName, FileFlags.VisibleOnly | FileFlags.IncludeFixedCells);
        //        }
        //    }
        //}

        //public static bool ImportFlexGrid(C1FlexGrid fg, bool ignoreFixed)
        //{
        //    OpenFileDialog dlg = new OpenFileDialog();
        //    dlg.Filter = "Semi-colon delimited text (*.txt)|*.txt|Comma Separated Values (*.csv)|*.csv|Excel (*.xls)|*.xls";

        //    if (dlg.ShowDialog() == DialogResult.OK)
        //    {
        //        if (dlg.FileName.EndsWith("txt", true, null))
        //        {
        //            string cs = fg.ClipSeparators;
        //            fg.ClipSeparators = ";" + "\r";

        //            if (ignoreFixed)
        //                fg.LoadGrid(dlg.FileName, FileFormatEnum.TextCustom);
        //            else
        //                fg.LoadGrid(dlg.FileName, FileFormatEnum.TextCustom, FileFlags.IncludeFixedCells);

        //            fg.ClipSeparators = cs;
        //        }
        //        else if (dlg.FileName.EndsWith("csv", true, null))
        //        {
        //            if (ignoreFixed)
        //                fg.LoadGrid(dlg.FileName, FileFormatEnum.TextComma);
        //            else
        //                fg.LoadGrid(dlg.FileName, FileFormatEnum.TextComma, FileFlags.IncludeFixedCells);
        //        }
        //        else if (dlg.FileName.EndsWith("csv", true, null))
        //        {
        //            if (ignoreFixed)
        //                fg.LoadExcel(dlg.FileName);
        //            else
        //                fg.LoadExcel(dlg.FileName, FileFlags.IncludeFixedCells);
        //        }

        //        return true;
        //    }
        //    else
        //        return false;
        //}


        //NOTE: Toolstrip buttons have their own mandatory tooltip fields that must be set,
        //so do NOT set the tag property for a toolstrip button.
        //This adds tooltips to a control, and all of its sub controls
        public static void CreateToolTipsFromTags(Control ctrl)
        {
            if (ctrl.GetType() == typeof(ToolStrip) || ctrl.GetType() == typeof(ToolStripButton))
                return;

            //recurse, if need to
            for (int i = 0; i < ctrl.Controls.Count; i++)
                CreateToolTipsFromTags(ctrl.Controls[i]);

            //don't do anything if no tag
            if (ctrl.Tag == null || ctrl.Tag.ToString().Trim() == "")
                return;

            string tag = ctrl.Tag.ToString().Trim();
            string tooltip = "";

            string[] tagbits = tag.Split(',');
            //Textboxes might have the Tag used to define data types, etc., so handle them differently
            if (ctrl.GetType() == typeof(TextBox))
            {
                if (tagbits[0] == "int")
                    tooltip = "Enter an integer";
                else if (tagbits[0] == "double")
                    tooltip = "Enter a number";
                else if (tagbits[0] == "string")
                    tooltip = "Enter text";
                else if (tagbits[0] == "fun")
                    tooltip = "Enter a number or function";
                else
                    tooltip = tag;

                if (tagbits.Length > 2)
                {
                    tooltip += " of value " + tagbits[1].ToString() + " to " + tagbits[2].ToString();
                }
                else if (tagbits.Length > 1) tooltip += " of value " + tagbits[1].ToString() + " or greater";

                //if (tag.StartsWith("int,"))
                //    tooltip = "Enter an integer";
                //else if (tag.StartsWith("double,"))
                //    tooltip = "Enter a number";
                //else if (tag.StartsWith("string,"))
                //    tooltip = "Enter text";
                //else if (tag.StartsWith("fun,"))
                //    tooltip = "Enter a number or function";
                //else
                //    tooltip = tag;
            }
            else
                tooltip = tag;

            System.Windows.Forms.ToolTip tt = new ToolTip();
            tt.ShowAlways = true;
            tt.SetToolTip(ctrl, tooltip);
        }

        public static void CreateToolTipsFromTagsForForm(Form frm)
        {
            for (int i = 0; i < frm.Controls.Count; i++)
                CreateToolTipsFromTags(frm.Controls[i]);
        }

        public static void resetTxttoBlack(Form frm)
        {
            for (int i = 0; i < frm.Controls.Count; i++)
                resetTxttoBlack(frm.Controls[i]);
        }

        public static void resetTxttoBlack(Control ctrl)
        {
            //recurse, if need to
            for (int i = 0; i < ctrl.Controls.Count; i++)
            {
                resetTxttoBlack(ctrl.Controls[i]);
            }

            if (ctrl.GetType() == typeof(TextBox))
                ctrl.ForeColor = System.Drawing.Color.Black;

            else if (ctrl.GetType() == typeof(C1.Win.C1FlexGrid.C1FlexGrid)) 
            { // rather clunky, but I am not sure how else to do it without messing up the table formating 
                for(int r = 0; r < ((C1.Win.C1FlexGrid.C1FlexGrid)ctrl).Rows.Count; r++)
                    for (int c = 0; c < ((C1.Win.C1FlexGrid.C1FlexGrid)ctrl).Cols.Count; c++)
                    {
                        if (((C1.Win.C1FlexGrid.C1FlexGrid)ctrl).GetCellStyleDisplay(r, c) != null && 
                            ((C1.Win.C1FlexGrid.C1FlexGrid)ctrl).GetCellStyleDisplay(r, c).ForeColor.Name == "Red") 
                        ((C1.Win.C1FlexGrid.C1FlexGrid)ctrl).SetCellStyle(r, c, "Normal");
                    }

            }

        }
    }
}
