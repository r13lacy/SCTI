using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;
using MMMCore;

namespace MMPathHistory
{
    public class Meta
    {
        private Project m_Project = null;

        Random rand = new Random();

//        StreamWriter stream = null;

        private int[] RunCount = null;
        private int CurrentYear = -1;


        public List<string> GetVars()
        {
            List<string> v = new List<string>();

            for (int i = 0; i < m_Project.Vars.Count; i++)
                v.Add(m_Project.Vars[i].Name);

            return v;
        }


        public bool Initialize(string projectFile, int numPops)
        {
            int i;
            //read project file into a project
            m_Project = new Project(projectFile);

            RunCount = new int[numPops];
            for (i = 0; i < numPops; i++)
                RunCount[i] = 0;

            for (i = 0; i < m_Project.Landscapes.Count; i++)
                m_Project.Landscapes[i].InitSlices();



            return true;

        }


        public bool Simulate(MMMCore.MPopulation pop, int year, int numTimeSteps, int popIndex)
        {
            int i, j;

            if (pop.IndList.Count == 0)
                return true;

            if (year != CurrentYear)
            {
                CurrentYear = year;

                if (m_Project.ResetVarsYearly)
                       RunCount[popIndex] = 0;
            }


            int[] varIndex = new int[m_Project.Vars.Count];

            for (i = 0; i < varIndex.Length; i++)
            {
                varIndex[i] = pop.GetIndividualVarIndex(m_Project.Vars[i].Name);
                if (varIndex[i] < 0) varIndex[i] = pop.AddIndVar(m_Project.Vars[i].Name, "0.0");
            }

            int varX = pop.GetIndividualVarIndex("X");
            int varY = pop.GetIndividualVarIndex("Y");

            for (int ts = 0; ts < numTimeSteps; ts++)
            {

                for (i = 0; i < pop.IndList.Count; i++)
                {
                    int x = Convert.ToInt32(pop.IndList[i].Vars[varX]);
                    int y = Convert.ToInt32(pop.IndList[i].Vars[varY]);

                    for (j = 0; j < m_Project.Vars.Count; j++)
                    {

                        double val = m_Project.Landscapes[m_Project.Vars[j].LandscapeIndex].GetValue(x, y, RunCount[popIndex] + 1);

                        if (RunCount[popIndex] == 0) //this is the first time, make sure the variable is there, then just give it the value
                        {
                            //if (varIndex[j] < 1 || varIndex[j] >= pop.IndList[i].Vars.Count)
                            //    pop.IndList[i].AddVar(m_Project.Vars[j].Name, val.ToString("0.0000"), typeof(string));
                            //else
                                pop.IndList[i].Vars[varIndex[j]] = val.ToString("0.0000");
                        }
                        else
                        {

                            if (m_Project.Vars[j].VarType == "Current")
                            {
                                pop.IndList[i].Vars[varIndex[j]] = val.ToString("0.0000");
                            }
                            else if (m_Project.Vars[j].VarType == "Mean")
                            {
                                //old value times the number of runs, plus the new value, all that divided by runs + 1
                                double d = (Convert.ToDouble(pop.IndList[i].Vars[varIndex[j]]) * RunCount[popIndex] + val) / (RunCount[popIndex] + 1);
                                pop.IndList[i].Vars[varIndex[j]] = d.ToString("0.0000");
                            }
                            else if (m_Project.Vars[j].VarType == "Min")
                            {
                                double d = Convert.ToDouble(pop.IndList[i].Vars[varIndex[j]]);
                                if (val < d)
                                    pop.IndList[i].Vars[varIndex[j]] = val.ToString("0.0000");
                            }
                            else if (m_Project.Vars[j].VarType == "Max")
                            {
                                double d = Convert.ToDouble(pop.IndList[i].Vars[varIndex[j]]);
                                if (val > d)
                                    pop.IndList[i].Vars[varIndex[j]] = val.ToString("0.0000");
                            }

                        }

                    }


                }

                RunCount[popIndex]++;
            }


            return true;
        }


        public bool CloseDLL()
        {
            


            return true;
        }

    }
}
