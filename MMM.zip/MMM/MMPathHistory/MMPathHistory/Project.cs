using System;
using System.Collections.Generic;
using System.Text;

using System.Xml.XPath;
using System.Xml;

namespace MMPathHistory
{
    public class Project
    {

        public string Name = "New PathHistory Project";

        public List<Landscape> Landscapes = new List<Landscape>();

        public bool ResetVarsYearly = true;

        public List<PHVariable> Vars = new List<PHVariable>();



        //various settingsS

        public Project()
        {

        }


        public Project(string projectFile)
        {
            //load a project from an existing xml project file
//            int i;

            XmlDocument doc = new XmlDocument();

            //make sure it is a valid document
            try { doc.Load(projectFile); }
            catch { return; }

            //doc is loaded, start reading

            XPathNavigator Nav = doc.CreateNavigator();
            XPathNodeIterator iter;

            //get the project name, if it has one
            iter = Nav.SelectChildren("MMPathHistoryProject", "");

            if (!iter.MoveNext())
                return;


            iter = Nav.Select("MMPathHistoryProject/Name");
            if (iter.MoveNext())
                Name = iter.Current.Value;

            iter = Nav.Select("MMPathHistoryProject/Landscapes");
            if (!iter.MoveNext())
                return;

            iter = iter.Current.Clone().SelectChildren(XPathNodeType.All);

            while (iter.MoveNext())
            {
                Landscape l = new Landscape();
                l.SetFromXML(iter.Current.Clone(), projectFile);
                Landscapes.Add(l);
            }

            iter = Nav.Select("MMPathHistoryProject/Vars");
            if (!iter.MoveNext())
                return;

            iter = iter.Current.Clone().SelectChildren(XPathNodeType.All);

            while (iter.MoveNext())
            {
                PHVariable p = new PHVariable();
                p.SetFromXML(iter.Current.Clone(), projectFile);
                Vars.Add(p);
            }


           

        }

        public void Save(string fileLocation)
        {
            XmlDocument doc = new XmlDocument();

            XmlDeclaration xmlInfoNode = doc.CreateXmlDeclaration("1.0", null, null);
            doc.AppendChild(xmlInfoNode);

            XmlElement topNode = doc.CreateElement("MMPathHistoryProject");
            doc.AppendChild(topNode);

            XmlElement n;
            int i;

            n = doc.CreateElement("Name");
            n.InnerText = Name;
            topNode.AppendChild(n);

            n = doc.CreateElement("Landscapes");
            topNode.AppendChild(n);

            for (i = 0; i < Landscapes.Count; i++)
            {
                XmlElement nn = doc.CreateElement("Landscape");
                n.AppendChild(nn);
                Landscapes[i].ToXML(nn, doc);
            }


            n = doc.CreateElement("Vars");
            topNode.AppendChild(n);

            for (i = 0; i < Vars.Count; i++)
            {
                XmlElement nn = doc.CreateElement("Var");
                n.AppendChild(nn);
                Vars[i].ToXML(nn, doc);
            }

            n = doc.CreateElement("ResetVarsYearly");
            n.InnerText = ResetVarsYearly.ToString();
            topNode.AppendChild(n);

            doc.Save(fileLocation);

        }
    }
}
