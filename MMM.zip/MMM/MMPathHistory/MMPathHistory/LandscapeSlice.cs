using System;
using System.Collections.Generic;
using System.Text;

using System.Diagnostics;

using System.IO;
using System.Xml;
using System.Xml.XPath;

namespace MMPathHistory
{
    public class LandscapeSlice
    {
        public string LFileName = "";
        public bool SimpleFile = true;

        public double[,] Values = null;

        public int ScaleWidth = 1000;
        public int ScaleHeight = 1000;

        private int Height = 0;
        private int Width = 0;

        private double XAdj = 1.0, YAdj = 1.0;

        private bool UseAdj = false;


        public GISHeader Header;

        public LandscapeSlice() { }

        public LandscapeSlice(string fileName, bool simpleFile)
        {
            //simpleFile means a csv file

            LFileName = fileName;
            SimpleFile = simpleFile;

            if (simpleFile)
                ReadSimpleFile();
            else
                ReadGISFile();

        }

        private void ReadSimpleFile()
        {

            StreamReader objReader = new StreamReader(LFileName);

            string sLine = "";
            List<string> arrText = new List<string>();

            while (sLine != null)
            {
                sLine = objReader.ReadLine();
                if (sLine != null)
                    arrText.Add(sLine.Trim());
            }
            objReader.Close();

            //the list should contain the matrix of values


            int len = arrText[0].Split(',').Length;

            Values = new double[arrText.Count, len];

            for (int i = 0; i < arrText.Count; i++)
            {
                string[] s = arrText[i].Split(',');
                for (int j = 0; j < s.Length; j++)
                    Values[i, j] = Convert.ToDouble(s[j]);
            }


            ScaleHeight = Height = Values.GetUpperBound(0) + 1;
            ScaleWidth = Width = Values.GetUpperBound(1) + 1;

        }

        private void ReadGISFile()
        {
            //import a data file to add a subscape
		//format = 
		//		ncols	      33
		//		nrows         24
		//		xllcorner     571511.51386328
		//		yllcorner     5140846.6125306
		//		cellsize      500
		//		NODATA_value  -9999
		//		4321 4576 4576 4464 4545 ... nCols
		
			

			StreamReader objReader;

			try 
			{ 
				objReader = new StreamReader(LFileName);

			}
			catch (Exception e)
			{
				Console.WriteLine(e.Message);
				return;
			}

			string sLine="";
			List<string> arrText = new List<string>();

			while (sLine != null)
			{
				sLine = objReader.ReadLine();
				if (sLine != null)
					arrText.Add(sLine);
				
				
			}
			objReader.Close();


			//arrText now contains the entire file

			
			//get the header info
			if ( !Header.SetValuesFromArrayList(arrText) )
				return;



			//check that there are the right number of rows in the file
            if (Header.nRows < arrText.Count - Header.numHeaderRows)
				return;


			//have header info, load the data

			int i, j;

			Values = new double[Header.nRows, Header.nCols];
			double noData = Convert.ToDouble(Header.NODATA_Value);

			for (i = Header.numHeaderRows; i < Header.numHeaderRows + Header.nRows; i++)
			{
				string[] vals = arrText[i].ToString().Split(' ');

				//make sure right number of cols in the file
                if (vals.Length < Values.GetUpperBound(1) + 1)
					return;



				for (j = 0; j < Header.nCols; j++)
				{
					Values[i - Header.numHeaderRows, j] = Convert.ToSingle(vals[j]);
				}
			}


            ScaleHeight = Height = Values.GetUpperBound(0) + 1;
            ScaleWidth = Width = Values.GetUpperBound(1) + 1;
			
		}

        public void SetScaleDimensions()
        {
            if (ScaleHeight == Height && ScaleWidth == Width)
                UseAdj = false;
            else
            {
                YAdj = Convert.ToDouble(Height) / ScaleHeight;
                XAdj = Convert.ToDouble(Width) / ScaleWidth;
                UseAdj = true;
            }

        }


        public double GetPointVal(int x, int y)
        {
            
            if (y >= this.Height)
                y = this.Height - 1;

            if (x >= this.Width)
                x = this.Width - 1;

            if (!UseAdj)
                return Values[y, x];
            else
                return Values[Convert.ToInt32(Math.Floor(y * YAdj)), Convert.ToInt32(Math.Floor(x * XAdj))];
        }


        public void SetFromXML(XPathNavigator Nav, string projectFileLocation)
        {
            XPathNodeIterator iter = Nav.Select("FileName");
            if (iter.MoveNext())
                LFileName = projectFileLocation.Substring(0, projectFileLocation.LastIndexOf("\\")) + "\\" + iter.Current.Value;

            iter = Nav.Select("SimpleFile");
            if (iter.MoveNext())
                SimpleFile = Convert.ToBoolean(iter.Current.Value);

            if (SimpleFile)
                ReadSimpleFile();
            else
                ReadGISFile();

            iter = Nav.Select("ScaleWidth");
            if (iter.MoveNext())
                ScaleWidth = Convert.ToInt32(iter.Current.Value);

            iter = Nav.Select("ScaleHeight");
            if (iter.MoveNext())
                ScaleHeight = Convert.ToInt32(iter.Current.Value);

        }

        //adds to the attribs of the headernode
        public void ToXML(XmlElement topNode, XmlDocument doc)
        {
            //add attribs
            XmlElement tmpNode = doc.CreateElement("FileName");
            tmpNode.InnerText = LFileName.Substring(LFileName.LastIndexOf("\\") + 1);
            topNode.AppendChild(tmpNode);

            tmpNode = doc.CreateElement("SimpleFile");
            tmpNode.InnerText = SimpleFile.ToString();
            topNode.AppendChild(tmpNode);

            tmpNode = doc.CreateElement("ScaleWidth");
            tmpNode.InnerText = ScaleWidth.ToString();
            topNode.AppendChild(tmpNode);

            tmpNode = doc.CreateElement("ScaleHeight");
            tmpNode.InnerText = ScaleHeight.ToString();
            topNode.AppendChild(tmpNode);
        }


    }







    public struct GISHeader
    {
        public int nCols, nRows, NODATA_Value;
        public double cellSize, xllCorner, yllCorner;

        public int numHeaderRows;



        public bool SetValuesFromArrayList(List<string> al)
        {
            this.numHeaderRows = 6;

            string[] tmpSplit;

            try
            {
                tmpSplit = al[0].ToString().Split(' ');
                this.nCols = Convert.ToInt32(tmpSplit[tmpSplit.Length - 1]);
            }
            catch { return false; }

            try
            {
                tmpSplit = al[1].ToString().Split(' ');
                this.nRows = Convert.ToInt32(tmpSplit[tmpSplit.Length - 1]);
            }
            catch { return false; }

            try
            {
                tmpSplit = al[2].ToString().Split(' ');
                this.xllCorner = Convert.ToDouble(tmpSplit[tmpSplit.Length - 1]);
            }
            catch { return false; }

            try
            {
                tmpSplit = al[3].ToString().Split(' ');
                this.yllCorner = Convert.ToDouble(tmpSplit[tmpSplit.Length - 1]);
            }
            catch { return false; }

            try
            {
                tmpSplit = al[4].ToString().Split(' ');
                this.cellSize = Convert.ToDouble(tmpSplit[tmpSplit.Length - 1]);
            }
            catch { return false; }

            try
            {
                tmpSplit = al[5].ToString().Split(' ');
                this.NODATA_Value = Convert.ToInt32(tmpSplit[tmpSplit.Length - 1]);
            }
            catch { return false; }

            return true;

        }

        
        
    }
}
