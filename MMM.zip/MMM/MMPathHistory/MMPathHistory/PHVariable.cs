using System;
using System.Collections.Generic;
using System.Text;

using System.Xml;
using System.Xml.XPath;

namespace MMPathHistory
{
    public class PHVariable
    {
        public string Name;
        public string VarType = "Current"; //Current, Mean, Min, Max

        public int LandscapeIndex = 0;

        public override string ToString() { return Name; }

        public void SetFromXML(XPathNavigator Nav, string projectFileLocation)
        {
            XPathNodeIterator iter = Nav.Select("Name");
            if (iter.MoveNext())
                Name = iter.Current.Value;

            iter = Nav.Select("VarType");
            if (iter.MoveNext())
                VarType = iter.Current.Value;

            iter = Nav.Select("LandscapeIndex");
            if (iter.MoveNext())
                LandscapeIndex = Convert.ToInt32(iter.Current.Value);

        }

        //adds to the attribs of the headernode
        public void ToXML(XmlElement topNode, XmlDocument doc)
        {
            //add attribs
            XmlElement tmpNode = doc.CreateElement("Name");
            tmpNode.InnerText = Name;
            topNode.AppendChild(tmpNode);

            tmpNode = doc.CreateElement("VarType");
            tmpNode.InnerText = VarType;
            topNode.AppendChild(tmpNode);

            tmpNode = doc.CreateElement("LandscapeIndex");
            tmpNode.InnerText = LandscapeIndex.ToString();
            topNode.AppendChild(tmpNode);
        }
    }
}
