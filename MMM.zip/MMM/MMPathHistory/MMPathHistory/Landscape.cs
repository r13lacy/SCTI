using System;
using System.Collections.Generic;
using System.Text;

using System.Xml;
using System.Xml.XPath;

namespace MMPathHistory
{
    public class Landscape
    {
        public string Name = "New Landscape";
        public List<LandscapeSlice> Slices = new List<LandscapeSlice>();
        public List<int> TimeStepTransitions = new List<int>();

        public Landscape()
        {


        }

        public void AddSlice(string fileName, bool simpleFile, int timeStepStart)
        {
            Slices.Add(new LandscapeSlice(fileName, simpleFile));
            TimeStepTransitions.Add(timeStepStart);

        }

        public void InitSlices()
        {
            for (int i = 0; i < Slices.Count; i++)
                Slices[i].SetScaleDimensions();
        }

        public double GetValue(int x, int y, int timeStep)
        {
            int i = 0;

            while (i < TimeStepTransitions.Count - 1 && timeStep >= TimeStepTransitions[i + 1])
                i++;

            //i is now the index of the current slice

            return Slices[i].GetPointVal(x, y);

        }

        public override string ToString()
        {
            return Name;
        }

        public void SetFromXML(XPathNavigator Nav, string projectFileLocation)
        {
            XPathNodeIterator iter = Nav.Select("Name");
            if (iter.MoveNext())
                Name = iter.Current.Value;

            iter = Nav.Select("Slices");
            if (!iter.MoveNext())
                return;

            iter = iter.Current.Clone().SelectChildren(XPathNodeType.All);

            while (iter.MoveNext())
            {
                LandscapeSlice ls = new LandscapeSlice();
                ls.SetFromXML(iter.Current.Clone(), projectFileLocation);
                Slices.Add(ls);
            }

            iter = Nav.Select("Transitions");
            if (!iter.MoveNext())
                return;

            iter = iter.Current.Clone().SelectChildren(XPathNodeType.All);

            while (iter.MoveNext())
            {
                TimeStepTransitions.Add(Convert.ToInt32(iter.Current.Value));
            }
            

        }

        //adds to the attribs of the headernode
        public void ToXML(XmlElement topNode, XmlDocument doc)
        {
            int i;

            //add attribs
            XmlElement tmpNode = doc.CreateElement("Name");
            tmpNode.InnerText = Name;
            topNode.AppendChild(tmpNode);
            
            tmpNode = doc.CreateElement("Slices");
            topNode.AppendChild(tmpNode);

            for (i = 0; i < Slices.Count; i++)
            {
                XmlElement n = doc.CreateElement("Slice");
                tmpNode.AppendChild(n);
                Slices[i].ToXML(n, doc);
            } 
            
            tmpNode = doc.CreateElement("Transitions");
            topNode.AppendChild(tmpNode);

            for (i = 0; i < Slices.Count; i++)
            {
                XmlElement n = doc.CreateElement("Transition");
                n.InnerText = TimeStepTransitions[i].ToString();
                tmpNode.AppendChild(n);
            }

        }

    }
}
