Notes about MetaModelManager program code

Users can add their own Modifier models to the toolbox available to MetaModelManager, if they create an interface through which to access the Global, Population, and Individual data contained within C# class MData. The standard function calls that MetaModelManager uses to communicate with any linked model are Initialize(), Simulate(), and Close(), although these three functions can be given different names if the synonymous names are specified to MetaModelManager in the model specifications. 

The structure of the metamodel data in MData is defined in the small library MMMCore. The code for the MMMCore.dll is provided in the MetaModelManager installation file. 

Another small code file � MMLinkTemplate.cs � is included to provide a template for the three key functions for passing data between MetaModelManager and a user-provided model. In addition, the code for the MMMacro modifier program is provided to show a more complete and complex example. (MMMacro provides a means to modify variables in MMData via macros or scripts.)

Source code files for the libraries (DLLs) for the Outbreak epidemiological model, the Evaluator function evaluator, and MMMacro macro interpreter, and for the algorithms that run MetaModelManager are also provided with the installation. The source code files for the libraries are not sufficient to recompile the full user interfaces for MetaModelManager, Outbreak.exe, Evaluate.exe (for testing functions in Evaluator) and the MMMacro editor, because the GUIs use tools from ComponentOne Studio for WinForms. The library source codes are published here to allow users and developers of models to be linked to see the details of the algorithms. All these source code files are copyrighted by the Chicago Zoological Society and cannot be modified or re-used in other programs without permission of the Chicago Zoological Society. All compiled programs in this installation � both the full EXE executable programs and the DLL function libraries � are distributed free for use in their compiled form as provided in this installation. 


