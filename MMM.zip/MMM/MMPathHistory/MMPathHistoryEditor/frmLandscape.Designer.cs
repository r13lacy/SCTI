namespace MMPathHistoryEditor
{
    partial class frmLandscape
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLandscape));
            this.txtName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddSimple = new System.Windows.Forms.Button();
            this.btnAddGIS = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.fgSlices = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnUp = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fgSlices)).BeginInit();
            this.SuspendLayout();
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(55, 12);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(351, 21);
            this.txtName.TabIndex = 4;
            this.txtName.Text = "New Path History Settings";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Name:";
            // 
            // btnAddSimple
            // 
            this.btnAddSimple.Location = new System.Drawing.Point(312, 227);
            this.btnAddSimple.Name = "btnAddSimple";
            this.btnAddSimple.Size = new System.Drawing.Size(36, 21);
            this.btnAddSimple.TabIndex = 13;
            this.btnAddSimple.Text = "Add";
            this.btnAddSimple.UseVisualStyleBackColor = true;
            this.btnAddSimple.Click += new System.EventHandler(this.btnAddSimple_Click);
            // 
            // btnAddGIS
            // 
            this.btnAddGIS.Location = new System.Drawing.Point(348, 227);
            this.btnAddGIS.Name = "btnAddGIS";
            this.btnAddGIS.Size = new System.Drawing.Size(58, 21);
            this.btnAddGIS.TabIndex = 12;
            this.btnAddGIS.Text = "Add GIS";
            this.btnAddGIS.UseVisualStyleBackColor = true;
            this.btnAddGIS.Click += new System.EventHandler(this.btnAddGIS_Click);
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(15, 227);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(36, 21);
            this.btnDel.TabIndex = 11;
            this.btnDel.Text = "Del";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Landscape Data Files:";
            // 
            // fgSlices
            // 
            this.fgSlices.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.fgSlices.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.fgSlices.ColumnInfo = "4,0,0,0,0,90,Columns:0{Width:210;Caption:\"File\";}\t1{Width:46;Caption:\"Width\";}\t2{" +
                "Width:46;Caption:\"Height\";}\t3{Width:61;Caption:\"Time Step\";}\t";
            this.fgSlices.ExtendLastCol = true;
            this.fgSlices.Location = new System.Drawing.Point(15, 80);
            this.fgSlices.Name = "fgSlices";
            this.fgSlices.Rows.DefaultSize = 18;
            this.fgSlices.Size = new System.Drawing.Size(391, 141);
            this.fgSlices.StyleInfo = resources.GetString("fgSlices.StyleInfo");
            this.fgSlices.TabIndex = 14;
            this.fgSlices.CellButtonClick += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgSlices_CellButtonClick);
            this.fgSlices.BeforeEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgSlices_BeforeEdit);
            // 
            // btnUp
            // 
            this.btnUp.Location = new System.Drawing.Point(88, 227);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(44, 21);
            this.btnUp.TabIndex = 15;
            this.btnUp.Text = "Up";
            this.btnUp.UseVisualStyleBackColor = true;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // btnDown
            // 
            this.btnDown.Location = new System.Drawing.Point(132, 227);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(44, 21);
            this.btnDown.TabIndex = 16;
            this.btnDown.Text = "Down";
            this.btnDown.UseVisualStyleBackColor = true;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(285, 335);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(57, 24);
            this.btnCancel.TabIndex = 28;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(348, 335);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(57, 24);
            this.btnOK.TabIndex = 27;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(371, 13);
            this.label3.TabIndex = 29;
            this.label3.Text = "Landscape width and height correspond to those set in your Spatial project!";
            // 
            // frmLandscape
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(413, 365);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnUp);
            this.Controls.Add(this.fgSlices);
            this.Controls.Add(this.btnAddSimple);
            this.Controls.Add(this.btnAddGIS);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmLandscape";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Landscape";
            ((System.ComponentModel.ISupportInitialize)(this.fgSlices)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddSimple;
        private System.Windows.Forms.Button btnAddGIS;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Label label2;
        private C1.Win.C1FlexGrid.C1FlexGrid fgSlices;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label label3;
    }
}