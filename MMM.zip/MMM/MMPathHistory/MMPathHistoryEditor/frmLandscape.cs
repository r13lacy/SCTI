using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MMPathHistoryEditor
{
    public partial class frmLandscape : Form
    {
        public MMPathHistory.Landscape LS = null;

        public frmLandscape(MMPathHistory.Landscape ls)
        {
            InitializeComponent();

            LS = ls;

            txtName.Text = ls.Name;


            fgSlices.Rows.Count = ls.Slices.Count + 1;
            fgSlices.Cols.Count = 5;
            fgSlices.Cols[4].Visible = false;
           

            for (int i = 0; i < ls.Slices.Count; i++)
            {
                fgSlices[i + 1, 0] = ls.Slices[i].LFileName;
                fgSlices[i + 1, 1] = ls.Slices[i].ScaleWidth;
                fgSlices[i + 1, 2] = ls.Slices[i].ScaleHeight;
                fgSlices[i + 1, 3] = ls.TimeStepTransitions[i];
                fgSlices[i + 1, 4] = ls.Slices[i];
            }

        }

        private void btnDel_Click(object sender, EventArgs e)
        {

            if (fgSlices.Row >= 0)
                fgSlices.Rows.Remove(fgSlices.Row);
        }

        private void btnAddSimple_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                MMPathHistory.LandscapeSlice slice = new MMPathHistory.LandscapeSlice(dlg.FileName, true);
                AddSliceToTable(slice);
            }

        }

        private void btnAddGIS_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                MMPathHistory.LandscapeSlice slice = new MMPathHistory.LandscapeSlice(dlg.FileName, false);
                AddSliceToTable(slice);
            }
        }

        private void AddSliceToTable(MMPathHistory.LandscapeSlice slice)
        {
            int r = fgSlices.Rows.Add().Index;
            fgSlices[r, 0] = slice.LFileName;
            fgSlices[r, 1] = slice.ScaleWidth;
            fgSlices[r, 2] = slice.ScaleHeight;
            fgSlices[r, 3] = 1;
            fgSlices[r, 4] = slice;


        }

        private void fgSlices_BeforeEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (e.Col == 0)
                fgSlices.ComboList = "...";
            else
                fgSlices.ComboList = "";
        }

        private void fgSlices_CellButtonClick(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            System.Diagnostics.Process.Start(((MMPathHistory.LandscapeSlice)fgSlices[e.Row, 4]).LFileName);
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            if (fgSlices.Row > 1)
            {
                fgSlices.Rows[fgSlices.Row].Move(fgSlices.Row - 1);

            }
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            if (fgSlices.Row < fgSlices.Rows.Count - 1)
            {
                fgSlices.Rows[fgSlices.Row].Move(fgSlices.Row - 1);

            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            LS.Name = txtName.Text;

            LS.Slices.Clear();
            LS.TimeStepTransitions.Clear();



            for (int i = 1; i < fgSlices.Rows.Count; i++)
            {
                LS.Slices.Add((MMPathHistory.LandscapeSlice)fgSlices[i, 4]);
                LS.Slices[LS.Slices.Count - 1].ScaleWidth = Convert.ToInt32(fgSlices[i, 1]);
                LS.Slices[LS.Slices.Count - 1].ScaleHeight = Convert.ToInt32(fgSlices[i, 2]);
                LS.TimeStepTransitions.Add(Convert.ToInt32(fgSlices[i, 3]));
            }
        }
    }
}