using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MMPathHistoryEditor
{
    public partial class frmVar : Form
    {
        private MMPathHistory.PHVariable Var = null;
 
        public frmVar(List<string> landscapes, MMPathHistory.PHVariable var)
        {
            InitializeComponent();

            Var = var;

            for (int i = 0; i < landscapes.Count; i++)
                cboLandscapes.Items.Add(landscapes[i]);

            txtName.Text = var.Name;
            cboLandscapes.SelectedIndex = var.LandscapeIndex;
            cboType.Text = var.VarType;

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Var.Name = txtName.Text;
            Var.LandscapeIndex = cboLandscapes.SelectedIndex;
            Var.VarType = cboType.Text;
        }
    }
}