using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MMPathHistoryEditor
{
    public partial class frmEditor : Form
    {
        public frmEditor()
        {
            InitializeComponent();
        }

        private void DisplayProject(MMPathHistory.Project proj)
        {
            txtName.Text = proj.Name;

            lstLandscapes.Items.Clear();
            lstVars.Items.Clear();

            int i;

            for (i = 0; i < proj.Landscapes.Count; i++)
                lstLandscapes.Items.Add(proj.Landscapes[i]);

            for (i = 0; i < proj.Vars.Count; i++)
                lstVars.Items.Add(proj.Vars[i]);

            chkResetAnnually.Checked = proj.ResetVarsYearly;
                

            
            

        }

        private void newProjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //clear all the tools
            DisplayProject(new MMPathHistory.Project());


        }

        private void openProjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "PathHistory Project Files (*.phproj)|*.phproj";

            if (dlg.ShowDialog() == DialogResult.OK)
                DisplayProject(new MMPathHistory.Project(dlg.FileName));
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "PathHistory Project Files (*.phproj)|*.phproj";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                //try
                //{
                    //write the info into the project file.
                    MMPathHistory.Project proj = new MMPathHistory.Project();

                    proj.Name = txtName.Text.Trim();

                    int i;

                    for (i = 0; i < lstLandscapes.Items.Count; i++)
                        proj.Landscapes.Add((MMPathHistory.Landscape)lstLandscapes.Items[i]);

                    for (i = 0; i < lstVars.Items.Count; i++)
                        proj.Vars.Add((MMPathHistory.PHVariable)lstVars.Items[i]);

                    proj.ResetVarsYearly = chkResetAnnually.Checked;




                    proj.Save(dlg.FileName);
                //}
                //catch
                //{
                //    MessageBox.Show("Please be sure inputs are in the correct format.");
                //}


            }
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dr = MessageBox.Show("Save project before closing?", "Save?", MessageBoxButtons.YesNoCancel);

            if (dr == DialogResult.Cancel)
                e.Cancel = true;
            else if (dr == DialogResult.Yes)
                saveAsToolStripMenuItem_Click(this, new EventArgs());
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (lstLandscapes.SelectedIndex >= 0)
                lstLandscapes.Items.RemoveAt(lstLandscapes.SelectedIndex);
        }

        private void btnAddSimple_Click(object sender, EventArgs e)
        {
            MMPathHistory.Landscape l = new MMPathHistory.Landscape();

            if (new frmLandscape(l).ShowDialog() == DialogResult.OK)
                lstLandscapes.Items.Add(l);
        }


        private void btnVarsDel_Click(object sender, EventArgs e)
        {
            if (lstVars.SelectedIndex >= 0)
                lstVars.Items.RemoveAt(lstVars.SelectedIndex);
        }

        private void btnVarsAdd_Click(object sender, EventArgs e)
        {
            if (lstLandscapes.Items.Count == 0)
                MessageBox.Show("You must add a landscape before adding variables.");
            else
            {
                List<string> l = new List<string>();
                for (int i = 0; i < lstLandscapes.Items.Count; i++)
                    l.Add(lstLandscapes.Items[i].ToString());

                MMPathHistory.PHVariable var = new MMPathHistory.PHVariable();
                

                if (new frmVar(l, var).ShowDialog() == DialogResult.OK)
                    lstVars.Items.Add(var);
            }
        }


        private void lstLandscapes_DoubleClick(object sender, EventArgs e)
        {
            if (lstLandscapes.SelectedIndex >= 0)
            {
                if (new frmLandscape((MMPathHistory.Landscape)lstLandscapes.SelectedItem).ShowDialog() == DialogResult.OK)
                    lstLandscapes.Refresh();
            }

        }

        private void lstVars_DoubleClick(object sender, EventArgs e)
        {
            if (lstVars.SelectedIndex >= 0)
            {
                List<string> l = new List<string>();
                for (int i = 0; i < lstLandscapes.Items.Count; i++)
                    l.Add(lstLandscapes.Items[i].ToString());

                if (new frmVar(l, (MMPathHistory.PHVariable)lstVars.SelectedItem).ShowDialog() == DialogResult.OK)
                    lstVars.Refresh();
            }
        }

    }
}