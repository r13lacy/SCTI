namespace MMPathHistoryEditor
{
    partial class frmEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newProjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openProjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lstLandscapes = new System.Windows.Forms.ListBox();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnAddSimple = new System.Windows.Forms.Button();
            this.btnVarsAdd = new System.Windows.Forms.Button();
            this.btnVarsDel = new System.Windows.Forms.Button();
            this.lstVars = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chkResetAnnually = new System.Windows.Forms.CheckBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(586, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newProjectToolStripMenuItem,
            this.openProjectToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.quitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newProjectToolStripMenuItem
            // 
            this.newProjectToolStripMenuItem.Name = "newProjectToolStripMenuItem";
            this.newProjectToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.newProjectToolStripMenuItem.Text = "New Project";
            this.newProjectToolStripMenuItem.Click += new System.EventHandler(this.newProjectToolStripMenuItem_Click);
            // 
            // openProjectToolStripMenuItem
            // 
            this.openProjectToolStripMenuItem.Name = "openProjectToolStripMenuItem";
            this.openProjectToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.openProjectToolStripMenuItem.Text = "Open Project...";
            this.openProjectToolStripMenuItem.Click += new System.EventHandler(this.openProjectToolStripMenuItem_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.saveAsToolStripMenuItem.Text = "Save As...";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.quitToolStripMenuItem.Text = "Quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.quitToolStripMenuItem_Click);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(55, 37);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(261, 21);
            this.txtName.TabIndex = 2;
            this.txtName.Text = "New Path History Settings";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Landscapes:";
            // 
            // lstLandscapes
            // 
            this.lstLandscapes.FormattingEnabled = true;
            this.lstLandscapes.Location = new System.Drawing.Point(55, 119);
            this.lstLandscapes.Name = "lstLandscapes";
            this.lstLandscapes.Size = new System.Drawing.Size(217, 147);
            this.lstLandscapes.TabIndex = 5;
            this.lstLandscapes.DoubleClick += new System.EventHandler(this.lstLandscapes_DoubleClick);
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(55, 266);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(36, 21);
            this.btnDel.TabIndex = 6;
            this.btnDel.Text = "Del";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnAddSimple
            // 
            this.btnAddSimple.Location = new System.Drawing.Point(236, 266);
            this.btnAddSimple.Name = "btnAddSimple";
            this.btnAddSimple.Size = new System.Drawing.Size(36, 21);
            this.btnAddSimple.TabIndex = 8;
            this.btnAddSimple.Text = "Add";
            this.btnAddSimple.UseVisualStyleBackColor = true;
            this.btnAddSimple.Click += new System.EventHandler(this.btnAddSimple_Click);
            // 
            // btnVarsAdd
            // 
            this.btnVarsAdd.Location = new System.Drawing.Point(236, 470);
            this.btnVarsAdd.Name = "btnVarsAdd";
            this.btnVarsAdd.Size = new System.Drawing.Size(36, 21);
            this.btnVarsAdd.TabIndex = 12;
            this.btnVarsAdd.Text = "Add";
            this.btnVarsAdd.UseVisualStyleBackColor = true;
            this.btnVarsAdd.Click += new System.EventHandler(this.btnVarsAdd_Click);
            // 
            // btnVarsDel
            // 
            this.btnVarsDel.Location = new System.Drawing.Point(55, 470);
            this.btnVarsDel.Name = "btnVarsDel";
            this.btnVarsDel.Size = new System.Drawing.Size(36, 21);
            this.btnVarsDel.TabIndex = 10;
            this.btnVarsDel.Text = "Del";
            this.btnVarsDel.UseVisualStyleBackColor = true;
            this.btnVarsDel.Click += new System.EventHandler(this.btnVarsDel_Click);
            // 
            // lstVars
            // 
            this.lstVars.FormattingEnabled = true;
            this.lstVars.Location = new System.Drawing.Point(55, 323);
            this.lstVars.Name = "lstVars";
            this.lstVars.Size = new System.Drawing.Size(217, 147);
            this.lstVars.TabIndex = 9;
            this.lstVars.DoubleClick += new System.EventHandler(this.lstVars_DoubleClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 300);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Variables:";
            // 
            // chkResetAnnually
            // 
            this.chkResetAnnually.AutoSize = true;
            this.chkResetAnnually.Checked = true;
            this.chkResetAnnually.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkResetAnnually.Location = new System.Drawing.Point(294, 323);
            this.chkResetAnnually.Name = "chkResetAnnually";
            this.chkResetAnnually.Size = new System.Drawing.Size(271, 17);
            this.chkResetAnnually.TabIndex = 14;
            this.chkResetAnnually.Text = "Reset means and other variable tracking each year";
            this.chkResetAnnually.UseVisualStyleBackColor = true;
            // 
            // frmEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 509);
            this.Controls.Add(this.chkResetAnnually);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnVarsAdd);
            this.Controls.Add(this.btnVarsDel);
            this.Controls.Add(this.lstVars);
            this.Controls.Add(this.btnAddSimple);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.lstLandscapes);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmEditor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmEditor";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newProjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openProjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lstLandscapes;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnAddSimple;
        private System.Windows.Forms.Button btnVarsAdd;
        private System.Windows.Forms.Button btnVarsDel;
        private System.Windows.Forms.ListBox lstVars;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkResetAnnually;
    }
}