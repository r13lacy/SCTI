using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using BioLib;
using MMMCore;
using System.Diagnostics;

using SpatialEngine;


namespace MetaSpatial
{
    public class Meta
    {
        //PRIVATE VARIABLES **************************************
        private SpatialProject m_Project;
        private bool m_Initialized;

        private int[] m_PopIndexList;			//this stores the indices of the populations passed, so that we know which ones to write out at the end
        private string[] m_PopFileLocations;	//so that we know where to write the populations out at the end of the simulation

        private Random rnd = new Random();

        private StreamWriter stream = null;
        private DateTime timeStamp;


        //REQUIRED FUNCTIONS**************************************************

        /// <summary>
        /// Initialization code for the dll
        /// </summary>
        /// <returns>True if successfully initialized</returns>
        public bool Initialize()
        {

            return true;
        }

        /// <summary>
        /// Loads a project file for the application
        /// </summary>
        /// <param name="fileName">Full path of the project file to open</param>
        /// <returns>True if the project file is successfully loaded</returns>
        public bool LoadProject(string fileName)
        {

            //open the project, and check that it is valid
            m_Project = new SpatialProject(fileName);

            m_Initialized = m_Project.IsValid();
            
            //debug
            //timeStamp = DateTime.Now;
            //string f = fileName.Substring(0, fileName.LastIndexOf("\\") + 1) + "spatial_debug.txt";
            //stream = new StreamWriter(f);
            //stream.WriteLine("Spatial Debug, run started " + timeStamp.ToLongTimeString());
            

            return m_Initialized;
        }

        


        public bool Simulate(List<MMMCore.MPopulation> pops, int numTimeSteps)
        {
            int i, j;

            //set the pops
            for (i = 0; i < m_Project.NumPopulations(); i++)
            {
                SPopulation pop = m_Project.GetPopulation(i);

// Bob
                //int x = pops[i].IndList[0].VarNames.IndexOf("X");
                //int y = pops[i].IndList[0].VarNames.IndexOf("Y");

                int x = pops[i].IndVarNames.IndexOf("X");
                int y = pops[i].IndVarNames.IndexOf("Y");

                int[] addls = new int[pops[i].VarNames.Count];

                //Debug.Assert(false);

                for (j = 0; j < pops[i].IndList.Count; j++)
                {



                    //Changed 1/14/2010 to just use the pop as it comes in, not worry about matching names
                    Individual ind = null;
                    if (j < pop.NumIndividuals())
                        ind = m_Project.GetPopulation(i).GetIndividual(j);

                    //Individual ind = m_Project.GetPopulation(i).GetIndividual(pops[i].IndList[j].Vars[0]);
                    if (ind == null) //individual not in the population, need to add it!
                    {
                        object[] newAddls = new object[pops[i].IndList[j].Vars.Count];
                        for (int ii = 0; ii < pops[i].IndList[j].Vars.Count; ii++)
                             newAddls[ii] = pops[i].IndList[j].Vars[ii];

                         if (x >= 0 && y >= 0 && Convert.ToInt32(Convert.ToDouble(pops[i].IndList[j].Vars[x])) >= 0 && Convert.ToInt32(Convert.ToDouble(pops[i].IndList[j].Vars[y])) >= 0)
                         {
                             ind = new Individual(pops[i].IndList[j].Vars[0],
                                 Convert.ToInt32(Convert.ToDouble(pops[i].IndList[j].Vars[x])), Convert.ToInt32(Convert.ToDouble(pops[i].IndList[j].Vars[x])), pop.NumIndividuals(), newAddls);
                         }
                         else
                             ind = new Individual(pops[i].IndList[j].Vars[0], rnd.Next(pop.GetBoundsX()), rnd.Next(pop.GetBoundsY()), pop.NumIndividuals(), newAddls);
                        
                        pop.AddIndividual(ind);
                    }
                    else
                    {
                        if (x >= 0)
                        {
                            int ix = -1;
                            //if vars come from vortex they are "0.0000" format, can't be converted to int
                            if (pops[i].IndList[j].Vars[x].Contains("."))
                                ix = Convert.ToInt32(Convert.ToDouble(pops[i].IndList[j].Vars[x]));
                            else
                                ix = Convert.ToInt32(pops[i].IndList[j].Vars[x]);

                            if (ix >= 0)
                                ind.SetX(ix);
                            else if (ind.GetX() < 0) //vortex has provided an animal with unseeded location and spatial doesn't know, give it a random location
                                ind.SetX(rnd.Next(pop.GetBoundsX()));
                      
                        }

                        if (y >= 0)
                        {
                            int iy = -1;

                            //if vars come from vortex they are "0.0000" format, can't be converted to int
                            if (pops[i].IndList[j].Vars[y].Contains("."))
                                iy = Convert.ToInt32(Convert.ToDouble(pops[i].IndList[j].Vars[y]));
                            else
                                iy = Convert.ToInt32(pops[i].IndList[j].Vars[y]);

                            if (iy >= 0)
                                ind.SetY(iy);
                            else if (ind.GetY() < 0) //vortex has provided an animal with unseeded location, give it a random location
                                ind.SetY(rnd.Next(pop.GetBoundsY()));
                           
                        }
                    }
                }

                    


            }

            if (stream != null)
            {
                stream.Write("Pops Loaded: " + ((TimeSpan)(DateTime.Now - timeStamp)).Milliseconds.ToString());
                timeStamp = DateTime.Now;
            }

            //make sure simulation info has been set up
            if (m_Project.GetSimulationInfo() == null)
                m_Project.SetSimulationInfo(new DispersalSimulatorInfo(m_Project));


            DispersalSimulatorInfo simInfo = m_Project.GetSimulationInfo();

            simInfo.SetNumTimeSteps(numTimeSteps);

            //set to simulate all populations
            for (i = 0; i < m_Project.NumPopulations(); i++)
                simInfo.SetIncludedPopulation(i, true);


            //now run the simulation
            DispersalSimulator sim = new DispersalSimulator(m_Project);

            


            sim.Simulate();



            if (stream != null)
            {
                stream.Write(";  Simulated: " + ((TimeSpan)(DateTime.Now - timeStamp)).Milliseconds.ToString());
                timeStamp = DateTime.Now;
            }


            //write back the new vals
            //set the pops
            for (i = 0; i < m_Project.NumPopulations(); i++)
            {
                SPopulation pop = m_Project.GetPopulation(i);

                int x = pops[i].IndVarNames.IndexOf("X");
                int y = pops[i].IndVarNames.IndexOf("Y");

                for (j = 0; j < pops[i].IndList.Count; j++)
                {
                    //Changed 1/14/2010 to just use the pop as it comes in, not worry about matching names
                    Individual ind = m_Project.GetPopulation(i).GetIndividual(j);
                    //Individual ind = m_Project.GetPopulation(i).GetIndividual(pops[i].IndList[j].Vars[0]);
                    if (ind != null)
                    {
                        if (x >= 0)
                            pops[i].IndList[j].Vars[x] = ind.GetX().ToString();

                        if (y >= 0)
                            pops[i].IndList[j].Vars[y] = ind.GetY().ToString();
                    }
                }
            }

            if (stream != null)
            {
                stream.Write(";  Data Written: " + ((TimeSpan)(DateTime.Now - timeStamp)).Milliseconds.ToString() + stream.NewLine);
                timeStamp = DateTime.Now;
            }


            return true;
        }

        public bool Close()
        {
            if (stream != null)
                stream.Close();

            return m_Project.Save(m_Project.GetSaveName().Substring(0, m_Project.GetSaveName().Length - 4) + "_res.spj");
            
        }




        //ADDITIONAL FUNCTIONS**************************************************

        public void SeedPopulationsXYRandom(int width, int height)
        {
            if (m_PopIndexList != null && m_PopIndexList.Length > 0)
            {
                for (int i = 0; i < m_PopIndexList.Length; i++)
                    m_Project.GetPopulation(m_PopIndexList[i]).SeedSpatialLocations(SpatialSeedMethods.SpatialSeedMethodsEnum.UniformRandom, width, height);
            }
        }


    }
}
