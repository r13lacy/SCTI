﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Windows.Forms;
using EvaluatorLibrary;
using C1.Win.C1Chart;

namespace Outbreak2
{
    public class Outbreak2
    {
        public static string O2version = "2.3.0";
//        public static string dateCompiled = "";
        public static string userDataFile = "";

        public string OName = "MyProject";
        public string Description = "";
        public string ProjFolder = "MyProject\\";
        public string DzTag = "";

        public List<OScenario> Oscenes = new List<OScenario>();
        public int nscenes = 1;
//        public List<string> ScenarioNames = new List<string>();
        public bool doDemog = true;
        public bool doDz = true;

        public Outbreak2(string ofile, bool dodemog)
        {
            doDemog = dodemog;
            OScenario OS = new OScenario(this, dodemog);
            Oscenes.Add(OS); // start with a single default OScenario
            nscenes = Oscenes.Count;

            if (ofile != null) readOfile(ofile);
            else OS.calcLambda();

            OS.scenendx = nscenes - 1;
        }

        public void setDefaults() // in case coming from a prior project, but new project doesn't have these defined in the xml
        {
            ProjFolder = "MyProject\\";
            OName = "MyProject";
            Description = "";
        }


        public bool saveXML(string filename, bool newfolder)
        {
            try
            {
                if (filename == null || filename.Trim() == "")
                {
                    filename = OName + ".xml";
                    ProjFolder = OName + "\\";
                }
                else
                {
                    if (!filename.ToLower().EndsWith(".xml")) filename = filename + ".xml";
                    if (newfolder)
                    {
                        int f = filename.LastIndexOf('\\');
                        if (f >= 0) ProjFolder = filename.Remove(f) + "\\";
                    }
                }

                //create the project settings file in the working folder
                XmlDocument doc = new XmlDocument();

                //add top node and name as attrib
                XmlElement nTop = doc.CreateElement("OutbreakProject");
                doc.AppendChild(nTop);
                XmlAttribute att = doc.CreateAttribute("Version");
                att.Value = Outbreak2.O2version;

                nTop.Attributes.Append(att);

                XmlElement n = doc.CreateElement("Name");
                n.InnerText = OName;
                nTop.AppendChild(n);

                n = doc.CreateElement("DzTag");
                n.InnerText = DzTag;
                nTop.AppendChild(n);

                n = doc.CreateElement("Description");
                n.InnerText = Description;
                nTop.AppendChild(n);

                for (int i = 0; i < nscenes; i++)
                {
                    if (!Oscenes[i].saveXMLscene(filename, doc, nTop)) return false;
                }

                doc.Save(filename);

            }
            catch
            {
                MessageBox.Show("Could not save " + filename);
                return false; // this can happen if the user doesn't have admin rights to save the file to the folder.
            }

            return true;
        }


        public bool readOfile(string filename)
        {
            setDefaults();
            DzTag = "";

            int f = filename.LastIndexOf('\\');
            if (f >= 0) ProjFolder = filename.Remove(f) + "\\";

            filename = filename.ToLower();

            if (filename.EndsWith(".xml")) { if (!readXML(filename)) return false; }
            else
            {
                OScenario os = Oscenes[0];

                if (filename.EndsWith(".ois")) { if (!os.readOPF(filename)) return false; }
                else if (filename.EndsWith(".opf")) { if (!os.readOPF(filename)) return false; }
                else if (filename.EndsWith(".infect")) { if (!os.readInfect(filename)) return false; }
                else
                {
                    MessageBox.Show("Could not determine filetype of " + filename + " for reading input");
                    return false;
                }
            }

            for (int i = 0; i < nscenes; i++)
            {
                OScenario os = Oscenes[i];
                os.runsDone = os.readResults();
                os.processInput();
            }

            return true;
        }


        public bool readXML(string filename)
        {
            try
            {
                XmlDocument doc = new XmlDocument();

                //will throw an exception
                doc.Load(filename);

                if (!doc.DocumentElement.Name.Contains("OutbreakProject"))
                    return false;

                //get a document navigator started at the top document
                XPathNavigator nav = doc.CreateNavigator();
                nav.MoveToFirstChild();

                XPathNodeIterator iter = nav.Select("Name");
                if (iter.MoveNext())
                    OName = iter.Current.Value;

                iter = nav.Select("DzTag");
                if (iter.MoveNext())
                    DzTag = iter.Current.Value;

                iter = nav.Select("Description");
                if (iter.MoveNext())
                    Description = iter.Current.Value;

                string oversion = nav.GetAttribute("Version", "");

                if (oversion.CompareTo("2.2") < 0)
                {
                    if(!Oscenes[0].readXMLscenario(doc, nav))
                    {
                        MessageBox.Show("Failed to load project");
                        return false;
                    }
                }
                else
                {
                    Oscenes.Clear();
                    nscenes = 0;
                    XPathNodeIterator iterSc = nav.Select("OutbreakScenario");
                    while (iterSc.MoveNext())
                    {
                        XPathNavigator scnav = iterSc.Current.Clone();
                        OScenario os = new OScenario(this, doDemog);
                        if (os.readXMLscenario(doc, scnav))
                        {
                            Oscenes.Add(os);
                            nscenes++;
                            os.scenendx = nscenes - 1;
                        }
                        else
                        {
                            MessageBox.Show("Failed to load project");
                            return false;
                        }
                    }
                }
            }
            catch 
            {
                MessageBox.Show("Failed to load project");
                return false; 
            }

            return true;
        }


        private object copyObject(object ob)
        {
            if (ob == null) return null;

            object newObj = null;

            if (ob.GetType() == typeof(Evaluator)) newObj = ((Evaluator)ob).copyEval();
            else newObj = ob;

            return newObj;
        }


        // make an explicit, element by element copy, to be sure that everything is copying values and not references.
        public bool copyScenario(OScenario os, string newScName)
        {
            OScenario newOS = new OScenario(this, os.doDemog);

            newOS.SceneName = newScName;
            newOS.SceneNotes = os.SceneNotes;

            newOS.outYearly = os.outYearly;
            newOS.outDaily = os.outDaily;
            newOS.outEpiRates = os.outEpiRates;
            newOS.outIndList = os.outIndList;
            newOS.outIndividuals = os.outIndividuals; // not currently used
            newOS.outMM = os.outMM; // not currently used

            newOS.PNotes = os.PNotes;
            newOS.SNotes = os.SNotes;
            newOS.ENotes = os.ENotes;
            newOS.INotes = os.INotes;
            newOS.RNotes = os.RNotes;
            newOS.VNotes = os.VNotes;
            newOS.CullNotes = os.CullNotes;
            newOS.InitNotes = os.InitNotes;
            newOS.DemogNotes = os.DemogNotes;
            newOS.SpatialNotes = os.SpatialNotes;

            newOS.prPermanentP = copyObject(os.prPermanentP);
            newOS.DaysP = copyObject(os.DaysP);
            newOS.MaternalR = os.MaternalR;
            newOS.DaysMaternalR = copyObject(os.DaysMaternalR);

            newOS.usePropEncounter = os.usePropEncounter;
            newOS.useFixedNEncounter = os.useFixedNEncounter;
            newOS.useDistanceEncounter = os.useDistanceEncounter;
            newOS.prPopEncounter = copyObject(os.prPopEncounter);
            newOS.NEncounter = copyObject(os.NEncounter);
            newOS.DistanceEncounterFunc = copyObject(os.DistanceEncounterFunc);
            newOS.prTransmission = copyObject(os.prTransmission);
            newOS.prOutsideEncounter = copyObject(os.prOutsideEncounter);
            newOS.prOutsideTransmission = copyObject(os.prOutsideTransmission);
            newOS.prMaternalTransmission = copyObject(os.prMaternalTransmission);

            newOS.DaysE = copyObject(os.DaysE);

            newOS.prPermanentI = copyObject(os.prPermanentI);
            newOS.DaysI = copyObject(os.DaysI);
            newOS.prRecovery = copyObject(os.prRecovery);
            newOS.prReSusceptible = copyObject(os.prReSusceptible);
            newOS.prDeath = copyObject(os.prDeath);

            newOS.prPermanentR = copyObject(os.prPermanentR);
            newOS.DaysR = copyObject(os.DaysR);

            newOS.vaccNow = os.vaccNow;
            newOS.useVaccInterval = os.useVaccInterval;
            newOS.useVaccPrev = os.useVaccPrev;
            newOS.vaccDays = copyObject(os.vaccDays);
            newOS.vaccDaysStart = copyObject(os.vaccDaysStart);
            newOS.vaccPrev = copyObject(os.vaccPrev);

            newOS.vaccAge0 = copyObject(os.vaccAge0);
            newOS.vaccAgeSA = copyObject(os.vaccAgeSA);
            newOS.vaccAgeAd = copyObject(os.vaccAgeAd);

            newOS.vaccEfficacy = copyObject(os.vaccEfficacy);
            newOS.vaccDuration = copyObject(os.vaccDuration);

            newOS.cullNow = os.cullNow;
            newOS.useCullInterval = os.useCullInterval;
            newOS.useCullPrev = os.useCullPrev;
            newOS.cullDays = copyObject(os.cullDays);
            newOS.cullDaysStart = copyObject(os.cullDaysStart);
            newOS.cullPrev = copyObject(os.cullPrev);

            newOS.cullAge0 = copyObject(os.cullAge0);
            newOS.cullAgeSA = copyObject(os.cullAgeSA);
            newOS.cullAgeAd = copyObject(os.cullAgeAd);

            newOS.initN = os.initN;
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 5; j++)
                    newOS.initStates[i, j] = os.initStates[i, j];
            newOS.useNcount = os.useNcount;
            newOS.juvDays = os.juvDays;
            newOS.SADays = os.SADays;

            newOS.useSpatial = os.useSpatial;
            newOS.gridXmin = os.gridXmin;
            newOS.gridXmax = os.gridXmax;
            newOS.gridYmin = os.gridYmin;
            newOS.gridYmax = os.gridYmax;
            newOS.gridSeed = os.gridSeed;
            newOS.gridXseed = copyObject(os.gridXseed);
            newOS.gridYseed = copyObject(os.gridYseed);
            newOS.moveRandom = os.moveRandom;
            newOS.moveRules = os.moveRules;
            newOS.moveWhen = copyObject(os.moveWhen);
            newOS.moveDist = copyObject(os.moveDist);
            newOS.moveXrule = copyObject(os.moveXrule);
            newOS.moveYrule = copyObject(os.moveYrule);
            newOS.gridBoundaryReflects = os.gridBoundaryReflects;
            newOS.gridBoundaryAbsorbs = os.gridBoundaryAbsorbs;

            newOS.spatialDisplayDays = os.spatialDisplayDays;

            newOS.breedDays = copyObject(os.breedDays);
            newOS.brAge = os.brAge;
            newOS.brAgeDays = os.brAgeDays;
            newOS.brMaxAge = os.brMaxAge;

            for (int i = 0; i < 4; i++)
            {
                newOS.Age0Mort[i] = copyObject(os.Age0Mort[i]);
                newOS.SAMort[i] = copyObject(os.SAMort[i]);
                newOS.AdultFMort[i] = copyObject(os.AdultFMort[i]);
                newOS.AdultMMort[i] = copyObject(os.AdultMMort[i]);
                newOS.prBreed[i] = copyObject(os.prBreed[i]);
                newOS.nLitters[i] = copyObject(os.nLitters[i]);
                newOS.litSize[i] = copyObject(os.litSize[i]);
            }

            newOS.K = copyObject(os.K);
            newOS.maintainK = os.maintainK;
            newOS.KDay = os.KDay;

            newOS.nRuns = os.nRuns;
            newOS.nYears = os.nYears;
            newOS.nDays = os.nDays;

            // to be used later, if we add a SV module
            //public List<string> gsVarNames = new List<string>();
            //public List<string> psVarNames = new List<string>();
            //public List<string> isVarNames = new List<string>();

            newOS.calcLambda();

            Oscenes.Add(newOS);
            nscenes++;
            newOS.scenendx = nscenes - 1;

            return true;
        }

    } // end of class Outbreak2

    public class OScenario
    {
        public static Random ORand = new Random();

        public Outbreak2 mOP;
        public int scenendx = 0;

        public string SceneName = "Scenario1";
        public string SceneNotes = "";

        public bool runsDone = false; // flag to say if we have output that is ready to graph
        public bool doDemog = true;

        public string PNotes = "For each input parameter that requests a duration, you can provide either a fixed number of days, or you can specify that the duration is to be sampled from some distribution.";
        public string SNotes = "The default values for a new project are provided simply to give one example of a model. Be sure to replace all default values with input that is appropriate for your system, and be sure to add your own notes to explain how you specified the model parameters.";
        public string ENotes = "";
        public string INotes = "";
        public string RNotes = "";
        public string VNotes = "";
        public string CullNotes = "";
        public string InitNotes = "";
        public string DemogNotes = "";
        public string SpatialNotes = "";

        public object prPermanentP = (double)0.0;
        public object DaysP = "=IUNIFORM(0;5)";
        public bool MaternalR = false;
        public object DaysMaternalR = "=IUNIFORM(10;20)";

        public bool usePropEncounter = true;
        public bool useFixedNEncounter = false;
        public bool useDistanceEncounter = false;
        public object prPopEncounter = 0.1;
        public object NEncounter = (int)0;
        public object DistanceEncounterFunc = "=0.1*(DIST<4)";
        public object prTransmission = 0.1;
        public object prOutsideEncounter = 0.0;
        public object prOutsideTransmission = 0.0;
        public object prMaternalTransmission = 0.0;

        public object DaysE = 10;

        public object prPermanentI = 0.0;
        public object DaysI = 30;
        public object prRecovery = 0.9;
        public object prReSusceptible = 0.0;

        public object prDeath = 0.1;

        public object prPermanentR = 0.0;
        public object DaysR = 14;

        private bool nowVacc = false;
        public bool vaccNow = false;
        public bool useVaccInterval = false;
        public bool useVaccPrev = false;
        public object vaccDays = (int)365;
        public object vaccDaysStart = (int)365;
        public object vaccPrev = "=PREV>0.1";

        public object vaccAge0 = 0.25;
        public object vaccAgeSA = 0.25;
        public object vaccAgeAd = 0.25;

        public object vaccEfficacy = 0.75;
        public object vaccDuration = (int)300;

        public bool cullNow = false;
        public bool useCullInterval = false;
        public bool useCullPrev = false;
        public object cullDays = (int)365;
        public object cullDaysStart = (int)365;
        public object cullPrev = "=PREV>0.1";

        public object cullAge0 = 0.25;
        public object cullAgeSA = 0.25;
        public object cullAgeAd = 0.25;

        public int initN = 100;
        public int[,] initStates = new int[4,5];
        public bool useNcount = true;
        public int juvDays = 365;
        public int SADays = 1095;

        public bool useSpatial = false;
        public int gridXmin = 0;
        public int gridXmax = 100;
        public int gridYmin = 0;
        public int gridYmax = 100;
        public bool gridSeed = true;
        public object gridXseed = "=50+10*NRAND";
        public object gridYseed = "=50+10*NRAND";
        public bool moveRandom = false;
        public bool moveRules = false;
        public object moveWhen = "=DAY%30=0";
        public object moveDist = "=5*NRAND";
        public object moveXrule = "=XCOORD+5*NRAND";
        public object moveYrule = "=YCOORD+5*NRAND";
        public bool gridBoundaryReflects = false;
        public bool gridBoundaryAbsorbs = false;

        public int spatialDisplayDays = 0;

        // Demography stuff
        public object breedDays = "=IUNIFORM(100;160)";
        public int brAge = 3;
        public int brAgeDays = 1095;
        public int brMaxAge = 12;
        public object[] Age0Mort = new object[4];
        public object[] SAMort = new object[4];
        public object[] AdultMMort = new object[4];
        public object[] AdultFMort = new object[4];
        public object[] prBreed = new object[4];
        public object[] nLitters = new object[4];
        public object[] litSize = new object[4];
        public object K = (int)300;
        public bool maintainK = true;
        public int KDay = 365;
        public bool enterStageMort = false; // data entry for Juv and Adult Mort will be for the stage, not annual

        public int nRuns = 100;
        public int nYears = 10;
        public int nDays = 365;

        public List<string> gsVarNames = new List<string>();
        public List<string> psVarNames = new List<string>();
        public List<string> isVarNames = new List<string>();

        //public List<double> gsVals = new List<double>();
        //public List<double> psVals = new List<double>();
        //public List<double> isVals = new List<double>(); 

        public int nID = 0;

        public OScenario(Outbreak2 op, bool dodemog)
        {
            mOP = op;
            doDemog = dodemog;

            for (int i = 0; i < 4; i++)
            {
                initStates[i, 0] = 24; // defaults
                initStates[i, 1] = 1;
            }

            for (int i = 0; i < 4; i++)
            {
                Age0Mort[i] = 0.5;
                SAMort[i] = 0.05;
                AdultMMort[i] = 0.1;
                AdultFMort[i] = 0.08;
                prBreed[i] = 0.5;
                nLitters[i] = 1;
                litSize[i] = 2;
            }

            // in case will not be modified from default input screens ...
            DistanceEncounterFunc = translateObject(DistanceEncounterFunc);
            gridXseed = translateIntObject(gridXseed);
            gridYseed = translateIntObject(gridYseed);
            moveXrule = translateObject(moveXrule);
            moveYrule = translateObject(moveYrule);
            moveWhen = translateObject(moveWhen);

        }

        public string OutFolder = "";
//        private StreamWriter yrSummaryWriter;
//        private StreamWriter yrDailyWriter;
        private StreamWriter[] yrDailyWriters;
        private StreamWriter[] yrSummaryWriters;

        public List<OIndividual> OIndivids;

        private int[,] states = new int[4, 6];
        private int[] stages = new int[4];

        private int[] dzstates = new int[6];
        public int nP { get { return dzstates[0]; } }
        public int nS { get { return dzstates[1]; } }
        public int nE { get { return dzstates[2]; } }
        public int nI { get { return dzstates[3]; } }
        public int nR { get { return dzstates[4]; } }
        public int nV { get { return dzstates[5]; } }

        public double[, ,] sYStates;
        public double[, ,] ssYStates;
        public double[,] sYStages;
        public double[,] ssYStages;
        public double[,] sYDz;
        public double[,] ssYDz;
        public double[] sYN;
        public double[] ssYN;

        public double[] sYNew;
        public double[] ssYNew;
        public double[] sYNewDeaths;
        public double[] ssYNewDeaths;

        public double[, , ,] sDStates;
        public double[, , ,] ssDStates;
        public double[, ,] sDStages;
        public double[, ,] ssDStages;
        public double[, ,] sDDz;
        public double[, ,] ssDDz;

        public double[,] sDNewCases;
        public double[,] ssDNewCases;

        public double[,] sDNewDeaths;
        public double[,] ssDNewDeaths;

        public double[,] yPrev;
        public double[] syPrev;

        public int[,] ryN;

        private int totalN;
        public int N
        {
            get { return totalN; }
        }
        private int KNow = 0;

        public double[] psstates;

        private double prevalence = 0.0;
        public double Prevalence { get { return prevalence; } }

        private int m_iter = 0;
        private int year = 0;
        private int day = 0;
        private int vday = 0;
        private int cullday = 0;
        private bool hasCulled = false;
        private bool nowCull = false;

        public int Iter
        {
            get { return m_iter; }
            set { m_iter = value; }
        }

        public int Year
        {
            get { return year; }
            set { year = value; }
        }

        public int Day
        {
            get { return day; }
            set { day = value; }
        }

        # region IO

        public bool saveXMLscene(string filename, XmlDocument doc, XmlElement nTop)
        {
            try
            {
                //add top node and name as attrib
                XmlElement nScene = doc.CreateElement("OutbreakScenario");
                nTop.AppendChild(nScene);

                XmlAttribute att = doc.CreateAttribute("index");
                att.Value = scenendx.ToString();
                nScene.Attributes.Append(att);

                XmlElement n = doc.CreateElement("SceneName");
                n.InnerText = SceneName;
                nScene.AppendChild(n);

                n = doc.CreateElement("Iterations");
                n.InnerText = nRuns.ToString();
                nScene.AppendChild(n);

                n = doc.CreateElement("Years");
                n.InnerText = nYears.ToString();
                nScene.AppendChild(n);

                n = doc.CreateElement("Days");
                n.InnerText = nDays.ToString();
                nScene.AppendChild(n);


                n = doc.CreateElement("OutputFiles");
                nScene.AppendChild(n);

                XmlElement nn = doc.CreateElement("outYearly");
                nn.InnerText = outYearly.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("outDaily");
                nn.InnerText = outDaily.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("outEpiRates");
                nn.InnerText = outEpiRates.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("outIndList");
                nn.InnerText = outIndList.ToString();
                n.AppendChild(nn);

                //nn = doc.CreateElement("outIndividuals");
                //nn.InnerText = outIndividuals.ToString();
                //n.AppendChild(nn);

                //nn = doc.CreateElement("outMM");
                //nn.InnerText = outMM.ToString();
                //n.AppendChild(nn);


                n = doc.CreateElement("Notes");
                nScene.AppendChild(n);

                nn = doc.CreateElement("SceneNotes");
                nn.InnerText = SceneNotes.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("PNotes");
                nn.InnerText = PNotes.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("SNotes");
                nn.InnerText = SNotes.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("ENotes");
                nn.InnerText = ENotes.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("INotes");
                nn.InnerText = INotes.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("RNotes");
                nn.InnerText = RNotes.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("VNotes");
                nn.InnerText = VNotes.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("CullNotes");
                nn.InnerText = CullNotes.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("InitNotes");
                nn.InnerText = InitNotes.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("DemogNotes");
                nn.InnerText = DemogNotes.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("SpatialNotes");
                nn.InnerText = SpatialNotes.ToString();
                n.AppendChild(nn);


                n = doc.CreateElement("Pre-susceptible");
                nScene.AppendChild(n);

                nn = doc.CreateElement("probPermanentP");
                nn.InnerText = prPermanentP.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("DaysP");
                nn.InnerText = DaysP.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("MaternalR");
                nn.InnerText = MaternalR.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("DaysMaternalR");
                nn.InnerText = DaysMaternalR.ToString();
                n.AppendChild(nn);

                n = doc.CreateElement("Susceptible");
                nScene.AppendChild(n);

                nn = doc.CreateElement("usePropEncounter");
                nn.InnerText = usePropEncounter.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("propPopEncounter");
                nn.InnerText = prPopEncounter.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("useFixedNEncounter");
                nn.InnerText = useFixedNEncounter.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("NEncounter");
                nn.InnerText = NEncounter.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("useDistanceEncounter");
                nn.InnerText = useDistanceEncounter.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("DistanceEncounterFunc");
                nn.InnerText = DistanceEncounterFunc.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("probTransmission");
                nn.InnerText = prTransmission.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("probOutsideEncounter");
                nn.InnerText = prOutsideEncounter.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("probOutsideTransmission");
                nn.InnerText = prOutsideTransmission.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("probMaternalTransmission");
                nn.InnerText = prMaternalTransmission.ToString();
                n.AppendChild(nn);

                n = doc.CreateElement("Exposed");
                nScene.AppendChild(n);

                nn = doc.CreateElement("DaysE");
                nn.InnerText = DaysE.ToString();
                n.AppendChild(nn);

                n = doc.CreateElement("Infectious");
                nScene.AppendChild(n);

                nn = doc.CreateElement("probPermanentI");
                nn.InnerText = prPermanentI.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("DaysI");
                nn.InnerText = DaysI.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("probRecovery");
                nn.InnerText = prRecovery.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("probReSusceptible");
                nn.InnerText = prReSusceptible.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("probDeath");
                nn.InnerText = prDeath.ToString();
                n.AppendChild(nn);

                n = doc.CreateElement("Resistant");
                nScene.AppendChild(n);

                nn = doc.CreateElement("probPermanentR");
                nn.InnerText = prPermanentR.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("DaysR");
                nn.InnerText = DaysR.ToString();
                n.AppendChild(nn);

                n = doc.CreateElement("Vaccinate");
                nScene.AppendChild(n);

                nn = doc.CreateElement("VaccNow");
                nn.InnerText = vaccNow.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("VaccInterval");
                nn.InnerText = useVaccInterval.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("VaccDays");
                nn.InnerText = vaccDays.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("VaccDaysStart");
                nn.InnerText = vaccDaysStart.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("VaccCriteria");
                nn.InnerText = useVaccPrev.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("VaccPrev");
                nn.InnerText = vaccPrev.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("VaccAge0");
                nn.InnerText = vaccAge0.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("VaccAgeSA");
                nn.InnerText = vaccAgeSA.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("VaccAgeAd");
                nn.InnerText = vaccAgeAd.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("VaccEfficacy");
                nn.InnerText = vaccEfficacy.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("VaccDuration");
                nn.InnerText = vaccDuration.ToString();
                n.AppendChild(nn);


                n = doc.CreateElement("Cull");
                nScene.AppendChild(n);

                nn = doc.CreateElement("CullNow");
                nn.InnerText = cullNow.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("CullInterval");
                nn.InnerText = useCullInterval.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("CullDays");
                nn.InnerText = cullDays.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("CullDaysStart");
                nn.InnerText = cullDaysStart.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("CullCriteria");
                nn.InnerText = useCullPrev.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("CullPrev");
                nn.InnerText = cullPrev.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("CullAge0");
                nn.InnerText = cullAge0.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("CullAgeSA");
                nn.InnerText = cullAgeSA.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("CullAgeAd");
                nn.InnerText = cullAgeAd.ToString();
                n.AppendChild(nn);


                n = doc.CreateElement("InitialPopulation");
                nScene.AppendChild(n);

                nn = doc.CreateElement("InitN");
                nn.InnerText = initN.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("useNCount");
                nn.InnerText = useNcount.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("Juveniles");
                n.AppendChild(nn);

                XmlElement n3 = doc.CreateElement("S");
                n3.InnerText = initStates[0, 0].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("E");
                n3.InnerText = initStates[0, 1].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("I");
                n3.InnerText = initStates[0, 2].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("R");
                n3.InnerText = initStates[0, 3].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("V");
                n3.InnerText = initStates[0, 4].ToString();
                nn.AppendChild(n3);

                nn = doc.CreateElement("Subadults");
                n.AppendChild(nn);

                n3 = doc.CreateElement("S");
                n3.InnerText = initStates[1, 0].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("E");
                n3.InnerText = initStates[1, 1].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("I");
                n3.InnerText = initStates[1, 2].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("R");
                n3.InnerText = initStates[1, 3].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("V");
                n3.InnerText = initStates[1, 4].ToString();
                nn.AppendChild(n3);

                nn = doc.CreateElement("AdultMales");
                n.AppendChild(nn);

                n3 = doc.CreateElement("S");
                n3.InnerText = initStates[2, 0].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("E");
                n3.InnerText = initStates[2, 1].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("I");
                n3.InnerText = initStates[2, 2].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("R");
                n3.InnerText = initStates[2, 3].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("V");
                n3.InnerText = initStates[2, 4].ToString();
                nn.AppendChild(n3);

                nn = doc.CreateElement("AdultFemales");
                n.AppendChild(nn);

                n3 = doc.CreateElement("S");
                n3.InnerText = initStates[3, 0].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("E");
                n3.InnerText = initStates[3, 1].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("I");
                n3.InnerText = initStates[3, 2].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("R");
                n3.InnerText = initStates[3, 3].ToString();
                nn.AppendChild(n3);

                n3 = doc.CreateElement("V");
                n3.InnerText = initStates[3, 4].ToString();
                nn.AppendChild(n3);

                nn = doc.CreateElement("JuvDays");
                nn.InnerText = juvDays.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("SADays");
                nn.InnerText = SADays.ToString();
                n.AppendChild(nn);


                n = doc.CreateElement("Demography");
                nScene.AppendChild(n);

                nn = doc.CreateElement("BreedDays");
                nn.InnerText = breedDays.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("BreedAgeDays");
                nn.InnerText = brAgeDays.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("BreedMaxAge");
                nn.InnerText = brMaxAge.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("EnterStageMort");
                nn.InnerText = enterStageMort.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("Age0MortS");
                nn.InnerText = Age0Mort[0].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("Age0MortE");
                nn.InnerText = Age0Mort[1].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("Age0MortI");
                nn.InnerText = Age0Mort[2].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("Age0MortR");
                nn.InnerText = Age0Mort[3].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("SAMortS");
                nn.InnerText = SAMort[0].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("SAMortE");
                nn.InnerText = SAMort[1].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("SAMortI");
                nn.InnerText = SAMort[2].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("SAMortR");
                nn.InnerText = SAMort[3].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("AMMortS");
                nn.InnerText = AdultMMort[0].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("AMMortE");
                nn.InnerText = AdultMMort[1].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("AMMortI");
                nn.InnerText = AdultMMort[2].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("AMMortR");
                nn.InnerText = AdultMMort[3].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("AFMortS");
                nn.InnerText = AdultFMort[0].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("AFMortE");
                nn.InnerText = AdultFMort[1].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("AFMortI");
                nn.InnerText = AdultFMort[2].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("AFMortR");
                nn.InnerText = AdultFMort[3].ToString();
                n.AppendChild(nn);


                nn = doc.CreateElement("prBreedS");
                nn.InnerText = prBreed[0].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("prBreedE");
                nn.InnerText = prBreed[1].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("prBreedI");
                nn.InnerText = prBreed[2].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("prBreedR");
                nn.InnerText = prBreed[3].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("nLittersS");
                nn.InnerText = nLitters[0].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("nLittersE");
                nn.InnerText = nLitters[1].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("nLittersI");
                nn.InnerText = nLitters[2].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("nLittersR");
                nn.InnerText = nLitters[3].ToString();
                n.AppendChild(nn);


                nn = doc.CreateElement("LitterSizeS");
                nn.InnerText = litSize[0].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("LitterSizeE");
                nn.InnerText = litSize[1].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("LitterSizeI");
                nn.InnerText = litSize[2].ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("LitterSizeR");
                nn.InnerText = litSize[3].ToString();
                n.AppendChild(nn);


                nn = doc.CreateElement("K");
                nn.InnerText = K.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("MaintainK");
                nn.InnerText = maintainK.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("KDay");
                nn.InnerText = KDay.ToString();
                n.AppendChild(nn);


                n = doc.CreateElement("Spatial");
                nScene.AppendChild(n);

                nn = doc.CreateElement("useSpatial");
                nn.InnerText = useSpatial.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("gridXmin");
                nn.InnerText = gridXmin.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("gridXmax");
                nn.InnerText = gridXmax.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("gridYmin");
                nn.InnerText = gridYmin.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("gridYmax");
                nn.InnerText = gridYmax.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("gridSeed");
                nn.InnerText = gridSeed.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("gridXseed");
                nn.InnerText = gridXseed.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("gridYseed");
                nn.InnerText = gridYseed.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("moveRandom");
                nn.InnerText = moveRandom.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("moveWhen");
                nn.InnerText = moveWhen.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("moveDist");
                nn.InnerText = moveDist.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("moveRules");
                nn.InnerText = moveRules.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("moveXrule");
                nn.InnerText = moveXrule.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("moveYrule");
                nn.InnerText = moveYrule.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("gridBoundaryReflects");
                nn.InnerText = gridBoundaryReflects.ToString();
                n.AppendChild(nn);

                nn = doc.CreateElement("gridBoundaryAbsorbs");
                nn.InnerText = gridBoundaryAbsorbs.ToString();
                n.AppendChild(nn);

//                doc.Save(filename);


                // also now save a file listing all input values
                string fin = filename.Replace(".xml", "_" + SceneName + ".inp");
//                filename = filename.Replace("xml", "inp");

                StreamWriter objWriter;
                objWriter = new StreamWriter(fin);

                objWriter.WriteLine("Outbreak version: " + Outbreak2.O2version);
                objWriter.WriteLine("Project Name: " + mOP.OName);
                if (mOP.DzTag.Trim() != "") objWriter.WriteLine("Disease label: " + mOP.DzTag);
                if (mOP.Description.Trim() != "") objWriter.WriteLine("Description: " + mOP.Description);
                objWriter.WriteLine();

                objWriter.WriteLine("Scenario Name: " + SceneName);
                if (SceneNotes.Trim() != "") objWriter.WriteLine("Scenario Notes: " + SceneNotes);
                objWriter.WriteLine();

                objWriter.WriteLine(nRuns.ToString() + " iterations over " + nYears.ToString() + " years of " + nDays.ToString() + " days");
                objWriter.WriteLine();

                objWriter.WriteLine("Disease parameters");

                objWriter.WriteLine("  P input section notes: " + PNotes);

                objWriter.WriteLine("  Probability Permanent P (immune from birth) = " + prPermanentP.ToString());
                objWriter.WriteLine("  Days Pre-susceptible = " + DaysP.ToString());
                if (MaternalR)
                {
                    objWriter.WriteLine("  Days with Maternally conferred immunity = " + DaysMaternalR.ToString());
                }
                else
                {
                    objWriter.WriteLine("  No Maternally conferred immunity");
                }
                objWriter.WriteLine("  Probability of transmission from I dam to newborn = " + prMaternalTransmission.ToString());

                objWriter.WriteLine();
                objWriter.WriteLine("  S input section notes: " + SNotes);

                if (usePropEncounter)
                {
                    objWriter.WriteLine("  Proportion of the population encountered by each I daily = " + prPopEncounter.ToString());
                }
                if (useFixedNEncounter)
                {
                    objWriter.WriteLine("  Number of individuals encountered by each I daily = " + NEncounter.ToString());
                }
                if (useDistanceEncounter)
                {
                    objWriter.WriteLine("  Transmission with each I encountering individuals with probability = " + DistanceEncounterFunc.ToString());
                }
                objWriter.WriteLine("  Upon encounter with an I, transmission occurs with probability = " + prTransmission.ToString());
                objWriter.WriteLine("  Probability of encountering an outside (environmental) disease source = " + prOutsideEncounter.ToString());
                objWriter.WriteLine("  Upon encounter with an outside source, transmission occurs with probability = " + prOutsideTransmission.ToString());

                objWriter.WriteLine();
                objWriter.WriteLine("  E input section notes: " + ENotes);

                objWriter.WriteLine("  Days E (incubation period) = " + DaysE.ToString());

                objWriter.WriteLine();
                objWriter.WriteLine("  I input section notes: " + INotes);
                objWriter.WriteLine("  Probability permanent I = " + prPermanentI.ToString());
                objWriter.WriteLine("  Days Infectious = " + DaysI.ToString());
                objWriter.WriteLine("  Probability of recovery with Resistance = " + prRecovery.ToString());
                objWriter.WriteLine("  Probability of recovery with return to Susceptibility = " + prReSusceptible.ToString());
                objWriter.WriteLine("  Probability of death = " + prDeath.ToString());

                objWriter.WriteLine();
                objWriter.WriteLine("  R input section notes: " + RNotes);
                objWriter.WriteLine("  Probability permanent Resistance = " + prPermanentR.ToString());
                objWriter.WriteLine("  Days Resistant = " + DaysR.ToString());

                objWriter.WriteLine();
                if (vaccNow || useVaccInterval || useVaccPrev) {
                    objWriter.WriteLine("Vaccinations");
                    objWriter.WriteLine("  V input section notes: " + VNotes);
                    if (vaccNow) objWriter.WriteLine("  Vaccinate at start");
                    if (useVaccInterval) objWriter.WriteLine("  Vaccinate every " + vaccDays.ToString() + " days, starting on day " + vaccDaysStart.ToString());
                    if (useVaccPrev) objWriter.WriteLine("  Vaccinate when: " + vaccPrev.ToString());

                    objWriter.WriteLine();
                    objWriter.WriteLine("  Proportion Age 0 vaccinated = " + vaccAge0.ToString());
                    objWriter.WriteLine("  Proportion SubAdults vaccinated = " + vaccAgeSA.ToString());
                    objWriter.WriteLine("  Proportion Adults vaccinated = " + vaccAgeAd.ToString());

                    objWriter.WriteLine();
                    objWriter.WriteLine("  Efficacy = " + vaccEfficacy.ToString());
                    objWriter.WriteLine("  Duration of protection = " + vaccDuration.ToString());
                }
                else objWriter.WriteLine("No Vaccination");

                objWriter.WriteLine();
                if (cullNow || useCullInterval || useCullPrev)
                {
                    objWriter.WriteLine("Management via Removals");
                    objWriter.WriteLine("  Removales input section notes: " + CullNotes);
                    if (cullNow) objWriter.WriteLine("  Remove animals at start");
                    if (useCullInterval) objWriter.WriteLine("  Remove animals every " + cullDays.ToString() + " days, starting on day " + cullDaysStart.ToString());
                    if (useCullPrev) objWriter.WriteLine("  Remove animals when: " + cullPrev.ToString());

                    objWriter.WriteLine();
                    objWriter.WriteLine("  Proportion Age 0 removed = " + cullAge0.ToString());
                    objWriter.WriteLine("  Proportion SubAdults removed = " + cullAgeSA.ToString());
                    objWriter.WriteLine("  Proportion Adults removed = " + cullAgeAd.ToString());
                }
                else objWriter.WriteLine("No Removals");

                objWriter.WriteLine();
                objWriter.WriteLine("Initial population, N = " + initN.ToString());
                objWriter.WriteLine("  Number of Juveniles (S, E, I, R, V): " + initStates[0, 0].ToString() + "; " + initStates[0, 1].ToString() + "; " + initStates[0, 2].ToString() + "; " + initStates[0, 3].ToString() + "; " + initStates[0, 4].ToString());
                objWriter.WriteLine("  Number of SubAdults:                 " + initStates[1, 0].ToString() + "; " + initStates[1, 1].ToString() + "; " + initStates[1, 2].ToString() + "; " + initStates[1, 3].ToString() + "; " + initStates[1, 4].ToString());
                objWriter.WriteLine("  Number of Adult Males:               " + initStates[2, 0].ToString() + "; " + initStates[2, 1].ToString() + "; " + initStates[2, 2].ToString() + "; " + initStates[2, 3].ToString() + "; " + initStates[2, 4].ToString());
                objWriter.WriteLine("  Number of Adult Females:             " + initStates[3, 0].ToString() + "; " + initStates[3, 1].ToString() + "; " + initStates[3, 2].ToString() + "; " + initStates[3, 3].ToString() + "; " + initStates[3, 4].ToString());
                objWriter.WriteLine("  Juveniles defined as individuals < " + juvDays.ToString() + " days");
                objWriter.WriteLine("  Subadults defined as individuals >= " + juvDays.ToString() + " days and < "+ SADays.ToString() + " days");

                objWriter.WriteLine();
                if (doDemog)
                {
                    objWriter.WriteLine("Demography");
                    objWriter.WriteLine("  Demography input section notes: " + DemogNotes);
                    objWriter.WriteLine("  Breeding season: " + breedDays.ToString());
                    objWriter.WriteLine("  Breeding age in days: " + brAgeDays.ToString());
                    objWriter.WriteLine("  Maximum breeding age (years): " + brMaxAge.ToString());
                    if(enterStageMort)
                        objWriter.Write("  Juvenile Stage Mortality (S, E, I, R): ");
                    else
                        objWriter.Write("  Juvenile Annual Mortality (S, E, I, R): ");
                    objWriter.WriteLine(Age0Mort[0].ToString() + "; " + Age0Mort[1].ToString() + "; " + Age0Mort[2].ToString() + "; " + Age0Mort[3].ToString());
                    if(enterStageMort)
                        objWriter.Write("  SubAdult Stage Mortality:          ");
                    else
                        objWriter.Write("  SubAdult Annual Mortality:          ");
                    objWriter.WriteLine(SAMort[0].ToString() + "; " + SAMort[1].ToString() + "; " + SAMort[2].ToString() + "; " + SAMort[3].ToString());
                    objWriter.WriteLine("  Adult Male Annual Mortality:        " + AdultMMort[0].ToString() + "; " + AdultMMort[1].ToString() + "; " + AdultMMort[2].ToString() + "; " + AdultMMort[3].ToString());
                    objWriter.WriteLine("  Adult Female Annual Mortality:      " + AdultFMort[0].ToString() + "; " + AdultFMort[1].ToString() + "; " + AdultFMort[2].ToString() + "; " + AdultFMort[3].ToString());
                    objWriter.WriteLine("  Probability of breeding:     " + prBreed[0].ToString() + "; " + prBreed[1].ToString() + "; " + prBreed[2].ToString() + "; " + prBreed[3].ToString());
                    objWriter.WriteLine("  Number of litters:           " + nLitters[0].ToString() + "; " + nLitters[1].ToString() + "; " + nLitters[2].ToString() + "; " + nLitters[3].ToString());
                    objWriter.WriteLine("  Litter size:                 " + litSize[0].ToString() + "; " + litSize[1].ToString() + "; " + litSize[2].ToString() + "; " + litSize[3].ToString());

                    objWriter.WriteLine("  Carrying capacity = " + K.ToString());
                    if (maintainK) objWriter.WriteLine("    Maintain K throughout year");
                    else objWriter.WriteLine("    Impose K once a year on day: " + KDay.ToString());
                }
                else
                {
                    objWriter.WriteLine("Demography was not simulated within Outbreak");
                }

                objWriter.WriteLine();
                objWriter.WriteLine("Spatial settings");
                objWriter.WriteLine("  Spatial input section notes: " + SpatialNotes);
                objWriter.WriteLine("  Grid size: xmin = " + gridXmin.ToString() + "; xmax = " + gridXmax.ToString() + "; ymin = " + gridYmin.ToString() + "; ymax = " + gridYmax.ToString());
                if (gridSeed) objWriter.WriteLine("  Seed individuals randomly");
                else
                {
                    objWriter.WriteLine("  Seed individuals according to rules");
                    objWriter.WriteLine("    X-rule: " + gridXseed.ToString());
                    objWriter.WriteLine("    Y-rule: " + gridYseed.ToString());
                }
                if (moveRandom || moveRules)
                {
                    objWriter.WriteLine("  Move when: " + moveWhen.ToString());
                    if (moveRandom) objWriter.WriteLine("  Move randomly, within distance range of " + moveDist.ToString());
                    else if (moveRules) 
                    {
                        objWriter.WriteLine("  Move according to rules");
                        objWriter.WriteLine("    X-rule: " + moveXrule.ToString());
                        objWriter.WriteLine("    Y-rule: " + moveYrule.ToString());
                    }
                    if (gridBoundaryReflects) objWriter.WriteLine("  Grid boundary reflects");
                    else if (gridBoundaryAbsorbs) objWriter.WriteLine("  Grid boundary absorbs");
                    else objWriter.WriteLine("  No grid boundary");
                }
                else objWriter.WriteLine("  No movement");

                objWriter.Close();
            }
            catch
            {
                MessageBox.Show("Could not save " + filename);
                return false; // this can happen if the user doesn't have admin rights to save the file to the folder.
            }

            return true;
        }

        public bool readOPF(string filename)
        {
            string sLine = "";
            char[] splits = { '=', ':', ';', ','}; // note: this won't work in EU
            string[] ss;
            string sval;

            try
            {
                StreamReader objReader;
                objReader = new StreamReader(filename);

                sLine = objReader.ReadLine();
                if (!sLine.Contains("OUTBREAK")) return false;
                if (sLine.StartsWith("\"OUTBREAK")) sLine = objReader.ReadLine(); // extra header in OPF, not in OIS

                sLine = objReader.ReadLine(); // header
                sLine = objReader.ReadLine(); // breeding window
                ss = sLine.Split(splits);
                breedDays = translateIntObject("=IUNIFORM(" + ss[1] + ";" + ss[2] + ")");

                sLine = objReader.ReadLine(); // breeding age
                ss = sLine.Split(splits);
                brAge = Convert.ToInt32(ss[1].Trim('"'));
                brAgeDays = brAge * 365; // was wrong before 4 Nov 2015
                brMaxAge = Convert.ToInt32(ss[2].Trim('"'));

                juvDays = 365;
                SADays = brAgeDays;

                sLine = objReader.ReadLine(); // mortality
                sLine = objReader.ReadLine(); // fecundity

                sLine = objReader.ReadLine(); // N
                sval = sLine.Substring(1 + sLine.LastIndexOf(','));
                initN = Convert.ToInt32(sval.Trim('"'));
                useNcount = true;

                sLine = objReader.ReadLine();
                ss = sLine.Split(splits);
                int i = 1;
                initStates[0, 0] = Convert.ToInt32(ss[i++]);
                initStates[0, 1] = Convert.ToInt32(ss[i++]);
                initStates[0, 2] = Convert.ToInt32(ss[i++]);
                initStates[0, 3] = Convert.ToInt32(ss[i++]);
                initStates[0, 4] = 0;
                initStates[1, 0] = Convert.ToInt32(ss[i++]);
                initStates[1, 1] = Convert.ToInt32(ss[i++]);
                initStates[1, 2] = Convert.ToInt32(ss[i++]);
                initStates[1, 3] = Convert.ToInt32(ss[i++]);
                initStates[1, 4] = 0;
                initStates[2, 0] = Convert.ToInt32(ss[i++]);
                initStates[2, 1] = Convert.ToInt32(ss[i++]);
                initStates[2, 2] = Convert.ToInt32(ss[i++]);
                initStates[2, 3] = Convert.ToInt32(ss[i++]);
                initStates[2, 4] = 0;
                initStates[3, 0] = Convert.ToInt32(ss[i++]);
                initStates[3, 1] = Convert.ToInt32(ss[i++]);
                initStates[3, 2] = Convert.ToInt32(ss[i++]);
                initStates[3, 3] = Convert.ToInt32(ss[i++]);
                initStates[3, 4] = 0;

                sLine = objReader.ReadLine(); // K
                ss = sLine.Split(splits);
                K = Convert.ToInt32(ss[1].Trim('\"'));
                sLine = objReader.ReadLine(); // strategy
                ss = sLine.Split(splits);
                maintainK = (ss[1] == "0");
                KDay = Convert.ToInt32(ss[2].Trim('\"'));

                sLine = objReader.ReadLine(); // SEIR Label

                sLine = objReader.ReadLine(); // P
                ss = sLine.Split(splits);
                DaysP = translateIntObject("=IUNIFORM(" + ss[1] + ";" + ss[2] + ")");
                prPermanentP = translateObject(ss[3]);

                sLine = objReader.ReadLine(); // S1
                ss = sLine.Split(splits);
                if (ss[1] == "0") useFixedNEncounter = false;
                else useFixedNEncounter = true;
                usePropEncounter = !useFixedNEncounter;
                useDistanceEncounter = false;
                prPopEncounter = translateObject(ss[2]);
                NEncounter = translateIntObject(ss[3]);

                sLine = objReader.ReadLine(); // S2
                ss = sLine.Split(splits);
                prTransmission = translateObject(ss[1]);
                prOutsideEncounter = translateObject(ss[2]);
                prOutsideTransmission = translateObject(ss[3]);

                sLine = objReader.ReadLine(); // E
                ss = sLine.Split(splits);
                DaysE = translateIntObject("=IUNIFORM(" + ss[1] + ";" + ss[2] + ")");

                sLine = objReader.ReadLine(); // I1
                ss = sLine.Split(splits);
                prPermanentI = translateObject(ss[1]);
                DaysI = translateIntObject("=IUNIFORM(" + ss[2] + ";" + ss[3] + ")");

                sLine = objReader.ReadLine(); // I2
                ss = sLine.Split(splits);
                //                prDeath = translateObject(ss[1]);
                prRecovery = translateObject(ss[2]);
                prReSusceptible = translateObject(ss[3]);

                sLine = objReader.ReadLine(); // R
                ss = sLine.Split(splits);
                prPermanentR = translateObject(ss[1]);

                DaysR = translateIntObject("=IUNIFORM(" + ss[2] + ";" + ss[3] + ")");

                sLine = objReader.ReadLine(); // Indirect Label
                sLine = objReader.ReadLine(); // Indirect mortality
                ss = sLine.Split(splits);
                i = 2;
                for (int j = 0; j < 4; j++) Age0Mort[j] = translateObject(ss[i++]);
                for (int j = 0; j < 4; j++) SAMort[j] = translateObject(ss[i++]);
                for (int j = 0; j < 4; j++) AdultMMort[j] = translateObject(ss[i++]);
                for (int j = 0; j < 4; j++) AdultFMort[j] = translateObject(ss[i++]);

                sLine = objReader.ReadLine(); // Indirect fecundity
                ss = sLine.Split(splits);
                i = 2;
                for (int j = 0; j < 4; j++) prBreed[j] = translateObject(ss[i++]);
                for (int j = 0; j < 4; j++) nLitters[j] = translateIntObject(ss[i++]);
                for (int j = 0; j < 4; j++) litSize[j] = translateIntObject(ss[i++]);

                sLine = objReader.ReadLine(); // Vacc Label
                sLine = objReader.ReadLine(); // Vacc option
                ss = sLine.Split(splits);
                if (ss[1] == "1") vaccNow = true;
                else vaccNow = false;
                vaccDaysStart = vaccDays = translateIntObject(ss[2]);
                if (Convert.ToInt32(ss[2]) > 0) useVaccInterval = true;
                else useVaccInterval = false;
                vaccPrev = translateObject(ss[3]);
                if (Convert.ToDouble(ss[3]) > 0) useVaccPrev = true;
                else useVaccPrev = false;
                sLine = objReader.ReadLine(); // Vacc age classes
                ss = sLine.Split(splits);
                vaccAge0 = translateObject(ss[1]);
                vaccAgeSA = translateObject(ss[2]);
                vaccAgeAd = translateObject(ss[3]);
                sLine = objReader.ReadLine(); // Vacc effectiveness
                ss = sLine.Split(splits);
                vaccEfficacy = translateObject(ss[1]);
                vaccDuration = translateIntObject(ss[2]);

                sLine = objReader.ReadLine(); // Culling Label
                sLine = objReader.ReadLine(); // Culling option
                ss = sLine.Split(splits);
                if (ss[1] == "1") cullNow = true;
                else cullNow = false;
                cullDaysStart = cullDays = translateIntObject(ss[2]);
                if (Convert.ToInt32(ss[2]) > 0) useCullInterval = true;
                else useCullInterval = false;
                cullPrev = translateObject(ss[3]);
                if (Convert.ToDouble(ss[3]) > 0) useCullPrev = true;
                else useCullPrev = false;
                sLine = objReader.ReadLine(); // Cull rate specified once for all age classes
                ss = sLine.Split(splits);
                cullAge0 = translateObject(ss[1]);
                cullAgeSA = translateObject(ss[1]);
                cullAgeAd = translateObject(ss[1]);
            }
            catch
            {
                return false;
            }

            return true;
        }

        public bool readInfect(string filename)
        {
            try
            {
                XmlDocument doc = new XmlDocument();

                // will throw an exception if file not found
                doc.Load(filename);

                if (!doc.DocumentElement.Name.Contains("InfectorProject"))
                    return false;

                //get a document navigator started at the top document
                XPathNavigator nav = doc.CreateNavigator();
                nav.MoveToFirstChild();

                XPathNodeIterator iter = nav.Select("ProbTransmitMom");
                if (iter.MoveNext())
                    prMaternalTransmission = translateObject(iter.Current.Value);

                string spFunc = "";
                iter = nav.Select("ProbTransmitInsideGroup");
                if (iter.MoveNext())
                {
                    string inside = iter.Current.Value;
                    if(Convert.ToDouble(inside) != 0.0) spFunc += "(" + inside + ")*SAME";
                }

                iter = nav.Select("ProbTransmitOutsideGroup");
                if (iter.MoveNext())
                {
                    string outside = iter.Current.Value;
                    if (Convert.ToDouble(outside) != 0.0) spFunc += "+(" + outside + ")*CONTACT";
                }
                if (spFunc.Length == 0)
                {
                    DistanceEncounterFunc = 0.0;
                    useDistanceEncounter = false;
                }
                else 
                { 
                    DistanceEncounterFunc = translateObject("=(" + spFunc + ")/(" + prTransmission.ToString() + ")");
                    useDistanceEncounter = true;
                }
            }
            catch
            {
                return false;
            }

            return true;
        }


        public bool readXMLscenario(XmlDocument doc, XPathNavigator nav)
        {
            XPathNodeIterator iter;

            try
            {
                iter = nav.Select("SceneName");
                if (iter.MoveNext())
                    SceneName = iter.Current.Value;

                iter = nav.Select("Iterations");
                if (iter.MoveNext())
                    nRuns = Convert.ToInt32(iter.Current.Value);

                iter = nav.Select("Years");
                if (iter.MoveNext())
                    nYears = Convert.ToInt32(iter.Current.Value);

                iter = nav.Select("Days");
                if (iter.MoveNext())
                    nDays = Convert.ToInt32(iter.Current.Value);

                iter = nav.Select("OutputFiles/outYearly");
                if (iter.MoveNext())
                    outYearly = Convert.ToBoolean(iter.Current.Value);

                iter = nav.Select("OutputFiles/outDaily");
                if (iter.MoveNext())
                    outDaily = Convert.ToBoolean(iter.Current.Value);

                iter = nav.Select("OutputFiles/outEpiRates");
                if (iter.MoveNext())
                    outEpiRates = Convert.ToBoolean(iter.Current.Value);

                iter = nav.Select("OutputFiles/outIndList");
                if (iter.MoveNext())
                    outIndList = Convert.ToBoolean(iter.Current.Value);

                iter = nav.Select("Notes/SceneNotes");
                if (iter.MoveNext())
                    SceneNotes = iter.Current.Value;

                iter = nav.Select("Notes/PNotes");
                if (iter.MoveNext())
                    PNotes = iter.Current.Value;

                iter = nav.Select("Notes/SNotes");
                if (iter.MoveNext())
                    SNotes = iter.Current.Value;

                iter = nav.Select("Notes/ENotes");
                if (iter.MoveNext())
                    ENotes = iter.Current.Value;

                iter = nav.Select("Notes/INotes");
                if (iter.MoveNext())
                    INotes = iter.Current.Value;

                iter = nav.Select("Notes/RNotes");
                if (iter.MoveNext())
                    RNotes = iter.Current.Value;

                iter = nav.Select("Notes/VNotes");
                if (iter.MoveNext())
                    VNotes = iter.Current.Value;

                iter = nav.Select("Notes/CullNotes");
                if (iter.MoveNext())
                    CullNotes = iter.Current.Value;

                iter = nav.Select("Notes/InitNotes");
                if (iter.MoveNext())
                    InitNotes = iter.Current.Value;

                iter = nav.Select("Notes/DemogNotes");
                if (iter.MoveNext())
                    DemogNotes = iter.Current.Value;

                iter = nav.Select("Notes/SpatialNotes");
                if (iter.MoveNext())
                    SpatialNotes = iter.Current.Value;


                iter = nav.Select("Pre-susceptible/probPermanentP");
                if (iter.MoveNext())
                    prPermanentP = translateObject(iter.Current.Value);

                object minDays = 0;
                object maxDays = 1;

                iter = nav.Select("Pre-susceptible/DaysP");
                if (iter.MoveNext())
                    DaysP = translateIntObject(iter.Current.Value);
                else
                {
                    iter = nav.Select("Pre-susceptible/minDaysP");
                    if (iter.MoveNext())
                        minDays = translateIntObject(iter.Current.Value);

                    iter = nav.Select("Pre-susceptible/maxDaysP");
                    if (iter.MoveNext())
                        maxDays = translateIntObject(iter.Current.Value);

                    DaysP = translateIntObject("=IUNIFORM(" + minDays.ToString().Trim('=') + ";" + maxDays.ToString().Trim('=') + ")");
                }

                iter = nav.Select("Pre-susceptible/MaternalR");
                if (iter.MoveNext())
                    MaternalR = Convert.ToBoolean(iter.Current.Value);

                iter = nav.Select("Pre-susceptible/DaysMaternalR");
                if (iter.MoveNext())
                    DaysMaternalR = translateIntObject(iter.Current.Value);

                else
                {
                    iter = nav.Select("Pre-susceptible/minDaysMaternalR");
                    if (iter.MoveNext())
                        minDays = translateIntObject(iter.Current.Value);

                    iter = nav.Select("Pre-susceptible/maxDaysMaternalR");
                    if (iter.MoveNext())
                        maxDays = translateIntObject(iter.Current.Value);

                    DaysMaternalR = translateIntObject("=IUNIFORM(" + minDays.ToString().Trim('=') + ";" + maxDays.ToString().Trim('=') + ")");
                }

                iter = nav.Select("Susceptible/usePropEncounter");
                if (iter.MoveNext())
                    usePropEncounter = Convert.ToBoolean(iter.Current.Value);

                iter = nav.Select("Susceptible/propPopEncounter");
                if (iter.MoveNext())
                    prPopEncounter = translateObject(iter.Current.Value);

                iter = nav.Select("Susceptible/useFixedNEncounter");
                if (iter.MoveNext())
                    useFixedNEncounter = Convert.ToBoolean(iter.Current.Value);

                iter = nav.Select("Susceptible/NEncounter");
                if (iter.MoveNext())
                    NEncounter = translateObject(iter.Current.Value);

                iter = nav.Select("Susceptible/useDistanceEncounter");
                if (iter.MoveNext())
                    useDistanceEncounter = Convert.ToBoolean(iter.Current.Value);
                useSpatial = useDistanceEncounter;

                iter = nav.Select("Susceptible/DistanceEncounterFunc");
                if (iter.MoveNext())
                    DistanceEncounterFunc = translateObject(iter.Current.Value);

                iter = nav.Select("Susceptible/probTransmission");
                if (iter.MoveNext())
                    prTransmission = translateObject(iter.Current.Value);

                iter = nav.Select("Susceptible/probOutsideEncounter");
                if (iter.MoveNext())
                    prOutsideEncounter = translateObject(iter.Current.Value);

                iter = nav.Select("Susceptible/probOutsideTransmission");
                if (iter.MoveNext())
                    prOutsideTransmission = translateObject(iter.Current.Value);

                iter = nav.Select("Susceptible/probMaternalTransmission");
                if (iter.MoveNext())
                    prMaternalTransmission = translateObject(iter.Current.Value);


                iter = nav.Select("Exposed/DaysE");
                if (iter.MoveNext())
                    DaysE = translateIntObject(iter.Current.Value);

                else
                {
                    iter = nav.Select("Exposed/minDaysE");
                    if (iter.MoveNext())
                        minDays = translateIntObject(iter.Current.Value);

                    iter = nav.Select("Exposed/maxDaysE");
                    if (iter.MoveNext())
                        maxDays = translateIntObject(iter.Current.Value);

                    DaysE = translateIntObject("=IUNIFORM(" + minDays.ToString().Trim('=') + ";" + maxDays.ToString().Trim('=') + ")");
                }


                iter = nav.Select("Infectious/probPermanentI");
                if (iter.MoveNext())
                    prPermanentI = translateObject(iter.Current.Value);

                iter = nav.Select("Infectious/DaysI");
                if (iter.MoveNext())
                    DaysI = translateIntObject(iter.Current.Value);

                else
                {
                    iter = nav.Select("Infectious/minDaysI");
                    if (iter.MoveNext())
                        minDays = translateIntObject(iter.Current.Value);

                    iter = nav.Select("Infectious/maxDaysI");
                    if (iter.MoveNext())
                        maxDays = translateIntObject(iter.Current.Value);

                    DaysI = translateIntObject("=IUNIFORM(" + minDays.ToString().Trim('=') + ";" + maxDays.ToString().Trim('=') + ")");
                }

                iter = nav.Select("Infectious/probRecovery");
                if (iter.MoveNext())
                    prRecovery = translateObject(iter.Current.Value);

                iter = nav.Select("Infectious/probReSusceptible");
                if (iter.MoveNext())
                    prReSusceptible = translateObject(iter.Current.Value);

                //iter = nav.Select("Infectious/probDeath");
                //if (iter.MoveNext())
                //    prDeath = Convert.ToDouble(iter.Current.Value);


                iter = nav.Select("Resistant/probPermanentR");
                if (iter.MoveNext())
                    prPermanentR = translateObject(iter.Current.Value);

                iter = nav.Select("Resistant/DaysR");
                if (iter.MoveNext())
                    DaysR = translateIntObject(iter.Current.Value);

                else
                {
                    iter = nav.Select("Resistant/minDaysR");
                    if (iter.MoveNext())
                        minDays = translateIntObject(iter.Current.Value);

                    iter = nav.Select("Resistant/maxDaysR");
                    if (iter.MoveNext())
                        maxDays = translateIntObject(iter.Current.Value);

                    DaysR = translateIntObject("=IUNIFORM(" + minDays.ToString().Trim('=') + ";" + maxDays.ToString().Trim('=') + ")");
                }

                iter = nav.Select("Vaccinate");
                if (iter.MoveNext())
                {
                    XPathNodeIterator iter2 = iter.Current.Clone().Select("VaccNow");
                    if (iter2.MoveNext())
                        vaccNow = Convert.ToBoolean(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("VaccInterval");
                    if (iter2.MoveNext())
                        useVaccInterval = Convert.ToBoolean(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("VaccDays");
                    if (iter2.MoveNext())
                        vaccDays = translateIntObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("VaccDaysStart");
                    if (iter2.MoveNext())
                        vaccDaysStart = translateIntObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("VaccCriteria");
                    if (iter2.MoveNext())
                        useVaccPrev = Convert.ToBoolean(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("VaccPrev");
                    if (iter2.MoveNext())
                        vaccPrev = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("VaccAge0");
                    if (iter2.MoveNext())
                        vaccAge0 = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("VaccAgeSa");
                    if (iter2.MoveNext())
                        vaccAgeSA = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("VaccAgeAd");
                    if (iter2.MoveNext())
                        vaccAgeAd = Convert.ToDouble(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("VaccEfficacy");
                    if (iter2.MoveNext())
                        vaccEfficacy = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("VaccDuration");
                    if (iter2.MoveNext())
                        vaccDuration = translateIntObject(iter2.Current.Value);
                }


                iter = nav.Select("Cull");
                if (iter.MoveNext())
                {
                    XPathNodeIterator iter2 = iter.Current.Clone().Select("CullNow");
                    if (iter2.MoveNext())
                        cullNow = Convert.ToBoolean(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("CullInterval");
                    if (iter2.MoveNext())
                        useCullInterval = Convert.ToBoolean(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("CullDays");
                    if (iter2.MoveNext())
                        cullDays = translateIntObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("CullDaysStart");
                    if (iter2.MoveNext())
                        cullDaysStart = translateIntObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("CullCriteria");
                    if (iter2.MoveNext())
                        useCullPrev = Convert.ToBoolean(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("CullPrev");
                    if (iter2.MoveNext())
                        cullPrev = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("CullAge0");
                    if (iter2.MoveNext())
                        cullAge0 = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("CullAgeSa");
                    if (iter2.MoveNext())
                        cullAgeSA = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("CullAgeAd");
                    if (iter2.MoveNext())
                        cullAgeAd = Convert.ToDouble(iter2.Current.Value);
                }


                iter = nav.Select("InitialPopulation/InitN");
                if (iter.MoveNext())
                    initN = Convert.ToInt32(iter.Current.Value);

                iter = nav.Select("InitialPopulation/useNCount");
                if (iter.MoveNext())
                {
                    useNcount = Convert.ToBoolean(iter.Current.Value);
                }

                iter = nav.Select("InitialPopulation/Juveniles");
                if (iter.MoveNext())
                {
                    XPathNodeIterator iter2 = iter.Current.Clone().Select("S");
                    if (iter2.MoveNext())
                        initStates[0, 0] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("E");
                    if (iter2.MoveNext())
                        initStates[0, 1] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("I");
                    if (iter2.MoveNext())
                        initStates[0, 2] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("R");
                    if (iter2.MoveNext())
                        initStates[0, 3] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("V");
                    if (iter2.MoveNext())
                        initStates[0, 4] = Convert.ToInt32(iter2.Current.Value);
                }

                iter = nav.Select("InitialPopulation/Subadults");
                if (iter.MoveNext())
                {
                    XPathNodeIterator iter2 = iter.Current.Clone().Select("S");
                    if (iter2.MoveNext())
                        initStates[1, 0] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("E");
                    if (iter2.MoveNext())
                        initStates[1, 1] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("I");
                    if (iter2.MoveNext())
                        initStates[1, 2] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("R");
                    if (iter2.MoveNext())
                        initStates[1, 3] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("V");
                    if (iter2.MoveNext())
                        initStates[1, 4] = Convert.ToInt32(iter2.Current.Value);
                }

                iter = nav.Select("InitialPopulation/AdultMales");
                if (iter.MoveNext())
                {
                    XPathNodeIterator iter2 = iter.Current.Clone().Select("S");
                    if (iter2.MoveNext())
                        initStates[2, 0] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("E");
                    if (iter2.MoveNext())
                        initStates[2, 1] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("I");
                    if (iter2.MoveNext())
                        initStates[2, 2] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("R");
                    if (iter2.MoveNext())
                        initStates[2, 3] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("V");
                    if (iter2.MoveNext())
                        initStates[2, 4] = Convert.ToInt32(iter2.Current.Value);
                }

                iter = nav.Select("InitialPopulation/AdultFemales");
                if (iter.MoveNext())
                {
                    XPathNodeIterator iter2 = iter.Current.Clone().Select("S");
                    if (iter2.MoveNext())
                        initStates[3, 0] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("E");
                    if (iter2.MoveNext())
                        initStates[3, 1] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("I");
                    if (iter2.MoveNext())
                        initStates[3, 2] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("R");
                    if (iter2.MoveNext())
                        initStates[3, 3] = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("V");
                    if (iter2.MoveNext())
                        initStates[3, 4] = Convert.ToInt32(iter2.Current.Value);
                }

                bool oldversion = false;
                iter = nav.Select("InitialPopulation/JuvDays");
                if (iter.MoveNext())
                    juvDays = Convert.ToInt32(iter.Current.Value);

                iter = nav.Select("InitialPopulation/SADays");
                if (iter.MoveNext())
                    SADays = Convert.ToInt32(iter.Current.Value);
                else oldversion = true;

                iter = nav.Select("Demography");
                if (iter.MoveNext())
                {
                    XPathNodeIterator iter2 = iter.Current.Clone().Select("BreedDays");
                    if (iter2.MoveNext())
                        breedDays = translateIntObject(iter2.Current.Value);
                    else
                    {
                        iter2 = iter.Current.Clone().Select("BreedMinDays");
                        if (iter2.MoveNext())
                            minDays = Convert.ToInt32(iter2.Current.Value);
                        iter2 = iter.Current.Clone().Select("BreedMaxDays");
                        if (iter2.MoveNext())
                            maxDays = Convert.ToInt32(iter2.Current.Value);

                        breedDays = translateIntObject("=IUNIFORM(" + minDays.ToString().Trim('=') + ";" + maxDays.ToString().Trim('=') + ")");
                    }

                    iter2 = iter.Current.Clone().Select("BreedAgeDays");
                    if (iter2.MoveNext())
                    {
                        brAgeDays = Convert.ToInt32(iter2.Current.Value);
                        brAge = brAgeDays / nDays;

                        if (oldversion) SADays = brAgeDays;
                    }

                    iter2 = iter.Current.Clone().Select("BreedMaxAge");
                    if (iter2.MoveNext())
                        brMaxAge = Convert.ToInt32(iter2.Current.Value);

                    iter2 = iter.Current.Clone().Select("EnterStageMort");
                    if (iter2.MoveNext())
                        enterStageMort = Convert.ToBoolean(iter2.Current.Value);

                    iter2 = iter.Current.Clone().Select("Age0MortS");
                    if (iter2.MoveNext())
                        Age0Mort[0] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("Age0MortE");
                    if (iter2.MoveNext())
                        Age0Mort[1] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("Age0MortI");
                    if (iter2.MoveNext())
                        Age0Mort[2] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("Age0MortR");
                    if (iter2.MoveNext())
                        Age0Mort[3] = translateObject(iter2.Current.Value);

                    iter2 = iter.Current.Clone().Select("SAMortS");
                    if (iter2.MoveNext())
                        SAMort[0] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("SAMortE");
                    if (iter2.MoveNext())
                        SAMort[1] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("SAMortI");
                    if (iter2.MoveNext())
                        SAMort[2] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("SAMortR");
                    if (iter2.MoveNext())
                        SAMort[3] = translateObject(iter2.Current.Value);

                    iter2 = iter.Current.Clone().Select("AMMortS");
                    if (iter2.MoveNext())
                        AdultMMort[0] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("AMMortE");
                    if (iter2.MoveNext())
                        AdultMMort[1] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("AMMortI");
                    if (iter2.MoveNext())
                        AdultMMort[2] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("AMMortR");
                    if (iter2.MoveNext())
                        AdultMMort[3] = translateObject(iter2.Current.Value);

                    iter2 = iter.Current.Clone().Select("AFMortS");
                    if (iter2.MoveNext())
                        AdultFMort[0] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("AFMortE");
                    if (iter2.MoveNext())
                        AdultFMort[1] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("AFMortI");
                    if (iter2.MoveNext())
                        AdultFMort[2] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("AFMortR");
                    if (iter2.MoveNext())
                        AdultFMort[3] = translateObject(iter2.Current.Value);

                    iter2 = iter.Current.Clone().Select("prBreedS");
                    if (iter2.MoveNext())
                        prBreed[0] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("prBreedE");
                    if (iter2.MoveNext())
                        prBreed[1] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("prBreedI");
                    if (iter2.MoveNext())
                        prBreed[2] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("prBreedR");
                    if (iter2.MoveNext())
                        prBreed[3] = translateObject(iter2.Current.Value);

                    iter2 = iter.Current.Clone().Select("nLittersS");
                    if (iter2.MoveNext())
                        nLitters[0] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("nLittersE");
                    if (iter2.MoveNext())
                        nLitters[1] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("nLittersI");
                    if (iter2.MoveNext())
                        nLitters[2] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("nLittersR");
                    if (iter2.MoveNext())
                        nLitters[3] = translateObject(iter2.Current.Value);

                    iter2 = iter.Current.Clone().Select("LitterSizeS");
                    if (iter2.MoveNext())
                        litSize[0] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("LitterSizeE");
                    if (iter2.MoveNext())
                        litSize[1] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("LitterSizeI");
                    if (iter2.MoveNext())
                        litSize[2] = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("LitterSizeR");
                    if (iter2.MoveNext())
                        litSize[3] = translateObject(iter2.Current.Value);

                    iter2 = iter.Current.Clone().Select("K");
                    if (iter2.MoveNext())
                        K = translateIntObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("MaintainK");
                    if (iter2.MoveNext())
                        maintainK = Convert.ToBoolean(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("KDay");
                    if (iter2.MoveNext())
                        KDay = Convert.ToInt32(iter2.Current.Value);
                }

                iter = nav.Select("Spatial");
                if (iter.MoveNext())
                {
                    XPathNodeIterator iter2 = iter.Current.Clone().Select("useSpatial");
                    if (iter2.MoveNext())
                        useSpatial = Convert.ToBoolean(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("gridXmin");
                    if (iter2.MoveNext())
                        gridXmin = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("gridXmax");
                    if (iter2.MoveNext())
                        gridXmax = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("gridYmin");
                    if (iter2.MoveNext())
                        gridYmin = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("gridYmax");
                    if (iter2.MoveNext())
                        gridYmax = Convert.ToInt32(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("gridSeed");
                    if (iter2.MoveNext())
                        gridSeed = Convert.ToBoolean(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("gridXseed");
                    if (iter2.MoveNext())
                        gridXseed = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("gridYseed");
                    if (iter2.MoveNext())
                        gridYseed = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("moveRandom");
                    if (iter2.MoveNext())
                        moveRandom = Convert.ToBoolean(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("moveWhen");
                    if (iter2.MoveNext())
                        moveWhen = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("moveDistMin");
                    string moveDistMin = "";
                    if (iter2.MoveNext())
                        moveDistMin = iter2.Current.Value;
                    iter2 = iter.Current.Clone().Select("moveDistMax");
                    string moveDistMax = "";
                    if (iter2.MoveNext())
                        moveDistMax = iter2.Current.Value;
                    if (moveDistMin != "" && moveDistMax != "") moveDist = "=IUNIFORM((" + moveDistMin.Trim('=') + ");(" + moveDistMax.Trim('=') + "))";
                    else
                    {
                        iter2 = iter.Current.Clone().Select("moveDist");
                        if (iter2.MoveNext())
                            moveDist = translateObject(iter2.Current.Value);
                    }

                    iter2 = iter.Current.Clone().Select("moveRules");
                    if (iter2.MoveNext())
                        moveRules = Convert.ToBoolean(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("moveXrule");
                    if (iter2.MoveNext())
                        moveXrule = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("moveYrule");
                    if (iter2.MoveNext())
                        moveYrule = translateObject(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("gridBoundaryReflects");
                    if (iter2.MoveNext())
                        gridBoundaryReflects = Convert.ToBoolean(iter2.Current.Value);
                    iter2 = iter.Current.Clone().Select("gridBoundaryAbsorbs");
                    if (iter2.MoveNext())
                        gridBoundaryAbsorbs = Convert.ToBoolean(iter2.Current.Value);
                }
            }
            catch
            {
                return false;
            }

            return true;
        }

        public bool newfile = true;

        public bool readResults()
        {
            string sLine = "";
            string[] ss;

            OutFolder = mOP.ProjFolder + mOP.OName + "_Results";
            if (!Directory.Exists(OutFolder))
                Directory.CreateDirectory(OutFolder);

            runsDone = false;

            sYStates = new double[nYears + 1, 4, 6];
            ssYStates = new double[nYears + 1, 4, 6];
            sYStages = new double[nYears + 1, 4];
            ssYStages = new double[nYears + 1, 4];
            sYDz = new double[nYears + 1, 6];
            ssYDz = new double[nYears + 1, 6];

            sYN = new double[nYears + 1];
            ssYN = new double[nYears + 1];

            sYNew = new double[nYears + 1];
            ssYNew = new double[nYears + 1];
            sYNewDeaths = new double[nYears + 1];
            ssYNewDeaths = new double[nYears + 1];

            sDStates = new double[nYears + 1, nDays + 1, 4, 6];
            ssDStates = new double[nYears + 1, nDays + 1, 4, 6];
            sDStages = new double[nYears + 1, nDays + 1, 4];
            ssDStages = new double[nYears + 1, nDays + 1, 4];
            sDDz = new double[nYears + 1, nDays + 1, 6];
            ssDDz = new double[nYears + 1, nDays + 1, 6];

            sDNewCases = new double[nYears + 1, nDays + 1];
            ssDNewCases = new double[nYears + 1, nDays + 1];
            sDNewDeaths = new double[nYears + 1, nDays + 1];
            ssDNewDeaths = new double[nYears + 1, nDays + 1];

            yPrev = new double[nYears + 1, nRuns + 1];
            syPrev = new double[nYears + 1];

            ryN = new int[nRuns + 1, nYears + 1];

            StreamReader objReader = null;

            string filename = OutFolder + "\\" + SceneName + "_day_stats.txt";
            if (!File.Exists(filename) && scenendx == 0)
            {
                string filenameOld = OutFolder + "\\day_stats.txt";
                if (File.Exists(filenameOld)) filename = filenameOld;
            }

            if (File.Exists(filename))
            {
                try
                {
                    objReader = new StreamReader(filename);

                    sLine = objReader.ReadLine();
                    if (!sLine.StartsWith("Summary daily statistics")) return false;
                    sLine = objReader.ReadLine(); // header
                    newfile = sLine.Contains("SD(V)");
                    if (!newfile && (vaccNow || useVaccInterval || useVaccPrev))
                        MessageBox.Show("Results files are from a prior version and do not contain data on the number of V individuals. Run simulations again to get full results.");

                    for (int y = 1; y <= nYears; y++)
                    {
                        for (int d = 1; d <= nDays; d++)
                        {
                            sLine = objReader.ReadLine();
                            ss = sLine.Split(';');
                            if (y != Convert.ToInt32(ss[0]) || d != Convert.ToInt32(ss[1])) { return false; }
                            int i = 2;
                            sDStages[y, d, 0] = Convert.ToDouble(ss[i++]);
                            ssDStages[y, d, 0] = Convert.ToDouble(ss[i++]);
                            sDStages[y, d, 1] = Convert.ToDouble(ss[i++]);
                            ssDStages[y, d, 1] = Convert.ToDouble(ss[i++]);
                            sDStages[y, d, 2] = Convert.ToDouble(ss[i++]);
                            ssDStages[y, d, 2] = Convert.ToDouble(ss[i++]);
                            sDStages[y, d, 3] = Convert.ToDouble(ss[i++]);
                            ssDStages[y, d, 3] = Convert.ToDouble(ss[i++]);

                            sDDz[y, d, 0] = Convert.ToDouble(ss[i++]);
                            ssDDz[y, d, 0] = Convert.ToDouble(ss[i++]);
                            sDDz[y, d, 1] = Convert.ToDouble(ss[i++]);
                            ssDDz[y, d, 1] = Convert.ToDouble(ss[i++]);
                            sDDz[y, d, 2] = Convert.ToDouble(ss[i++]);
                            ssDDz[y, d, 2] = Convert.ToDouble(ss[i++]);
                            sDDz[y, d, 3] = Convert.ToDouble(ss[i++]);
                            ssDDz[y, d, 3] = Convert.ToDouble(ss[i++]);
                            sDDz[y, d, 4] = Convert.ToDouble(ss[i++]);
                            ssDDz[y, d, 4] = Convert.ToDouble(ss[i++]);
                            if (newfile)
                            {
                                sDDz[y, d, 5] = Convert.ToDouble(ss[i++]);
                                ssDDz[y, d, 5] = Convert.ToDouble(ss[i++]);
                            }

                            sDStates[y, d, 0, 0] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 0, 0] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 1, 0] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 1, 0] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 2, 0] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 2, 0] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 3, 0] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 3, 0] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 0, 1] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 0, 1] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 1, 1] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 1, 1] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 2, 1] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 2, 1] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 3, 1] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 3, 1] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 0, 2] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 0, 2] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 1, 2] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 1, 2] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 2, 2] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 2, 2] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 3, 2] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 3, 2] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 0, 3] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 0, 3] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 1, 3] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 1, 3] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 2, 3] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 2, 3] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 3, 3] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 3, 3] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 0, 4] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 0, 4] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 1, 4] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 1, 4] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 2, 4] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 2, 4] = Convert.ToDouble(ss[i++]);
                            sDStates[y, d, 3, 4] = Convert.ToDouble(ss[i++]);
                            ssDStates[y, d, 3, 4] = Convert.ToDouble(ss[i++]);

                            if (newfile)
                            {
                                sDStates[y, d, 0, 5] = Convert.ToDouble(ss[i++]);
                                ssDStates[y, d, 0, 5] = Convert.ToDouble(ss[i++]);
                                sDStates[y, d, 1, 5] = Convert.ToDouble(ss[i++]);
                                ssDStates[y, d, 1, 5] = Convert.ToDouble(ss[i++]);
                                sDStates[y, d, 2, 5] = Convert.ToDouble(ss[i++]);
                                ssDStates[y, d, 2, 5] = Convert.ToDouble(ss[i++]);
                                sDStates[y, d, 3, 5] = Convert.ToDouble(ss[i++]);
                                ssDStates[y, d, 3, 5] = Convert.ToDouble(ss[i++]);
                            }

                            if (ss.Length > i)
                            {
                                sDNewCases[y, d] = Convert.ToDouble(ss[i++]);
                                ssDNewCases[y, d] = Convert.ToDouble(ss[i++]);
                            }
                            if (ss.Length > i)
                            {
                                sDNewDeaths[y, d] = Convert.ToDouble(ss[i++]);
                                ssDNewDeaths[y, d] = Convert.ToDouble(ss[i++]);
                            }
                        }
                    }
                    objReader.Close();
                }
                catch
                {
                    if (objReader != null) objReader.Close();
                    return false;
                }
            }
            else
            {
                return false;
            }

            filename = OutFolder + "\\" + SceneName + "_year_stats.txt";
            if (!File.Exists(filename) && scenendx == 0)
            {
                string filenameOld = OutFolder + "\\year_stats.txt";
                if (File.Exists(filenameOld)) filename = filenameOld;
            }

            if (File.Exists(filename))
            {
                try
                {
                    objReader = new StreamReader(filename);

                    sLine = objReader.ReadLine();
                    if (!sLine.StartsWith("Summary yearly statistics")) return false;
                    sLine = objReader.ReadLine(); // header
                    for (int y = 0; y <= nYears; y++)
                    {
                        sLine = objReader.ReadLine();
                        ss = sLine.Split(';');
                        int i = 0;
                        if (Convert.ToInt32(ss[i++]) != y) { return false; }
                        sYN[y] = Convert.ToDouble(ss[i++]);
                        ssYN[y] = Convert.ToDouble(ss[i++]);

                        sYStages[y, 0] = Convert.ToDouble(ss[i++]);
                        ssYStages[y, 0] = Convert.ToDouble(ss[i++]);
                        sYStages[y, 1] = Convert.ToDouble(ss[i++]);
                        ssYStages[y, 1] = Convert.ToDouble(ss[i++]);
                        sYStages[y, 2] = Convert.ToDouble(ss[i++]);
                        ssYStages[y, 2] = Convert.ToDouble(ss[i++]);
                        sYStages[y, 3] = Convert.ToDouble(ss[i++]);
                        ssYStages[y, 3] = Convert.ToDouble(ss[i++]);

                        sYDz[y, 0] = Convert.ToDouble(ss[i++]);
                        ssYDz[y, 0] = Convert.ToDouble(ss[i++]);
                        sYDz[y, 1] = Convert.ToDouble(ss[i++]);
                        ssYDz[y, 1] = Convert.ToDouble(ss[i++]);
                        sYDz[y, 2] = Convert.ToDouble(ss[i++]);
                        ssYDz[y, 2] = Convert.ToDouble(ss[i++]);
                        sYDz[y, 3] = Convert.ToDouble(ss[i++]);
                        ssYDz[y, 3] = Convert.ToDouble(ss[i++]);
                        sYDz[y, 4] = Convert.ToDouble(ss[i++]);
                        ssYDz[y, 4] = Convert.ToDouble(ss[i++]);
                        if (newfile)
                        {
                            sYDz[y, 5] = Convert.ToDouble(ss[i++]);
                            ssYDz[y, 5] = Convert.ToDouble(ss[i++]);
                        }

                        sYStates[y, 0, 0] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 0, 0] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 1, 0] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 1, 0] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 2, 0] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 2, 0] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 3, 0] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 3, 0] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 0, 1] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 0, 1] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 1, 1] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 1, 1] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 2, 1] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 2, 1] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 3, 1] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 3, 1] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 0, 2] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 0, 2] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 1, 2] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 1, 2] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 2, 2] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 2, 2] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 3, 2] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 3, 2] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 0, 3] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 0, 3] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 1, 3] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 1, 3] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 2, 3] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 2, 3] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 3, 3] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 3, 3] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 0, 4] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 0, 4] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 1, 4] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 1, 4] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 2, 4] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 2, 4] = Convert.ToDouble(ss[i++]);
                        sYStates[y, 3, 4] = Convert.ToDouble(ss[i++]);
                        ssYStates[y, 3, 4] = Convert.ToDouble(ss[i++]);
                        if (newfile)
                        {
                            sYStates[y, 0, 5] = Convert.ToDouble(ss[i++]);
                            ssYStates[y, 0, 5] = Convert.ToDouble(ss[i++]);
                            sYStates[y, 1, 5] = Convert.ToDouble(ss[i++]);
                            ssYStates[y, 1, 5] = Convert.ToDouble(ss[i++]);
                            sYStates[y, 2, 5] = Convert.ToDouble(ss[i++]);
                            ssYStates[y, 2, 5] = Convert.ToDouble(ss[i++]);
                            sYStates[y, 3, 5] = Convert.ToDouble(ss[i++]);
                            ssYStates[y, 3, 5] = Convert.ToDouble(ss[i++]);
                        }

                        if (ss.Length > i)
                        {
                            sYNew[y] = Convert.ToDouble(ss[i++]);
                            ssYNew[y] = Convert.ToDouble(ss[i++]);
                        }
                        if (ss.Length > i)
                        {
                            sYNewDeaths[y] = Convert.ToDouble(ss[i++]);
                            ssYNewDeaths[y] = Convert.ToDouble(ss[i++]);
                        }
                    }
                    objReader.Close();
                }
                catch
                {
                    if (objReader != null) objReader.Close();
                    return false;
                }
            }
            else
            {
                return false;
            }


            filename = OutFolder + "\\" + SceneName + "_prev_stats.txt";
            if (!File.Exists(filename) && scenendx == 0)
            {
                string filenameOld = OutFolder + "\\prev_stats.txt";
                if (File.Exists(filenameOld)) filename = filenameOld;
            }

            if (File.Exists(filename))
            {
                try
                {
                    objReader = new StreamReader(filename);

                    sLine = objReader.ReadLine();
                    if (!sLine.StartsWith("Prevalence")) return false;
                    for (int y = 0; y <= nYears; y++)
                    { 
                        sLine = objReader.ReadLine();
                        ss = sLine.Split(';');
//                        if (Convert.ToInt32(ss[0]) != y) { return false; }
                        syPrev[y] = Convert.ToDouble(ss[1]);
                    }

                    sLine = objReader.ReadLine();
                    sLine = objReader.ReadLine();
                    for (int r = 1; r <= nRuns; r++)
                    {
                        for(int y = 0; y <= nYears; y++) 
                        {
                            sLine = objReader.ReadLine();
                            ss = sLine.Split(';');
                            yPrev[y, r] = Convert.ToDouble(ss[2]);
                        }
                    }
                    sLine = objReader.ReadLine();
                    if (sLine != null && sLine.Trim() != "") return false;

                    objReader.Close();
                }
                catch
                {
                    if (objReader != null) objReader.Close();
                    return false;
                }
            }
            else
            {
                return false;
            }

            filename = OutFolder + "\\" + SceneName + "_ryN.txt";
            if (!File.Exists(filename) && scenendx == 0)
            {
                string filenameOld = OutFolder + "\\ryN.txt";
                if (File.Exists(filenameOld)) filename = filenameOld;
            }

            if (File.Exists(filename))
            {
                try
                {
                    objReader = new StreamReader(filename);

                    sLine = objReader.ReadLine();
                    if (!sLine.StartsWith("Population Size")) return false;

                    for (int r = 1; r <= nRuns; r++)
                    {
                        for (int y = 0; y <= nYears; y++)
                        {
                            sLine = objReader.ReadLine();
                            ss = sLine.Split(';');
                            ryN[r, y] = Convert.ToInt32(ss[2]); // note that r,y are reversed in ryN relative to prev
                        }
                    }
                    sLine = objReader.ReadLine();
                    if (sLine != null && sLine.Trim() != "") return false;

                    objReader.Close();
                }
                catch
                {
                    if (objReader != null) objReader.Close();
                    return false;
                }
            }
            //else
            //{
            //    return false;
            //}

            runsDone = true;

            return true;
        }


        public bool processInput()
        {
            prPermanentP = limitObject(prPermanentP, 0.0, 1.0);

            prPopEncounter = limitObject(prPopEncounter, 0.0, 1.0);
            NEncounter = limitObject(NEncounter, 0.0, 0.0);
            prTransmission = limitObject(prTransmission, 0.0, 1.0);
            prOutsideEncounter = limitObject(prOutsideEncounter, 0.0, 1.0);
            prOutsideTransmission = limitObject(prOutsideTransmission, 0.0, 1.0);
            prMaternalTransmission = limitObject(prMaternalTransmission, 0.0, 1.0);

            prPermanentI = limitObject(prPermanentI, 0.0, 1.0);
            prRecovery = limitObject(prRecovery, 0.0, 1.0);
            prReSusceptible = limitObject(prReSusceptible, 0.0, 1.0);
            if (prRecovery.GetType() == typeof(double) && prReSusceptible.GetType() == typeof(double))
                prDeath = (double)(1.0 - ((double)prRecovery + (double)prReSusceptible));
            else prDeath = translateObject("100 - (" + prRecovery.ToString() + "+" + prReSusceptible.ToString() + ")");

            prPermanentR = limitObject(prPermanentR, 0.0, 1.0);

            vaccDays = limitObject(vaccDays, 0, 0);
            vaccDaysStart = limitObject(vaccDaysStart, 0, 0);
            vaccPrev = limitObject(vaccPrev, 0.0, 1.0);
            vaccAge0 = limitObject(vaccAge0, 0.0, 1.0);
            vaccAgeSA = limitObject(vaccAgeSA, 0.0, 1.0);
            vaccAgeAd = limitObject(vaccAgeAd, 0.0, 1.0);
            vaccEfficacy = limitObject(vaccEfficacy, 0.0, 1.0);
            vaccDuration = limitObject(vaccDuration, 0, 0);

            cullDays = limitObject(cullDays, 0, 0);
            cullDaysStart = limitObject(cullDaysStart, 0, 0);
            cullPrev = limitObject(cullPrev, 0.0, 1.0);
            cullAge0 = limitObject(cullAge0, 0.0, 1.0);
            cullAgeSA = limitObject(cullAgeSA, 0.0, 1.0);
            cullAgeAd = limitObject(cullAgeAd, 0.0, 1.0);

            // demog variables
            nDays = limitInt(nDays, 1, 0);
            brAge = limitInt(brAge, 0, 0);
            brAgeDays = limitInt(brAgeDays, 0, 0);
            brMaxAge = limitInt(brMaxAge, 0, 0);
            for (int i = 0; i < 4; i++)
            {
                Age0Mort[i] = limitObject(Age0Mort[i], 0.0, 1.0);
                SAMort[i] = limitObject(SAMort[i], 0.0, 1.0);
                AdultMMort[i] = limitObject(AdultMMort[i], 0.0, 1.0);
                AdultFMort[i] = limitObject(AdultFMort[i], 0.0, 1.0);
                prBreed[i] = limitObject(prBreed[i], 0.0, 1.0);
                nLitters[i] = limitObject(nLitters[i], 0, 0);
                litSize[i] = limitObject(litSize[i], 0, 0);
            }
            K = limitObject(K, 0, 0);
            KDay = limitInt(KDay, 0, nDays);

            calcLambda();

            return true;
        }

        private object limitObject(object d, double dmin, double dmax)
        {
            double val;

            if (d.GetType() == typeof(Evaluator)) return d;
            val = Convert.ToDouble(d);

            if (val < dmin) val = dmin;
            else if (dmax != 0 && val > dmax) val = dmax;

            return (object)val;
        }

        private object limitObject(object d, int dmin, int dmax)
        {
            int val;

            if (d.GetType() == typeof(Evaluator)) return d;
                val = Convert.ToInt32(d);

            if (val < dmin) val = dmin;
            else if (dmax != 0 && val > dmax) val = dmax;

            return (object)val;
        }

        private double limitDouble(double d, double dmin, double dmax)
        {
            if (d < dmin) d = dmin;
            else if (dmax != 0 && d > dmax) d = dmax;

            return d;
        }

        private int limitInt(int d, int dmin, int dmax)
        {
            if (d < dmin) d = dmin;
            else if (dmax != 0 && d > dmax) d = dmax;

            return d;
        }

# endregion


        private void makeDailyWriters(int yrs)
        {
            yrDailyWriters = new StreamWriter[yrs];
            for (int i = 1; i <= yrs; i++) yrDailyWriters[i - 1] = new StreamWriter(OutFolder + "\\year_daily_" + i.ToString() + ".txt", false);
        }

        private void closeDailyWriters(int yrs)
        {
            for (int i = 0; i < yrs; i++) {
                yrDailyWriters[i].Close();
            }
        }

        private void makeYearlyWriters(int yrs)
        {
            yrSummaryWriters = new StreamWriter[yrs + 1];
            for (int i = 0; i <= yrs; i++) yrSummaryWriters[i] = new StreamWriter(OutFolder + "\\year_summary_" + i.ToString() + ".txt", false);
        }

        private void closeYearlyWriters(int yrs)
        {
            for (int i = 0; i <= yrs; i++) yrSummaryWriters[i].Close();
        }

        public bool makePop()
        {
            OIndivids = new List<OIndividual>();
            fillProjVars(); // needed when assigning dz states to inds
            vars['N' - 'A'] = initN;
            yCases = 0;
            newCases = 0;
            yDeaths = 0;
            newDeaths = 0;

            for (int i = 0; i < 4; i++)
            {
                Sex sx = Sex.Unknown;
                int aig; // initial min age, later add by sampling from breeding season

                if (i == 0)
                {
                    aig = 1; // so starting Juveniles were born within the past year
                    // start out at least 1 day old on Jan 1
                }
                else if (i == 1)
                {
                    aig = juvDays + 1; // start out at least 366 d on Jan 1
                }
                else if (i == 2)
                {
                    aig = SADays + 1;
                    sx = Sex.Male;
                }
                else 
                {
                    aig = SADays + 1; 
                    sx = Sex.Female;
                }

                for (int j = 0; j < 5; j++)
                {
                    DiseaseState dz = DiseaseState.S;
                    //if (j == 0)
                    //{
                    //    if (aig == 1) dz = DiseaseState.P; // can be P or S, depends on age -- set it below, once we know age
                    //}
                    //else 
                        if (j == 1)
                    {
                        dz = DiseaseState.E;
                    }
                    else if (j == 2)
                    {
                        dz = DiseaseState.I;
                    }
                    else if (j == 3)
                    {
                        dz = DiseaseState.R;
                    }
                    else if (j == 4)
                    {
                        dz = DiseaseState.V;
                    }

                    int ct = initStates[i, j];
                    for (int k = 0; k < ct; k++)
                    {
                        OIndividual oind = new OIndividual(this, null, null, sx);

                        oind.DzState = dz;
                        oind.age = aig;

                        // added 5 Nov 2015, adjusted ages for when in year animal was born

                        int yage = aig / nDays;
                        double prop = (double)k / (double)ct;

                        if (sx == Sex.Male)
                        {
                            for (int aclass = yage; aclass <= brMaxAge; aclass++) // inefficient to do this for each OInd, but so what
                            {
                                if (prop <= sadMale[aclass])
                                {
                                    oind.age += (aclass - yage) * nDays;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            for (int aclass = yage; aclass <= brMaxAge; aclass++)
                            {
                                if (prop <= sadFemale[aclass])
                                {
                                    oind.age += (aclass - yage) * nDays;
                                    break;
                                }
                            }
                        }

                        oind.fillIndVars();
                        int bday = GetObjIntVal(breedDays);
                        bday = limitInt(bday, 1, nDays);
                        oind.age += nDays - bday;

                        if (j == 0) // determine if still P
                        {
                            bool perm = false;
                            int tenure = 0;
                            double prP = GetObjVal(prPermanentP);
                            if (prP >= 1.0) perm = true;
                            else if (prP > 0.0 && OScenario.ORand.NextDouble() < prP) perm = true;
                            else tenure = GetObjIntVal(DaysP);

                            if (perm || tenure > oind.age)
                            {
                                oind.DzState = DiseaseState.P;
                                oind.StatePermanent = perm; // these over-ride what was recalculated within DzState accessor
                                oind.Tenure = tenure;
                                oind.DaysInState = oind.age;
                            }
                            else // not really needed for S, unless user has some weird function of DaysInState
                            {
                                oind.DaysInState = oind.age - tenure;
                            }
                        }

                        OIndivids.Add(oind);
                    }
                }
            }

            tallyDz();
            KNow = GetObjIntVal(K);

            nowVacc = vaccNow;
            nowCull = cullNow;

            return true;
        }

        private StreamWriter epiWriter;

        public bool runO(int runs, int years, int days)
        {
            if(!startRuns(runs, years, days)) return false;
            for (int r = 1; r <= runs; r++)
            {
                m_iter = r;
                if (!runO(years, days, false)) return false;
            }

            if (!endRun()) return false;

            return true;
        }

        public bool runO()
        {
            return runO(nRuns, nYears, nDays);
        }

        public bool startRuns()
        {
            return startRuns(nRuns, nYears, nDays);
        }


        public bool startRuns(int runs, int years, int days)
        {
            OutFolder = mOP.ProjFolder + mOP.OName + "_Results";
            if (!Directory.Exists(OutFolder))
                Directory.CreateDirectory(OutFolder);

                sYStates = new double[years + 1, 4, 6];
                ssYStates = new double[years + 1, 4, 6];
                sYStages = new double[years + 1, 4];
                ssYStages = new double[years + 1, 4];
                sYDz = new double[years + 1, 6];
                ssYDz = new double[years + 1, 6];
                sYN = new double[years + 1];
                ssYN = new double[years + 1];
                sYNew = new double[years + 1];
                ssYNew = new double[years + 1];
                sYNewDeaths = new double[years + 1];
                ssYNewDeaths = new double[years + 1];
                sDStates = new double[years + 1, days + 1, 4, 6];
                ssDStates = new double[years + 1, days + 1, 4, 6];
                sDStages = new double[years + 1, days + 1, 4];
                ssDStages = new double[years + 1, days + 1, 4];
                sDDz = new double[years + 1, days + 1, 6];
                ssDDz = new double[years + 1, days + 1, 6];
                sDNewCases = new double[years + 1, days + 1];
                ssDNewCases = new double[years + 1, days + 1];
                sDNewDeaths = new double[years + 1, days + 1];
                ssDNewDeaths = new double[years + 1, days + 1];
                yPrev = new double[years + 1, runs + 1];
                syPrev = new double[years + 1];

                ryN = new int[runs + 1, years + 1];

                if (outEpiRates)
                {
                    epiWriter = new StreamWriter(OutFolder + "\\RawData.txt", false);
                    epiWriter.WriteLine("# P, S, E, I, R, V, Iteration, Year, Day, NewInfections, DiseaseDeaths");
                }

            if (outDaily) makeDailyWriters(years);

            if (outYearly) makeYearlyWriters(years);

            checkDistFunc();

            return true;
        }

        public bool endRun()
        {
            if (outEpiRates) epiWriter.Close();
            if (outDaily) closeDailyWriters(nYears);
            if (outYearly) closeYearlyWriters(nYears);

            double iRuns = 1.0 / (double)nRuns;

            if (nRuns > 1)
            {
                for (int yr = 0; yr <= nYears; yr++)
                {
                    syPrev[yr] *= iRuns;

                    ssYN[yr] -= sYN[yr] * sYN[yr] * iRuns;
                    ssYN[yr] /= (double)(nRuns - 1);
                    ssYN[yr] = Math.Sqrt(ssYN[yr]);
                    sYN[yr] *= iRuns;

                    ssYNew[yr] -= sYNew[yr] * sYNew[yr] * iRuns;
                    ssYNew[yr] /= (double)(nRuns - 1);
                    ssYNew[yr] = Math.Sqrt(ssYNew[yr]);
                    sYNew[yr] *= iRuns;

                    ssYNewDeaths[yr] -= sYNewDeaths[yr] * sYNewDeaths[yr] * iRuns;
                    ssYNewDeaths[yr] /= (double)(nRuns - 1);
                    ssYNewDeaths[yr] = Math.Sqrt(ssYNewDeaths[yr]);
                    sYNewDeaths[yr] *= iRuns;

                    for (int i = 0; i < 4; i++)
                    {
                        ssYStages[yr, i] -= sYStages[yr, i] * sYStages[yr, i] * iRuns;
                        ssYStages[yr, i] /= (double)(nRuns - 1);
                        ssYStages[yr, i] = Math.Sqrt(ssYStages[yr, i]);
                        sYStages[yr, i] *= iRuns;
                        for (int j = 0; j < 6; j++)
                        {
                            ssYStates[yr, i, j] -= sYStates[yr, i, j] * sYStates[yr, i, j] * iRuns;
                            ssYStates[yr, i, j] /= (double)(nRuns - 1);
                            ssYStates[yr, i, j] = Math.Sqrt(ssYStates[yr, i, j]);
                            sYStates[yr, i, j] *= iRuns;
                        }
                    }
                    for (int j = 0; j < 6; j++)
                    {
                        ssYDz[yr, j] -= sYDz[yr, j] * sYDz[yr, j] * iRuns;
                        ssYDz[yr, j] /= (double)(nRuns - 1);
                        ssYDz[yr, j] = Math.Sqrt(ssYDz[yr, j]);
                        sYDz[yr, j] *= iRuns;
                    }
                }
            }
            else
            {
                for (int yr = 0; yr <= nYears; yr++)
                {
                    ssYN[yr] = 0.0;
                    ssYNew[yr] = 0.0;
                    ssYNewDeaths[yr] = 0.0;

                    for (int i = 0; i < 4; i++)
                    {
                        ssYStages[yr, i] = 0.0;
                        for (int j = 0; j < 6; j++)
                        {
                            ssYStates[yr, i, j] = 0.0;
                        }
                    }
                    for (int j = 0; j < 6; j++)
                    {
                        ssYDz[yr, j] = 0.0;
                    }
                }
            }

            StreamWriter prevStatsWriter = new StreamWriter(OutFolder + "\\" + SceneName + "_prev_stats.txt", false);
            prevStatsWriter.WriteLine("Prevalence for: " + mOP.OName + "   across " + nYears.ToString() + " years, averaged over " + nRuns.ToString() + " iterations (Year; Prevalence)");
            for (int yr = 0; yr <= nYears; yr++) prevStatsWriter.WriteLine(yr.ToString() + "; " + (syPrev[yr]).ToString("0.00000"));
            prevStatsWriter.WriteLine();
            prevStatsWriter.WriteLine("Prevalence for: " + mOP.OName + "   across " + nYears.ToString() + " years, for each of " + nRuns.ToString() + " iterations (Iteration; Year; Prevalence)");
            for (int r = 1; r <= nRuns; r++)
            {
                for (int yr = 0; yr <= nYears; yr++) prevStatsWriter.WriteLine(r.ToString() + "; " + yr.ToString() + "; " + (yPrev[yr, r]).ToString("0.00000"));
            }
            prevStatsWriter.Close();

            StreamWriter ryNWriter = new StreamWriter(OutFolder + "\\" + SceneName + "_ryN.txt", false);
            ryNWriter.WriteLine("Population Size for: " + mOP.OName + "   across " + nYears.ToString() + " years, for each of " + nRuns.ToString() + " iterations (Iteration; Year; N)");
            for (int r = 1; r <= nRuns; r++)
            {
                for (int yr = 0; yr <= nYears; yr++) ryNWriter.WriteLine(r.ToString() + "; " + yr.ToString() + "; " + (ryN[r, yr]).ToString());
            }
            ryNWriter.Close();

            StreamWriter yrStatsWriter = new StreamWriter(OutFolder + "\\" + SceneName + "_year_stats.txt", false);
                yrStatsWriter.WriteLine("Summary yearly statistics for: " + mOP.OName + "    over " + nRuns.ToString() + " iterations");
                yrStatsWriter.Write("    Year; N; SD(N); Juv; SD(Juv); SubAdult; SD(SA); AdultM; SD(AM); AdultF; SD(AF); P; SD(P); S; SD(S); E; SD(E); I; SD(I); R; SD(R); V; SD(V); ");
                yrStatsWriter.Write("JuvP; SD(JuvP); SAdultP; SD(SAdultP); AMP; SD(AMP); AFP; SD(AFP); ");
                yrStatsWriter.Write("JuvS; SD(JuvS); SAdultS; SD(SAdultS); AMS; SD(AMS); AFS; SD(AFS); ");
                yrStatsWriter.Write("JuvE; SD(JuvE); SAdultE; SD(SAdultE); AME; SD(AME); AFE; SD(AFE); ");
                yrStatsWriter.Write("JuvI; SD(JuvI); SAdultI; SD(SAdultI); AMI; SD(AMI); AFI; SD(AFI); ");
                yrStatsWriter.Write("JuvR; SD(JuvR); SAdultR; SD(SAdultR); AMR; SD(AMR); AFR; SD(AFR); ");
                yrStatsWriter.Write("JuvV; SD(JuvV); SAdultV; SD(SAdultV); AMV; SD(AMV); AFV; SD(AFV); ");
                yrStatsWriter.WriteLine("NewInfections; SD(Infections); Deaths; SD(Deaths)");

            for(int yr = 0; yr <= nYears; yr++) {
                yrStatsWriter.Write(yr.ToString() + "; " + sYN[yr].ToString("0.00") + "; " + ssYN[yr].ToString("0.00") + "; " + sYStages[yr, 0].ToString("0.00") + "; " + ssYStages[yr, 0].ToString("0.00") + "; " + sYStages[yr, 1].ToString("0.00") + "; " + ssYStages[yr, 1].ToString("0.00") + "; " + sYStages[yr, 2].ToString("0.00") + "; " + ssYStages[yr, 2].ToString("0.00") + "; " + sYStages[yr, 3].ToString("0.00") + "; " + ssYStages[yr, 3].ToString("0.00") + "; ");
                yrStatsWriter.Write(sYDz[yr, 0].ToString("0.00") + "; " + ssYDz[yr, 0].ToString("0.00") + "; " + sYDz[yr, 1].ToString("0.00") + "; " + ssYDz[yr, 1].ToString("0.00") + "; " + sYDz[yr, 2].ToString("0.00") + "; " + ssYDz[yr, 2].ToString("0.00") + "; " + sYDz[yr, 3].ToString("0.00") + "; " + ssYDz[yr, 3].ToString("0.00") + "; " + sYDz[yr, 4].ToString("0.00") + "; " + ssYDz[yr, 4].ToString("0.00") + "; " + sYDz[yr, 5].ToString("0.00") + "; " + ssYDz[yr, 5].ToString("0.00") + "; ");
                yrStatsWriter.Write(sYStates[yr, 0, 0].ToString("0.00") + "; " + ssYStates[yr, 0, 0].ToString("0.00") + "; " + sYStates[yr, 1, 0].ToString("0.00") + "; " + ssYStates[yr, 1, 0].ToString("0.00") + "; " + sYStates[yr, 2, 0].ToString("0.00") + "; " + ssYStates[yr, 2, 0].ToString("0.00") + "; " + sYStates[yr, 3, 0].ToString("0.00") + "; " + ssYStates[yr, 3, 0].ToString("0.00") + "; ");
                yrStatsWriter.Write(sYStates[yr, 0, 1].ToString("0.00") + "; " + ssYStates[yr, 0, 1].ToString("0.00") + "; " + sYStates[yr, 1, 1].ToString("0.00") + "; " + ssYStates[yr, 1, 1].ToString("0.00") + "; " + sYStates[yr, 2, 1].ToString("0.00") + "; " + ssYStates[yr, 2, 1].ToString("0.00") + "; " + sYStates[yr, 3, 1].ToString("0.00") + "; " + ssYStates[yr, 3, 1].ToString("0.00") + "; ");
                yrStatsWriter.Write(sYStates[yr, 0, 2].ToString("0.00") + "; " + ssYStates[yr, 0, 2].ToString("0.00") + "; " + sYStates[yr, 1, 2].ToString("0.00") + "; " + ssYStates[yr, 1, 2].ToString("0.00") + "; " + sYStates[yr, 2, 2].ToString("0.00") + "; " + ssYStates[yr, 2, 2].ToString("0.00") + "; " + sYStates[yr, 3, 2].ToString("0.00") + "; " + ssYStates[yr, 3, 2].ToString("0.00") + "; ");
                yrStatsWriter.Write(sYStates[yr, 0, 3].ToString("0.00") + "; " + ssYStates[yr, 0, 3].ToString("0.00") + "; " + sYStates[yr, 1, 3].ToString("0.00") + "; " + ssYStates[yr, 1, 3].ToString("0.00") + "; " + sYStates[yr, 2, 3].ToString("0.00") + "; " + ssYStates[yr, 2, 3].ToString("0.00") + "; " + sYStates[yr, 3, 3].ToString("0.00") + "; " + ssYStates[yr, 3, 3].ToString("0.00") + "; ");
                yrStatsWriter.Write(sYStates[yr, 0, 4].ToString("0.00") + "; " + ssYStates[yr, 0, 4].ToString("0.00") + "; " + sYStates[yr, 1, 4].ToString("0.00") + "; " + ssYStates[yr, 1, 4].ToString("0.00") + "; " + sYStates[yr, 2, 4].ToString("0.00") + "; " + ssYStates[yr, 2, 4].ToString("0.00") + "; " + sYStates[yr, 3, 4].ToString("0.00") + "; " + ssYStates[yr, 3, 4].ToString("0.00") + "; ");
                yrStatsWriter.Write(sYStates[yr, 0, 5].ToString("0.00") + "; " + ssYStates[yr, 0, 5].ToString("0.00") + "; " + sYStates[yr, 1, 5].ToString("0.00") + "; " + ssYStates[yr, 1, 5].ToString("0.00") + "; " + sYStates[yr, 2, 5].ToString("0.00") + "; " + ssYStates[yr, 2, 5].ToString("0.00") + "; " + sYStates[yr, 3, 5].ToString("0.00") + "; " + ssYStates[yr, 3, 5].ToString("0.00") + "; ");
                yrStatsWriter.WriteLine(sYNew[yr].ToString("0.00") + "; " + ssYNew[yr].ToString("0.00") + "; " + sYNewDeaths[yr].ToString("0.00") + "; " + ssYNewDeaths[yr].ToString("0.00"));
            }
            yrStatsWriter.Close();

            if (nRuns > 1)
            {
                for (int yr = 1; yr <= nYears; yr++)
                {
                    for (int d = 1; d <= nDays; d++)
                    {
                        for (int i = 0; i < 4; i++)
                        {
                            ssDStages[yr, d, i] -= sDStages[yr, d, i] * sDStages[yr, d, i] * iRuns;
                            ssDStages[yr, d, i] /= (double)(nRuns - 1);
                            ssDStages[yr, d, i] = Math.Sqrt(ssDStages[yr, d, i]);
                            sDStages[yr, d, i] *= iRuns;
                            for (int j = 0; j < 6; j++)
                            {
                                ssDStates[yr, d, i, j] -= sDStates[yr, d, i, j] * sDStates[yr, d, i, j] * iRuns;
                                ssDStates[yr, d, i, j] /= (double)(nRuns - 1);
                                ssDStates[yr, d, i, j] = Math.Sqrt(ssDStates[yr, d, i, j]);
                                sDStates[yr, d, i, j] *= iRuns;
                            }
                        }
                        for (int j = 0; j < 6; j++)
                        {
                            ssDDz[yr, d, j] -= sDDz[yr, d, j] * sDDz[yr, d, j] * iRuns;
                            ssDDz[yr, d, j] /= (double)(nRuns - 1);
                            ssDDz[yr, d, j] = Math.Sqrt(ssDDz[yr, d, j]);
                            sDDz[yr, d, j] *= iRuns;
                        }

                        ssDNewCases[yr, d] -= sDNewCases[yr, d] * sDNewCases[yr, d] * iRuns;
                        ssDNewCases[yr, d] /= (double)(nRuns - 1);
                        ssDNewCases[yr, d] = Math.Sqrt(ssDNewCases[yr, d]);
                        sDNewCases[yr, d] *= iRuns;

                        ssDNewDeaths[yr, d] -= sDNewDeaths[yr, d] * sDNewDeaths[yr, d] * iRuns;
                        ssDNewDeaths[yr, d] /= (double)(nRuns - 1);
                        ssDNewDeaths[yr, d] = Math.Sqrt(ssDNewDeaths[yr, d]);
                        sDNewDeaths[yr, d] *= iRuns;
                    }
                }
            }
            else
            {
                for (int yr = 1; yr <= nYears; yr++)
                {
                    for (int d = 1; d <= nDays; d++)
                    {
                        for (int i = 0; i < 4; i++)
                        {
                            ssDStages[yr, d, i] = 0.0;
                            for (int j = 0; j < 6; j++)
                            {
                                ssDStates[yr, d, i, j] = 0.0;
                            }
                        }
                        for (int j = 0; j < 6; j++)
                        {
                            ssDDz[yr, d, j] = 0.0;
                        }

                        ssDNewCases[yr, d] = 0.0;
                        ssDNewDeaths[yr, d] = 0.0;
                    }
                }
            }

            StreamWriter dayStatsWriter = new StreamWriter(OutFolder + "\\" + SceneName + "_day_stats.txt", false);
            dayStatsWriter.WriteLine("Summary daily statistics for: " + mOP.OName + "    over " + nRuns.ToString() + " iterations");
            dayStatsWriter.Write("    Year; Day; Juv; SD(Juv); SubAdult; SD(SA); AdultM; SD(AM); AdultF; SD(AF); P; SD(P); S; SD(S); E; SD(E); I; SD(I); R; SD(R); V; SD(V); ");
            dayStatsWriter.Write("JuvP; SD(JuvP); SAdultP; SD(SAdultP); AMP; SD(AMP); AFP; SD(AFP); ");
            dayStatsWriter.Write("JuvS; SD(JuvS); SAdultS; SD(SAdultS); AMS; SD(AMS); AFS; SD(AFS); ");
            dayStatsWriter.Write("JuvE; SD(JuvE); SAdultE; SD(SAdultE); AME; SD(AME); AFE; SD(AFE); ");
            dayStatsWriter.Write("JuvI; SD(JuvI); SAdultI; SD(SAdultI); AMI; SD(AMI); AFI; SD(AFI); ");
            dayStatsWriter.Write("JuvR; SD(JuvR); SAdultR; SD(SAdultR); AMR; SD(AMR); AFR; SD(AFR); ");
            dayStatsWriter.Write("JuvV; SD(JuvV); SAdultV; SD(SAdultV); AMV; SD(AMV); AFV; SD(AFV); ");
            dayStatsWriter.WriteLine("NewInfections; SD(Infections); Deaths; SD(Deaths)");

            for (int yr = 1; yr <= nYears; yr++)
            {
                for (int d = 1; d <= nDays; d++)
                {
                    dayStatsWriter.Write(yr.ToString() + "; " + d.ToString() + "; " + sDStages[yr, d, 0].ToString("0.00") + "; " + ssDStages[yr, d, 0].ToString("0.00") + "; " + sDStages[yr, d, 1].ToString("0.00") + "; " + ssDStages[yr, d, 1].ToString("0.00") + "; " + sDStages[yr, d, 2].ToString("0.00") + "; " + ssDStages[yr, d, 2].ToString("0.00") + "; " + sDStages[yr, d, 3].ToString("0.00") + "; " + ssDStages[yr, d, 3].ToString("0.00") + "; ");
                    dayStatsWriter.Write(sDDz[yr, d, 0].ToString("0.00") + "; " + ssDDz[yr, d, 0].ToString("0.00") + "; " + sDDz[yr, d, 1].ToString("0.00") + "; " + ssDDz[yr, d, 1].ToString("0.00") + "; " + sDDz[yr, d, 2].ToString("0.00") + "; " + ssDDz[yr, d, 2].ToString("0.00") + "; " + sDDz[yr, d, 3].ToString("0.00") + "; " + ssDDz[yr, d, 3].ToString("0.00") + "; " + sDDz[yr, d, 4].ToString("0.00") + "; " + ssDDz[yr, d, 4].ToString("0.00") + "; " + sDDz[yr, d, 5].ToString("0.00") + "; " + ssDDz[yr, d, 5].ToString("0.00") + "; ");
                    dayStatsWriter.Write(sDStates[yr, d, 0, 0].ToString("0.00") + "; " + ssDStates[yr, d, 0, 0].ToString("0.00") + "; " + sDStates[yr, d, 1, 0].ToString("0.00") + "; " + ssDStates[yr, d, 1, 0].ToString("0.00") + "; " + sDStates[yr, d, 2, 0].ToString("0.00") + "; " + ssDStates[yr, d, 2, 0].ToString("0.00") + "; " + sDStates[yr, d, 3, 0].ToString("0.00") + "; " + ssDStates[yr, d, 3, 0].ToString("0.00") + "; ");
                    dayStatsWriter.Write(sDStates[yr, d, 0, 1].ToString("0.00") + "; " + ssDStates[yr, d, 0, 1].ToString("0.00") + "; " + sDStates[yr, d, 1, 1].ToString("0.00") + "; " + ssDStates[yr, d, 1, 1].ToString("0.00") + "; " + sDStates[yr, d, 2, 1].ToString("0.00") + "; " + ssDStates[yr, d, 2, 1].ToString("0.00") + "; " + sDStates[yr, d, 3, 1].ToString("0.00") + "; " + ssDStates[yr, d, 3, 1].ToString("0.00") + "; ");
                    dayStatsWriter.Write(sDStates[yr, d, 0, 2].ToString("0.00") + "; " + ssDStates[yr, d, 0, 2].ToString("0.00") + "; " + sDStates[yr, d, 1, 2].ToString("0.00") + "; " + ssDStates[yr, d, 1, 2].ToString("0.00") + "; " + sDStates[yr, d, 2, 2].ToString("0.00") + "; " + ssDStates[yr, d, 2, 2].ToString("0.00") + "; " + sDStates[yr, d, 3, 2].ToString("0.00") + "; " + ssDStates[yr, d, 3, 2].ToString("0.00") + "; ");
                    dayStatsWriter.Write(sDStates[yr, d, 0, 3].ToString("0.00") + "; " + ssDStates[yr, d, 0, 3].ToString("0.00") + "; " + sDStates[yr, d, 1, 3].ToString("0.00") + "; " + ssDStates[yr, d, 1, 3].ToString("0.00") + "; " + sDStates[yr, d, 2, 3].ToString("0.00") + "; " + ssDStates[yr, d, 2, 3].ToString("0.00") + "; " + sDStates[yr, d, 3, 3].ToString("0.00") + "; " + ssDStates[yr, d, 3, 3].ToString("0.00") + "; ");
                    dayStatsWriter.Write(sDStates[yr, d, 0, 4].ToString("0.00") + "; " + ssDStates[yr, d, 0, 4].ToString("0.00") + "; " + sDStates[yr, d, 1, 4].ToString("0.00") + "; " + ssDStates[yr, d, 1, 4].ToString("0.00") + "; " + sDStates[yr, d, 2, 4].ToString("0.00") + "; " + ssDStates[yr, d, 2, 4].ToString("0.00") + "; " + sDStates[yr, d, 3, 4].ToString("0.00") + "; " + ssDStates[yr, d, 3, 4].ToString("0.00") + "; ");
                    dayStatsWriter.Write(sDStates[yr, d, 0, 5].ToString("0.00") + "; " + ssDStates[yr, d, 0, 5].ToString("0.00") + "; " + sDStates[yr, d, 1, 5].ToString("0.00") + "; " + ssDStates[yr, d, 1, 5].ToString("0.00") + "; " + sDStates[yr, d, 2, 5].ToString("0.00") + "; " + ssDStates[yr, d, 2, 5].ToString("0.00") + "; " + sDStates[yr, d, 3, 5].ToString("0.00") + "; " + ssDStates[yr, d, 3, 5].ToString("0.00") + "; ");
                    dayStatsWriter.WriteLine(sDNewCases[yr, d].ToString("0.00") + "; " + ssDNewCases[yr, d].ToString("0.00") + "; " + sDNewDeaths[yr, d].ToString("0.00") + "; " + ssDNewDeaths[yr, d].ToString("0.00"));
                }
            }
            dayStatsWriter.Close();

            runsDone = true;

            mOP.saveXML(mOP.ProjFolder + mOP.OName + "_Results\\" + mOP.OName, false);  // as backup
            return true;
        }

//        Thread spatialPlotThread;

        public bool runO(int years, int days, bool showDisplay)
        {
            try
            {
                makePop();
                year0(days);

                if (showDisplay)
                {//spatialPlotPoints(1, 0);
                    //spatialPlotThread = new Thread(new ThreadStart(delegate { spatialPlotPoints(); }));
                    //spatialPlotThread.Start();
                    //spatialPlotThread.Join();

                    spatialPlotPoints();
                }

                for (int y = 1; y <= years; y++) Oyear(y, days);
            }
            catch
            {
                MessageBox.Show("Error in Outbreak run " + m_iter.ToString() + " in year " + year.ToString() + " on day " + day.ToString());

                return false;
            }

            return true;
        }

        C1Chart chartSpatialDisplay;

        private System.Drawing.Color[] ColorList = {
            System.Drawing.Color.Blue,  //P
            System.Drawing.Color.Green,  //S
            System.Drawing.Color.DarkOrange,  //E
            System.Drawing.Color.Red,   //I
            System.Drawing.Color.Magenta,  //R
            System.Drawing.Color.Purple,  //V
            System.Drawing.Color.Black, // D
        };

        public void startSpatialPlot(C1Chart chart)
        {
            chartSpatialDisplay = chart;

            chartSpatialDisplay.ChartGroups.Group0.ChartType = Chart2DTypeEnum.XYPlot;
            chartSpatialDisplay.Header.Visible = false;
            //chartSpatialDisplay.ChartArea.AxisX.ValueLabels.Clear();
            //chartSpatialDisplay.ChartArea.AxisY.ValueLabels.Clear();
            chartSpatialDisplay.ChartArea.AxisX.Text = "";
            chartSpatialDisplay.ChartArea.AxisX.Min = gridXmin;
            chartSpatialDisplay.ChartArea.AxisX.Max = gridXmax;
            chartSpatialDisplay.ChartArea.AxisY.Text = "";
            chartSpatialDisplay.ChartArea.AxisY.Min = gridYmin;
            chartSpatialDisplay.ChartArea.AxisY.Max = gridYmax;
            chartSpatialDisplay.ChartArea.AxisX.AnnoMethod = AnnotationMethodEnum.Values;
            chartSpatialDisplay.ChartArea.AxisY.AnnoMethod = AnnotationMethodEnum.Values;
            chartSpatialDisplay.Footer.Visible = true;

            chartSpatialDisplay.ChartGroups.Group0.ChartData.SeriesList.Clear();
            for (int j = 0; j < 6; j++)
            {
                C1.Win.C1Chart.ChartDataSeries ds = new C1.Win.C1Chart.ChartDataSeries();

                if (j == 2)
                {
                    ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.DiagCross;
                }
                else if (j == 3)
                {
                    ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Cross;
                }
                else if (j == 4)
                {
                    ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Diamond;
                }
                else if (j == 5)
                {
                    ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Box;
                }
                else ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Circle;
                ds.SymbolStyle.Color = ColorList[j];
                ds.SymbolStyle.Size = 4;
                ds.LineStyle.Pattern = LinePatternEnum.None;
                if (j == 0) ds.Label = "P";
                else if (j == 1) ds.Label = "S";
                else if (j == 2) ds.Label = "E";
                else if (j == 3) ds.Label = "I";
                else if (j == 4) ds.Label = "R";
                else if (j == 5) ds.Label = "V";
                //                    else if (j == 6) ds.Label = "D";
                ds.LegendEntry = true;

                chartSpatialDisplay.ChartGroups.Group0.ChartData.SeriesList.Add(ds);
                chartSpatialDisplay.Legend.Visible = true;

                chartSpatialDisplay.Update();
            }
        }

        public void spatialPlotPoints()
        {
            chartSpatialDisplay.BeginUpdate();

            for (int j = 0; j < 6; j++)
            {
                C1.Win.C1Chart.ChartDataSeries ds = chartSpatialDisplay.ChartGroups.Group0.ChartData.SeriesList[j];

                ds.X.Clear();
                ds.Y.Clear();

                for (int i = 0; i < OIndivids.Count; i++) // this nesting probably isn't the fastest ...
                {
                    OIndividual oind = OIndivids[i];
                    if (oind.iDz != j) continue;

                    ds.X.Add(oind.X);
                    ds.Y.Add(oind.Y);
                }
            }

            int yr = year;
            if (yr == 0) yr = 1;
            chartSpatialDisplay.Footer.Text = "Iteration = " + m_iter.ToString() + "   Year = " + yr.ToString() + "   Day = " + day.ToString();

            chartSpatialDisplay.EndUpdate();
            chartSpatialDisplay.Update();
        }

        //public bool runO(int years, int days)
        //{
        //    try
        //    {
        //        makePop();
        //        year0(days);
                
        //        for (int y = 1; y <= years; y++) Oyear(y, days);
        //    }
        //    catch
        //    {
        //        //if (outDaily)
        //        //{
        //        //    yrDailyWriter.Close();
        //        //}

        //        MessageBox.Show("Error in Outbreak run " + m_iter.ToString() + " in year " + year.ToString() + " on day " + day.ToString());

        //        return false;
        //    }

        //    return true;
        //}

        
        public bool year0(int days)
        {
            year = 0;

            int vd = GetObjIntVal(vaccDays);
            int vd0 = GetObjIntVal(vaccDaysStart);
            vday = vd - vd0;

            int vc = GetObjIntVal(cullDays);
            int vc0 = GetObjIntVal(cullDaysStart);
            cullday = vc - vc0;

            tallyDz();

            if (nowVacc)
            {
                vaccinate();
                tallyDz();
            }
            if (nowCull)
            {
                cull();
                tallyDz();
            }

            if (outYearly)
            {
                writeYearly(0);
            }

            syPrev[year] += prevalence;
            yPrev[year, m_iter] = prevalence;

            ryN[m_iter, year] = N;

            sYN[year] += N;
            ssYN[year] += N * N;

            sYNew[year] += newCases; // initial number of cases at year 0, day 0
            ssYNew[year] += newCases * newCases;

            for (int i = 0; i < 4; i++)
                {
                    sYStages[year, i] += stages[i];
                    ssYStages[year, i] += stages[i] * stages[i];

                    for (int j = 0; j < 6; j++)
                    {
                        sYStates[year, i, j] += states[i, j];
                        ssYStates[year, i, j] += states[i, j] * states[i, j];
                    }
                    //sYStates[year, i, 4] += states[i, 4] + states[i, 5];
                    //ssYStates[year, i, 4] += (states[i, 4] + states[i, 5]) * (states[i, 4] + states[i, 5]);
                }
                for (int j = 0; j < 6; j++)
                {
                    sYDz[year, j] += dzstates[j];
                    ssYDz[year, j] += dzstates[j] * dzstates[j];
                }
                //sYDz[year, 4] += dzstates[4] + dzstates[5];
                //ssYDz[year, 4] += (dzstates[4] + dzstates[5]) * (dzstates[4] + dzstates[5]);

            if (outIndList) writeIndlist(true);
//            if (outIndividuals) writeIndlist(false);

            return true;
        }


        public bool Oyear(int y, int days)
        {
            return Oyear(y, days, 1);
        }
        
        public bool Oyear(int y, int days, int d)
        {
            year = y;
            day = d;
            hasCulled = false;

            yCases = 0;
            yDeaths = 0;

            if (!runO(days)) return false;

            if (day <= nDays) return true; // for MMOutbreak, so can step through partial years within a Group

            if (outIndList) writeIndlist(true);
//            if (outIndividuals) writeIndlist(false);

            if (outYearly)
            {
                writeYearly(y);
            }

            if (year <= nYears) // protect against writing to years that weren't declared
            {
                syPrev[year] += prevalence;
                if(m_iter <= nRuns) yPrev[year, m_iter] = prevalence;

                if (m_iter <= nRuns) ryN[m_iter, year] = N;

                sYN[year] += N;
                ssYN[year] += N * N;

                for (int i = 0; i < 4; i++)
                {
                    sYStages[year, i] += stages[i];
                    ssYStages[year, i] += stages[i] * stages[i];

                    for (int j = 0; j < 6; j++)
                    {
                        sYStates[year, i, j] += states[i, j];
                        ssYStates[year, i, j] += states[i, j] * states[i, j];
                    }
                    //sYStates[year, i, 4] += states[i, 4] + states[i, 5];
                    //ssYStates[year, i, 4] += (states[i, 4] + states[i, 5]) * (states[i, 4] + states[i, 5]);
                }
                for (int j = 0; j < 6; j++)
                {
                    sYDz[year, j] += dzstates[j];
                    ssYDz[year, j] += dzstates[j] * dzstates[j];
                }
                //sYDz[year, 4] += dzstates[4] + dzstates[5];
                //ssYDz[year, 4] += (dzstates[4] + dzstates[5]) * (dzstates[4] + dzstates[5]);

                sYNew[year] += (double)yCases;
                ssYNew[year] += (double)(yCases * yCases);
                sYNewDeaths[year] += (double)yDeaths;
                ssYNewDeaths[year] += (double)(yDeaths * yDeaths);
            }

            return true;
        }


        List<OIndividual> AMales = new List<OIndividual>();
        public int newCases = 0;
        public int yCases = 0;
        public int newDeaths = 0;
        public int yDeaths = 0;
        public bool breedDayWarning = false;

        private bool runO(int days)
        {
            if (nowVacc)
            {
                tallyDz();
                vaccinate();
            }
            if (nowCull)
            {
                tallyDz();
                cull();
            }

            //if (outDaily)
            //{
            //    yrDailyWriter = new StreamWriter(OutFolder + "\\year_daily_" + year.ToString() + ".txt", iter > 1);
            //}


            double i365 = 1.0 / (double)nDays;
            double j365 = i365;
            double sa365 = i365;
            if (enterStageMort)
            {
                j365 = 1.0 / (double)(juvDays);
                sa365 = 1.0 / (double)(SADays - juvDays);
            }

            for (int d = 1; d <= days; d++, day++)
            {
//                day = d;  // so that we can start after day 1, as in a MM with Grouped days
                tallyDz();

                if (doDemog)
                {

                    if (day == 1) // determine how many litters and on what days for each female, and tally the males
                    {
                        AMales.Clear();

                        foreach (OIndividual oind in OIndivids)
                        {
                            if (!oind.alive) continue; // there shouldn't be any dead animals, but just to be sure

                            // see when litters will born to each female
                            if (oind.age + nDays <= brAgeDays) continue; // augmented 3 Nov 2015 with daily check, below, for animals that might be old enough to breed

                            if (oind.sex == Sex.Female)
                            {
                                oind.fillIndVars();
                                oind.BreedDays.Clear();

                                double prB = GetObjVal(prBreed[oind.i4Dz]);
                                if (prB > 0.0 && (prB >= 1.0 || prB > ORand.NextDouble()))
                                {
                                    int nlits = GetObjIntVal(nLitters[oind.i4Dz]);
                                    for (int i = 0; i < nlits; i++)
                                    {
                                        vars['L' - 'A'] = (double)(i + 1);

                                        // changed 3 Nov 2015 to determine #litters based on if female is old enough (in days)
                                        int breedDay = GetObjIntVal(breedDays); // get the date for this litter
                                        if (breedDay < 1 || breedDay > nDays)
                                        {
                                            if (!breedDayWarning)
                                            {
                                                MessageBox.Show("A breeding day was outside of the current year, and has been adjusted.");
                                                breedDayWarning = true;
                                            }
                                            breedDay = limitInt(breedDay, 1, nDays);
                                        }
                                        if(breedDay + oind.age > brAgeDays) oind.BreedDays.Add(breedDay); 
                                        // e.g., get a different distribution of breedDay for each subsequent litter with =100+10*NRAND+30*L
                                    }
                                }
                            }
                            else AMales.Add(oind);
                        }
                    } // endif day = 1

                    // find males old enough to breed on this day
                    List<OIndividual> AdultMales = new List<OIndividual>();
                    for (int i = 0; i < AMales.Count; i++)
                    {
                        OIndividual omate = AMales[i];
                        if (day + omate.age > brAgeDays) AdultMales.Add(omate);
                    }

                    int oct = OIndivids.Count; // use this so that don't do demog on newborns as they are produced
                    int nmales = AdultMales.Count;
                    if (nmales > 0)
                    { // breeding
                        for (int oi = 0; oi < oct; oi++)
                        {
                            OIndividual oind = OIndivids[oi];

                            if (oind.sex == Sex.Male) continue; // 4 Nov 2015 -- this wasn't letting males ever be subject to mortality!  when it was within same loop as mortality
                            if (oind.BreedDays.Count < 1) continue;
                            if (!oind.BreedDays.Contains(day)) continue;
                            oind.BreedDays.Remove(day);

                            oi--; // so will check to see if the female has another litter on that day

                            oind.fillIndVars();
                            int z = oind.i4Dz;

                            int litsz = GetObjIntVal(litSize[z]);
                            if (litsz < 1) continue;

                                OIndividual omate = AdultMales[ORand.Next(nmales)];
                                for (int i = 0; i < litsz; i++)
                                {
                                    OIndividual okid = new OIndividual(this, oind, omate, Sex.Unknown);
                                    OIndivids.Add(okid);
                                }
                        }
                    }

                    // mortality
                    for (int oi = 0; oi < oct; oi++)
                    {
                        OIndividual oind = OIndivids[oi];

                        if (oind.age >= brMaxAge * nDays) 
                        {
                            oind.alive = false;
                            continue;
                        }

                        oind.fillIndVars();
                        int z = oind.i4Dz;
                        double surv = 1.0;
//                        double i365 = 1.0 / (double)nDays; // moved out of daily loop

                        if (oind.age <= juvDays)
                        {
                            surv = 1.0 - GetObjVal(Age0Mort[z]);
                            surv = Math.Pow(surv, j365);
                        }
                        else if (oind.age <= SADays)
                        {
                            surv = 1.0 - GetObjVal(SAMort[z]);
                            surv = Math.Pow(surv, sa365);
                        }
                        else if (oind.sex == Sex.Male)
                        {
                            surv = 1.0 - GetObjVal(AdultMMort[z]);
                            surv = Math.Pow(surv, i365);
                        }
                        else
                        {
                            surv = 1.0 - GetObjVal(AdultFMort[z]);
                            surv = Math.Pow(surv, i365);
                        }

                        if (surv < 1.0)
                        {
                            if (surv <= 0.0 || surv < ORand.NextDouble())
                            {
                                oind.alive = false;
                            }
                        }

                    } // end of mortality for the day

                    if (maintainK || KDay == day) Kcheck();
                }  // end of demog for the day

                newCases = 0;
                newDeaths = 0;
                OTimeStep();   // dead animals get removed from OIndivid and dead males get removed from AMales in here

                yCases += newCases;
                yDeaths += newDeaths;

                if (outDaily) writeDaily(year);

                if (year <= nYears && day <= nDays)
                {
                    for (int i = 0; i < 4; i++)
                    {
                        sDStages[year, day, i] += stages[i];
                        ssDStages[year, day, i] += stages[i] * stages[i];

                        for (int j = 0; j < 6; j++)
                        {
                            sDStates[year, day, i, j] += states[i, j];
                            ssDStates[year, day, i, j] += states[i, j] * states[i, j];
                        }
                        //sDStates[year, day, i, 4] += states[i, 4] + states[i, 5];
                        //ssDStates[year, day, i, 4] += (states[i, 4] + states[i, 5]) * (states[i, 4] + states[i, 5]);
                    }
                    for (int j = 0; j < 6; j++)
                    {
                        sDDz[year, day, j] += dzstates[j];
                        ssDDz[year, day, j] += dzstates[j] * dzstates[j];
                    }
                    //sDDz[year, day, 4] += dzstates[4] + dzstates[5];
                    //ssDDz[year, day, 4] += (dzstates[4] + dzstates[5]) * (dzstates[4] + dzstates[5]);

                    sDNewCases[year, day] += (double)newCases;
                    ssDNewCases[year, day] += (double)(newCases * newCases);

                    sDNewDeaths[year, day] += (double)newDeaths;
                    ssDNewDeaths[year, day] += (double)(newDeaths * newDeaths);
                }

                if (outEpiRates) writeEpiRates();

                // moved here so that aging occurs after all the tallies and reports for the day are done. 
                foreach (OIndividual oind in OIndivids)
                {
                    oind.DaysInState++;
                    oind.age++;
                }

            }

            return true;
        }


        private bool Kcheck()
        {
            tallyDz();
            if (totalN < 1) return true;

            KNow = GetObjIntVal(K);

            if (KNow >= totalN) return true;

            double surv = 1.0;
            if (KNow < 1) surv = 0.0;
            else surv = (double)KNow / (double)totalN;

            foreach (OIndividual oind in OIndivids)
            {
                if (surv < ORand.NextDouble())
                {
                    oind.alive = false;
                }
            }

            return true;
        }


        public bool OTimeStep()
        {
            // moved the aging to the very end of the day, after finish with the day of Dz transmission, and after all tallies for the year
            //foreach (OIndividual oind in OIndivids) 
            //{
            //    oind.DaysInState++;
            //    oind.age++;
            //}

            tallyDz(); // dead animals get removed from OIndivid and dead males get removed from AMales in here

            // vaccination 
            if (useVaccInterval)
            {
                int vd = GetObjIntVal(vaccDays);
                if (vd == vday)
                {
                    vaccinate();
                }
                else vday++;
                tallyDz();
            }
            if (useVaccPrev)
            {
                double vpr = GetObjVal(vaccPrev);
                if (vpr >= 1.0) vaccinate();
                else if (vpr > 0.0 && vpr > OScenario.ORand.NextDouble()) 
                {
                    vaccinate();
                }
                tallyDz();
            }

            // culling
            if (useCullInterval)
            {
                int cd = GetObjIntVal(cullDays);
                if (cd == cullday)
                {
                    cull();
                }
                else cullday++;

                tallyDz();
            }
            if (useCullPrev && !hasCulled)
            {
                double cpr = GetObjVal(cullPrev);
                if (cpr >= 1.0)
                {
                    cull();
                    hasCulled = true;
                }
                else if (cpr > 0.0 && cpr > OScenario.ORand.NextDouble())
                {
                    cull();
                    hasCulled = true;
                }
                tallyDz();
            }

            if (totalN < 1) return true;

            if (mOP.doDz)
            {
                List<OIndividual> indsI = new List<OIndividual>();
                List<OIndividual> indsS = new List<OIndividual>();
                foreach (OIndividual indS in OIndivids)
                {
                    if (indS.DzState == DiseaseState.I) indsI.Add(indS);

                    if (indS.DzState != DiseaseState.S) continue;
                    indS.fillIndVars();
                    indS.fillSvars(); // in case user uses this notation, the vars for the S recipient

                    double prOut = GetObjVal(prOutsideEncounter) * GetObjVal(prOutsideTransmission);

                    if (prOut > 0.0 && OScenario.ORand.NextDouble() < prOut) // check for prOut > 0 avoids calling rand if not needed
                        indS.DzState = DiseaseState.E;
                    else indsS.Add(indS);
                }

                // disease transmission
                double prT;
                double prE;

                if (indsI.Count > 0)
                {
                    if (usePropEncounter) for (int os = 0; os < indsS.Count; os++)
                        {
                            OIndividual indS = indsS[os];
                            indS.fillSvars();
                            prT = GetObjVal(prTransmission);

                            //                        if (prT > 0.0) 
                            for (int oi = 0; oi < indsI.Count; oi++)
                            {
                                OIndividual indI = indsI[oi];
                                indI.fillIndVars();

                                prT = GetObjVal(prTransmission);
                                prE = GetObjVal(prPopEncounter);

                                if (prT > 0.0 && prE > 0.0 && OScenario.ORand.NextDouble() < prE * prT)
                                {
                                    //                                    indS.fillIndVars(); // this is done in DzState
                                    indS.DzState = DiseaseState.E;
                                    indsS.Remove(indS);
                                    os--;
                                    break;
                                }
                            }
                        }

                    if (useFixedNEncounter && indsS.Count > 0)
                    {
                        int ct = OIndivids.Count;
                        for (int oi = 0; oi < indsI.Count; oi++)
                        {
                            OIndividual indI = indsI[oi];
                            indI.fillIndVars();
                            double dect = GetObjVal(NEncounter);
                            int ect = (int)dect;
                            if (dect - (double)ect > 0.0) if (OScenario.ORand.NextDouble() < (dect - (double)ect)) ect++;

                            for (int i = 0; i < ect; i++)
                            {
                                int orand;
                                do
                                    orand = OScenario.ORand.Next(ct);
                                while (orand == oi); // pick new ind if happen to get focal I individual
                                OIndividual ind = OIndivids[orand];
                                if (ind.DzState != DiseaseState.S) continue;

                                ind.fillSvars();

                                prT = GetObjVal(prTransmission);
                                if (prT >= 1.0 || (prT > 0.0 && OScenario.ORand.NextDouble() < prT))
                                {
                                    ind.DzState = DiseaseState.E;
                                    indsS.Remove(ind);

                                    indI.fillIndVars(); // need to re-set, because DzState has fillIndivVars in it
                                }
                            }
                        }
                    }

                    if (useDistanceEncounter)
                    {
                        for (int os = 0; os < indsS.Count; os++)
                        {
                            OIndividual indS = indsS[os];
                            indS.fillSvars();

                            //if (prT > 0.0) 
                            for (int oi = 0; oi < indsI.Count; oi++)
                            {
                                OIndividual indI = indsI[oi];
                                if (usingDIST) vars['E' - 'A'] = XYdistance(indI, indS);
                                if (usingCONNECTS) vars['G' - 'A'] = XYconnects(indI, indS);
                                if (usingCONTACT) vars['L' - 'A'] = (XYcontact(indI, indS) ? 1 : 0);
                                if (usingSTEPS) vars['H' - 'A'] = XYsteps(indI, indS);
                                if (usingSAME) vars['I' - 'A'] = (XYsame(indI, indS) ? 1 : 0);

                                indI.fillIndVars();
                                prT = GetObjVal(prTransmission);
                                prE = GetObjVal(DistanceEncounterFunc);

                                if (prT > 0.0 && prE > 0.0 && OScenario.ORand.NextDouble() < prE * prT)
                                {
                                    indS.fillIndVars();
                                    indS.DzState = DiseaseState.E;
                                    indsS.Remove(indS);
                                    os--;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            
            tallyDz();

            // state transitions
            foreach (OIndividual oind in OIndivids)
            {
                if (oind.StatePermanent) continue;
                oind.fillIndVars();

                int t = oind.Tenure;
                int days = oind.DaysInState;

                if (oind.DzState == DiseaseState.P)
                {
                    if (days >= t) oind.DzState = DiseaseState.S;
                    continue;
                }
                if (oind.DzState == DiseaseState.S)
                {
                    // handled above, so that Infectious pool not changing while infections are occurring
                    continue;
                }
                if (oind.DzState == DiseaseState.E)
                {
                    if (days >= t)
                    {
                        oind.DzState = DiseaseState.I;
                        days = oind.DaysInState;
                        t = oind.Tenure; // re-setting days and t here allows the model to have a duration of state I be 0 days. 
                    }
                    else continue;
                }
                if (oind.DzState == DiseaseState.I)
                {
                    if (days >= t)
                    {
                        double prR = GetObjVal(prRecovery);
                        double drand = OScenario.ORand.NextDouble();
                        if (drand < prR) oind.DzState = DiseaseState.R;
                        else if (drand <= prR + GetObjVal(prReSusceptible)) oind.DzState = DiseaseState.S;
                        else
                        {
                            newDeaths++;
                            oind.alive = false;
                        }
                    }
                    continue;
                }
                if (oind.DzState == DiseaseState.R)
                {
                    if (days >= t) oind.DzState = DiseaseState.S;
                    continue;
                }
                if (oind.DzState == DiseaseState.V)
                {
                    if (days >= t) // worn off
                    {
                        oind.DzState = DiseaseState.S;
                    }
                    else
                    {
                    }
                }
                tallyDz();
            }

            if (moveRandom || moveRules)
            {
                foreach (OIndividual oind in OIndivids)
                {
                    oind.fillIndVars();
                    double prMove = GetObjVal(moveWhen);
                    if (prMove > 0.0 && (prMove >= 1.0 || OScenario.ORand.NextDouble() < prMove))
                    {
                        oind.moveXY();
                    }
                }
            }

            if (useSpatial && spatialDisplayDays > 0)
            {
                if (spatialDisplayDays > 0 && (((year - 1) * nDays + day) % spatialDisplayDays == 0))
                {
//                    Thread spatialPlotThread = new Thread(new ThreadStart(delegate { spatialPlotPoints(); }));

                    //spatialPlotThread.Start();
                    //spatialPlotThread.Join();

                    spatialPlotPoints();
//                    chartSpatialDisplay.Update(); // can't be within a different thread
                }

            }

            return true;
        }


        public int tallyDz()
        {
            double prev = 0.0;

            states = new int[4,6];
            dzstates = new int[6];
            stages = new int[4];

            for(int i = 0; i < OIndivids.Count; i++)
            {
                OIndividual oind = OIndivids[i];

                if (!oind.alive)
                {
                    OIndivids.Remove(oind);
                    if(oind.sex == Sex.Male) AMales.Remove(oind);
                    i--;
                    continue;
                }

                if (oind.age < juvDays)
                {
                    if (oind.DzState == DiseaseState.P) states[0, 0]++;
                    else if (oind.DzState == DiseaseState.S) states[0, 1]++;
                    else if (oind.DzState == DiseaseState.E) states[0, 2]++;
                    else if (oind.DzState == DiseaseState.I) states[0, 3]++;
                    else if (oind.DzState == DiseaseState.R) states[0, 4]++;
                    else if (oind.DzState == DiseaseState.V) states[0, 5]++;
                }
                else if (oind.age < SADays)
                {
                    if (oind.DzState == DiseaseState.P) states[1, 0]++;
                    else if (oind.DzState == DiseaseState.S) states[1, 1]++;
                    else if (oind.DzState == DiseaseState.E) states[1, 2]++;
                    else if (oind.DzState == DiseaseState.I) states[1, 3]++;
                    else if (oind.DzState == DiseaseState.R) states[1, 4]++;
                    else if (oind.DzState == DiseaseState.V) states[1, 5]++;
                }
                else if (oind.sex == Sex.Male)
                {
                    if (oind.DzState == DiseaseState.P) states[2, 0]++;
                    else if (oind.DzState == DiseaseState.S) states[2, 1]++;
                    else if (oind.DzState == DiseaseState.E) states[2, 2]++;
                    else if (oind.DzState == DiseaseState.I) states[2, 3]++;
                    else if (oind.DzState == DiseaseState.R) states[2, 4]++;
                    else if (oind.DzState == DiseaseState.V) states[2, 5]++;
                }
                else //if (oind.sex == Sex.Female)
                {
                    if (oind.DzState == DiseaseState.P) states[3, 0]++;
                    else if (oind.DzState == DiseaseState.S) states[3, 1]++;
                    else if (oind.DzState == DiseaseState.E) states[3, 2]++;
                    else if (oind.DzState == DiseaseState.I) states[3, 3]++;
                    else if (oind.DzState == DiseaseState.R) states[3, 4]++;
                    else if (oind.DzState == DiseaseState.V) states[3, 5]++;
                }
            }

            for (int i = 0; i < 4; i++)
            {
                prev += states[i, 2] + states[i, 3];
                stages[i] += states[i, 0] + states[i, 1] + states[i, 2] + states[i, 3] + states[i, 4] + states[i, 5];
                dzstates[0] += states[i, 0];
                dzstates[1] += states[i, 1];
                dzstates[2] += states[i, 2];
                dzstates[3] += states[i, 3];
                dzstates[4] += states[i, 4];
                dzstates[5] += states[i, 5];
            }

            totalN = OIndivids.Count;
            if (totalN > 0) prevalence = prev / (double)totalN;
            else prevalence = 0.0;

            fillProjVars();

            return totalN;
        }

        public bool outYearly = true;
        public bool outDaily = true;
        public bool outEpiRates = false;
        public bool outIndList = false;
        public bool outIndividuals = false; // not currently used
        public bool outMM = false; // not currently used

        private bool writeIndlist(bool living)
        {
            if (living)
            {
                StreamWriter iWriter = new StreamWriter(OutFolder + "\\indlist_iter_" + m_iter.ToString() + "_yr_" + year.ToString() + ".txt", false);

                iWriter.WriteLine("Prevalence=" + prevalence.ToString());
                iWriter.WriteLine("Index,Age,Sex,DiseaseState,StatePermanent,DaysInState,IsVaccinated,Alive");

                foreach (OIndividual oind in OIndivids)
                {
                    if (!oind.alive) continue;
                    iWriter.WriteLine(oind.OID.ToString() + "," + oind.age.ToString() + "," + oind.iSex.ToString() + "," + oind.iDz.ToString() + "," + (oind.StatePermanent ? "1" : "0") + ","
                        + oind.DaysInState.ToString() + "," + (oind.DzState == DiseaseState.V ? "1" : "0") + ",1");
                }
                iWriter.Close();
            }

            else
            {
                StreamWriter iWriter = new StreamWriter(OutFolder + "\\allindlist_iter_" + m_iter.ToString() + "_yr_" + year.ToString() + ".txt", false);

                iWriter.WriteLine("Prevalence=" + prevalence.ToString());
                iWriter.WriteLine("Index,Age,Sex,DiseaseState,StatePermanent,DaysInState,IsVaccinated,Alive");

                foreach (OIndividual oind in OIndivids)
                {
                    iWriter.WriteLine(oind.OID.ToString() + "," + oind.age.ToString() + "," + oind.iSex.ToString() + "," + oind.iDz.ToString() + "," + (oind.StatePermanent ? "1" : "0") + ","
                        + oind.DaysInState.ToString() + "," + (oind.DzState == DiseaseState.V ? "1" : "0") + "," + (oind.alive ? "1" : "0"));
                }
                iWriter.Close();
            }

            return true;
        }

        private void writeEpiRates()
        {
            epiWriter.Write(dzstates[0].ToString() + "," + dzstates[1].ToString() + "," + dzstates[2].ToString() + "," + dzstates[3].ToString() + "," + dzstates[4].ToString() + "," + dzstates[5].ToString() + "," + m_iter.ToString() + "," + year.ToString() + "," + day.ToString());
            epiWriter.WriteLine("," + newCases.ToString() + "," + newDeaths.ToString());
        }


        //private bool writeDaily()
        //{
        //    yrDailyWriter.WriteLine("Day " + day.ToString());
        //    yrDailyWriter.WriteLine("Prevalence," + prevalence.ToString("0.00000"));
        //    yrDailyWriter.WriteLine("Juveniles," + (states[0, 0]).ToString() + "," + (states[0, 1]).ToString() + "," + (states[0, 2]).ToString() + "," + (states[0, 3]).ToString() + "," + (states[0, 4] + states[0, 5]).ToString());
        //    yrDailyWriter.WriteLine("SubAdults," + (states[1, 0]).ToString() + "," + (states[1, 1]).ToString() + "," + (states[1, 2]).ToString() + "," + (states[1, 3]).ToString() + "," + (states[1, 4] + states[1, 5]).ToString());
        //    yrDailyWriter.WriteLine("Females," + (states[3, 0]).ToString() + "," + (states[3, 1]).ToString() + "," + (states[3, 2]).ToString() + "," + (states[3, 3]).ToString() + "," + (states[3, 4] + states[3, 5]).ToString());
        //    yrDailyWriter.WriteLine("Males," + (states[2, 0]).ToString() + "," + (states[2, 1]).ToString() + "," + (states[2, 2]).ToString() + "," + (states[2, 3]).ToString() + "," + (states[2, 4] + states[2, 5]).ToString());
        //    yrDailyWriter.WriteLine();
        //    yrDailyWriter.Flush();

        //    return true;
        //}

        private bool writeDaily(int y)
        {
            int y1 = y - 1;

            yrDailyWriters[y1].WriteLine("Day " + day.ToString());
            yrDailyWriters[y1].WriteLine("Prevalence," + prevalence.ToString("0.00000"));
            yrDailyWriters[y1].WriteLine("Juveniles," + (states[0, 0]).ToString() + "," + (states[0, 1]).ToString() + "," + (states[0, 2]).ToString() + "," + (states[0, 3]).ToString() + "," + states[0, 4].ToString() + "," + states[0, 5].ToString());
            yrDailyWriters[y1].WriteLine("SubAdults," + (states[1, 0]).ToString() + "," + (states[1, 1]).ToString() + "," + (states[1, 2]).ToString() + "," + (states[1, 3]).ToString() + "," + states[1, 4].ToString() + "," + states[1, 5].ToString());
            yrDailyWriters[y1].WriteLine("Females," + (states[3, 0]).ToString() + "," + (states[3, 1]).ToString() + "," + (states[3, 2]).ToString() + "," + (states[3, 3]).ToString() + "," + states[3, 4].ToString() + "," + states[3, 5].ToString());
            yrDailyWriters[y1].WriteLine("Males," + (states[2, 0]).ToString() + "," + (states[2, 1]).ToString() + "," + (states[2, 2]).ToString() + "," + (states[2, 3]).ToString() + "," + states[2, 4].ToString() + "," + states[2, 5].ToString());
            yrDailyWriters[y1].WriteLine();

            return true;
        }

        private bool writeYearly(int y)
        {
            yrSummaryWriters[y].WriteLine("Prevalence," + prevalence.ToString("0.00000"));
            yrSummaryWriters[y].WriteLine("Juveniles," + (states[0, 0]).ToString() + "," + (states[0, 1]).ToString() + "," + (states[0, 2]).ToString() + "," + (states[0, 3]).ToString() + "," + states[0, 4].ToString() + "," + states[0, 5].ToString());
            yrSummaryWriters[y].WriteLine("SubAdults," + (states[1, 0]).ToString() + "," + (states[1, 1]).ToString() + "," + (states[1, 2]).ToString() + "," + (states[1, 3]).ToString() + "," + states[1, 4].ToString() + "," + states[1, 5].ToString());
            yrSummaryWriters[y].WriteLine("Females," + (states[3, 0]).ToString() + "," + (states[3, 1]).ToString() + "," + (states[3, 2]).ToString() + "," + (states[3, 3]).ToString() + "," + states[3, 4].ToString() + "," + states[3, 5].ToString());
            yrSummaryWriters[y].WriteLine("Males," + (states[2, 0]).ToString() + "," + (states[2, 1]).ToString() + "," + (states[2, 2]).ToString() + "," + (states[2, 3]).ToString() + "," + states[2, 4].ToString() + "," + states[2, 5].ToString());
            yrSummaryWriters[y].WriteLine();

            return true;
        }

        //private bool writeYearly()
        //{
        //    yrSummaryWriter = new StreamWriter(OutFolder + "\\year_summary_" + year.ToString() + ".txt", iter > 1);

        //    yrSummaryWriter.WriteLine("Prevalence," + prevalence.ToString("0.00000"));
        //    yrSummaryWriter.WriteLine("Juveniles," + (states[0, 0]).ToString() + "," + (states[0, 1]).ToString() + "," + (states[0, 2]).ToString() + "," + (states[0, 3]).ToString() + "," + (states[0, 4] + states[0, 5]).ToString());
        //    yrSummaryWriter.WriteLine("SubAdults," + (states[1, 0]).ToString() + "," + (states[1, 1]).ToString() + "," + (states[1, 2]).ToString() + "," + (states[1, 3]).ToString() + "," + (states[1, 4] + states[1, 5]).ToString());
        //    yrSummaryWriter.WriteLine("Females," + (states[3, 0]).ToString() + "," + (states[3, 1]).ToString() + "," + (states[3, 2]).ToString() + "," + (states[3, 3]).ToString() + "," + (states[3, 4] + states[3, 5]).ToString());
        //    yrSummaryWriter.WriteLine("Males," + (states[2, 0]).ToString() + "," + (states[2, 1]).ToString() + "," + (states[2, 2]).ToString() + "," + (states[2, 3]).ToString() + "," + (states[2, 4] + states[2, 5]).ToString());
        //    yrSummaryWriter.WriteLine();

        //    yrSummaryWriter.Close();

        //    return true;
        //}

        private bool vaccinate()
        {
            foreach (OIndividual oind in OIndivids)
            {
                if (oind.DzState == DiseaseState.E || oind.DzState == DiseaseState.I) continue;

                oind.fillIndVars();
                double orand = OScenario.ORand.NextDouble();
                double vEff = GetObjVal(vaccEfficacy);

                if (oind.age < juvDays) // how do we want to define "newborn"? // born within the past nDays
                {
                    if (orand < vEff * GetObjVal(vaccAge0)) oind.DzState = DiseaseState.V;
                }
                else if (oind.age < SADays)
                {
                    if (orand < vEff * GetObjVal(vaccAgeSA)) oind.DzState = DiseaseState.V;
                }
                else
                {
                    if (orand < vEff * GetObjVal(vaccAgeAd)) oind.DzState = DiseaseState.V;
                }
            }

            nowVacc = false;
            vday = 0; // reset the clock for vacc interval

            return true;
        }


        private bool cull()
        {
            foreach (OIndividual oind in OIndivids)
            {
                oind.fillIndVars();

                double orand = OScenario.ORand.NextDouble();

                if (oind.age < juvDays)
                {
                    if (orand < GetObjVal(cullAge0)) { oind.alive = false; }
                }
                else if (oind.age < SADays)
                {
                    if (orand < GetObjVal(cullAgeSA)) { oind.alive = false; }
                }
                else
                {
                    if (orand < GetObjVal(cullAgeAd)) { oind.alive = false; }
                }
            }

            nowCull = false;
            cullday = 0;

            return true;
        }


        // Spatial stuff ...

        private bool usingDIST = false;
        private bool usingCONNECTS = false;
        private bool usingSTEPS = false;
        private bool usingSAME = false;
        private bool usingCONTACT = false;

        private bool checkDistFunc()
        {
            if (DistanceEncounterFunc.ToString().Contains("DIST")) usingDIST = true;
            else usingDIST = false;
            if (DistanceEncounterFunc.ToString().Contains("CONNECT")) usingCONNECTS = true;
            else usingCONNECTS = false;
            if (DistanceEncounterFunc.ToString().Contains("CONTACT")) usingCONTACT = true;
            else usingCONTACT = false;
            if (DistanceEncounterFunc.ToString().Contains("SAME")) usingSAME = true;
            else usingSAME = false;
            if (DistanceEncounterFunc.ToString().Contains("STEPS")) usingSTEPS = true;
            else usingSTEPS = false;

            return true;
        }

        private double XYdistance(OIndividual o1, OIndividual o2)
        {
            return Math.Sqrt((o1.X - o2.X) * (o1.X - o2.X) + (o1.Y - o2.Y) * (o1.Y - o2.Y));
        }
        private bool XYcontact(OIndividual o1, OIndividual o2)
        {
            if (o1.X == o2.X && o1.Y == o2.Y) return false; // Don't count SAME as a CONTACT
            if (o1.X - o2.X > 1.0 || o1.X - o2.X < -1.0) return false;
            if (o1.Y - o2.Y > 1.0 || o1.Y - o2.Y < -1.0) return false;
            return true;
        }
        private bool XYsame(OIndividual o1, OIndividual o2)
        {
            if (o1.X != o2.X || o1.Y != o2.Y) return false;
            return true;
        }
        // min number of connecting cells to traverse
        private int XYconnects(OIndividual o1, OIndividual o2)
        {
            return (int)(Math.Max(Math.Abs(o1.X - o2.X), Math.Abs(o1.Y - o2.Y)));
        }
        // min number of steps in X or Y direction to traverse
        private int XYsteps(OIndividual o1, OIndividual o2)
        {
            return (int)(Math.Abs(o1.X - o2.X) + Math.Abs(o1.Y - o2.Y));
        }

        // randomize an Individual list -- ever needed?
        //private List<OIndividual> randIndivList(List<OIndividual> olist)
        //{
        //    List<OIndividual> list1 = new List<OIndividual>();
        //    List<OIndividual> list2 = new List<OIndividual>();

        //    foreach (OIndividual oind in olist) list1.Add(oind); // use a copy, to be safe

        //    while (list1.Count > 0)
        //    {
        //        int oi = ORand.Next(list1.Count);
        //        list2.Add(list1[oi]);
        //        list1.RemoveAt(oi);
        //    }

        //    return list2;
        //}

        # region DeterministicDemography

        // note that deterministic demography will be only approximate, 
        // because it uses an annual life table, while Outbreak does things on a daily basis

        public double[] lambda0 = new double[4]; // initial estimates, by DzState
        public double[] lambda1 = new double[4]; // Euler solutions

        public double[] sadMale;
        public double[] sadFemale;
        public double[] sadClasses;

        public bool calcLambda()
        {
            double[] Mx = new double[brMaxAge + 1];
            double[] Lx = new double[brMaxAge + 2];
            double[] mLx = new double[brMaxAge + 2]; // needed for S.A.D. calculation
            sadFemale = new double[brMaxAge + 1];
            sadMale = new double[brMaxAge + 1];
            sadClasses = new double[brMaxAge + 1];

            // determine if breeding season is a fixed date, otherwise assume mid year, and determine how far into the year it is
            double propYear = 0.5; 
            if (breedDays.GetType() == typeof(int)) propYear = (double)((int)breedDays) / (double)nDays;           

            for (int z = 0; z < 4; z++)
            {
                mLx[0] = Lx[0] = 1.0; 
                Mx[0] = 0.0;

                double sumLxMx = 0.0;
                double sumxLxMx = 0.0;

                for (int i = 0; i <= brMaxAge; i++)
                {
                    Mx[i] = 0.0;
                    fill0IndVars(i * nDays, z);
                    if(i * nDays < juvDays)
                        mLx[i + 1] = Lx[i + 1] = Lx[i] * (1.0 - limitDouble(GetObjVal(Age0Mort[z]), 0.0, 1.0)); // TODO flag out of limits to user!
                    else if (i * nDays < SADays)
                        mLx[i + 1] = Lx[i + 1] = Lx[i] * (1.0 - limitDouble(GetObjVal(SAMort[z]), 0.0, 1.0));
                    else
                    {
                        if (i < brMaxAge)
                        {
                            Lx[i + 1] = Lx[i] * (1.0 - limitDouble(GetObjVal(AdultFMort[z]), 0.0, 1.0));
                            mLx[i + 1] = mLx[i] * (1.0 - limitDouble(GetObjVal(AdultMMort[z]), 0.0, 1.0));
                        }
                        else
                        {
                            Lx[i + 1] = mLx[i + 1] = 0.0;
                        }
                    }

                    // adjust Lx values to mid year
                    Lx[i] = (1.0 - propYear) * Lx[i] + propYear * Lx[i + 1];
                    mLx[i] = (1.0 - propYear) * mLx[i] + propYear * mLx[i + 1];

                    if (i >= brAge)
                    {
                        Mx[i] = 0.5 * limitDouble(GetObjVal(prBreed[z]), 0.0, 1.0) * GetObjIntVal(nLitters[z]) * GetObjVal(litSize[z]);

                        sumLxMx += Lx[i] * Mx[i];
                        sumxLxMx += Lx[i] * Mx[i] * (double)i;
                    }

                }

                double GT = sumxLxMx / sumLxMx;
                double lamb = Math.Pow(sumLxMx, 1.0 / GT);

                lambda0[z] = lamb;
                lambda1[z] = findlamb(lamb, Mx, Lx);

                // now calculate Cumulative Stable Age Distributions for each sex, represented as a proportion of that age-sex class
                // calculate as end-of-year distribution, with no age class 0?
                // just use S demography, as individuals don't stay in other Dz states long enough to attain SAD
                if (z == 0)
                {
                    double mtot = 0.0;
                    double ftot = 0.0;
                    double jtot = 0.0;
                    double satot = 0.0;

                    for (int i = 0; i <= brMaxAge; i++)
                    {
                        double p = Lx[i] * Math.Pow(lambda1[0], -i);
                        if (i * nDays < juvDays)
                        {
                            jtot += p;
                            sadFemale[i] = jtot;
                        }
                        else if (i * nDays < SADays)
                        {
                            satot += p;
                            sadFemale[i] = satot;
                        }
                        else
                        {
                            ftot += p;
                            sadFemale[i] = ftot;
                            p = mLx[i] * Math.Pow(lambda1[0], -i);
                            mtot += p;
                            sadMale[i] = mtot;
                        }
                    }

                    for (int i = 0; i <= brMaxAge; i++)
                    {
                        if (i * nDays < juvDays)
                        {
                            sadFemale[i] /= jtot;
                            sadMale[i] = sadFemale[i];
                        }
                        else if (i * nDays < SADays)
                        {
                            sadFemale[i] /= satot;
                            sadMale[i] = sadFemale[i];
                        }
                        else
                        {
                            sadFemale[i] /= ftot;
                            sadMale[i] /= mtot;
                        }

                        // now calculate distribution among age classes
                        if (breedDays.ToString() == "1") jtot = 0; // because then there can be no juveniles on Day 1
                        double ttot = jtot + satot + mtot + ftot;
                        sadClasses[0] = jtot / ttot;
                        sadClasses[1] = satot / ttot;
                        sadClasses[3] = ftot / ttot;
                        sadClasses[2] = mtot / ttot;
                    }
                }

            }

            return true;
        }

        private double findlamb(double lamb0, double[] mx, double[] lx)
        {
            double est1 = lamb0;
            double est2 = lamb0;
            double sum = 0.0;

            for (int i = 1; i <= brMaxAge; i++)
            {
                sum += mx[i] * lx[i] / Math.Pow(lamb0, (double)i);  
            }
            if (sum > 1.0) est2 *= sum; // upper estimate
            else est1 *= sum; // lower estimate

            for (int j = 0; j < 1000; j++)
            {
                lamb0 = 0.5 * (est1 + est2);
                sum = 0.0;
                for (int i = 1; i <= brMaxAge; i++) 
                {
                    sum += mx[i] * lx[i] / Math.Pow(lamb0, (double)i);
                }
                if (Math.Abs(sum - 1.0) < 0.00001) return lamb0;
                if (sum > 1.0) est1 = lamb0; // lambda was too small
                else est2 = lamb0;
            }

            return lamb0;
        }

        private bool fill0IndVars(int aig, int idz)
        {
            fillProjVars(); // this also initializes all vars to 0

            // note: female = 0

            vars[0] = aig;
            vars['Z' - 'A'] = idz;

            return true;
        }



        # endregion

        # region functionTools
        public double[] vars = new double[26];
        public double[] specvars = new double[8]; // use for properties of S animal becoming infected! Also specvars[0] is Founder flag
        public double[] gsvars;
        public double[] psvars;
        public double[] isvars;
        public double[,] ppsvars;

        //private object copyObject(object ob)
        //{
        //    if (ob == null) return null;

        //    object newObj = null;

        //    if (ob.GetType() == typeof(Evaluator)) newObj = ((Evaluator)ob).copyEval();
        //    else newObj = ob;

        //    return newObj;
        //}

        public object translateObject(object o)
        {
            try
            {
                if (o == null)
                {
                    o = (double)0;
                    return o;
                }
                if (o.GetType() == typeof(double)) return o;
                if (o.GetType() == typeof(int)) return Convert.ToDouble(o);
                if (o.GetType() == typeof(Evaluator)) return o;

                string s = (string)o;
                s = s.Trim('\"');

                if (s == "Empty" || s == "")
                {
                    o = (double)0;
                    return o;
                }

                if (s[0] == '=')
                {
                    o = new Evaluator(s);
                    setSynons((Evaluator) o);
                }
                else
                {
                    try
                    {
                        o = Convert.ToDouble(s);
                    }
                    catch
                    {
                        o = new Evaluator(s);
                        setSynons((Evaluator)o);
                    }
                }

                return o;
            }
            catch
            {
                return null;
            }
        }

        public object translateIntObject(object o)
        {
            try
            {
                if (o == null)
                {
                    o = (int)0;
                    return o;
                }

                if (o.GetType() == typeof(double)) return (int)o;
                if (o.GetType() == typeof(int)) return (int)o;
                if (o.GetType() == typeof(Evaluator)) return o;

                string s = (string)o;
                s = s.Trim('\"');

                if (s == "Empty" || s == "")
                {
                    o = (int)0;
                    return o;
                }

                if (s[0] == '=')
                {
                    o = new Evaluator(s);
                    setSynons((Evaluator)o);
                }
                else
                {
                    try
                    {
                        o = Convert.ToInt32(s);
                    }
                    catch
                    {
                        try 
                        {
                            double d = Convert.ToDouble(s);
                            o = (int)d;
                        }
                        catch
                        { // assume is a func string
                            o = new Evaluator(s);
                            setSynons((Evaluator)o);
                        }
                    }
                }

                return o;
            }
            catch
            {
                return null;
            }
        }

        public double GetObjVal(object o)
        {
            try
            {
                if (o.GetType() == typeof(double)) return (double)o;
                else if (o.GetType() == typeof(int)) return Convert.ToDouble(o);
                else if (o.GetType() == typeof(Evaluator))
                {
                    Evaluator e = (Evaluator)o;
                    return e.doEval(vars, specvars, gsvars, psvars, isvars, ppsvars);
                }
                else
                {
                    o = translateObject(o);
                    Evaluator e = (Evaluator)o;
                    return e.doEval(vars, specvars, gsvars, psvars, isvars, ppsvars);
                }
            }
            catch
            {
                MessageBox.Show("Error in evaluation of function: " + o.ToString());

                throw new Exception("Bad object");
            }
        }

        public int GetObjIntVal(object o)
        {
            int i;

            try
            {
                if (o.GetType() == typeof(int)) i = (int)o;
                else if (o.GetType() == typeof(double)) i = Convert.ToInt32(o);
                else if (o.GetType() == typeof(Evaluator))
                {
                    Evaluator e = (Evaluator)o;
                    i = Convert.ToInt32(e.doEval(vars, specvars, gsvars, psvars, isvars, ppsvars));
                }
                else
                {
                    o = translateIntObject(o);
                    Evaluator e = (Evaluator)o;
                    i = Convert.ToInt32(e.doEval(vars, specvars, gsvars, psvars, isvars, ppsvars));
                }
            }
            catch
            {
                throw new Exception("Bad object");
            }

            return i;
        }

        public double doEvalO(Evaluator evalO)
        {
            return evalO.doEval(vars, specvars, gsvars, psvars, isvars, ppsvars);
        }

        private bool fillProjVars()
        {
            for (int i = 0; i < 26; i++) vars[i] = 0.0;

            vars['R' - 'A'] = m_iter;
            vars['Y' - 'A'] = year;
            vars['D' - 'A'] = day; // use DIST or E for Euclidean Dist
            vars['J' - 'A'] = stages[0];
            vars['U' - 'A'] = stages[1];
            vars['F' - 'A'] = stages[3];
            vars['M' - 'A'] = stages[2];
            vars['N' - 'A'] = totalN;
            vars['P' - 'A'] = prevalence;
            vars['K' - 'A'] = KNow;

            // A = age
            // B = daysInState
            // C = statepermanent
            // D = day
            // E = Dist
            // F = Ad F
            // G = CONNECTS
            // H = STEPS
            // I = SAME
            // J = juveniles
            // K = K
            // L = CONTACT
            // M = Ad Males
            // N = N
            // O = ID
            // P = Prevalence
            // Q = Mom's Dz
            // R = run
            // S = sex
            // T = Dad's Dz
            // U = subadults
            // V = vaccinated
            // W = Y
            // X = X
            // Y = Year
            // Z = Dz

            return true;
        }
        # endregion

        private void setSynons(Evaluator e)
        {
            e.addSynonymy("PREV", "P");
            e.addSynonymy("RUN", "R");
            e.addSynonymy("DAY", "D");
            e.addSynonymy("YEAR", "Y");
            e.addSynonymy("DIST", "E");
            e.addSynonymy("CONNECTS", "G");
            e.addSynonymy("STEPS", "H");
            e.addSynonymy("SAME", "I");
            e.addSynonymy("CONTACT", "L");
            e.addSynonymy("LITTER", "L");
            e.addSynonymy("ID", "O");
            e.addSynonymy("DAMZ", "Q");
            e.addSynonymy("SIREZ", "T");
            e.addSynonymy("DSTATE", "B");
            e.addSynonymy("CHRONIC", "C");
            e.addSynonymy("SEX", "S");
            e.addSynonymy("AGE", "A");
            e.addSynonymy("XCOORD", "X");
            e.addSynonymy("YCOORD", "W"); // Can't use Y because it stands for Year

            // add specvars to hold properties of S individuals being infected
            e.clearSpecials();
            e.addSpecial("FOUNDER");
            e.addSpecial("SAGE");
            e.addSpecial("SSEX");
            e.addSpecial("SID");
            e.addSpecial("SDSTATE");
            e.addSpecial("SCHRONIC");
            e.addSpecial("SXCOORD");
            e.addSpecial("SYCOORD");

            e.addSynonymy("IXCOORD", "X");
            e.addSynonymy("IYCOORD", "W");
            e.addSynonymy("IAGE", "A");
            e.addSynonymy("ISEX", "S");
            e.addSynonymy("IID", "O");
            e.addSynonymy("IDSTATE", "B");
            e.addSynonymy("ICHRONIC", "C");

        }
    }

    public enum Sex
    {
        Female = 0,
        Male = 1,
        Both = 2,
        Unknown = 3
    }

    public enum DiseaseState
    {
        P = 0,
        S = 1,
        E = 2,
        I = 3,
        R = 4,
        V = 5
    }

    public enum DemogStage
    {
        Juveniles = 0,
        SubAdults = 1,
        AdultMales = 2,
        AdultFemales = 3
    }



    public class OIndividual
    {
        //private static int nID = 0;

        public int OID;
        public int Oname;
        public int MMindex = -1;
//        private Outbreak2 MyOProj;
        private OScenario MyScene;
        public bool alive = true;
        private Sex sx = Sex.Female;
        public int age = 0; // in days
        public OIndividual dam = null;
        public OIndividual sire = null;
        public int X = -1;
        public int Y = -1;
        public double[] isstates;

        private DiseaseState dzState = DiseaseState.S;
        public int DaysInState = 0;
        private int tenure = 0;
        private bool statePermanent = false;

        public int deathDay = 0; // used to store on what day of the year an animal will die. 0 if lives. 

        public OIndividual(OScenario oscene, OIndividual mydam, OIndividual mysire, Sex mysex, int age, int X, int Y)
        {
            makeIndividual(oscene, mydam, mysire, mysex, age, X, Y);
        }

        public OIndividual(OScenario oscene, OIndividual mydam, OIndividual mysire, Sex mysex)
        {
            makeIndividual(oscene, mydam, mysire, mysex, -1, -1, -1);
        }

        public OIndividual(OScenario oscene)
        {
            makeIndividual(oscene, null, null, Sex.Unknown, -1, -1, -1);
        }

        public void makeIndividual(OScenario oscene, OIndividual mydam, OIndividual mysire, Sex mysex, int myage, int myX, int myY)
        {
//            MyOProj = oproj;
            MyScene = oscene;
            MyScene.nID++;
            OID = MyScene.nID; // so starts with 1
            Oname = OID; // default, but can be set differently by MMM

            isstates = new double[MyScene.isVarNames.Count];

            if (mysex == Sex.Unknown)
            {
                if (OScenario.ORand.Next(2) == 0) sx = Sex.Male;
            }
            else sx = mysex;

            if (myage >= 0) age = myage;

            if (mydam != null)
            {
                if (myX != -1) X = myX;
                else X = mydam.X;
                if (myY != -1) Y = myY;
                else Y = mydam.Y;

                dam = mydam;
                sire = mysire;

                for (int i = 0; i < MyScene.isVarNames.Count; i++) isstates[i] = mydam.isstates[i]; // initially, inherit isvars from dam

                if (mydam.DzState == DiseaseState.I)
                {
                    mydam.fillIndVars(); // using dam's vars to set maternal transmission
                    double prT = MyScene.GetObjVal(MyScene.prMaternalTransmission);
                    if (prT > 0.0 && prT > OScenario.ORand.NextDouble()) DzState = DiseaseState.E;
                }
                else if (mydam.DzState == DiseaseState.R && MyScene.MaternalR)
                {
                    mydam.fillIndVars(); // note that we are using dam's vars to set tenure
                    dzState = DiseaseState.R;
                    tenure = MyScene.GetObjIntVal(MyScene.DaysMaternalR);
                }
                else
                {
                    fillIndVars(); // added 15 May 2015, so SireZ and DamZ available

                    DzState = DiseaseState.P;  // statePermanent and tenure set in here
                    if (!statePermanent)
                    {
                        if (tenure <= DaysInState) DzState = DiseaseState.S;
                    }
                }

            }
            else if (myX != -1 && myY != -1) // use X, Y if provided
            {
                X = myX;
                Y = myY;
            }
            else
            {  // seed X,Y
                if (MyScene.gridSeed)
                {
                    X = OScenario.ORand.Next(MyScene.gridXmin, MyScene.gridXmax + 1);
                    Y = OScenario.ORand.Next(MyScene.gridYmin, MyScene.gridYmax + 1);
                }
                else
                {
                    // determine from funcs
                    fillIndVars();
                    X = MyScene.GetObjIntVal(MyScene.gridXseed);
                    Y = MyScene.GetObjIntVal(MyScene.gridYseed);

                    if (MyScene.gridBoundaryAbsorbs)
                    {
                        if (X < MyScene.gridXmin) X = MyScene.gridXmin;
                        if (X > MyScene.gridXmax) X = MyScene.gridXmax;
                        if (Y < MyScene.gridYmin) Y = MyScene.gridYmin;
                        if (Y > MyScene.gridYmax) Y = MyScene.gridYmax;
                    }
                    else if (MyScene.gridBoundaryReflects)
                    {
                        if (X < MyScene.gridXmin) X = 2 * MyScene.gridXmin - X;
                        if (X > MyScene.gridXmax) X = 2* MyScene.gridXmax - X;
                        if (Y < MyScene.gridYmin) Y = 2 * MyScene.gridYmin - Y;
                        if (Y > MyScene.gridYmax) Y = 2 * MyScene.gridYmax - Y;
                    }
                }
            }

        }

        public int Tenure { get { return tenure; }
            set
            { // extended 8 Jan 2014 to account for posibility that external program won't have set tenure, indicated by value = -1
                if (value >= 0) tenure = value;
                else
                {
                    if (statePermanent) tenure = 0; // tenure not used

                    else if (dzState == DiseaseState.P)
                    {
                        tenure = MyScene.GetObjIntVal(MyScene.DaysP);
                    }
                    else if (dzState == DiseaseState.S)
                    {
                        tenure = 0; // not used
                    }
                    else if (dzState == DiseaseState.E)
                    {
                        tenure = MyScene.GetObjIntVal(MyScene.DaysE);
                    }
                    else if (dzState == DiseaseState.I)
                    {
                        tenure = MyScene.GetObjIntVal(MyScene.DaysI);
                    }
                    else if (dzState == DiseaseState.R)
                    {
                        tenure = MyScene.GetObjIntVal(MyScene.DaysR);
                    }
                    else if (dzState == DiseaseState.V)
                    {
                        tenure = MyScene.GetObjIntVal(MyScene.vaccDuration);
                        if (tenure == 0) statePermanent = true;
                    }
                }
            } 
        }

        public bool StatePermanent { get { return statePermanent; } set { statePermanent = value; } }
        public bool isVaccinated { get { return (dzState == DiseaseState.V); } }

        public int iSex
        {
            get { if (sx == Sex.Male) return 1; else return 0; }
            set { if (value == 1) sx = Sex.Male; else sx = Sex.Female; }
        }

        public Sex sex
        {
            get { return sx; }
            set { sx = value; }
        }

        public int iDz
        {
            get
            {
                return (int)dzState;
                //if (dzState == DiseaseState.P) return 0;
                //else if (dzState == DiseaseState.S) return 1;
                //else if (dzState == DiseaseState.E) return 2;
                //else if (dzState == DiseaseState.I) return 3;
                //else return 4;
            }
            set
            {
                dzState = (DiseaseState)value;
            }
        }

        public int i4Dz // lumps P with S
        {
            get
            {
                if (dzState == DiseaseState.P) return 0;
                else if (dzState == DiseaseState.S) return 0;
                else if (dzState == DiseaseState.E) return 1;
                else if (dzState == DiseaseState.I) return 2;
                else return 3;
            }
            set
            {
                dzState = (DiseaseState)(value + 1);
            }
        }

        public DiseaseState DzState
        {
            get { return dzState;  }
            set 
            {
                fillIndVars();

                DaysInState = 0;

                if (value == DiseaseState.P)
                {
                    double prP = MyScene.GetObjVal(MyScene.prPermanentP);
                    if (prP >= 1.0) statePermanent = true;
                    else if (prP > 0.0 && OScenario.ORand.NextDouble() <  prP) statePermanent = true; 
                    else
                    {
                        statePermanent = false;
                        tenure = MyScene.GetObjIntVal(MyScene.DaysP);
                    }
                }
                else if (value == DiseaseState.S)
                {
                }
                else if (value == DiseaseState.E)
                {
                    if(dzState != DiseaseState.E) MyScene.newCases++;

                    tenure = MyScene.GetObjIntVal(MyScene.DaysE);
                    statePermanent = false;
                }
                else if (value == DiseaseState.I)
                {
                    double prP = MyScene.GetObjVal(MyScene.prPermanentI);
                    if (prP >= 1.0) statePermanent = true;
                    else if (prP > 0.0 && OScenario.ORand.NextDouble() <  prP) statePermanent = true;
                    else
                    {
                        statePermanent = false;
                        tenure = MyScene.GetObjIntVal(MyScene.DaysI);
                    }
                }
                else if (value == DiseaseState.R)
                {
                    double prP = MyScene.GetObjVal(MyScene.prPermanentR);
                    if (prP >= 1.0) statePermanent = true;
                    else if (prP > 0.0 && OScenario.ORand.NextDouble() <  prP) 
                    {
                        statePermanent = true;
                    }
                    else
                    {
                        statePermanent = false;
                        tenure = MyScene.GetObjIntVal(MyScene.DaysR);
                    }
                }
                else if (value == DiseaseState.V)
                {
                    int priorTenure = tenure;
                    tenure = MyScene.GetObjIntVal(MyScene.vaccDuration);
                    if (tenure == 0) statePermanent = true;
                    else if (dzState == DiseaseState.R) // was already Resistant
                    {
                        // statePermanent left as it was in R
                        if (statePermanent) tenure = 0;
                        else if (tenure < priorTenure) tenure = priorTenure; // don't let V shorten resistance
                    }
                    else statePermanent = false;
                }

                dzState = value;
            }
        }

        //public bool isVaccinated { 
        //    get { return DzState == DiseaseState.V; } 
        //    set { if(value) DzState = DiseaseState.V; } }

        public int DamID { get {
            if (dam != null) return dam.OID;
            else return 0;
        } }
        public int SireID { get {
            if (sire != null) return sire.OID;
            else return 0;
        } }

        public OIndividual Dam { get { return dam; } set { dam = value; } }
        public OIndividual Sire { get { return sire; } set { sire = value; } }

//        public int BreedDay = -1;
        public List<int> BreedDays = new List<int>();

        //public double GetMort()
        //{
        //    double mort = 0.0;

        //    fillIndVars();

        //    if (age < MyScene.juvDays)
        //    {
        //        mort = MyScene.GetObjVal(MyScene.Age0Mort[i4Dz]);
        //    }
        //    else if (age < MyScene.SADays)
        //    {
        //        mort = MyScene.GetObjVal(MyScene.SAMort[i4Dz]);
        //    }
        //    else if (sex == Sex.Male)
        //    {
        //        mort = MyScene.GetObjVal(MyScene.AdultMMort[i4Dz]);
        //    }
        //    else
        //    {
        //        mort = MyScene.GetObjVal(MyScene.AdultFMort[i4Dz]);
        //    }

        //    mort = 1.0 - Math.Pow((1.0 - mort),(1.0 / MyScene.nDays));

        //    return mort;
        //}



        public bool fillIndVars()
        {
            MyScene.vars[0] = (double)age;
            MyScene.vars['S' - 'A'] = (int)sx;
            //if (sx == Sex.Male) MyOProj.vars['S' - 'A'] = 1;
            //else MyOProj.vars['S' - 'A'] = 0;

            MyScene.vars['Z' - 'A'] = iDz;
            //if (dzState == DiseaseState.P) MyOProj.vars['Z' - 'A'] = 0;
            //else if (dzState == DiseaseState.S) MyOProj.vars['Z' - 'A'] = 1;
            //else if (dzState == DiseaseState.E) MyOProj.vars['Z' - 'A'] = 2;
            //else if (dzState == DiseaseState.I) MyOProj.vars['Z' - 'A'] = 3;
            //else if (dzState == DiseaseState.R) MyOProj.vars['Z' - 'A'] = 4;
            //else if (dzState == DiseaseState.V) MyOProj.vars['Z' - 'A'] = 4;

            if (dzState == DiseaseState.V) MyScene.vars['V' - 'A'] = 1;
            else MyScene.vars['V' - 'A'] = 0;
            
            MyScene.vars['X' - 'A'] = (double)X;
            MyScene.vars['W' - 'A'] = (double)Y; // Y would conflict w Year

            if (statePermanent) MyScene.vars['C' - 'A'] = 1; // C for chronic
            else MyScene.vars['C' - 'A'] = 0;

            MyScene.vars['B' - 'A'] = (double)DaysInState;

            MyScene.vars['O' - 'A'] = (double)OID;

            if (dam != null)
            {
                MyScene.vars['Q' - 'A'] = dam.iDz;
                MyScene.specvars[0] = 0.0;
            }
            else
            {
                MyScene.vars['Q' - 'A'] = -1;
                MyScene.specvars[0] = 1.0;
            }
            if (sire != null) MyScene.vars['T' - 'A'] = sire.iDz;
            else MyScene.vars['T' - 'A'] = -1;

            for (int i = 0; i < MyScene.isVarNames.Count; i++) MyScene.isvars[i] = isstates[i];

            return true;
        }

        // 14 May 2015
        public bool fillSvars()
        {
            MyScene.specvars[1] = (double)age;
            MyScene.specvars[2] = (int)sx;
            MyScene.specvars[3] = (double)OID;
            MyScene.specvars[4] = (double)DaysInState;
            if (statePermanent) MyScene.specvars[5] = 1; // C for chronic
            else MyScene.specvars[5] = 0;
            MyScene.specvars[6] = X;
            MyScene.specvars[7] = Y;

            // TODO -- later add ISvars too!

            return true;
        }

        public bool moveXY()
        {
//            fillIndVars(); // already done outside of moveXY call

            if (MyScene.moveRandom)
            {
                double dist = MyScene.GetObjVal(MyScene.moveDist);

                    double direction = 6.2831853 * OScenario.ORand.NextDouble(); // selects a direction from 0 to 2*PI
                    double xdist = Math.Cos(direction) * dist;
                    double ydist = Math.Sin(direction) * dist;

                    X += probRound(xdist); // (int)(xdist + 0.5);
                    Y += probRound(ydist); // (int)(ydist + 0.5);
            }
            else if (MyScene.moveRules)
            {
                // determine from funcs
                X = MyScene.GetObjIntVal(MyScene.moveXrule);
                Y = MyScene.GetObjIntVal(MyScene.moveYrule);
            }

            // boundaries
            if (MyScene.gridBoundaryAbsorbs)
            {
                if (X < MyScene.gridXmin) X = MyScene.gridXmin;
                if (X > MyScene.gridXmax) X = MyScene.gridXmax;
                if (Y < MyScene.gridYmin) Y = MyScene.gridYmin;
                if (Y > MyScene.gridYmax) Y = MyScene.gridYmax;
            }
            else if (MyScene.gridBoundaryReflects)
            {
                X = XYreflection(MyScene.gridXmin, MyScene.gridXmax, X);
                Y = XYreflection(MyScene.gridYmin, MyScene.gridYmax, Y);
            }

            return true;
        }

        private int XYreflection(int min, int max, int val)
        {
            if (val < min)
            {
                val = 2 * min - val;
                if (val > max) val = max;
                else if (val < min) val = min;
            }
            else if (val > max)
            {
                val = 2 * max - val;
                if (val > max) val = max;
                else if (val < min) val = min;
            }
            return val;
        }

        // probabilistic rounding
        public int probRound(double val)
        {
            int ival = (int)val;
            double diff = val - (double)ival;
            if(diff > 0)
            {
                if (OScenario.ORand.NextDouble() < diff) ival++;
            }
            else if (diff < 0 && OScenario.ORand.NextDouble() < -diff) ival--;

            return ival;
        }
    }
}
