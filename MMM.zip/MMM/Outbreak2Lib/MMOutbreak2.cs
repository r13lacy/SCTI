﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using EvaluatorLibrary;
using MMMCore;

namespace Outbreak2
{
    public class MMOutbreak2
    {
//        public List<Outbreak2> OPops = new List<Outbreak2>();

        public Outbreak2 OP;
        public OScenario Opop;
        private MDataSet mdata;
        private MPopulation mpop;
        private int MMDay = 0;
        private bool MMdoDemog = true;

//        private List<int> whichPops = new List<int>();

        public MMOutbreak2()
        {
        }

        public MMOutbreak2(bool dodemog)
        {
            MMdoDemog = dodemog;
        }

        public bool Initialize(MDataSet data, MPopulation pop, string O2File, int scndx, int iterations, int years, int days)
        {
            string MMOName = "";

            mpop = pop;
            mdata = data;

            // temporary filler, until decide how to pass list of populations from MMM
            //whichPops = new List<int>();
            //for (int p = 0; p < mdata.Populations.Count; p++) whichPops.Add(p);

//            OPops.Clear();
//            for (int i = 0; i < whichPops.Count; i++)
//            {
//                int p = whichPops[i];

                OP = new Outbreak2(null, MMdoDemog);

                if (!OP.readOfile(O2File))
                {
                    MessageBox.Show("Error reading Outbreak file: " + O2File);
                    return false;
                }

                Opop = OP.Oscenes[scndx]; 
                if (OP.nscenes > 1)
                {
                    MMOName = OP.Oscenes[scndx].SceneName;
                    OP.OName += "_" + pop.Name;
                }

                //if (mdata.Populations.Count > 1)
                //{
                //    if (i == 0) MMOName = Opop.OName;

                //    Opop.OName = MMOName + "_Pop" + (p + 1).ToString();
                //}

                else OP.OName += "_" + MMOName + "_" + pop.Name;

                Opop.nRuns = iterations;
                Opop.nYears = years;
                if(days > 0) Opop.nDays = days;
                MMDay = 1;

//                OPops.Add(Opop);
                
                // get core vars from MData
                IDindex = pop.IDindex;
                NameIndex = pop.NameIndex;
                SexIndex = pop.SexIndex;
                AgeIndex = pop.AgeIndex;
                AliveIndex = pop.AliveIndex;

                //IDindex = pop.GetIndividualVarIndex("Index");
                //NameIndex = pop.GetIndividualVarIndex("Name");
                //AgeIndex = pop.GetIndividualVarIndex("Age");
                //AliveIndex = pop.GetIndividualVarIndex("Alive");
                //SexIndex = pop.GetIndividualVarIndex("Sex");

                //if (NameIndex < 0) NameIndex = pop.AddIndVar("Name", "");
                //if (IDindex < 0) IDindex = pop.AddIndVar("Index", "");
                //if (AgeIndex < 0) AgeIndex = pop.AddIndVar("Age", "");
                //if (SexIndex < 0) SexIndex = pop.AddIndVar("Sex", "");
                //if (AliveIndex < 0) AliveIndex = pop.AddIndVar("Alive", "0");

                DamIndex = pop.GetIndividualVarIndex("Dam");
                if (DamIndex < 0) DamIndex = pop.AddIndVar("Dam", "");
                SireIndex = pop.GetIndividualVarIndex("Sire");
                if (SireIndex < 0) SireIndex = pop.AddIndVar("Sire", "");
                
            return true;
        }


        public bool MMStartOutbreak() //MDataSet mdata) // only called for Outbreak system model
        {
            //for (int p = 0; p < mdata.Populations.Count; p++)
            //{
//                Outbreak2 OPop = OPops[p];

//                MMMCore.MPopulation pop = mdata.Populations[p];

                // Dz vars declared here (if using Outbreak as a System model), because need to have before initial call to MMPutBack()

                string dzTag = "-" + OP.DzTag;
                if (OP.DzTag.Trim() == "") dzTag = "";

                PrevIndex = mpop.GetVarIndex("Prevalence" + dzTag);
                if (PrevIndex < 0) PrevIndex = mpop.AddVar("Prevalence" + dzTag, "0");

                Nindex = mpop.GetVarIndex("N");
                if (Nindex < 0) Nindex = mpop.AddVar("N", "0");

                nPindex = mpop.GetVarIndex("nP" + dzTag);
                if (nPindex < 0) nPindex = mpop.AddVar("nP" + dzTag, "0");

                nSindex = mpop.GetVarIndex("nS" + dzTag);
                if (nSindex < 0) nSindex = mpop.AddVar("nS" + dzTag, "0");

                nEindex = mpop.GetVarIndex("nE" + dzTag);
                if (nEindex < 0) nEindex = mpop.AddVar("nE" + dzTag, "0");

                nIindex = mpop.GetVarIndex("nI" + dzTag);
                if (nIindex < 0) nIindex = mpop.AddVar("nI" + dzTag, "0");

                nRindex = mpop.GetVarIndex("nR" + dzTag);
                if (nRindex < 0) nRindex = mpop.AddVar("nR" + dzTag, "0");

                nVindex = mpop.GetVarIndex("nV" + dzTag);
                if (nVindex < 0) nVindex = mpop.AddVar("nV" + dzTag, "0");


                DzStateIndex = mpop.GetIndividualVarIndex("DiseaseState" + dzTag);
//                if (DzStateIndex < 0) DzStateIndex = mpop.GetIndividualVarIndex("DzState" + dzTag);
                if (DzStateIndex < 0) DzStateIndex = mpop.GetIndividualVarIndex("DiseaseState");
//                if (DzStateIndex < 0) DzStateIndex = mpop.GetIndividualVarIndex("DzState");
                if (DzStateIndex < 0) DzStateIndex = mpop.AddIndVar("DiseaseState" + dzTag, "0");

                DaysIndex = mpop.GetIndividualVarIndex("DaysInState" + dzTag);
                if (DaysIndex < 0) DaysIndex = mpop.GetIndividualVarIndex("DaysInState");
                if (DaysIndex < 0) DaysIndex = mpop.AddIndVar("DaysInState" + dzTag, "0");

                TenureIndex = mpop.GetIndividualVarIndex("Tenure" + dzTag);
                if (TenureIndex < 0) TenureIndex = mpop.GetIndividualVarIndex("Tenure");
                if (TenureIndex < 0) TenureIndex = mpop.AddIndVar("Tenure" + dzTag, "-1");

                VaccIndex = mpop.GetIndividualVarIndex("IsVaccinated" + dzTag);
                if (VaccIndex < 0) VaccIndex = mpop.GetIndividualVarIndex("IsVaccinated");
                if (VaccIndex < 0) VaccIndex = mpop.AddIndVar("IsVaccinated" + dzTag, "0");

                DzPermanentIndex = mpop.GetIndividualVarIndex("StatePermanent" + dzTag);
                if (DzPermanentIndex < 0) DzPermanentIndex = mpop.GetIndividualVarIndex("StatePermanent");
                if (DzPermanentIndex < 0) DzPermanentIndex = mpop.AddIndVar("StatePermanent" + dzTag, "0");

                Xindex = mpop.GetIndividualVarIndex("X");
                if (Xindex < 0) Xindex = mpop.GetIndividualVarIndex("XCOORD");
                Yindex = mpop.GetIndividualVarIndex("Y");
                if (Yindex < 0) Yindex = mpop.GetIndividualVarIndex("YCOORD");
                if (Xindex < 0) Xindex = mpop.AddIndVar("X", "-1");
                if (Yindex < 0) Yindex = mpop.AddIndVar("Y", "-1");

                
                if (!Opop.makePop() || !MMputBack(Opop))
                {
                    MessageBox.Show("Year0 Failed in Outbreak System Model.");
                    return false;
                }
            //}

            return true;
        }

        private int lastRun = 0;
        private int lastYear = 0;

        public bool Simulate(MMMCore.MPopulation mpop, int iter, int year, int numTimeSteps)
        {
            if (year == 0 && MMDay == 1)
            {
                if (iter == 0) MMRun0(numTimeSteps);
                MMYear0(iter, numTimeSteps);
            }

            MMYear(iter, year, numTimeSteps);

            if (iter > lastRun) lastRun = iter;
            if (year > lastYear) lastYear = year;

            return true;
        }


        public bool CloseDLL()
        {
//            for (int p = 0; p < mdata.Populations.Count; p++)
//            {
//                Outbreak2 Opop = OPops[p];

                if (Opop.nRuns > lastRun + 1) Opop.nRuns = lastRun + 1;
                if (Opop.nYears > lastYear + 1) Opop.nYears = lastYear + 1;

                Opop.endRun();

                //if(mdata.Populations.Count > 1) 
                    OP.saveXML(OP.ProjFolder + OP.OName, false); // so that can easily read results for each population in Outbreak
  //          }            

            return true;
        }

        private int NameIndex = -1;
        private int IDindex = -1;
        private int DaysIndex = -1;
        private int VaccIndex = -1;
        private int AgeIndex = -1;
        private int DzStateIndex = -1;
        private int DzPermanentIndex = -1;
        private int Xindex = -1;
        private int Yindex = -1;
        private int DamIndex = -1;
        private int SireIndex = -1;
        private int SexIndex = -1;
        private int AliveIndex = -1;
        private int TenureIndex = -1;

        // Pop Level things, esp for O as a system model
        private int PrevIndex = -1;
        private int Nindex = -1;
        private int nPindex = -1;
        private int nSindex = -1;
        private int nEindex = -1;
        private int nIindex = -1;
        private int nRindex = -1;
        private int nVindex = -1;

        private List<int> ISindex;

        private void MMRun0(int numTimeSteps) // keep separate from Initialize, because need to be sure that all models have declared their MM variables first
        {
            //for (int p = 0; p < mdata.Populations.Count; p++)
            //{
            //    Outbreak2 Opop = OPops[p];

                Opop.startRuns();
            //}
        }


        private void MMYear0(int iter, int numTimeSteps) // keep separate from Initialize, because need to be sure that all models have declared their MM variables first
        {
            //for (int p = 0; p < mdata.Populations.Count; p++)
            //{
            //    Outbreak2 Opop = OPops[p];
                Opop.Iter = iter + 1;

//                MMMCore.MPopulation pop = mdata.Populations[p];

                Opop.gsVarNames.Clear();
            
                for (int i = 0; i < mdata.Vars.Count; i++)
                {
                    Opop.gsVarNames.Add(mdata.VarNames[i]);
                }
                Opop.gsvars = new double[mdata.Vars.Count];

                Opop.psVarNames.Clear();

                //if (!MMdoDemog)
                //{
                    string dzTag = "-" + OP.DzTag;
                    if (OP.DzTag.Trim() == "") dzTag = "";

                    if (MMdoDemog)
                    {
                        Nindex = mpop.GetVarIndex("N");
                        if (Nindex < 0) Nindex = mpop.AddVar("N", "0");
                    }

                    PrevIndex = mpop.GetVarIndex("Prevalence" + dzTag);
                    if (PrevIndex < 0) PrevIndex = mpop.AddVar("Prevalence" + dzTag, "0"); 

                    // Do we want to add any other PopVars from Outbreak? 
                    nPindex = mpop.GetVarIndex("nP" + dzTag);
                    if (nPindex < 0) nPindex = mpop.AddVar("nP" + dzTag, "0");

                    nSindex = mpop.GetVarIndex("nS" + dzTag);
                    if (nSindex < 0) nSindex = mpop.AddVar("nS" + dzTag, "0");

                    nEindex = mpop.GetVarIndex("nE" + dzTag);
                    if (nEindex < 0) nEindex = mpop.AddVar("nE" + dzTag, "0");

                    nIindex = mpop.GetVarIndex("nI" + dzTag);
                    if (nIindex < 0) nIindex = mpop.AddVar("nI" + dzTag, "0");

                    nRindex = mpop.GetVarIndex("nR" + dzTag);
                    if (nRindex < 0) nRindex = mpop.AddVar("nR" + dzTag, "0");

                    nVindex = mpop.GetVarIndex("nV" + dzTag);
                    if (nVindex < 0) nVindex = mpop.AddVar("nV" + dzTag, "0");


                    DzStateIndex = mpop.GetIndividualVarIndex("DiseaseState" + dzTag);
                    if (DzStateIndex < 0) DzStateIndex = mpop.GetIndividualVarIndex("DiseaseState");
                    if (DzStateIndex < 0) DzStateIndex = mpop.AddIndVar("DiseaseState" + dzTag, "0");

                    DaysIndex = mpop.GetIndividualVarIndex("DaysInState" + dzTag);
                    if(DaysIndex < 0) DaysIndex = mpop.GetIndividualVarIndex("DaysInState");
                    if (DaysIndex < 0) DaysIndex = mpop.AddIndVar("DaysInState" + dzTag, "0");

                    TenureIndex = mpop.GetIndividualVarIndex("Tenure" + dzTag);
                    if (TenureIndex < 0) TenureIndex = mpop.GetIndividualVarIndex("Tenure");
                    if (TenureIndex < 0) TenureIndex = mpop.AddIndVar("Tenure" + dzTag, "-1"); // -1 is code for not set

                    VaccIndex = mpop.GetIndividualVarIndex("IsVaccinated" + dzTag);
                    if (VaccIndex < 0) VaccIndex = mpop.GetIndividualVarIndex("IsVaccinated");
                    if (VaccIndex < 0) VaccIndex = mpop.AddIndVar("IsVaccinated" + dzTag, "0");

                    DzPermanentIndex = mpop.GetIndividualVarIndex("StatePermanent" + dzTag);
                    if (DzPermanentIndex < 0) DzPermanentIndex = mpop.GetIndividualVarIndex("StatePermanent");
                    if (DzPermanentIndex < 0) DzPermanentIndex = mpop.AddIndVar("StatePermanent" + dzTag, "0");
                    
                    Xindex = mpop.GetIndividualVarIndex("X");
                    if (Xindex < 0) Xindex = mpop.GetIndividualVarIndex("XCOORD");
                    Yindex = mpop.GetIndividualVarIndex("Y");
                    if (Yindex < 0) Yindex = mpop.GetIndividualVarIndex("YCOORD");
                    if (Xindex < 0) Xindex = mpop.AddIndVar("X", "-1");
                    if (Yindex < 0) Yindex = mpop.AddIndVar("Y", "-1");
                    
                //}


                for (int i = 0; i < mpop.Vars.Count; i++)
                {
                    if (i == PrevIndex) continue;
                    if (i == Nindex) continue;
                    if (i == nPindex) continue;
                    if (i == nSindex) continue;
                    if (i == nEindex) continue;
                    if (i == nIindex) continue;
                    if (i == nRindex) continue;
                    if (i == nVindex) continue;
                    Opop.psVarNames.Add(mpop.VarNames[i]);
                }
                Opop.psvars = new double[Opop.psVarNames.Count];

                Opop.isVarNames.Clear();
                Opop.isvars = new double[mpop.IndVarNames.Count];
                ISindex = new List<int>();

                for (int i = 0; i < mpop.IndVarNames.Count; i++)
                {
                    if (i == IDindex) continue;
                    if (i == NameIndex) continue;
                    if (i == DamIndex) continue;
                    if (i == SireIndex) continue;
                    if (i == DaysIndex) continue;
                    if (i == TenureIndex) continue;
                    if (i == VaccIndex) continue;
                    if (i == AgeIndex) continue;
                    if (i == SexIndex) continue;
                    if (i == AliveIndex) continue;
                    if (i == DzStateIndex) continue;
                    if (i == DzPermanentIndex) continue;
                    if (i == Xindex) continue;
                    if (i == Yindex) continue;

                    Opop.isVarNames.Add(mpop.IndVarNames[i]);
                    ISindex.Add(i);
                }

                addSVsynons(Opop.prPermanentP);
                addSVsynons(Opop.DaysP);
                addSVsynons(Opop.DaysMaternalR);
                addSVsynons(Opop.prPopEncounter);
                addSVsynons(Opop.NEncounter);
                addSVsynons(Opop.DistanceEncounterFunc);
                addSVsynons(Opop.prTransmission);
                addSVsynons(Opop.prOutsideEncounter);
                addSVsynons(Opop.prOutsideTransmission);
                addSVsynons(Opop.prMaternalTransmission);
                addSVsynons(Opop.DaysE);
                addSVsynons(Opop.prPermanentI);
                addSVsynons(Opop.DaysI);
                addSVsynons(Opop.prRecovery);
                addSVsynons(Opop.prReSusceptible);
                addSVsynons(Opop.prDeath);
                addSVsynons(Opop.prPermanentR);
                addSVsynons(Opop.DaysR);
                addSVsynons(Opop.vaccDays);
                addSVsynons(Opop.vaccDaysStart);
                addSVsynons(Opop.vaccPrev);
                addSVsynons(Opop.vaccAge0);
                addSVsynons(Opop.vaccAgeAd);
                addSVsynons(Opop.vaccAgeSA);
                addSVsynons(Opop.vaccEfficacy);
                addSVsynons(Opop.vaccDuration);
                addSVsynons(Opop.cullDays);
                addSVsynons(Opop.cullDaysStart);
                addSVsynons(Opop.cullPrev);
                addSVsynons(Opop.cullAge0);
                addSVsynons(Opop.cullAgeSA);
                addSVsynons(Opop.cullAgeAd);
                addSVsynons(Opop.gridSeed);
                addSVsynons(Opop.gridYseed);
                addSVsynons(Opop.moveWhen);
                addSVsynons(Opop.moveDist);
                addSVsynons(Opop.moveXrule);
                addSVsynons(Opop.moveYrule);
                if (Opop.doDemog) for (int i = 0; i < 4; i++)
                {
                    addSVsynons(Opop.breedDays);
                    addSVsynons(Opop.K);
                    addSVsynons(Opop.Age0Mort[i]);
                    addSVsynons(Opop.SAMort[i]);
                    addSVsynons(Opop.AdultMMort[i]);
                    addSVsynons(Opop.AdultFMort[i]);
                    addSVsynons(Opop.prBreed);
                    addSVsynons(Opop.nLitters);
                    addSVsynons(Opop.litSize);
                }

            //}
        }


        private void addSVsynons(object oo)
        {
            if (oo.GetType() != typeof(Evaluator)) return;
            Evaluator e = (Evaluator)oo;

            // add any PSvar and GSvar names that came from MMM
            for (int i = 0; i < Opop.psVarNames.Count; i++)
                e.addSynonymy(Opop.psVarNames[i], "PS" + (i + 1).ToString());
            for (int i = 0; i < Opop.gsVarNames.Count; i++)
                e.addSynonymy(Opop.gsVarNames[i], "GS" + (i + 1).ToString());
            for (int i = 0; i < Opop.isVarNames.Count; i++)
                e.addSynonymy(Opop.isVarNames[i], "IS" + (i + 1).ToString());
        }


        private OIndividual findInd(int ID)
        {
            foreach (OIndividual oi in Opop.OIndivids)
            {
                if (oi.Oname == ID) return oi;
            }
            return null;
        }

        private void MMYear(int iter, int yr, int numtimesteps)
        {
            //for (int p = 0; p < mdata.Populations.Count; p++)
            //{
            //    MMMCore.MPopulation mpop = mdata.Populations[p];

                //Outbreak2 Opop = OPops[p];
                Opop.Iter = iter + 1;
                
                for (int g = 0; g < Opop.gsVarNames.Count; g++)
                {
//                    int gindex = mpop.GetVarIndex(Opop.gsVarNames[g]); // was looking in the wrong place for GSvars 27 Nov 2015
                    int gindex = mdata.GetVarIndex(Opop.gsVarNames[g]);
                    if (gindex < 0) Opop.gsvars[g] = 0.0;
                    else
                    {
                        //Opop.gsvars[g] = Convert.ToDouble(mdata.Vars[gindex]);
                        Opop.gsvars[g] = mdata.GetVarDouble(gindex);
                    }   
                }

                for (int v = 0; v < Opop.psVarNames.Count; v++)
                {
                        string dzTag = "-" + OP.DzTag;
                        if (OP.DzTag.Trim() == "") dzTag = "";

                        if (Opop.psVarNames[v] == "Prevalence" + dzTag) continue;
                        if (Opop.psVarNames[v] == "N") continue;
                        if (Opop.psVarNames[v] == "nP" + dzTag) continue;
                        if (Opop.psVarNames[v] == "nS" + dzTag) continue;
                        if (Opop.psVarNames[v] == "nE" + dzTag) continue;
                        if (Opop.psVarNames[v] == "nI" + dzTag) continue;
                        if (Opop.psVarNames[v] == "nR" + dzTag) continue;
                        if (Opop.psVarNames[v] == "nV" + dzTag) continue;

                    int gindex = mpop.GetVarIndex(Opop.psVarNames[v]);
                    if (gindex < 0) Opop.psvars[v] = 0.0;
                    else
                    {
                        Opop.psvars[v] = Convert.ToDouble(mpop.Vars[gindex]);
                    }
                }

                Opop.OIndivids = new List<OIndividual>();

            // If MM system model is popbased, need to make individuals for Outbreak
                if (mpop.IndList.Count == 0 && mpop.Nindividuals > 0)
                {
                    mpop.makeIndividuals();
                    // how do we set the Dz states?
                }
            // if MM individuals exist from prior Outbreak call, but tallies have been changed by other models
            // then ... ???

            // Get the individuals from MData
                for (int i = 0; i < mpop.IndList.Count; i++)
                {
                    MMMCore.MIndividual mind = mpop.IndList[i];

                    bool live = mind.Vars[AliveIndex] != "0";
                    if (!live) continue;

                    int ID = Convert.ToInt32(mind.Vars[NameIndex]);

                    int age = Convert.ToInt32(mind.Vars[AgeIndex]) + MMDay - 1;
                    int X = Convert.ToInt32(mind.Vars[Xindex]);
                    int Y = Convert.ToInt32(mind.Vars[Yindex]);

                    int damID = Convert.ToInt32(mind.Vars[DamIndex]);
                    int sireID = Convert.ToInt32(mind.Vars[SireIndex]);
                    
                    int sx = Convert.ToInt32(mind.Vars[SexIndex]);
                    int daysState = Convert.ToInt32(mind.Vars[DaysIndex]) + MMDay - 1;
                    int tenure = Convert.ToInt32(mind.Vars[TenureIndex]);
                    int dz = Convert.ToInt32(mind.Vars[DzStateIndex]);
                    bool statePerm = mind.Vars[DzPermanentIndex] != "0";
                    bool vacc = mind.Vars[VaccIndex] != "0";

                    Sex csex = Sex.Male;
                    if (sx == 0) csex = Sex.Female; // need to pass sex and age to Oind constructor, so that can calc any funcs for X, Y
                    // but note that Dz not yet known when X, Y are seeded
                    
                    OIndividual oind;
                    OIndividual odam = null;

                    if (dz < 0 && damID >= 0)
                    {
                        odam = findInd(damID); // note that Outbreak doesn't care who the sire is; no need to assign it
                    }

                    oind = new OIndividual(Opop, odam, null, csex, age, X, Y);

                    if (dz >= 0) // otherwise, use Dz that was set in OIndividual constructor
                    {
                        oind.iDz = dz;
                        oind.StatePermanent = statePerm;
                        oind.Tenure = tenure; // a code of -1 means that it still needs to be set in "Tenure ="
                    }

                    oind.MMindex = i; // so can put it back later without having to replace everything
                    oind.Oname = ID; // so can track parents

                    //oind.iSex = sx;
                    //oind.age = age;
                    oind.alive = live;
                    oind.DaysInState = daysState;

                    if (vacc) oind.iDz = 5;

                    for(int si = 0; si < Opop.isVarNames.Count; si++) oind.isstates[si] = Convert.ToDouble(mind.Vars[ISindex[si]]);

                    Opop.OIndivids.Add(oind);
                }


            // do the simulation!
                if (yr == 0 && MMDay == 1) Opop.year0(numtimesteps);
                Opop.Oyear(yr + 1, numtimesteps, MMDay);

                // put pop back into MData ...
                MMputBack(Opop);

            //}

            MMDay += numtimesteps;
            if (MMDay > Opop.nDays) MMDay = 1; // year has ended

            return;
        }


        private bool MMputBack(OScenario Opop)
        {
            // put pop back into MData ...
            mpop.Vars[PrevIndex] = Opop.Prevalence.ToString();
            if(Nindex != -1) mpop.Vars[Nindex] = Opop.N.ToString();
            if (nPindex != -1) mpop.Vars[nPindex] = Opop.nP.ToString();
            if (nSindex != -1) mpop.Vars[nSindex] = Opop.nS.ToString();
            if (nEindex != -1) mpop.Vars[nEindex] = Opop.nE.ToString();
            if (nIindex != -1) mpop.Vars[nIindex] = Opop.nI.ToString();
            if (nRindex != -1) mpop.Vars[nRindex] = Opop.nR.ToString();
            if (nVindex != -1) mpop.Vars[nVindex] = Opop.nV.ToString();

            int aCount = 0;

            bool[] animUsed = new bool[mpop.IndList.Count];
            for (int i = 0; i < animUsed.Length; i++) animUsed[i] = false;

            foreach (OIndividual anim in Opop.OIndivids)
            {
                if (!anim.alive) continue;

                MIndividual ind;
                int pos = anim.MMindex;

                if (pos >= 0)
                {
                    ind = mpop.IndList[pos];
                    animUsed[pos] = true;
                }
                else //new animal. Add it and add vars
                {
                    if (!Opop.doDemog)
                    {
                        MessageBox.Show("Outbreak error: Animal " + anim.OID.ToString() + " not found in MPop");
                        return false;
                    }
                    ind = new MIndividual(mpop);
                    ind.Vars[SexIndex] = anim.iSex.ToString();
                    ind.Vars[NameIndex] = anim.Oname.ToString();
                    ind.Vars[DamIndex] = anim.DamID.ToString();
                    ind.Vars[SireIndex] = anim.SireID.ToString();
                }

                ind.Vars[IDindex] = aCount.ToString();
                aCount++;
                if (Opop.doDemog) ind.Vars[AgeIndex] = anim.age.ToString();

                //                    if(anim.alive) 
                ind.Vars[AliveIndex] = "1";
                //                    else ind.Vars[AliveIndex] = "0"; 

                ind.Vars[Xindex] = anim.X.ToString();
                ind.Vars[Yindex] = anim.Y.ToString();
                ind.Vars[DzStateIndex] = anim.iDz.ToString();
                ind.Vars[DaysIndex] = anim.DaysInState.ToString();
                ind.Vars[TenureIndex] = anim.Tenure.ToString();
                ind.Vars[DzPermanentIndex] = (anim.StatePermanent ? "1" : "0");
                ind.Vars[VaccIndex] = (anim.isVaccinated ? "1" : "0");
            }

            //remove all animals from the Mpop that aren't used
            for (int i = animUsed.Length - 1; i >= 0; i--)
            {
                if (!animUsed[i]) mpop.IndList.RemoveAt(i);
            }

            mpop.tallyPopulation(); // so tallies available for pop-based modifier programs

            return true;
        }

    }
}
