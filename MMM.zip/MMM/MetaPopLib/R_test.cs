﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using RDotNet;

namespace MetaPopLib
{
    public class R_test
    {
        public static void Main(string[] args)
        {
            //REngine.SetEnvironmentVariables(); // Currently under development - coming soon
            SetupPath(); // current process, soon to be deprecated
            using (REngine engine = REngine.CreateInstance("RDotNet"))
            {
                engine.Initialize(); // required since v1.5
                CharacterVector charVec = engine.CreateCharacterVector(new[] { "Hello, R world!, .NET speaking" });
                engine.SetSymbol("greetings", charVec);
                engine.Evaluate("str(greetings)"); // print out in the console
                string[] a = engine.Evaluate("'Hi there .NET, from the R engine'").AsCharacter().ToArray();
                Console.WriteLine("R answered: '{0}'", a[0]);
                Console.WriteLine("Press any key to exit the program");
                //Console.ReadKey();


                var mat = new double[,] {{0, 1}, {1, 2}};
                var rmat = engine.CreateNumericMatrix(mat);
                engine.SetSymbol("tempMMMVariable", rmat);
                engine.Evaluate("mat" + " <- tempMMMVariable");

                var rmat2 = engine.Evaluate("mat").AsNumericMatrix();
                double[,] mat2 = new double[rmat2.ColumnCount, rmat2.RowCount];
                for (int i = 0; i < rmat2.ColumnCount; i++)
                {
                    for (int j = 0; j < rmat2.RowCount; j++)
                    {
                        mat2[i, j] = rmat2[i, j];
                    }
                }
                var mat3 = new double[rmat2.RowCount, rmat2.ColumnCount];
                rmat2.CopyTo(mat3, rmat2.RowCount, rmat2.ColumnCount);
                Console.WriteLine(mat2.ToString());
            }
        }

        public static void SetupPath()
        {
            var oldPath = System.Environment.GetEnvironmentVariable("PATH");
            var rPath = System.Environment.Is64BitProcess ? @"C:\Program Files\R\R-3.0.2\bin\x64" : @"C:\Program Files\R\R-3.0.2\bin\i386";
            // Mac OS X
            //var rPath = "/Library/Frameworks/R.framework/Libraries";
            // Linux (in case of libR.so exists in the directory)
            //var rPath = "/usr/lib";
            if (Directory.Exists(rPath) == false)
                throw new DirectoryNotFoundException(string.Format("Could not found the specified path to the directory containing R.dll: {0}", rPath));
            var newPath = string.Format("{0}{1}{2}", rPath, System.IO.Path.PathSeparator, oldPath);
            System.Environment.SetEnvironmentVariable("PATH", newPath);
            // NOTE: you may need to set up R_HOME manually also on some machines
            string rHome = "";
            var platform = Environment.OSVersion.Platform;
            switch (platform)
            {
                case PlatformID.Win32NT:
                    break; // R on Windows seems to have a way to deduce its R_HOME if its R.dll is in the PATH
                case PlatformID.MacOSX:
                    rHome = "/Library/Frameworks/R.framework/Resources";
                    break;
                case PlatformID.Unix:
                    rHome = "/usr/lib/R";
                    break;
                default:
                    throw new NotSupportedException(platform.ToString());
            }
            if (!string.IsNullOrEmpty(rHome))
                Environment.SetEnvironmentVariable("R_HOME", rHome);
        }
    }

    //public class NumericMatrixExt : NumericMatrix
    //{
    //    public NumericMatrixExt(REngine engine, double [,] mat) : base (engine,mat)
    //    {
    //    }

    //    protected double[,] Test()
    //    {
    //        return base.
    //    }
    //}
}
