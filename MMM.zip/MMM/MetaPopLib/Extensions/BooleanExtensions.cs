﻿namespace MetaPopLib.Extensions
{
    public static class BooleanExtensions
    {
        public static int? AsNullableInt(this bool b)
        {
            return b ? 1 : 0;
        }
    }
}
