﻿using System.Xml.Linq;

namespace MetaPopLib.Extensions
{
   public static class XElementExtensions
    {
       public static string GetAttributeValue(this XElement element, string name)
       {
           var attribute = element.Attribute(name);
           return attribute != null ? attribute.Value : string.Empty;
       }
    }
}
