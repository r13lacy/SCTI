﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MetaPopLib.Extensions
{
    public static class StringExtensions
    {
        /// <summary>
        /// Extension method - converts a delimeted string to an array of a given type (Generic Method)
        /// </summary>
        /// <typeparam name="T">The value type of the resuting array</typeparam>
        /// <param name="s">The string reference that will be extended</param>
        /// <param name="delimeter">The delimeter</param>
        /// <returns>An array of the provided type</returns>
        /// <remarks>This method should only be used to create arrays of primitive types</remarks>
        public static IEnumerable<T> AsIEnumerable<T>(this string s, char delimeter) where T : IConvertible
        {
            if (s == string.Empty)
                return null;       // return empty array

            string[] array = s.Split(delimeter);
            return array.Length == 1 ? (new List<T> { (T)Convert.ChangeType(s, typeof(T)) }).AsEnumerable() : array.Select(value => (T)Convert.ChangeType(value, typeof(T)));
        }

        public static bool AsBool(this string s)
        {
            if (s == null)
                return false;
            return bool.Parse(s);
        }

        public static bool AsBool(this string s, bool defValue)
        {
            try
            {
                return s.AsBool();
            }
            catch (Exception)
            {
                return defValue;
            }
        }

        public static int AsInt(this string s)
        {
            int value = int.MinValue;

            //cf does not support tryparse
            try
            {
                value = int.Parse(s);
            }
            catch
            {
            }
            return value;
        }

        public static int AsInt(this string s, int defValue)
        {
            var value = s.AsInt();
            return value == int.MinValue ? defValue : value;
        }

        public static decimal AsDecimal(this string s)
        {
            decimal value = decimal.MinValue;

            //cf does not support tryparse
            try
            {
                value = decimal.Parse(s);
            }
            catch
            {
            }
            return value;
        }

        public static decimal AsDecimal(this string s, decimal defValue)
        {
            decimal result = s.AsDecimal();
            return result == decimal.MinValue ? defValue : result;
        }

        public static long AsLong(this string s)
        {
            long value = long.MinValue;

            //cf does not support tryparse
            try
            {
                value = long.Parse(s);
            }
            catch
            {
            }
            return value;
        }

        public static long AsLong(this string s, long defaultValue)
        {
            var value = s.AsLong();
            return value == long.MinValue ? defaultValue : value;
        }

        public static DateTime AsDateTime(this string s)
        {
            DateTime value = DateTime.MinValue;

            //cf does not support tryparse
            try
            {
                value = DateTime.Parse(s);
            }
            catch
            {
            }
            return value;
        }

        public static DateTime AsDateTime(this string s, DateTime defValue)
        {
            DateTime value = s.AsDateTime();
            return value == DateTime.MinValue ? defValue : value;
        }

        public static DateTime AsDateTimeFromJulienDate(this string julienDate)
        {
            // this will not work beyond 2099
            var year = ("20" + julienDate.Substring(0, 2)).AsInt();
            var dt = new DateTime(year, 1, 1);

            var dayOfYear = julienDate.Substring(2).AsInt();
            if (dayOfYear > 1)
                dt = dt.AddDays(dayOfYear - 1); // since we are starting at 1, not 0, we must play for that offset

            return dt;
        }

        public static DateTime AsSalesDate(this string sDate)
        {
            if (sDate.Length != 7) return new DateTime(0);
            var yyyy = int.Parse(sDate.Substring(0, 1)) + 19;
            yyyy = yyyy * 100;
            yyyy += int.Parse(sDate.Substring(1, 2));
            int mm = int.Parse(sDate.Substring(3, 2));
            int dd = int.Parse(sDate.Substring(5, 2));
            var retdate = new DateTime(yyyy, mm, dd);
            return retdate;
        }

        public static TimeSpan AsTimeSpan(this string s)
        {
            TimeSpan t = new TimeSpan();

            if (s == string.Empty)
                return t;       // return empty timespan

            string[] array = s.Split(':');
            if (array.Length == 4)
            {
                t = new TimeSpan(array[0].AsInt(), array[1].AsInt(), array[2].AsInt(), array[3].AsInt());
            }
            return t;
        }


    }
}
