﻿using System;

namespace MetaPopLib.Extensions
{
    public static class DatetimeExtensions
    {
        /// <summary>
        /// Extension Method => Print out DateTime in a standard format
        /// </summary>
        /// <param name="dt">The date time object being extended</param>
        /// <param name="showDayOfWeek">Display the day of the week, yes or no</param>
        /// <returns>A standard string formatted to approved standards</returns>
        public static string AsDateTimeSelectString(this DateTime dt, bool showDayOfWeek)
        {
            string s = dt.AsStandardFormatString();
            if (showDayOfWeek)
                s += " - " + dt.AsDayOfWeek();

            return s;
        }

        /// <summary>
        /// Extension Method - Convert a DateTime reference to its Julian date representation
        /// </summary>
        /// <param name="inDate">The DateTime reference being extended</param>
        /// <returns>String representing the date in Julian time format</returns>
        public static string AsJulianDate(this DateTime inDate)
        {
            string year = inDate.ToString("yy");
            string dayOftheYear = inDate.DayOfYear.ToString().PadLeft(3, '0');
            return year + dayOftheYear;
        }

        /// <summary>
        /// Extension Method - Get the Previous week start value for a given datetime
        /// </summary>
        /// <param name="dt">The date provided as a relative starting point</param>
        /// <returns>Previous DateTime</returns>
        public static DateTime AsPreviousWeekStart(this DateTime dt)
        {
            DateTime currentWeekStart = dt.AsWeekStart();
            return currentWeekStart.AddDays(-1).AsWeekStart();
        }

        /// <summary>
        /// Extension Method - Print out the Day of the week the date falls on
        /// </summary>
        /// <param name="dt">The DateTime reference being exteended</param>
        /// <returns>String representation of the day of the week</returns>
        public static string AsDayOfWeek(this DateTime dt)
        {
            return dt.ToString("dddd");
        }

        /// <summary>
        /// Extension Method - Given a date get the weekOf date
        /// </summary>
        /// <param name="dt">The date within the week being referenced</param>
        /// <returns>The nearest Sunday to the given date (going backwards)</returns>
        public static DateTime AsWeekStart(this DateTime dt)
        {
            switch (dt.DayOfWeek)
            {
                case DayOfWeek.Monday:
                    dt = dt.AddDays(-1);
                    break;
                case DayOfWeek.Tuesday:
                    dt = dt.AddDays(-2);
                    break;
                case DayOfWeek.Wednesday:
                    dt = dt.AddDays(-3);
                    break;
                case DayOfWeek.Thursday:
                    dt = dt.AddDays(-4);
                    break;
                case DayOfWeek.Friday:
                    dt = dt.AddDays(-5);
                    break;
                case DayOfWeek.Saturday:
                    dt = dt.AddDays(-6);
                    break;
                default:
                    break;
            }

            return dt.Date;
        }

        /// <summary>
        /// Extension Method - Output DateTime object in a standard format
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static string AsDateWithDayString(this DateTime dt)
        {
            return string.Format("{0} ({1})", dt.AsDayOfWeek(), dt.AsStandardFormatString());
        }

        /// <summary>
        /// Extension Method => convert a datetime object to a string with a standard format
        /// </summary>
        /// <param name="dt">The date time object being extended</param>
        /// <returns>Standard foramtted string</returns>
        public static string AsStandardFormatString(this DateTime dt)
        {
            if (dt == DateTime.MinValue)
                return "No Date";

            return dt.ToString("d");
        }

        /// <summary>
        /// Extension Method - Convert DateTime based on Facility offset from EST
        /// </summary>
        /// <param name="dt">The datetime object being extended</param>
        /// <param name="offset">The facility offset from EST</param>
        /// <returns>DateTime object formatted for the given TZ the facility is located in</returns>
        public static DateTime AsDateTimeForFacility(this DateTime dt, int offset)
        {
            return dt.AddHours(offset);
        }

        /// <summary>
        /// Extension Method - Return a string as a standard time value in military format
        /// </summary>
        /// <param name="dt">The datetime object being extended</param>
        /// <returns>A string for the time value</returns>
        public static string AsTimeString(this DateTime dt)
        {
            if (dt == DateTime.MinValue)
                return "No Time";

            return string.Format("{0}:{1}", dt.ToString("HH"), dt.ToString("mm"));
        }

        /// <summary>
        /// Extension Method - Return a string representing the time in a standard format
        /// </summary>
        /// <param name="dt">The datetime object being extended</param>
        /// <param name="useMilitaryTime">Output in military time</param>
        /// <returns>A string for the time value</returns>
        public static string AsTimeString(this DateTime dt, bool useMilitaryTime)
        {
            return useMilitaryTime ? dt.AsTimeString() : string.Format("{0}:{1}{2}", dt.ToString("hh"), dt.ToString("mm"), dt.ToString("tt"));
        }

        /// <summary>
        /// Extension Method - Return a string representing the date and time with a standard format for both
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="useMilitary">Should the time be dispayed using military time</param>
        /// <returns></returns>
        public static string AsDateWithTimeString(this DateTime dt, bool useMilitary)
        {
            return string.Format("{0} {1}", dt.AsStandardFormatString(), dt.AsTimeString(useMilitary));
        }

        /// <summary>
        /// Extension Method - Return a string representing the in AS400 Format
        /// </summary>
        /// <param name="dt">The datetime object being extended</param>
        /// <returns>A string for the AS500 date value</returns>
        public static string AsSalesDateString(this DateTime dt)
        {
            string s = dt.ToString("MM/dd/yyyy");
            return "1" + s.Substring(8, 2) + s.Substring(0, 2) + s.Substring(3, 2);
        }

    }
}
