﻿using System;

namespace MetaPopLib.Extensions
{
    public static class IntegerExtensions
    {
        /// <summary>
        /// Extension Method - Format a number as a Day Of week value (Sunday = 0)
        /// </summary>
        /// <param name="i"></param>
        /// <returns></returns>
        public static string AsDayOfWeekString(this int i)
        {
            if (i == -1) return "No Day";

            var value = Enum.Parse(typeof(DayOfWeek), i.ToString(), true);
            return value.ToString();
        }

        /// <summary>
        /// Return the absolute value of a given integer
        /// </summary>
        /// <param name="i">Integer instance being extended</param>
        /// <returns>Absolute value of the given value</returns>
        public static int AsAbsoluteValue(this int i)
        {
            return Math.Abs(i);
        }

        /// <summary>
        /// Extension Method - Format a Sales date number as a Date
        /// ' Sales Date Format – CYYMMDD (1090813)
        /// </summary>
        /// <param name="i"></param>
        /// <returns></returns>
        public static DateTime AsSalesDate(this int i)
        {
            var sDate = i.ToString();
            if (sDate.Length != 7) return new DateTime(0);
            int yyyy = int.Parse(sDate.Substring(0, 1)) + 19;
            yyyy = yyyy * 100;
            yyyy += int.Parse(sDate.Substring(1, 2));
            int mm = int.Parse(sDate.Substring(3, 2));
            int dd = int.Parse(sDate.Substring(5, 2));
            var retdate = new DateTime(yyyy, mm, dd);
            return retdate;
        }

        /// <summary>
        /// Extension Method - Get the negative of the current int reference
        /// </summary>
        /// <param name="value">The int instance being extended</param>
        /// <returns>The negative value of the int being extended</returns>
        public static int AsNegative(this int value)
        {
            if (value < 0)
                return value;
            return value * -1;
        }
    }
}
