﻿using System.Collections.Generic;
using System.Text;

namespace MetaPopLib.Extensions
{
    public static class IEnumerableExtensions
    {
        public static string Concatenate<T>(this IEnumerable<T> collection, string separator)
        {
            var sb = new StringBuilder();
            bool isFirst = true;

            foreach (var s in collection)
            {
                if (!isFirst) sb.Append(separator);

                sb.Append(s.ToString());
                isFirst = false;
            }

            var returnString = sb.ToString();
            return returnString;
        }
    }
}
