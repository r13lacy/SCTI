﻿using System;

namespace MetaPopLib.Extensions
{
    public static class TimeSpanExtensions
    {
        /// <summary>
        /// Extension Method - Return a string representing the TimeSpan as Days:Hours:Minutes:Seconds
        /// </summary>
        /// <param name="ts">The timspan object being extended</param>
        /// <returns>A string to store in the database</returns>
        public static string AsDBString(this TimeSpan ts)
        {
            return string.Format("{0}:{1}:{2}:{3}", ts.Days, ts.Hours, ts.Minutes, ts.Seconds);
        }

    }
}
