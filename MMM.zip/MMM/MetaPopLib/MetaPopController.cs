using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.IO;
using MetaPopLib.Extensions;
using Microsoft.Win32.SafeHandles;
using Newtonsoft.Json.Linq;
using RDotNet;
//using AustinHarris.JsonRpc;
//using AustinHarris;
using Newtonsoft.Json;


// Note: this code file has not been tested for any specific application. 
// It is intended only to provide a template of the general structure of code that can be used by a model to share data with MetaModelManager.
// For any specific use, the code will likely need to be customized, extended, and thoroughly tested.


namespace MetaPopLib
{
    internal class Population
    {
        public string name;
        public int Nindividuals;
        public List<int> Males;
        public List<int> Females;
        public List<double> myPSvals;
        public List<Individual> IndList;
        public int PopClientID;
        public int PopNum;

        public Population(int myPSvarsCount)
        {
            Males = new List<int>();
            Females = new List<int>();
            myPSvals = new List<double>();
            for (int i = 0; i < myPSvarsCount; i++)
                myPSvals.Add(0);
            IndList = new List<Individual>();
        }
    }

    internal class Individual
    {
        public int name;
        public int age;
        public int sex;
        public List<double> myISvals;

        public Individual()
        {
            myISvals = new List<double>();
        }
    }

    public class MetaPopController
    {
        public List<string> myGSvars;
        public List<double> myGSvals;
        public List<string> myPSvars;
        public List<string> myISvars;

        public Dictionary<string, object> myASvars;
        public Dictionary<string, object> myCPSvars;

        int yr;
        int iter;
        int nTimeSteps;
        int nPops;
        int nMPPops;

        bool PopBase;
        bool sysModel;

        private List<Population> sysPops;
        private int ClientID;
        private int MetaPopClientIDIndex;

        public static string MetaPopExe = @"Metapop.exe";
        public string PipeName = "MetapopManager";
        public static string MetapopOptions = "";
        public static int MetapopTimeStepTimeout = 10;
        private NamedPipeServerStream pipeServer;
        private StreamReader pipeReader;
        private StreamWriter pipeWriter;

        public MetaPopController()
        {
            // constructor

            myGSvars = new List<string>();
            myGSvals = new List<double>();
            myPSvars = new List<string>();
            myISvars = new List<string>();
            myASvars = new Dictionary<string, object>();
            myCPSvars = new Dictionary<string, object>();
            sysPops = new List<Population>();

            yr = 0;
            iter = 0;
            nTimeSteps = 0;
            nPops = 0;

            PopBase = true; // set to true if pop-based model
            sysModel = true; // set to false if modifier model rather than system model

            ClearLogFile();
        }


        #region MetaModel Functions

        // first parameter is the name of the datafile via which MeMoMa passes the current population
        // second parameter is whatever file (or null, if nothing) that specifies the project settings (input) that are needed by the Modifier program,
        // usually set up within an external editor program or sometimes by simple manual editing of an input file. 
        public bool Initialize(string datafilename, string MyFile)
        {
            // Do whatever stuff needs to be done at the outset of the metamodel, to have this modifier program ready to go

            WriteLog("Initialize");

            //myGSvals[GetGSVarIndex("TotalPop")]++;
            //UpdateGSvar("NumberOfClients", 1);
            //UpdateGSvar("popK", 0);
            //nPops = 2;
            //sysPops.Add(new Population());
            //sysPops.Add(new Population());

            ReadDataFile(datafilename);

            myGSvals[GetGSVarIndex("NumberOfClients")]++;
            ClientID = (int)GetGSVar("NumberOfClients");
            PipeName += ClientID;
            MetaPopClientIDIndex = GetPSVarIndex("MetaPopClientID");

            //var k = GetPSVarIndex("K");
            //sysPops[0].myPSvals[k] = 10;
            //sysPops[1].myPSvals[k] = 50;


            pipeServer = new NamedPipeServerStream(PipeName);

            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = MetaPopExe;
            startInfo.Arguments = "\"" + MyFile + "\"";
            //Settings.MetapopOptions,
            //PIPE_NAME,
            //process.ClientID,
            //process.Filename,
            //Settings.MetapopTimeStepTimeout + 2
            var args = String.Format("{0} /RUN=YES /RPC={1} /RPCID={2} \"{3}\" /RpcResponseTimeout={4}",
                                        MetapopOptions, PipeName, ClientID, MyFile, MetapopTimeStepTimeout);
            startInfo.Arguments = args;
            Process.Start(startInfo);

            WriteLog("Start R Engine");
            InitializeR();

            ReadPipe(); //Initalize
            ReadPipe(); //StartSimulation

            WriteDataFile(datafilename);
            WriteLog("Initialize Complete\r\n");

            return true;

            #region oldcode
            //StreamReader objReader;
            //try
            //{
            //    objReader = new StreamReader(MyFile);
            //}
            //catch
            //{
            //    throw new Exception("MyFile Read Failed");
            //}

            //string sLine = "";
            //char[] splits = { '=', ':', ';' };
            //string[] ss;

            //while ((sLine = objReader.ReadLine()) != null && !string.IsNullOrEmpty(sLine))
            //{

            //    // file format (an example, myModel can use whatever kind of specification file that it wants)

            //    // "Populations: Pop1, Pop2"
            //    // "Globals: T; Y; Z"
            //    // "PopVars: P; A; B"
            //    // "IndVars: ID; Sex; Age"

            //    ss = sLine.Split(splits,StringSplitOptions.RemoveEmptyEntries);

            //    if (ss[0].StartsWith("Populations"))
            //    {
            //        nPops = ss.Length - 1;
            //        for (int j = 1; j < ss.Length; j++)
            //        {
            //            Population mpop = new Population();
            //            mpop.name = ss[j].Trim();
            //            mpop.Nindividuals = 0;
            //            mpop.Males = new List<int>();
            //            mpop.Females = new List<int>();
            //            mpop.myPSvals = new List<double>();
            //            mpop.IndList = new List<Individual>();
            //            myPops.Add(mpop);
            //        }
            //        continue;
            //    }

            //    if (ss[0].StartsWith("Ind"))
            //    {
            //        for (int j = 1; j < ss.Length; j++)
            //        {
            //            myISvars.Add(ss[j].Trim());
            //        }
            //    }
            //    else if (ss[0].StartsWith("Pop"))
            //    {
            //        for (int j = 1; j < ss.Length; j++)
            //        {
            //            myPSvars.Add(ss[j].Trim());
            //        }
            //    }
            //    else if (ss[0].StartsWith("Global"))
            //    {
            //        for (int j = 1; j < ss.Length; j++)
            //        {
            //            myGSvars.Add(ss[j].Trim());
            //            myGSvals.Add(0.0);
            //        }
            //    }
            //}

            //objReader.Close();

            //for (int p = 0; p < nPops; p++)
            //{
            //    Population mpop = myPops[p];
            //    for(int j = 0; j < myPSvars.Count; j++)
            //        mpop.myPSvals.Add(0.0); // do this initialization now, rather than later, to be sure that myPSvals count = myPSvars count
            //} 
            #endregion
        }


        // Bob pulled Year 0 initial stuff out of Simulate(), now called specifically from MSystemAppExternal.DoYear0()
        public bool SimYear0(string filename, int iteration)
        {
            //return Simulate(filename, iteration, 0, 1);
            
            WriteLog("Simulate Year 0");

            iter = iteration;

            ReadDataFile(filename); // needed?

                // do whatever work is needed to create the initial population
                // ...
                foreach (var sysPop in sysPops)
                {
                    if (sysPop.PopClientID != 0)
                    {
                        sysPop.myPSvals[MetaPopClientIDIndex] = sysPop.PopClientID;
                    }
                }

                ReadPipe(); //StopTimeStep - Initial Data


                // note: some system models might create population in Initialize(), 
                // but usually not because normally a new population is created with each independent iteration

            //PushVariablesToR();
            //CallRScript();
            //PullVariablesFromR();
            //WriteLog("R Complete");

            //LogGlobalVariables();

            //ReadPipe(); //StartTimeStep
            //ReadPipe(); //StopTimeStep

            WriteLog("Current Total Pop: " + myGSvals[myGSvars.IndexOf("TotalPop")]);

            foreach (var sysPop in sysPops)
            {
                sysPop.Nindividuals = Convert.ToInt32(sysPop.myPSvals[GetPSVarIndex("popAbundTot")] > 0 ? sysPop.myPSvals[GetPSVarIndex("popAbundTot")] : sysPop.myPSvals[GetPSVarIndex("PS1")]);

                // Need also to set age-sex structure!
            }

//            LogPopulationVariables();

            // then put the values back into data file
            WriteDataFile(filename);

            WriteLog("Simulate Year 0 Complete \r\n");
            return true; // just a flag saying that all was processed OK
        }

        // params are 
        //the filename for the current data file (will always be passed as xchangefile.txt by MeMoMa)
        //the iteration number of the metamodel, 
        //the year of the metamodel (i.e., the number of top level loops through the metamodel that have been completed), 
        //and the number of time steps to be run within the Modifier before passing control back to MMM
        public bool Simulate(string filename, int iteration, int year, int numTimeSteps)
        {
            WriteLog("Simulate");

            iter = iteration;
            yr = year +1; // Bob had added +1 because MModel calls Simulate with year = 0 to nyears - 1
            nTimeSteps = numTimeSteps;

//            ReadDataFile(filename);

            //if (yr == 0 && sysModel)
            //{
            //    //NOTE: all vars are set to 0 on first year
            //    // do whatever work is needed to create the initial population
            //    // ...
            //    foreach (var sysPop in sysPops)
            //    {
            //        if (sysPop.PopClientID != 0)
            //        {
            //            sysPop.myPSvals[MetaPopClientIDIndex] = sysPop.PopClientID;
            //        }

            //    //    sysPop.Nindividuals = Convert.ToInt32(sysPop.myPSvals[GetPSVarIndex("popAbundTot")]); // by Bob
            //    }

            //    ReadPipe(); //StopTimeStep - Initial Data


            //    // note: some system models might create population in Initialize(), 
            //    // but usually not because normally a new population is created with each independent iteration
            //}
            //else  
            //{
                ReadDataFile(filename);

                foreach (var sysPop in sysPops)
                {
                    if (sysPop.myPSvals[MetaPopClientIDIndex] != 0)
                    {
                        sysPop.PopClientID = Convert.ToInt32(sysPop.myPSvals[MetaPopClientIDIndex]);
                    }
                    sysPop.Nindividuals = Convert.ToInt32(sysPop.myPSvals[GetPSVarIndex("popAbundTot")]);

                    // Need also to transfer age-sex structure to sysPop!
                }
            //}


        // not used for anything yet?
            //for (int istep = 0; istep < numTimeSteps; istep++)
            //{
            //    for (int p = 0; p < nPops; p++)
            //    {
            //        Population mpop = sysPops[p];

            //        // now, do whatever it is that myModel does to modify the variables for each individual 
            //        // ...

            //        // now do anything further (such as tallies across individuals) that is needed to modify Population variables
            //        // ...
            //    }

            //    // now, do anything further (such as tallies across populations) that is needed to modify Global variables
            //    // ...
            //}

            PushVariablesToR();
            CallRScript();
            PullVariablesFromR();
            WriteLog("R Complete");

            LogGlobalVariables();

            ReadPipe(); //StartTimeStep
            ReadPipe(); //StopTimeStep

            WriteLog("Current Total Pop: " + myGSvals[myGSvars.IndexOf("TotalPop")]);

            foreach (var sysPop in sysPops)
            {
                sysPop.Nindividuals = Convert.ToInt32(sysPop.myPSvals[GetPSVarIndex("popAbundTot")] > 0 ? sysPop.myPSvals[GetPSVarIndex("popAbundTot")] : sysPop.myPSvals[GetPSVarIndex("PS1")]);

                // Need also to set age-sex structure!
            }

            LogPopulationVariables();

            // then put the values back into data file
            WriteDataFile(filename);

            WriteLog("Simulate Complete \r\n");
            return true; // just a flag saying that all was processed OK
        }


        public bool CloseDLL()
        {
            // do anything that needs to be cleaned up, writing to output files, closing files, etc.
            WriteLog("CloseDLL");

            ReadPipe(); //StopSimulation
            ReadPipe(); //Finalize

            return true;
        }

        #region ReadWritePipe

        public void ReadPipe()
        {
            WriteLog("Start Read Pipe");
            WriteLog("Connected " + pipeServer.IsConnected);
            try
            {
                pipeServer.WaitForConnection(); // Note: it seems to get hung up at this Wait at times.
                pipeReader = new StreamReader(pipeServer);
                pipeWriter = new StreamWriter(pipeServer);

                var endOfLine = false;
                var line = "";
                int unmatched = 0;

                while (!endOfLine)
                {
                    var nextChar = (char)pipeReader.Read();
                    line += nextChar;
                    if (nextChar == '{')
                        unmatched++;
                    if (nextChar == '}')
                        unmatched--;

                    endOfLine = unmatched == 0;
                }
                WriteLog("Read Pipe - " + line);

                var MPrpc = JsonConvert.DeserializeObject<Dictionary<string, object>>(line);

                var id = MPrpc["id"];
                var method = MPrpc["method"].ToString();

                if (method == "StartSimulation")
                {
                    var p = JsonConvert.DeserializeObject<Dictionary<string, object>>(MPrpc["params"].ToString());
                    //var clientID = p["ClientID"].ToString().AsInt(0);
                    var MetapopStateVarsGlobal = JsonConvert.DeserializeObject<Dictionary<string, object>>(p["MetapopStateVarsGlobal"].ToString());

                    UpdateASvar("nPopulations", Convert.ToInt32(MetapopStateVarsGlobal["nPopulations"]));
                    UpdateASvar("nCatastrophes", Convert.ToInt32(MetapopStateVarsGlobal["nCatastrophes"]));
                    UpdateASvar("catStages", ((JArray)MetapopStateVarsGlobal["catStages"]).ToObject(typeof(double[,])));
                    UpdateASvar("stageBreed", ((JArray)MetapopStateVarsGlobal["stageBreed"]).ToObject(typeof(double[])));
                    UpdateASvar("constraintsMat", ((JArray)MetapopStateVarsGlobal["constraintsMat"]).ToObject(typeof(double[,])));
                    UpdateASvar("stageMass", ((JArray)MetapopStateVarsGlobal["stageMass"]).ToObject(typeof(double[])));
                    UpdateASvar("stageRelDisp", ((JArray)MetapopStateVarsGlobal["stageRelDisp"]).ToObject(typeof(double[])));
                    UpdateASvar("nYears", Convert.ToInt32(MetapopStateVarsGlobal["nYears"]));
                    UpdateASvar("catType", ((JArray)MetapopStateVarsGlobal["catType"]).ToObject(typeof(bool[,])));
                    UpdateASvar("nStages", Convert.ToInt32(MetapopStateVarsGlobal["nStages"]));
                    UpdateASvar("stageDD", ((JArray)MetapopStateVarsGlobal["stageDD"]).ToObject(typeof(double[])));
                    
                    nMPPops = (int)GetASVar("nPopulations");

                    // This little section by Bob, to clear things out for any re-run of the Simulation called by MeMoMa
                    for (int i = 0; i < nMPPops; i++)
                    {
                        Population ppop = sysPops[i];
                        ppop.myPSvals.Clear();

                        for (int j = 0; j < myPSvars.Count; j++)
                            ppop.myPSvals.Add(0);
                    }


                    for (int i = 0; i < nMPPops; i++)
                    {
                        var myPop = sysPops.Find(pop => pop.myPSvals[MetaPopClientIDIndex] == 0);
                        myPop.myPSvals[MetaPopClientIDIndex] = ClientID;
                        myPop.PopClientID = ClientID;
                        myPop.PopNum = i;
                    }
                }

                if (method == "StopTimeStep")
                {
                    var p = JsonConvert.DeserializeObject<Dictionary<string, object>>(MPrpc["params"].ToString());
                    var clientID = p["ClientID"].ToString().AsInt(0);
                    var MetapopStateVarsPop = JsonConvert.DeserializeObject<Dictionary<string, object>>(p["MetapopStateVarsPop"].ToString());

                    //Update MP pop vars for R
                    UpdateCPSvar("popEmigrants", ((JArray) MetapopStateVarsPop["popEmigrants"]).ToObject(typeof (double[,])));
                    UpdateCPSvar("PBM", ((JArray)MetapopStateVarsPop["PBM"]).ToObject(typeof(double[])));
                    UpdateCPSvar("NDS", ((JArray)MetapopStateVarsPop["NDS"]).ToObject(typeof(double[])));
                    UpdateCPSvar("NDK", ((JArray)MetapopStateVarsPop["NDK"]).ToObject(typeof(double[])));
                    UpdateCPSvar("NDF", ((JArray)MetapopStateVarsPop["NDF"]).ToObject(typeof(double[])));
                    UpdateCPSvar("popCatStatus", ((JArray)MetapopStateVarsPop["popCatStatus"]).ToObject(typeof(bool[,])));
                    UpdateCPSvar("popCatProb", ((JArray)MetapopStateVarsPop["popCatProb"]).ToObject(typeof(double[])));
                    UpdateCPSvar("popAbundMale", ((JArray)MetapopStateVarsPop["popAbundMale"]).ToObject(typeof(double[])));
                    UpdateCPSvar("popRmax", ((JArray)MetapopStateVarsPop["popRmax"]).ToObject(typeof(double[])));
                    UpdateCPSvar("popSupplement", ((JArray)MetapopStateVarsPop["popSupplement"]).ToObject(typeof(double[,])));
                    UpdateCPSvar("popStMat", ((JArray)MetapopStateVarsPop["popStMat"]).ToObject(typeof(double[,,])));
                    UpdateCPSvar("popHarvest", ((JArray)MetapopStateVarsPop["popHarvest"]).ToObject(typeof(double[,])));
                    UpdateCPSvar("popAbundSt", ((JArray)MetapopStateVarsPop["popAbundSt"]).ToObject(typeof(double[,])));
                    UpdateCPSvar("popTimeSince", ((JArray)MetapopStateVarsPop["popTimeSince"]).ToObject(typeof(double[,])));
                    UpdateCPSvar("popImmigrants", ((JArray)MetapopStateVarsPop["popImmigrants"]).ToObject(typeof(double[,])));
                    UpdateCPSvar("disperserMat", ((JArray)MetapopStateVarsPop["disperserMat"]).ToObject(typeof(double[,,])));
                    UpdateCPSvar("popAbundTot", ((JArray)MetapopStateVarsPop["popAbundTot"]).ToObject(typeof(int[])));
                    UpdateCPSvar("popAbundFem", ((JArray)MetapopStateVarsPop["popAbundFem"]).ToObject(typeof(double[])));
                    UpdateCPSvar("currentYear", Convert.ToInt32(MetapopStateVarsPop["currentYear"]));
                    UpdateCPSvar("popK", ((JArray)MetapopStateVarsPop["popK"]).ToObject(typeof(int[])));
                    UpdateCPSvar("relDispersal", ((JArray)MetapopStateVarsPop["relDispersal"]).ToObject(typeof(double[,])));
                    UpdateCPSvar("popStMat2", ((JArray)MetapopStateVarsPop["popStMat2"]).ToObject(typeof(double[,,])));
                    UpdateCPSvar("dispersalMat", ((JArray)MetapopStateVarsPop["dispersalMat"]).ToObject(typeof(double[,])));
                    UpdateCPSvar("popK2", ((JArray)MetapopStateVarsPop["popK2"]).ToObject(typeof(double[])));

                    //Update MMM pop vars
                    for (int i = 0; i < nMPPops; i++)
                    {
                        var popStMat = (double[,,])GetCPSVar("popStMat");
                        var popAbundTot = (int[])GetCPSVar("popAbundTot");
                        var popK = (int[])GetCPSVar("popK");

                        UpdatePSvar("popStMat", popStMat[i,0,0], i);
                        UpdatePSvar("popAbundTot", popAbundTot[i], i);
                        UpdatePSvar("popK", popK[i], i);
                        WriteLog("Update Pop " + i + " Vars");
                    }
                }

                string result;
                if (method == "StartTimeStep")
                {
                    var Vital = JsonConvert.SerializeObject(GetCPSVar("popStMat"));
                    var Abund = JsonConvert.SerializeObject(GetCPSVar("popAbundTot"));
                    var K = JsonConvert.SerializeObject(GetCPSVar("popK"));
                    var Disp = "[0, 0 ]";

                    //result = "{  \"jsonrpc\": \"2.0\", \"result\": { \"result\": true,\"modifier\": { \"ChangeAbund\": true,\"ChangeVital\": true,\"ChangeK\": true,\"ChangeDisp\": true,\"Timestep\":      " + (yr + 1) + ",\"Complete\": true,\"Active\": true,\"Abund\": [ [100000], [100000] ],\"Vital\": [ [[1]], [[2]] ],\"K\": [100000, 100000],\"Disp\": [0, 0 ] } }, \"id\":      " + id + "  }";
                    result = "{  \"jsonrpc\": \"2.0\", \"result\": { \"result\": true,\"modifier\": { \"ChangeAbund\": true,\"ChangeVital\": true,\"ChangeK\": true,\"ChangeDisp\": true,\"Timestep\":      " + (yr + 1) + ",\"Complete\": true,\"Active\": true,\"Abund\": " + Abund + ",\"Vital\": " + Vital + ",\"K\": " + K + ",\"Disp\": " + Disp + " } }, \"id\":      " + id + "  }";
                }
                else
                {
                    result = "{  \"jsonrpc\": \"2.0\", \"result\": true, \"id\":      " + id + "  }";
                }

                WriteLog("Write Pipe = " + result);
                pipeWriter.WriteLine(result);
                pipeWriter.Flush();
                pipeServer.Disconnect();
            }
            catch (IOException)
            {
                pipeServer.Disconnect();
            }
            WriteLog("End Read Pipe");
        }

        #endregion


        #region ReadWriteDataFile
        // Note that although an iteration of a year elapses within Simulate(), 
        //   the incrementing of iteration and year will be handled by MeMoMa when it passes data to the next model
        //   so there shouldn't be any need to be concerned about what myModel puts into these variables in the file.
        // they are there only to maintain file structure consistency with the MeMoMa format of the datafile.
        public void WriteDataFile(string fileLocation)
        {
            WriteLog("WriteDataFile");

            //Creator = MyModel ...
            //Iteration = 1, Year = 50, Timesteps = 5
            //GlobalVariables, NumGSVars = 2
            //GS1, GS2
            //1.0000,2.0000
            //PopulationVariables, NumPSVars = 2, Population 1: PopName
            //PS1,PS2
            //22.000000; 11.000000
            //PopulationSize = 100
            //AgeStructure
            //Females: 12;22;33
            //Males: 32;12;11
            //IndividualVariables, NumISVars = 2
            //Name,Index,Age,Sex,Var1,Var2
            //33;0;11688;0;33.00000000;34.00000000
            //35;1;11688;1;33.00000000;34.00000000
            //PopulationVariables, NumPSVars = 2, Population 2: PopName
            //PS1,PS2
            //222.000000; 111.000000
            //IndividualVariables, NumISVars = 2
            //Name,Index,Age,Sex,Var1,Var2
            //33;0;11688;0;33.00000000;34.00000000
            //35;1;11688;1;33.00000000;34.00000000


            using (var writer = new StreamWriter(fileLocation, false))
            {
                writer.AutoFlush = true;

                writer.WriteLine("MData File Created by MetaPopController - " + DateTime.Now.ToLongDateString());
                writer.WriteLine("Iteration = " + iter.ToString() + ", Year = " + yr.ToString() + ", Timesteps = " + nTimeSteps.ToString());
                writer.WriteLine("GlobalVariables, NumGSVars = " + myGSvars.Count.ToString());

                if (myGSvars.Count > 0)
                {
                    string sGV = myGSvars[0];
                    for (int j = 1; j < myGSvars.Count; j++)
                        sGV += "," + myGSvars[j];
                    writer.WriteLine(sGV);

                    sGV = myGSvals[0].ToString();
                    for (int j = 1; j < myGSvars.Count; j++)
                        sGV += ";" + myGSvals[j].ToString();
                    writer.WriteLine(sGV);
                }

                for (int p = 0; p < nPops; p++)
                {
                    Population mpop = sysPops[p];

                    writer.WriteLine("PopulationVariables, NumPSVars = " + myPSvars.Count.ToString() + ", Population " + (p + 1).ToString() + ": " + mpop.name);

                    if (myPSvars.Count > 0)
                    {
                        string sPV = myPSvars[0];
                        for (int j = 1; j < myPSvars.Count; j++)
                            sPV += "," + myPSvars[j];
                        writer.WriteLine(sPV);

                        sPV = mpop.myPSvals[0].ToString();
                        for (int j = 1; j < mpop.myPSvals.Count; j++)
                            sPV += ";" + mpop.myPSvals[j].ToString();
                        writer.WriteLine(sPV);
                    }

                    writer.WriteLine("PopulationSize = " + mpop.Nindividuals.ToString());
                    if (mpop.Females.Count > 0 || mpop.Males.Count > 0)
                    {
                        writer.WriteLine("AgeStructure");
                        string tally = "Females: ";
                        for (int j = 0; j < mpop.Females.Count; j++) tally += mpop.Females[j].ToString() + ";";
                        writer.WriteLine(tally.Trim(';'));
                        tally = "Males: ";
                        for (int j = 0; j < mpop.Males.Count; j++) tally += mpop.Males[j].ToString() + ";";
                        writer.WriteLine(tally.Trim(';'));
                    }

                    if (!PopBase)  // Note: pop-based models can skip writing Individual data
                    {
                        writer.WriteLine("IndividualVariables, NumISVars = " + myISvars.Count.ToString());

                        string sIV = "Name,Index,Age,Sex"; // Note, these core Individual vars could be made ISvars in myModel instead of handled specially
                        // but be aware that MMM expect numISvars to not include these 4 core vars

                        for (int j = 0; j < myISvars.Count; j++)
                            sIV += "," + myISvars[j];
                        writer.WriteLine(sIV);

                        for (int m = 0; m < mpop.IndList.Count; m++)
                        {
                            string sLine = mpop.IndList[m].name + ";" + m.ToString() + ";" + mpop.IndList[m].age.ToString() + ";" + mpop.IndList[m].sex.ToString();

                            for (int j = 0; j < mpop.IndList[m].myISvals.Count; j++)
                                sLine += ";" + mpop.IndList[m].myISvals[j].ToString();

                            writer.WriteLine(sLine);
                        }
                    }
                }
                writer.Close();
            }
        }

        // returns false on error
        private bool ReadDataFile(string fileLocation)
        {
            try
            {
                WriteLog("ReadDataFile");

                using (var reader = new StreamReader(fileLocation))
                {
                    //Creator = MyModel ...
                    //Iteration = 1, Year = 50, Timesteps = 5
                    reader.ReadLine();
                    reader.ReadLine();

                    string[] ss;
                    char[] delims = { ',', ':', ';', '\t', '=' };
                    char[] delims2 = { ',', ':', ';', '\t', '=' }; // don't use commas to separate numbers, EU format problem

                    //GlobalVariables, NumGSVars = 2
                    //GS1, GS2
                    //1.0000,2.0000
                    string line = reader.ReadLine();
                    ss = line.Split(delims);
                    int nGSV = ss[ss.Length - 1].AsInt(0);

                    if (nGSV > 0)
                    {
                        line = reader.ReadLine();
                        ss = line.Split(delims); // read GSvar labels
                        List<string> MMGSV = new List<string>();
                        for (int i = 0; i < ss.Length; i++) MMGSV.Add(ss[i].Trim());

                        line = reader.ReadLine();
                        ss = line.Split(delims2); //read GSvar values
                        for (int i = 0; i < ss.Length; i++)
                        {
                            //for (int j = 0; j < MMGSV.Count; j++) // find the GSvar in local data set
                            //{
                            //int dex = myGSvars.IndexOf(MMGSV[i]); // caution: this will be case sensitive
                            int dex = GetGSVarIndex(MMGSV[i]); // caution: this will be case sensitive
                            if (dex >= 0) myGSvals[dex] = (double)ss[i].AsDecimal(0);
                            //}
                        }
                    }

                    //PopulationVariables, NumPSVars = 2, Population 1: PopName
                    //PS1,PS2
                    //22.000000; 11.000000

                    line = reader.ReadLine();
                    //for (int p = 0; p < nPops; p++)
                    var p = -1;
                    while (line.StartsWith("PopulationVar"))
                    {
                        p++;
                        while (sysPops.Count <= p)
                        {
                            sysPops.Add(new Population(myPSvars.Count));
                        }
                        Population mpop = sysPops[p];

                        if (!line.StartsWith("PopulationVar")) return false; // error handling should be added throughout the code

                        ss = line.Split(delims);
                        int nPSV = ss[2].AsInt(0);

                        if (nPSV > 0)
                        {
                            line = reader.ReadLine();
                            ss = line.Split(delims); // read PSvar labels
                            List<string> MMPSV = new List<string>();
                            for (int i = 0; i < ss.Length; i++) MMPSV.Add(ss[i].Trim());

                            line = reader.ReadLine();
                            ss = line.Split(delims2); //read PSvar values
                            for (int i = 0; i < ss.Length; i++)
                            {
                                //for (int j = 0; j < MMPSV.Count; j++) // find the PSvar in local data set
                                //{
                                //int dex = myPSvars.IndexOf(MMPSV[i]); // caution: this will be case sensitive
                                int dex = GetPSVarIndex(MMPSV[i]); // caution: this will be case sensitive
                                if (dex >= 0) mpop.myPSvals[dex] = (double)ss[i].AsDecimal(0);
                                //}
                            }
                        }

                        //PopulationSize = 100
                        //AgeStructure
                        //Females: 12;22;33
                        //Males: 32;12;11

                        line = reader.ReadLine();
                        while (line != null && !line.StartsWith("PopulationVar"))
                        {
                            ss = line.Split(delims2);

                            if (line.StartsWith("PopulationSize"))
                            {
                                mpop.Nindividuals = ss[1].AsInt(0);
                            }
                            else if (line.StartsWith("Females"))
                            {
                                mpop.Females.Clear();
                                for (int i = 1; i < ss.Length; i++) mpop.Females.Add(ss[i].AsInt(0));
                            }
                            else if (line.StartsWith("Males"))
                            {
                                mpop.Males.Clear();
                                for (int i = 1; i < ss.Length; i++) mpop.Males.Add(ss[i].AsInt(0));
                            }

                            if (!PopBase && line.StartsWith("IndividualVar"))
                            {
                                //IndividualVariables, NumISVars = 2
                                //Name,Index,Age,Sex,Var1,Var2
                                //33;0;11688;0;33.00000000;34.00000000
                                //35;1;11688;1;33.00000000;34.00000000

                                #region Individual Read
                                line = reader.ReadLine();
                                ss = line.Split(delims); // read ISvar labels
                                List<string> MMISV = new List<string>();
                                for (int i = 0; i < ss.Length; i++) MMISV.Add(ss[i].Trim());
                                if (MMISV[0] != "Name") return false; // this error should be handled somehow

                                // need to keep track of which individuals are in file and then remove missing ones
                                // because don't want to simply replace IndList, as it may have individual data not shared with MMM
                                List<bool> alive = new List<bool>();
                                int ict = mpop.IndList.Count;
                                for (int i = 0; i < ict; i++)
                                {
                                    alive.Add(false);
                                }

                                line = reader.ReadLine();
                                if (line == null) return true;

                                while (!line.StartsWith("PopulationVar"))
                                {
                                    ss = line.Split(delims2); //read values for each individual

                                    Individual ind;
                                    int id = ss[0].AsInt(0);
                                    int i1;
                                    for (i1 = 0; i1 < ict; i1++)
                                    {
                                        if (mpop.IndList[i1].name == id) break;
                                    }
                                    if (i1 >= ict)
                                    {
                                        ind = new Individual();
                                        // Note: Model may need to do more when a new individual appears 
                                        // if so, do it here
                                        // e.g., what if anything should be assigned as default values for age, sex, and ISvars?
                                        ind.name = id;
                                    }
                                    else
                                    {
                                        alive[i1] = true;
                                        ind = mpop.IndList[i1];
                                    }

                                    for (int i = 1; i < ss.Length; i++)
                                    {
                                        if (MMISV[i] == "Index") continue;
                                        if (MMISV[i] == "Sex")
                                        {
                                            ind.sex = ss[i].AsInt(0);
                                        }
                                        else if (MMISV[i] == "Age")
                                        {
                                            ind.age = ss[i].AsInt(0);
                                        }

                                        else for (int j = 0; j < MMISV.Count; j++) // find the ISvar in local data set
                                            {
                                                int dex = myISvars.IndexOf(MMISV[j]); // caution: this will be case sensitive
                                                if (dex >= 0) ind.myISvals[dex] = (double)ss[i].AsDecimal(0);
                                            }
                                    }

                                    line = reader.ReadLine();

                                    if (line.StartsWith("PopulationVar") || line == null) // end of individuals in pop
                                    {
                                        for (int i = ict - 1; i >= 0; ict--) if (!alive[ict]) mpop.IndList.RemoveAt(i);
                                    }
                                }
                                #endregion
                            }
                            else if ((line = reader.ReadLine()) == null)
                            {
                                nPops = sysPops.Count;
                                reader.Close();
                                return true; // Note that this can return without completing the using { }
                            } // probably should check for premature end of file

                        } // end of pop

                    }
                    nPops = sysPops.Count;
                    reader.Close();
                }
            }
            catch (Exception e)
            {
                WriteLog("Exception in Read: " + e.Message);
                return false;
            }

            return true;
        }

        #endregion

        #endregion

        #region Manipulate Variables

        private Population GetPop(int popNum)
        {
            return sysPops.Find(p => p.myPSvals[MetaPopClientIDIndex] == ClientID && p.PopNum == popNum);
        }

        #region Global State Vars
        public int UpdateGSvar(string varName, double val)
        {
            int ivar = myGSvars.IndexOf(varName);
            if (ivar >= 0)
            {
                myGSvals[ivar] = val;
                return ivar; // Don't allow duplicates
            }

            myGSvars.Add(varName);
            myGSvals.Add(val);
            return myGSvars.Count - 1; //index of added var
        }

        public int GetGSVarIndex(string varName)
        {
            int ivar = myGSvars.IndexOf(varName);
            if (ivar >= 0)
            {
                return ivar;
            }

            myGSvars.Add(varName);
            myGSvals.Add(0);
            return myGSvars.Count - 1; //index of added var
        }

        public double GetGSVar(string varName)
        {
            int ivar = myGSvars.IndexOf(varName);
            if (ivar >= 0)
            {
                return myGSvals[ivar];
            }

            return 0;
        }
        #endregion

        #region Population State Vars
        public int UpdatePSvar(string varName, double val, int popNum)
        {
            int ivar = GetPSVarIndex(varName);

            sysPops.Find(p => p.myPSvals[MetaPopClientIDIndex] == ClientID && p.PopNum == popNum).myPSvals[ivar] = val;
            return ivar; // Don't allow duplicates
        }

        public int GetPSVarIndex(string varName)
        {
            int ivar = myPSvars.IndexOf(varName);
            if (ivar >= 0)
            {
                return ivar;
            }

            myPSvars.Add(varName);
            foreach (var pop in sysPops)
            {
                pop.myPSvals.Add(0);
            }

            return myPSvars.Count - 1; //index of added var
        }

        public double GetPSVar(string varName, int popNum)
        {
            int ivar = GetPSVarIndex(varName);

            return sysPops.Find(p => p.myPSvals[MetaPopClientIDIndex] == ClientID && p.PopNum == popNum).myPSvals[ivar];
        }
        #endregion

        #region Application State Vars

        public object UpdateASvar(string varName, object val)
        {
            if (!myASvars.ContainsKey(varName))
            {
                myASvars.Add(varName, val);
            }
            else
            {
                myASvars[varName] = val;
            }

            return myASvars[varName];
        }

        public object GetASVar(string varName)
        {
            if (!myASvars.ContainsKey(varName))
            {
                myASvars.Add(varName, (double)0);
            }
            return myASvars[varName];
        }

        #endregion

        #region Complex Population State Vars
        
        public object UpdateCPSvar(string varName, object val)
        {
            if (!myCPSvars.ContainsKey(varName))
            {
                myCPSvars.Add(varName, val);
            }
            else
            {
                myCPSvars[varName] = val;
            }
            
            return myCPSvars[varName];
        }

        public object GetCPSVar(string varName)
        {
            if(!myCPSvars.ContainsKey(varName))
            {
                myCPSvars.Add(varName, (double)0);
            }
            return myCPSvars[varName];
        }

        #endregion

        #endregion

        #region R Functions

        public REngine engine;
        public static string engineID = "RDotNet";
        public static string RScriptFileLocation = "MMM_Functions.r";
        //public static string RScriptFileLocation = "MM_Functions_metamodelManager.R";
        //public static string RScriptDirectory = "C:/Documents and Settings/czeisej/My Documents/Dropbox/School/RAMAS/MMM/MeMoMa/bin/Release/";
        public static string RScriptDirectory = "";

        public void InitializeR()
        {
            SetupRPath();
            engine = REngine.GetInstanceFromID(engineID) ?? REngine.CreateInstance(engineID);
            if (!engine.IsRunning)
            {
                engine.Initialize();
            }

            string source = "source(\"" + RScriptDirectory + RScriptFileLocation + "\")";
            engine.Evaluate(source);
        }

        public void SetupRPath()
        {
            var oldPath = System.Environment.GetEnvironmentVariable("PATH");
            var rPath = System.Environment.Is64BitProcess ? @"C:\Program Files\R\R-3.0.2\bin\x64" : @"C:\Program Files\R\R-3.0.2\bin\i386";
            // Mac OS X
            //var rPath = "/Library/Frameworks/R.framework/Libraries";
            // Linux (in case of libR.so exists in the directory)
            //var rPath = "/usr/lib";
            if (Directory.Exists(rPath) == false)
                throw new DirectoryNotFoundException(string.Format("Could not found the specified path to the directory containing R.dll: {0}", rPath));
            var newPath = string.Format("{0}{1}{2}", rPath, System.IO.Path.PathSeparator, oldPath);
            System.Environment.SetEnvironmentVariable("PATH", newPath);
            // NOTE: you may need to set up R_HOME manually also on some machines
            string rHome = "";
            var platform = Environment.OSVersion.Platform;
            switch (platform)
            {
                case PlatformID.Win32NT:
                    break; // R on Windows seems to have a way to deduce its R_HOME if its R.dll is in the PATH
                case PlatformID.MacOSX:
                    rHome = "/Library/Frameworks/R.framework/Resources";
                    break;
                case PlatformID.Unix:
                    rHome = "/usr/lib/R";
                    break;
                default:
                    throw new NotSupportedException(platform.ToString());
            }
            if (!string.IsNullOrEmpty(rHome))
                Environment.SetEnvironmentVariable("R_HOME", rHome);
        }

        public void PushVariablesToR()
        {
            WriteLog("Push Vars to R");

            //Setup vars in R
            if (engine.GetSymbol("MMM") == null)
            {
                engine.Evaluate("MMM <- list()"); //For ALL vars in MMM
                engine.Evaluate("MMM$pop <- list()"); //For PopVars in MMM
            }
            if (engine.GetSymbol("MP") == null)
            {
                engine.Evaluate("MP <- list()"); //For ALL vars in MP
                engine.Evaluate("MP$client <- list()"); //For each client
            }


            //Global State Vars
            for (int i = 0; i < myGSvars.Count; i++)
            {
                var statement = String.Format("MMM${0} <- {1}", myGSvars[i], myGSvals[i]);
                engine.Evaluate(statement);
            }

            //Population State Vars
            for (int p = 0; p < sysPops.Count; p++)
            {
                var popstatement = String.Format("MMM$pop[[{0}]] <- list()", p + 1);
                engine.Evaluate(popstatement);

                for (int v = 0; v < myPSvars.Count; v++)
                {
                    var statement = String.Format("MMM$pop[[{0}]]${1} <- {2}", p + 1, myPSvars[v], sysPops[p].myPSvals[v]);
                    engine.Evaluate(statement);
                }
            }

            //Declare MP Clients
            var clientstatment = String.Format("MP$client[[{0}]] <- list()", ClientID);
            engine.Evaluate(clientstatment);

            //Declare global vars for the client
            var globalstatment = String.Format("MP$client[[{0}]]$global <- list()", ClientID);
            engine.Evaluate(globalstatment);

            //Application State Vars
            foreach (var asVar in myASvars)
            {
                var varName = String.Format("MP$client[[{0}]]$global${1}", ClientID, asVar.Key);
                PushValueToR(varName, asVar.Value);
            }

            //Declare global vars for the client
            var popstatment = String.Format("MP$client[[{0}]]$pop <- list()", ClientID);
            engine.Evaluate(popstatment);

            //Application State Vars
            foreach (var cpsVar in myCPSvars)
            {
                var varName = String.Format("MP$client[[{0}]]$pop${1}", ClientID, cpsVar.Key);
                PushValueToR(varName, cpsVar.Value);
            }
        }

        public void PushValueToR(string varname, object o)
        {
            if (o.GetType() == typeof(double[,,]))
            {
                string data = "";
                string dim = "";

                var mat = (double[, ,])o;
                var x = mat.GetLength(0);
                var y = mat.GetLength(1);
                var z = mat.GetLength(2);
                dim = String.Format("{0},{1},{2}", x, y, z);

                var values = new List<double>();
                for (int i = 0; i < x; i++)
                {
                    for (int j = 0; j < y; j++)
                    {
                        for (int k = 0; k < z; k++)
                        {
                            values.Add(mat[i,j,k]);
                        }
                    }
                }
                data = String.Join(",", values);

                var statement = String.Format("{0} <- array( data=c({1}), dim=c({2}) )", varname, data, dim);
                engine.Evaluate(statement);
            }
            else if (o.GetType() == typeof(double[,]))
            {
                var mat = (double[,])o;
                var rmat = engine.CreateNumericMatrix(mat);
                engine.SetSymbol("tempMMMVariable", rmat);
                engine.Evaluate(varname + " <- tempMMMVariable");
            }
            else if (o.GetType() == typeof(double[]))
            {
                var vec = (double[])o;
                var rvec = engine.CreateNumericVector(vec);
                engine.SetSymbol("tempMMMVariable", rvec);
                engine.Evaluate(varname + " <- tempMMMVariable");
            }
            else if (o.GetType() == typeof(double))
            {
                var val = (double) o;
                var statement = String.Format("{0} <- {1}", varname, val);
                engine.Evaluate(statement);
            }
            else if (o.GetType() == typeof(int) || o.GetType() == typeof(long))
            {
                var val = Convert.ToInt32(o);
                var statement = String.Format("{0} <- {1}", varname, val);
                engine.Evaluate(statement);
            }
            else if (o.GetType() == typeof(bool[,]))
            {
                var mat = (bool[,])o;
                var rmat = engine.CreateLogicalMatrix(mat);
                engine.SetSymbol("tempMMMVariable", rmat);
                engine.Evaluate(varname + " <- tempMMMVariable");
            }
            else if (o.GetType() == typeof(int[]))
            {
                var vec = (int[])o;
                var rvec = engine.CreateIntegerVector(vec);
                engine.SetSymbol("tempMMMVariable", rvec);
                engine.Evaluate(varname + " <- tempMMMVariable");
            }
            else
            {
                throw new InvalidCastException("Object data type not support by MetaPop Library");
            }
        }

        public void CallRScript()
        {
            WriteLog("Call R Script");
            engine.Evaluate("ModVitalRates(" + ClientID + ", " + yr + ")");
        }

        public void PullVariablesFromR()
        {
            WriteLog("Pull Vars from R");

            //Global State Vars
            for (int i = 0; i < myGSvars.Count; i++)
            {
                var statement = String.Format("MMM${0}", myGSvars[i]);
                string[] rvalue = engine.Evaluate(statement).AsCharacter().ToArray();
                myGSvals[i] = Convert.ToDouble(rvalue[0]);
            }

            //Population State Vars
            for (int p = 0; p < sysPops.Count; p++)
            {
                for (int v = 0; v < myPSvars.Count; v++)
                {
                    var statement = String.Format("MMM$pop[[{0}]]${1}", p + 1, myPSvars[v]);
                    string[] rvalue = engine.Evaluate(statement).AsCharacter().ToArray();
                    sysPops[p].myPSvals[v] = Convert.ToDouble(rvalue[0]);
                }
            }

            //Application State Vars
            foreach (var asVar in myASvars.ToList())
            {
                var varName = String.Format("MP$client[[{0}]]$global${1}", ClientID, asVar.Key);
                myASvars[asVar.Key] = PullValueFromR(varName, asVar.Value);
            }

            //Application State Vars
            foreach (var cpsVar in myCPSvars.ToList())
            {
                var varName = String.Format("MP$client[[{0}]]$pop${1}", ClientID, cpsVar.Key);
                myCPSvars[cpsVar.Key] = PullValueFromR(varName, cpsVar.Value);
            }
        }

        public object PullValueFromR(string varname, object o)
        {
            if (o.GetType() == typeof(double[, ,]))
            {
                var mat = (double[, ,])o;
                var x = mat.GetLength(0);
                var y = mat.GetLength(1);
                var z = mat.GetLength(2);

                for (int i = 0; i < x; i++)
                {
                    for (int j = 0; j < y; j++)
                    {
                        for (int k = 0; k < z; k++)
                        {
                            var statement = String.Format("{0}[{1},{2},{3}]", varname, i + 1, j + 1, k + 1);
                            var rval = engine.Evaluate(statement).AsNumeric()[0];
                            mat[i, j, k] = rval;
                        }
                    }
                }

                return mat;
            }
            else if (o.GetType() == typeof(double[,]))
            {
                var mat = (double[,])o;
                var rmat = engine.Evaluate(varname).AsNumericMatrix();
                rmat.CopyTo(mat, rmat.RowCount, rmat.ColumnCount);
                return mat;
            }
            else if (o.GetType() == typeof(double[]))
            {
                var vec = (double[])o;
                var rvec = engine.Evaluate(varname).AsNumeric();
                rvec.CopyTo(vec, rvec.Length);
                return vec;
            }
            else if (o.GetType() == typeof(double))
            {
                var val = (double)o;
                var rval = engine.Evaluate(varname).AsNumeric()[0];
                return rval;
            }
            else if (o.GetType() == typeof(int) || o.GetType() == typeof(long))
            {
                var val = Convert.ToInt32(o);
                var rval = engine.Evaluate(varname).AsNumeric()[0];
                return Convert.ToInt32(rval);
            }
            else if (o.GetType() == typeof(bool[,]))
            {
                var mat = (bool[,])o;
                var rmat = engine.Evaluate(varname).AsLogicalMatrix();
                rmat.CopyTo(mat, rmat.RowCount, rmat.ColumnCount);
                return mat;
            }
            else if (o.GetType() == typeof(int[]))
            {
                var vec = (int[])o;
                var rvec = engine.Evaluate(varname).AsInteger();
                rvec.CopyTo(vec, rvec.Length);
                return vec;
            }
            throw new InvalidCastException("Object data type not support by MetaPop Library");
            return new object();
        }

        #endregion

        #region Population Models

        //alpha: .5
        //htime: .01
        public double RDFuncResp(int PreyPop, int PredPop, double alpha, double htime)
        {
            double FuncResp;
            if ((PreyPop == 0) | (PredPop == 0))
            {
                FuncResp = 0;
            }
            else
            {
                FuncResp = (alpha * PreyPop) / (PredPop + alpha * htime * PreyPop);
            }
            return FuncResp;
        }

        public void PredatorPreyInteract()
        {
            WriteLog("PredPreyInteract");

            //GSVars: TotalPop,NumberOfClients,elNino
            //PSVars: popStMat,popAbundTot,popK,PS1,PS2,PS3
            //PS1 = N, PS2 = Mortality %, PS3 = K
            var alpha = 0.5;
            var maxKill = 365;
            var htime = 1 / maxKill;

            var popMP = sysPops[0];
            var popVortex = sysPops[1];

            var popMPTotal = Convert.ToInt32(popMP.myPSvals[GetPSVarIndex("popAbundTot")]);
            var popVortexTotal = Convert.ToInt32(popVortex.myPSvals[GetPSVarIndex("PS1")]);

            var FuncResp = RDFuncResp(popMPTotal, popVortexTotal, alpha, htime);
            WriteLog("FuncResp = " + FuncResp);

            popMP.myPSvals[GetPSVarIndex("popStMat")] *= (popVortexTotal / popMPTotal * 100) > 20 ? .75 : 1.1;
            //popVortex.myPSvals[GetPSVarIndex("PS2")] *= (popVortexTotal/popMPTotal*100) > 20 ? 1.5 : .75;
            popVortex.myPSvals[GetPSVarIndex("PS2")] = 100;
            popVortex.myPSvals[GetPSVarIndex("PS3")] *= 10;
        }

        #endregion

        #region Logger

        public static string ActivityLogFileLocation = @"Logger.txt";
        public static string ActivityLogDirectory = @"\";
        private static StreamWriter _logFile = null; //initialize stream for performance

        public bool LogPopulationVariables()
        {
            //public string name;
            //public int Nindividuals;
            //public List<int> Males;
            //public List<int> Females;
            //public List<double> myPSvals;
            //public List<Individual> IndList;
            //public int PopClientID;
            //public int PopNum;

            var result = true;
            for (int p = 0; p < sysPops.Count; p++)
            {
                string value = (string.IsNullOrEmpty(sysPops[p].name) ? "Pop " + p : sysPops[p].name) + ": ";
                for (int i = 0; i < myPSvars.Count; i++)
                {
                    value += myPSvars[i] + " = " + sysPops[p].myPSvals[i] + ", ";
                }
                value += "name - " + sysPops[p].name + ", ";
                value += "Nindividuals - " + sysPops[p].Nindividuals + ", ";
                value += "PopClientID - " + sysPops[p].PopClientID + ", ";
                value += "PopNum - " + sysPops[p].PopNum + ", ";
                result = result && WriteLog(value);
            }
            return result;
        }

        public bool LogGlobalVariables()
        {
            var result = true;

            string value = "Global Vars: ";
            for (int i = 0; i < myGSvars.Count; i++)
            {
                value += myGSvars[i] + " = " + myGSvals[i] + ", ";
            }
            result = result && WriteLog(value);

            return result;
        }

        public bool LogMPVars()
        {
            var result = true;

            string value = "MP Global Vars: ";
            value += String.Join(",", myASvars);
            result = result && WriteLog(value);

            value = "MP Pop Vars: ";
            value += String.Join(",", myCPSvars);
            result = result && WriteLog(value);

            return result;
        }

        public bool WriteLog(string message, bool append = true)
        {
            if (string.IsNullOrEmpty(message))
                return false;		// don't write empty messages
            if (ActivityLogFileLocation == String.Empty)
                return false;
            //if (!Directory.Exists(ActivityLogDirectory))
            //    return false;

            message = FormatMessage(message);

            bool printed = false;
            int tryCount = 0;

            //try writing 3x
            while (!printed && tryCount < 3)
            {
                ++tryCount;
                printed = true;
                _logFile = new StreamWriter(ActivityLogFileLocation, append);
                if (_logFile != null)
                {
                    _logFile.AutoFlush = true;
                    _logFile.Write(message);
                    _logFile.Close();
                    _logFile = null;
                }
                else
                {
                    printed = false;
                    //Thread.Sleep(5);
                }
            }

            return printed;
        }

        public void ClearLogFile()
        {
            if (!File.Exists(ActivityLogFileLocation))
                return;

            File.Delete(ActivityLogFileLocation);
            WriteLog("Log File Reset", false);
        }

        private string FormatMessage(string message)
        {
            var formattedMessage = String.Format("{0:MM/dd/yy hh:mm:ss tt}: ID: {1} - {2}\r\n",
                                                 DateTime.Now, ClientID, message);
            return formattedMessage;
        }

        #endregion
    }
}