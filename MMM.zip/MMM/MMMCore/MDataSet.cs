using System;
using System.Collections.Generic;
using System.IO;

namespace MMMCore
{
    public class MDataSet
    {
        // make core MM properties (nY, nIter, etc.) available through MDataSet, and changeable by linked programs
        public int Years = 10;
        public int Iterations = 10;

        public List<object> Vars = new List<object>();
//        public List<string> Vars = new List<string>();
        public List<string> VarNames = new List<string>();
        public List<Type> VarTypes = new List<Type>();

        public List<MPopulation> Populations = new List<MPopulation>();

        public int AddVar(string varName, object val, Type type)
        {
            varName = varName.ToUpper(); // 18 dec 2014

            int ivar = VarNames.IndexOf(varName);
            if (ivar >= 0)
            {
                Vars[ivar] = val; //.ToString();
                return ivar; // Don't allow duplicates
            }

            VarNames.Add(varName);
            Vars.Add(val.ToString());
            VarTypes.Add(type);
            return Vars.Count - 1; //index of added var
        }

        public int AddVar(string varName, object val)
        {
            varName = varName.ToUpper();

            int ivar = VarNames.IndexOf(varName);
            if (ivar >= 0)
            {
                Vars[ivar] = val; //.ToString();
                return ivar; // Don't allow duplicates
            }

            VarNames.Add(varName);
            Vars.Add(val.ToString());
            VarTypes.Add(val.GetType());
//            VarTypes.Add(typeof(string));
            return Vars.Count - 1; //index of added var
        }

        public int AddVar(string varName)
        {
            varName = varName.ToUpper();

            if (VarNames.IndexOf(varName) >= 0) return VarNames.IndexOf(varName); // Don't allow duplicates

            VarNames.Add(varName);
            Vars.Add("");
            VarTypes.Add(typeof(string));
            return Vars.Count - 1; //index of added var
        }

        public int GetVarIndex(string varName) { 
            return VarNames.IndexOf(varName.ToUpper()); }

        // new stuff to handle object Vars
        public object SetVarVal(int i, string svar)
        {
            object o = null;

            Type type = VarTypes[i];
            //if (type == typeof(double)
            //    || type == typeof(int)
            //    || type == typeof(string)
            //    || type == typeof(decimal)
            //    || type == typeof(float)
            //    || type == typeof(bool)
            //    || type == typeof(long)
            //    || type == typeof(short)
            //    || type == typeof(char)
            //    || type == typeof(ulong)
            //    || type == typeof(ushort)
            //    || type == typeof(byte)
            //    || type == typeof(sbyte)
            //    || type == typeof(DateTime)
            //    || type == typeof(uint)) 

            try
            {
                o = Convert.ChangeType(svar, type);
            }
            catch { }

            // and handle more complex types, such as arrays ...

            Vars[i] = o; 

            return o;
        }

        public object SetVarVal(int i, object ovar)
        {
            object o = null;

            Type type = VarTypes[i];
            //if (type == typeof(double)
            //    || type == typeof(int)
            //    || type == typeof(string)
            //    || type == typeof(decimal)
            //    || type == typeof(float)
            //    || type == typeof(bool)
            //    || type == typeof(long)
            //    || type == typeof(short)
            //    || type == typeof(char)
            //    || type == typeof(ulong)
            //    || type == typeof(ushort)
            //    || type == typeof(byte)
            //    || type == typeof(sbyte)
            //    || type == typeof(DateTime)
            //    || type == typeof(uint))

            try
            {
                o = Convert.ChangeType(ovar, type);
            }
            catch { }

            // and handle more complex types, such as arrays ...

            Vars[i] = o;

            return o;
        }

        public string GetVarVal(int i)
        {
            string s = "";

//            Type type = VarTypes[i];

            //if (type == typeof(double)
            //    || type == typeof(int)
            //    || type == typeof(string)
            //    || type == typeof(decimal)
            //    || type == typeof(float)
            //    || type == typeof(bool)
            //    || type == typeof(long)
            //    || type == typeof(short)
            //    || type == typeof(char)
            //    || type == typeof(ulong)
            //    || type == typeof(ushort)
            //    || type == typeof(byte)
            //    || type == typeof(sbyte)
            //    || type == typeof(DateTime)
            //    || type == typeof(uint))
                s = Vars[i].ToString();

            // and handle more complex types, such as arrays ...

            return s;
        }

        public double GetVarDouble(int i)
        {
            double d = 0.0;

            //Type type = VarTypes[i];

            // this was very slow for some reason ...
            //if (type == typeof(double)
            //    || type == typeof(int)
            //    || type == typeof(string)
            //    || type == typeof(decimal)
            //    || type == typeof(float)
            //    || type == typeof(bool)
            //    || type == typeof(long)
            //    || type == typeof(short)
            //    || type == typeof(char)
            //    || type == typeof(ulong)
            //    || type == typeof(ushort)
            //    || type == typeof(byte)
            //    || type == typeof(sbyte)
            //    || type == typeof(DateTime)
            //    || type == typeof(uint))

            try
            {
                d = Convert.ToDouble(Vars[i]);
            }
            catch { }
            // and handle more complex types, such as arrays ...

            return d;
        }


        public void WritePopulationFile(string fileLocation, int populationIndex)
        {
            int j, m;

            using (StreamWriter writer = new StreamWriter(fileLocation))
            {
                writer.WriteLine("Population File.");
                writer.WriteLine("GlobalVariables, NumGSVars = " + VarNames.Count.ToString());

                if (VarNames.Count > 0)
                {
                    writer.Write(VarNames[0]);
                    for (j = 1; j < VarNames.Count; j++)
                        writer.Write("," + VarNames[j]);
                    writer.Write(writer.NewLine);

                    writer.Write(GetVarVal(0));
                    //writer.Write(this.Vars[0]);
                    for (j = 1; j < Vars.Count; j++)
                        writer.Write(";" + GetVarVal(j));
                    //                writer.Write(";" + this.Vars[j]);
                    writer.Write(writer.NewLine);

                }

                writer.WriteLine("PopulationVariables, NumPSVars = " + Populations[populationIndex].VarNames.Count.ToString());

                if (Populations[populationIndex].VarNames.Count > 0)
                {
                    writer.Write(Populations[populationIndex].VarNames[0]);
                    for (j = 1; j < Populations[populationIndex].VarNames.Count; j++)
                        writer.Write("," + Populations[populationIndex].VarNames[j]);
                    writer.Write(writer.NewLine);

                    writer.Write(Populations[populationIndex].Vars[0]);
                    for (j = 1; j < Populations[populationIndex].Vars.Count; j++)
                        writer.Write(";" + Populations[populationIndex].Vars[j]);
                    writer.Write(writer.NewLine);
                }


                writer.Write(Populations[populationIndex].IndVarNames[0]);
                for (j = 1; j < Populations[populationIndex].IndVarNames.Count; j++)
                    writer.Write("," + Populations[populationIndex].IndVarNames[j]);

                writer.Write(writer.NewLine);

                if (Populations[populationIndex].IndList.Count > 0)
                {
                    for (m = 0; m < Populations[populationIndex].IndList.Count; m++)
                    {
                        writer.Write(Populations[populationIndex].IndList[m].Vars[0]);

                        for (j = 1; j < Populations[populationIndex].IndList[m].Vars.Count; j++)
                            writer.Write(";" + Populations[populationIndex].IndList[m].Vars[j]);
                        writer.Write(writer.NewLine);
                    }
                }
                writer.Close();
            }
        }


    }
}
