using System;
using System.Collections.Generic;
using System.Xml;

namespace MMMCore
{
    public class MPopulation
    {
        public string Name = "";

        public List<string> Vars = new List<string>();
        public List<string> VarNames = new List<string>();
        public List<Type> VarTypes = new List<Type>();

        public List<MIndividual> IndList = new List<MIndividual>();

        public List<string> IndVarDefault = new List<string>(); // value to be assigned to new Individual in MIndividual constructor
        public List<string> IndVarNames = new List<string>();
        public List<Type> IndVarTypes = new List<Type>();

        // for use in population-based models
        public int AgeClassDuration = 365;
        public List<int> Males = new List<int>(); // age structure for males
        public List<int> Females = new List<int>(); // age structure for females
        private int mIndividuals = -1;
        public int Nindividuals
        {
            get
            {
                if (mIndividuals < 0) return IndList.Count;
                else return mIndividuals; 
            } 
            set { mIndividuals = value; } // so a pop-based model can change Nindividuals
        }


        public int Count() // for use by models that set the Males and Females age structure, but don't themselves set Nindividuals
        {
            int ct = 0;

            for (int i = 0; i < Males.Count; i++) ct += Males[i];
            for (int i = 0; i < Females.Count; i++) ct += Females[i];

            mIndividuals = ct;

            return ct;
        }


        public int tallyPopulation()
        {
            Males = new List<int>(); 
            Females = new List<int>(); 
            int ct = 0;

            try
            {
                getCoreIndVars();

                foreach (MIndividual mind in IndList)
                {
                    if (mind.Vars[mAliveIndex] == "0") continue;

                    if (mind.Vars[mSexIndex] == "1")
                    {
                        int ageClass = Convert.ToInt32(mind.Vars[mAgeIndex]) / AgeClassDuration;
                        while (ageClass >= Males.Count) Males.Add(0);

                        Males[ageClass]++;
                    }
                    else
                    {
                        int ageClass = Convert.ToInt32(mind.Vars[mAgeIndex]) / AgeClassDuration;
                        while (ageClass >= Females.Count) Females.Add(0);

                        Females[ageClass]++;
                    }

                }

                for (int i = 0; i < Males.Count; i++) ct += Males[i];
                for (int i = 0; i < Females.Count; i++) ct += Females[i];

            }
            catch
            {
                return -1;
            }

            mIndividuals = ct;

            return ct;
        }

        // method to make individuals from pop tallies
        // caution: will destroy any pre-existing Individuals
        public int makeIndividuals()
        {
            int ndx = 0;

            try
            {
                IndList.Clear();

                getCoreIndVars();

                for (int i = 0; i < Males.Count; i++) 
                {
                    for (int j = 0; j < Males[i]; j++)
                    {
                        MIndividual mind = new MIndividual(this);
                        string sndx = ndx.ToString();
                        mind.Vars[mIDindex] = sndx;
                        mind.Vars[mNameIndex] = sndx;
                        mind.Vars[mSexIndex] = "1";
                        int age = AgeClassDuration * i;
                        mind.Vars[mAgeIndex] = age.ToString();
                        mind.Vars[mAliveIndex] = "1";

                        IndList.Add(mind);
                        ndx++;
                    }
                }

                for (int i = 0; i < Females.Count; i++)
                {
                    for (int j = 0; j < Females[i]; j++)
                    {
                        MIndividual mind = new MIndividual(this);
                        string sndx = ndx.ToString();
                        mind.Vars[mIDindex] = sndx;
                        mind.Vars[mNameIndex] = sndx;
                        mind.Vars[mSexIndex] = "0";
                        int age = AgeClassDuration * i;
                        mind.Vars[mAgeIndex] = age.ToString();
                        mind.Vars[mAliveIndex] = "1";

                        IndList.Add(mind);
                        ndx++;
                    }
                }

            }
            catch
            {
                return -1;
            }

//            mIndividuals = -1;

            return ndx;
        }

        public int GetMIndividualIndexFromName(int startIndex, string name) 
            // option to provide starting index can speed up the search if you know the individ will be after the last one searched
        {
            if (startIndex < 0) startIndex = 0;

            for (int i = startIndex; i < IndList.Count; i++)
            {
                if (IndList[i].Vars[mNameIndex].Equals(name))
                    return i;
            }

            return -1;
        }

        public int GetMIndividualIndexFromName(string name)
        {
            return GetMIndividualIndexFromName(0, name);
        }

        public MIndividual GetMIndividualFromName(int startIndex, string name)
        {
            if (startIndex < 0) startIndex = 0;

            for (int i = startIndex; i < IndList.Count; i++)
            {
                if (IndList[i].Vars[mNameIndex].Equals(name))
                    return IndList[i];
            }

            return null;
        }

        public MIndividual GetMIndividualFromName(string name)
        {
            return GetMIndividualFromName(0, name);
        }

        private int mIDindex = -1;
        private int mNameIndex = -1;
        private int mAgeIndex = -1;
        private int mAliveIndex = -1;
        private int mSexIndex = -1;

        public int IDindex { get { if (mIDindex < 0) mIDindex = AddIndVar("Index", ""); return mIDindex; } }
        public int NameIndex { get { if (mNameIndex < 0) mNameIndex = AddIndVar("Name", ""); return mNameIndex; } }
        public int AgeIndex { get { if (mAgeIndex < 0) mAgeIndex = AddIndVar("Age", ""); return mAgeIndex; } }
        public int AliveIndex { get { if (mAliveIndex < 0) mAliveIndex = AddIndVar("Alive", "0"); return mAliveIndex; } }
        public int SexIndex { get { if (mSexIndex < 0) mSexIndex = AddIndVar("Sex", ""); return mSexIndex; } }

        public bool getCoreIndVars() 
        {
            try
            {
                //mIDindex = GetIndividualVarIndex("Index");
                //mNameIndex = GetIndividualVarIndex("Name");
                //mAgeIndex = GetIndividualVarIndex("Age");
                //mAliveIndex = GetIndividualVarIndex("Alive");
                //mSexIndex = GetIndividualVarIndex("Sex");

                if (mNameIndex < 0) mNameIndex = AddIndVar("Name", "");
                if (mIDindex < 0) mIDindex = AddIndVar("Index", "");
                if (mAgeIndex < 0) mAgeIndex = AddIndVar("Age", "");
                if (mSexIndex < 0) mSexIndex = AddIndVar("Sex", "");
                if (mAliveIndex < 0) mAliveIndex = AddIndVar("Alive", "0");
            }
            catch
            {
                return false;
            }

            return true;
        }


        public int AddVar(string varName, object val, Type type)
        {
            varName = varName.ToUpper();  //18 Dec 2014, convert all varnames to uppercase, so don't have conflicts 

            int ivar = VarNames.IndexOf(varName);
            if (ivar >= 0)
            {
                Vars[ivar] = val.ToString();
                return ivar; // Don't allow duplicates
            }

            VarNames.Add(varName);
            Vars.Add(val.ToString());
            VarTypes.Add(type);
            return Vars.Count - 1; //index of added var
        }

        public int AddVar(string varName, object val)
        {
            varName = varName.ToUpper();  //18 Dec 2014, convert all varnames to uppercase, so don't have conflicts 

            int ivar = VarNames.IndexOf(varName);
            if (ivar >= 0)
            {
                Vars[ivar] = val.ToString();
                return ivar; // Don't allow duplicates
            }

            VarNames.Add(varName);
            Vars.Add(val.ToString());
            VarTypes.Add(typeof(string));
            return Vars.Count - 1; //index of added var
        }

        public int AddVar(string varName)
        {
            varName = varName.ToUpper();  //18 Dec 2014, convert all varnames to uppercase, so don't have conflicts 

            if (VarNames.IndexOf(varName) >= 0) return VarNames.IndexOf(varName); // Don't allow duplicates

            VarNames.Add(varName);
            Vars.Add("");
            VarTypes.Add(typeof(string));
            return Vars.Count - 1; //index of added var
        }

        public int GetVarIndex(string varName) {
              //18 Dec 2014, convert all varnames to uppercase, so don't have conflicts 
            return VarNames.IndexOf(varName.ToUpper()); 
        }

        //public int GetIndividualVarIndex(string varName)
        //{
        //    if (IndList.Count == 0)
        //        return -1;
        //    else
        //        return IndList[0].GetVarIndex(varName);
        //}

        public int GetIndividualVarIndex(string varName)
        {
  //18 Dec 2014, convert all varnames to uppercase, so don't have conflicts 
            return IndVarNames.IndexOf(varName.ToUpper());
        }

        public int AddIndVar(string varName, object val, Type type)
        {
            varName = varName.ToUpper();  //18 Dec 2014, convert all varnames to uppercase, so don't have conflicts 

            int ivar = IndVarNames.IndexOf(varName);
            if (ivar >= 0)
            {
                IndVarDefault[ivar] = val.ToString();
                return ivar; // Don't allow duplicates
            }

            IndVarNames.Add(varName);
            IndVarDefault.Add(val.ToString());
            IndVarTypes.Add(type);

            foreach (MIndividual mind in IndList) mind.Vars.Add(val.ToString());

            return IndVarNames.Count - 1; //index of added var
        }

        public int AddIndVar(string varName, object val)
        {
            return AddIndVar(varName, val, typeof(string));
        }

        public int AddIndVar(string varName)
        {
            return AddIndVar(varName, "", typeof(string));
        }


        public void ToXML(string fileLocation)
        {
            XmlDocument doc = new XmlDocument();

            //add top level node
            XmlElement popNode = doc.CreateElement("Population");
            doc.AppendChild(popNode);

            //attribute for population node
            XmlAttribute tmpAttrib = doc.CreateAttribute("Name");
            tmpAttrib.Value = "Pop";
            popNode.Attributes.Append(tmpAttrib);

            tmpAttrib = doc.CreateAttribute("Creator");
            tmpAttrib.Value = "MMM";
            popNode.Attributes.Append(tmpAttrib);

            

            //population variables
            XmlElement popVarsNode = doc.CreateElement("PopulationVariables");
            popNode.AppendChild(popVarsNode);
            tmpAttrib = doc.CreateAttribute("NumVars");
            tmpAttrib.Value = Vars.Count.ToString();
            popVarsNode.Attributes.Append(tmpAttrib);

            for (int j = 0; j < Vars.Count; j++)
            {
                XmlElement varNode = doc.CreateElement(VarNames[j]);
                varNode.InnerText = Vars[j].ToString();

                XmlAttribute varAttrib = doc.CreateAttribute("Type");
                varAttrib.Value = Convert.ToInt32(VarTypes[j]).ToString();
                varNode.Attributes.Append(varAttrib);

                popVarsNode.AppendChild(varNode);
            }



            //Additional Variables List
            XmlElement addlVarsNode = doc.CreateElement("IndividualVariables");
            popNode.AppendChild(addlVarsNode);
            tmpAttrib = doc.CreateAttribute("NumVars");
            tmpAttrib.Value = IndList[0].Vars.ToString();
            addlVarsNode.Attributes.Append(tmpAttrib);

            for (int j = 0; j < IndList[0].Vars.Count; j++)
            {
                //XmlElement varNode = doc.CreateElement(IndList[0].VarNames[j]);

                //XmlAttribute varAttrib = doc.CreateAttribute("Type");
                //varAttrib.Value = Convert.ToInt32(IndList[0].VarTypes[j]).ToString();
                //varNode.Attributes.Append(varAttrib);

                XmlElement varNode = doc.CreateElement(IndVarNames[j]);
                varNode.InnerText = IndVarDefault[j].ToString();

                XmlAttribute varAttrib = doc.CreateAttribute("Type");
                varAttrib.Value = Convert.ToInt32(IndVarTypes[j]).ToString();
                varNode.Attributes.Append(varAttrib);

                addlVarsNode.AppendChild(varNode);
            }


            //individuals
            XmlElement indListNode = doc.CreateElement("IndividualList");
            popNode.AppendChild(indListNode);
            tmpAttrib = doc.CreateAttribute("NumIndividuals");
            tmpAttrib.Value = IndList.Count.ToString();
            indListNode.Attributes.Append(tmpAttrib);

            for (int i = 0; i < IndList.Count; i++)
            {
                XmlElement iNode = doc.CreateElement("Individual");
                indListNode.AppendChild(iNode);

                XmlAttribute varAttrib = doc.CreateAttribute("Name");
                varAttrib.Value = i.ToString();
                iNode.Attributes.Append(varAttrib);

                for (int j = 0; j < IndList[i].Vars.Count; j++)
                {
//                    XmlElement n = doc.CreateElement(IndList[i].VarNames[j]);
                    XmlElement n = doc.CreateElement(IndVarNames[j]);
                    n.InnerText = IndList[i].Vars[j];
                    iNode.AppendChild(n);
                }

            }

        }
    }
}
