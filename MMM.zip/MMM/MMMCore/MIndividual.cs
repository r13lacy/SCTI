using System;
using System.Collections.Generic;

namespace MMMCore
{
    public class MIndividual
    {
        public List<string> Vars = new List<string>();

        // put VarNames and VarTypes over in Mpop, because they should never been different for different Individuals
        //public List<string> VarNames = new List<string>();
        //public List<Type> VarTypes = new List<Type>();

        public MPopulation MPop;

        public MIndividual(MPopulation mPop)
        {
            MPop = mPop;
            mPop.IndList.Add(this);

            foreach (string iVar in mPop.IndVarDefault) Vars.Add(iVar);
        }

        // following functions provide backward compatibilty with any programs that added IndVars at the Ind level. 

        public List<string> VarNames { get { return MPop.VarNames; } set { MPop.VarNames = value; } }
        public List<Type> VarTypes { get { return MPop.VarTypes; } }

        public int AddVar(string varName, object val, Type type)
        {
            int ct = 0;

            if (!VarNames.Contains(varName))
            {
                ct = MPop.AddIndVar(varName, val, type);
            }
            return ct; //index of added var
        }

        public int AddVar(string varName, object val)
        {
            return AddVar(varName, val, typeof(string));
        }

        public int AddVar(string varName)
        {
            return AddVar(varName, "", typeof(string));
        }


        //public int AddVar(string varName, object val, Type type)
        //{
        //    VarNames.Add(varName);
        //    Vars.Add(val.ToString());
        //    VarTypes.Add(type);
        //    return Vars.Count - 1; //index of added var
        //}

        //public int AddVar(string varName, object val)
        //{
        //    VarNames.Add(varName);
        //    Vars.Add(val.ToString());
        //    VarTypes.Add(typeof(string));
        //    return Vars.Count - 1; //index of added var
        //}

        //public int AddVar(string varName)
        //{
        //    VarNames.Add(varName);
        //    Vars.Add("");
        //    VarTypes.Add(typeof(string));
        //    return Vars.Count - 1; //index of added var
        //}

        public int GetVarIndex(string varName) { return MPop.GetIndividualVarIndex(varName); }

    
    }
}
