using System;
using System.Collections.Generic;
using System.Windows.Forms;
using EvaluatorLibrary;

namespace EvaluatorForm
{
    public partial class EvaluateForm : Form
    {
        Evaluator eval;

        public EvaluateForm()
        {
            InitializeComponent();
            label6.Visible = false;
        }

        private void textBox1_LostFocus(object sender, EventArgs e)
        {
            eval = new Evaluator(textBox1.Text);

            eval.clearSynonymies();
            eval.addSynonymy(textBox41.Text, textBox38.Text);
            eval.addSynonymy(textBox40.Text, textBox37.Text);
            eval.addSynonymy(textBox39.Text, textBox36.Text);

            eval.clearSpecials();
            eval.addSpecial(textBox23.Text);
            eval.addSpecial(textBox13.Text);
            eval.addSpecial(textBox12.Text);

//            label4.Text = eval.Parenthetical;
//            label3.Text = eval.Polish;
//            eval.Translate();
        }

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    label4.Text = eval.Parenthetical;
        //    label3.Text = eval.Polish;
        //}

        //private void button2_Click(object sender, EventArgs e)
        //{
        //    eval.Translate();
        //}

        private void button3_Click(object sender, EventArgs e)
        {
            eval.Translate();
            label4.Text = eval.Parenthetical;
            label3.Text = eval.Polish;

            string used = "";
            List<string> usedV = eval.usedVars();
            foreach (string svar in usedV) used += svar + "; ";
            label50.Text = "Vars used: " + used;

            if (eval.checkEval()) label6.Text = "OK!";
            else label6.Text = "Check Failure";
            label6.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();

            dlg.Filter = "Timeseries (*.txt)|*.txt";

            if (dlg.ShowDialog() == DialogResult.OK)
                textBox1.Text = textBox1.Text + "FILE(" + dlg.FileName + ")";
        }

        List<double> vars = new List<double>();
        List<double> gsvars = new List<double>();
        List<double> psvars = new List<double>();
        List<List<double>> ppsvars = new List<List<double>>();
        List<double> isvars = new List<double>();
        List<double> spvars = new List<double>();

        private void button5_Click(object sender, EventArgs e)
        {
            label4.Text = eval.Parenthetical;
            label3.Text = eval.Polish;
            eval.Translate();

            string used = "";
            List<string> usedV = eval.usedVars();
            foreach (string svar in usedV) used += svar + "; ";
            label50.Text = "Vars used: " + used;

            setvars();
//            label35.Text = Convert.ToString(eval.doEval(vars, spvars, gsvars, psvars, isvars, ppsvars));
            label35.Text = eval.doStringEval(vars, spvars, gsvars, psvars, isvars, ppsvars);
        }

        private void setvars() {
            //List<double> vars = new List<double>();
            //List<double> gsvars = new List<double>();
            //List<double> psvars = new List<double>();
            //List<List<double>> ppsvars = new List<List<double>>();
            //List<double> isvars = new List<double>();
            //List<double> spvars = new List<double>();

            eval.clearSynonymies();
            eval.addSynonymy(textBox41.Text, textBox38.Text);
            eval.addSynonymy(textBox40.Text, textBox37.Text);
            eval.addSynonymy(textBox39.Text, textBox36.Text);

            vars.Clear();
            vars.Add(Convert.ToDouble(textBox2.Text));
            vars.Add(Convert.ToDouble(textBox3.Text));
            vars.Add(Convert.ToDouble(textBox4.Text));
            vars.Add(Convert.ToDouble(textBox5.Text));
            vars.Add(Convert.ToDouble(textBox6.Text));
            vars.Add(Convert.ToDouble(textBox7.Text));
            vars.Add(Convert.ToDouble(textBox8.Text));
            vars.Add(Convert.ToDouble(textBox9.Text));
            vars.Add(Convert.ToDouble(textBox10.Text));

            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(10.0);
            vars.Add(Convert.ToDouble(textBox11.Text)); //Y
            vars.Add(10.0);

            vars.Add(Convert.ToDouble(textBox32.Text));
            vars.Add(Convert.ToDouble(textBox31.Text));
            vars.Add(Convert.ToDouble(textBox30.Text));

            isvars.Clear();
            isvars.Add(Convert.ToDouble(textBox22.Text));
            isvars.Add(Convert.ToDouble(textBox21.Text));
            isvars.Add(Convert.ToDouble(textBox20.Text));

            gsvars.Clear();
            gsvars.Add(Convert.ToDouble(textBox16.Text));
            gsvars.Add(Convert.ToDouble(textBox15.Text));
            gsvars.Add(Convert.ToDouble(textBox14.Text));

            eval.clearSpecials();
            eval.addSpecial(textBox23.Text);
            eval.addSpecial(textBox13.Text);
            eval.addSpecial(textBox12.Text);

            spvars.Clear();
            spvars.Add(Convert.ToDouble(textBox35.Text));
            spvars.Add(Convert.ToDouble(textBox34.Text));
            spvars.Add(Convert.ToDouble(textBox33.Text));

            psvars.Clear();
            psvars.Add(Convert.ToDouble(textBox19.Text));
            psvars.Add(Convert.ToDouble(textBox18.Text));
            psvars.Add(Convert.ToDouble(textBox17.Text));

            List<double> pps1 = new List<double>();
            List<double> pps2 = new List<double>();
            List<double> pps3 = new List<double>();

            pps1.Add(Convert.ToDouble(textBox19.Text));
            pps1.Add(Convert.ToDouble(textBox26.Text));
            pps1.Add(Convert.ToDouble(textBox29.Text));
            ppsvars.Add(pps1);

            pps2.Add(Convert.ToDouble(textBox18.Text));
            pps2.Add(Convert.ToDouble(textBox25.Text));
            pps2.Add(Convert.ToDouble(textBox28.Text));
            ppsvars.Add(pps2);

            pps3.Add(Convert.ToDouble(textBox17.Text));
            pps3.Add(Convert.ToDouble(textBox24.Text));
            pps3.Add(Convert.ToDouble(textBox27.Text));
            ppsvars.Add(pps3);
        }

        private void Check3D_CheckedChanged(object sender, EventArgs e)
        {
            if (Check3D.Checked) {
                Plot2D.Visible = false;
//                Plot3D.Visible = true;
            }
            else {
                Plot2D.Visible = true;
//                Plot3D.Visible = false;
            }
        }

        private void PlotBtn_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            List<double> xvals = new List<double>();
            List<double> x2vals = new List<double>();
            List<double> yvals = new List<double>();
            List<double> zvals = new List<double>();

            label4.Text = eval.Parenthetical;
            label3.Text = eval.Polish;
            eval.Translate();

            string used = "";
            List<string> usedV = eval.usedVars();
            foreach (string svar in usedV) used += svar + "; ";
            label50.Text = "Vars used: " + used;

            setvars();

            xvals.Clear();
            x2vals.Clear();
            yvals.Clear();
            zvals.Clear();
            string xs;
            List<string> specs = eval.specialVars();

            for (double i = Convert.ToDouble(XRangeStart.Text); i <= Convert.ToDouble(XRangeEnd.Text); i += Convert.ToDouble(XIncrement.Text))
            {
                string xvar = Xvar.Text.Trim().ToUpper();

                if (null != (xs = eval.findSynonym(xvar)))
                {
                    xvar = xs;
                }

                int sndx = specs.IndexOf(xvar);
                if (sndx >= 0) spvars[sndx] = i;


                if (xvar.Length == 1 && (xvar[0] >= 'A' && xvar[0] <= 'Z'))
                {
                    vars[xvar[0] - 'A'] = i;
                }
                else if (xvar.StartsWith("VAR"))
                {
                    int ndx = 25 + Convert.ToInt32(xvar.Substring(3));
                    while (vars.Count <= ndx) vars.Add(100.0);
                    vars[ndx] = i;
                }
                else if (xvar.StartsWith("GS"))
                {
                    int ndx = -1 + Convert.ToInt32(xvar.Substring(2));
                    while (gsvars.Count <= ndx) gsvars.Add(100.0);
                    gsvars[ndx] = i;
                }
                else if (xvar.StartsWith("PS"))
                {
                    int ndx = -1 + Convert.ToInt32(xvar.Substring(2));
                    while (psvars.Count <= ndx) psvars.Add(100.0);
                    psvars[ndx] = i;
                }
                else if (xvar.StartsWith("IS"))
                {
                    int ndx = -1 + Convert.ToInt32(xvar.Substring(2));
                    while (isvars.Count <= ndx) isvars.Add(100.0);
                    isvars[ndx] = i;
                }
                else if (xvar.StartsWith("PSS"))
                {
                    int ndx = -1 + Convert.ToInt32(xvar.Substring(3));
                    xs = xvar.Substring(5);
                    int ndx2 = -1 + Convert.ToInt32(xs);
                    while (ppsvars.Count <= ndx) ppsvars.Add(new List<double>() );
                    while (ppsvars[ndx].Count <= ndx2) ppsvars[ndx].Add(100.0);
                    ppsvars[ndx][ndx2] = i;
                }


                if (Check3D.Checked)
                {
                    for (double j = Convert.ToDouble(YRangeStart.Text); j <= Convert.ToDouble(YRangeEnd.Text); j += Convert.ToDouble(YIncrement.Text))
                    {
                        xvals.Add(i);
                        yvals.Add(j);

                        string yvar = Yvar.Text.Trim().ToUpper();

                        if (null != (xs = eval.findSynonym(yvar)))
                        {
                            yvar = xs;
                        }

                        sndx = specs.IndexOf(yvar);
                        if (sndx >= 0) spvars[sndx] = j;

                        if (yvar.Length == 1 && yvar[0] >= 'A' && yvar[0] <= 'Z')
                        {
                            vars[yvar[0] - 'A'] = j;
                        }
                        else if (yvar.StartsWith("VAR"))
                        {
                            int ndx = 25 + Convert.ToInt32(yvar.Substring(3));
                            while (vars.Count <= ndx) vars.Add(100.0);
                            vars[ndx] = j;
                        }
                        else if (yvar.StartsWith("GS"))
                        {
                            int ndx = -1 + Convert.ToInt32(yvar.Substring(2));
                            while (gsvars.Count <= ndx) gsvars.Add(100.0);
                            gsvars[ndx] = j;
                        }
                        else if (yvar.StartsWith("PS"))
                        {
                            int ndx = -1 + Convert.ToInt32(yvar.Substring(2));
                            while (psvars.Count <= ndx) psvars.Add(100.0);
                            psvars[ndx] = j;
                        }
                        else if (yvar.StartsWith("IS"))
                        {
                            int ndx = -1 + Convert.ToInt32(yvar.Substring(2));
                            while (isvars.Count <= ndx) isvars.Add(100.0);
                            isvars[ndx] = j;
                        }

                        else if (yvar.StartsWith("PSS"))
                        {
                            int ndx = -1 + Convert.ToInt32(yvar.Substring(3));
                            xs = yvar.Substring(5);
                            int ndx2 = -1 + Convert.ToInt32(xs);
                            while (ppsvars.Count <= ndx) ppsvars.Add(new List<double>());
                            while (ppsvars[ndx].Count <= ndx2) ppsvars[ndx].Add(100.0);
                            ppsvars[ndx][ndx2] = i;
                        }

                        try
                        {
                            zvals.Add(eval.doEval(vars, spvars, gsvars, psvars, isvars, ppsvars));
                        }
                        catch {
                            //MessageBox("Failed function evaluation");
                            return;
                        }
                    }
                }
                else
                {
                    try
                    {
                        xvals.Add(i);
                        yvals.Add(eval.doEval(vars, spvars, gsvars, psvars, isvars, ppsvars));
                    }
                    catch
                    {
                        // MessageBox("Failed function evaluation");
                        return;
                    }

                }

            }

            // now do graphs
            if (Check3D.Checked)
            {
                Plot2D.Visible = false;
                Plot3D.Visible = true;
                EvalChart.Do3DPlot(Plot3D, eval.FuncStr, Xvar.Text, Yvar.Text, "Result", xvals, yvals, zvals);
            }
            else
            {
                Plot2D.Visible = true;
                Plot3D.Visible = false;

                EvalChart.DoPlot(Plot2D, eval.FuncStr, Xvar.Text, "Result", xvals, yvals);
            }

            Cursor.Current = Cursors.Default;

        }

        private void Plot3D_DoubleClick(object sender, EventArgs e)
        {
            Plot3D.ShowProperties();
        }

        private void Plot2D_DoubleClick(object sender, EventArgs e)
        {
            Plot2D.ShowProperties();
        }

        private void label35_DoubleClick(object sender, EventArgs e)
        {
            //FileStream file = new FileStream("funtest.txt", FileMode.Create, FileAccess.Write);
            //StreamWriter txtWriter = new StreamWriter(file);

            //txtWriter.WriteLine("Results for function: " + eval.ToString());
            //string answer = "";

            //for (int i = 0; i < spvars[2]; i++)
            //{
            //    answer = eval.doStringEval(vars, spvars, gsvars, psvars, isvars, ppsvars);
            //    txtWriter.WriteLine(answer);
            //}

            //txtWriter.Close();
            //file.Close();
        }

        private void label40_DoubleClick(object sender, EventArgs e)
        {
//            FileStream file = new FileStream("funtest.txt", FileMode.Create, FileAccess.Write);
//            StreamWriter txtWriter = new StreamWriter(file);

//            txtWriter.Write("Seed");
//            for(int i = 5; i < 100; i += 5) 
//            {
//                for (int j = 1; j < 6; j++)
//                {
//                    txtWriter.Write("; m" + i.ToString() + "v" + j.ToString());
//                }
//            }
//            txtWriter.WriteLine();

//            string answer = "";

//            int seed = 13;
//            for (int i = 0; i < 1000; i++)
//            {
//                seed += 23;
//                txtWriter.Write(seed.ToString());

////                int ct = 0;
//                for (double mean = 0.05; mean < 0.99; mean += 0.05)
//                {
//                    vars[0] = mean;
//                    double vlimit = mean * (1.0 - mean);
//                    vars[2] = seed;

//                    double var = vlimit * 0.1;
//                    vars[1] = var;
//                    answer = eval.doStringEval(vars, spvars, gsvars, psvars, isvars, ppsvars);
////                    txtWriter.WriteLine((++ct).ToString() + ", " + seed.ToString() + ", " + mean.ToString() + ", " + var.ToString() + ", " + answer);
//                    txtWriter.Write("; " + answer);

//                    var = vlimit * 0.2;
//                    vars[1] = var;
//                    answer = eval.doStringEval(vars, spvars, gsvars, psvars, isvars, ppsvars);
//                    //                    txtWriter.WriteLine((++ct).ToString() + ", " + seed.ToString() + ", " + mean.ToString() + ", " + var.ToString() + ", " + answer);
//                    txtWriter.Write("; " + answer);

//                    var = vlimit * 0.3;
//                    vars[1] = var;
//                    answer = eval.doStringEval(vars, spvars, gsvars, psvars, isvars, ppsvars);
//                    //                    txtWriter.WriteLine((++ct).ToString() + ", " + seed.ToString() + ", " + mean.ToString() + ", " + var.ToString() + ", " + answer);
//                    txtWriter.Write("; " + answer);
                    
//                    var = vlimit * 0.4;
//                    vars[1] = var;
//                    answer = eval.doStringEval(vars, spvars, gsvars, psvars, isvars, ppsvars);
//                    //                    txtWriter.WriteLine((++ct).ToString() + ", " + seed.ToString() + ", " + mean.ToString() + ", " + var.ToString() + ", " + answer);
//                    txtWriter.Write("; " + answer);
                    
//                    var = vlimit * 0.5;
//                    vars[1] = var;
//                    answer = eval.doStringEval(vars, spvars, gsvars, psvars, isvars, ppsvars);
//                    //                    txtWriter.WriteLine((++ct).ToString() + ", " + seed.ToString() + ", " + mean.ToString() + ", " + var.ToString() + ", " + answer);
//                    txtWriter.Write("; " + answer);
//                }
//                txtWriter.WriteLine();
//            }

//            txtWriter.Close();
//            file.Close();
        }

        
    }
}