using System;
using System.Windows.Forms;
using EvaluatorForm;

namespace EvaluateEvaluator
{
    static class EvaluatorTest
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new EvaluateForm());
        }
    }
}