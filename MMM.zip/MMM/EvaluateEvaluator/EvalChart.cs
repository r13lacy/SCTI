using System;
using System.Collections.Generic;
using C1.Win.C1Chart;
using C1.Win.C1Chart3D;

namespace EvaluatorForm
{
    public class EvalChart
    {
        //colors for plotting
        private static System.Drawing.Color[] colorList = {
            System.Drawing.Color.Blue,
            System.Drawing.Color.Red,
            System.Drawing.Color.LimeGreen,
            System.Drawing.Color.DarkViolet, 
            System.Drawing.Color.Black,
            System.Drawing.Color.DeepSkyBlue,
            System.Drawing.Color.LightSeaGreen 
        };

        //GENERAL PLOTTING FUNCTIONS************************************************************************************************
        public static void DoPlotBarTextLabels(C1Chart chart, string title, string xTitle, string yTitle, List<string> xData, List<double> yData)
        {
            //Compute y Min and Max
            DoPlotBarTextLabels(chart, title, xTitle, yTitle, ListMin(yData), ListMax(yData), xData, yData);
        }

        public static void DoPlotBarTextLabels(C1Chart chart, string title, string xTitle, string yTitle, 
            double yMin, double yMax, List<string> xData, List<double> yData)
        {
            //Master function, does the plotting
            chart.ChartGroups.Group0.ChartType = Chart2DTypeEnum.Bar;
            chart.ChartGroups.Group0.Bar.ClusterWidth = 100;


            chart.ChartGroups.Group0.ChartData.SeriesList.Clear();
            chart.ChartGroups.Group1.ChartData.SeriesList.Clear();
            chart.ChartArea.AxisX.ValueLabels.Clear();

            chart.Header.Text = title;
            chart.Header.Visible = true;

            chart.ChartArea.AxisY.Text = yTitle;
            chart.ChartArea.AxisY.Min = yMin;
            chart.ChartArea.AxisY.Max = yMax;

            chart.ChartArea.AxisX.Text = xTitle;
            chart.ChartArea.AxisX.AutoMax = true;
            chart.ChartArea.AxisX.AutoMin = true;


            //plot it
            C1.Win.C1Chart.ChartDataSeries ds = new C1.Win.C1Chart.ChartDataSeries();
            chart.ChartGroups.Group0.ChartData.SeriesList.Add(ds);

            ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.None;
            ds.FillStyle.Color1 = colorList[0];


            for (int j = 0; j < xData.Count; j++)
            {
                ds.X.Add(j);
                ds.Y.Add(yData[j]);
                chart.ChartArea.AxisX.ValueLabels.Add(j, xData[j]);
            }

            chart.ChartArea.AxisX.AnnoMethod = C1.Win.C1Chart.AnnotationMethodEnum.ValueLabels;
        }

// 2D plots
        public static void DoPlot(C1Chart chart, string title, string xTitle, string yTitle, List<double> xData, List<double> yData)
        {
            //Compute y Min and Max
            DoPlot(chart, title, xTitle, yTitle, ListMin(yData), ListMax(yData), xData, yData);
        }

        public static void DoPlot(C1Chart chart, string title, string xTitle, string yTitle, 
            double yMin, double yMax, List<double> xData, List<double> yData)
        {
            List<List<double>> newList = new List<List<double>>();
            newList.Add(yData);
            DoPlot(chart, title, xTitle, yTitle, ListMin(xData), ListMax(xData), yMin, yMax, xData, newList, null);
        }

        public static void DoPlot(C1Chart chart, string title, string xTitle, string yTitle, List<double> xData, List<List<double>> yData)
        {
            //Compute y Min and Max
            DoPlot(chart, title, xTitle, yTitle, ListMin(xData), ListMax(xData), ListMin(yData), ListMax(yData), xData, yData, null);
        }

        public static void DoPlot(C1Chart chart, string title, string xTitle, string yTitle,
            double yMin, double yMax, List<double> xData, List<List<double>> yData)
        {
            DoPlot(chart, title, xTitle, yTitle, ListMin(xData), ListMax(xData), yMin, yMax, xData, yData, null);
        }

        public static void DoPlot(C1Chart chart, string title, string xTitle, string yTitle,
            double yMin, double yMax, List<double> xData, List<List<double>> yData, List<string> yLabels)
        {
            DoPlot(chart, title, xTitle, yTitle, ListMin(xData), ListMax(xData), yMin, yMax, xData, yData, yLabels);
        }

        public static void DoPlot(C1Chart chart, string title, string xTitle, string yTitle,
            double xMin, double xMax, double yMin, double yMax, List<double> xData, List<List<double>> yData, List<string> yLabels)
        {
            //Master function, does the plotting
            chart.ChartGroups.Group0.ChartType = Chart2DTypeEnum.XYPlot;

            chart.Header.Text = title;
            chart.Header.Visible = true;

            chart.ChartGroups.Group0.ChartData.SeriesList.Clear();
            chart.ChartGroups.Group1.ChartData.SeriesList.Clear();
            chart.ChartArea.AxisX.ValueLabels.Clear();

            chart.ChartArea.AxisX.Text = xTitle;
            chart.ChartArea.AxisX.AutoMax = false;
            chart.ChartArea.AxisX.AutoMin = false;
            chart.ChartArea.AxisX.Min = xMin;
            chart.ChartArea.AxisX.Max = xMax;

            chart.ChartArea.AxisY.Text = yTitle;
            chart.ChartArea.AxisY.Min = yMin;
            chart.ChartArea.AxisY.Max = yMax;

            //plot it
            for (int i = 0; i < yData.Count; i++)
            {
                C1.Win.C1Chart.ChartDataSeries ds = new C1.Win.C1Chart.ChartDataSeries();
                chart.ChartGroups.Group0.ChartData.SeriesList.Add(ds);

                ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.None;
                //ds.SymbolStyle.Color = colorList[i % colorList.Count];
                ds.LineStyle.Pattern = C1.Win.C1Chart.LinePatternEnum.Solid;
                ds.LineStyle.Thickness = 2;
                ds.LineStyle.Color = colorList[i % colorList.Length];

                if (yLabels != null)
                    ds.Label = yLabels[i];

                for (int j = 0; j < xData.Count; j++)
                {
                    ds.X.Add(xData[j]);
                    ds.Y.Add(yData[i][j]);
                }

            }

            chart.ChartArea.AxisX.AnnoMethod = C1.Win.C1Chart.AnnotationMethodEnum.Values;

            //legend
            if (yLabels == null)
                chart.Legend.Visible = false;
            else
            {

                chart.Legend.Visible = true;
            }

        }

// 3D plots
        public static void Do3DPlot(C1Chart3D chart, string title, string xTitle, string yTitle, string zTitle, List<double> xData, List<double> yData, List<double> zData)
        {
            //Compute y Min and Max
            Do3DPlot(chart, title, xTitle, yTitle, zTitle, ListMin(xData), ListMax(xData), ListMin(yData), ListMax(yData), ListMin(zData), ListMax(zData), xData, yData, zData);
        }

        public static void Do3DPlot(C1Chart3D chart, string title, string xTitle, string yTitle, string zTitle,
            double zMin, double zMax, List<double> xData, List<double> yData, List<double> zData)
        {
            Do3DPlot(chart, title, xTitle, yTitle, zTitle, ListMin(xData), ListMax(xData), ListMin(yData), ListMax(yData), zMin, zMax, xData, yData, zData);
        }

        public static void Do3DPlot(C1Chart3D chart, string title, string xTitle, string yTitle, string zTitle,
            double xMin, double xMax, double yMin, double yMax, double zMin, double zMax, List<double> xData, List<double> yData, List<double> zData)
        {
//            Master function, does the 3D plotting
            chart.ChartGroups.Group0.ChartType = Chart3DTypeEnum.Scatter;
//            chart.ChartGroups.Group0.ChartType = Chart3DTypeEnum.Surface;
//            chart.ChartGroups.Group0.Contour.IsContoured = true;

            chart.Header.Text = title;
            chart.Header.Visible = true;

            chart.ChartArea.AxisX.ValueLabels.Clear();

            chart.ChartArea.AxisX.Text = xTitle;
            chart.ChartArea.AxisX.AutoMax = false;
            chart.ChartArea.AxisX.AutoMin = false;
            chart.ChartArea.AxisX.Min = xMin;
            chart.ChartArea.AxisX.Max = xMax;

            chart.ChartArea.AxisY.ValueLabels.Clear();
            chart.ChartArea.AxisY.Text = yTitle;
            chart.ChartArea.AxisY.Min = yMin;
            chart.ChartArea.AxisY.Max = yMax;

            chart.ChartArea.AxisZ.Text = zTitle;
            chart.ChartArea.AxisZ.Min = zMin;
            chart.ChartArea.AxisZ.Max = zMax;

            //plot it

            Chart3DPoint[] xyzSeries = new Chart3DPoint[zData.Count];
            Chart3DDataSetPoint setPoint = new Chart3DDataSetPoint(); 

            for (int k = 0; k < zData.Count; k++)
            {
                Chart3DPoint xyz = new Chart3DPoint(); 

                xyz.X = xData[k];
                xyz.Y = yData[k];
                xyz.Z = zData[k];

                xyzSeries[k] = xyz;
            }
            setPoint.AddSeries(xyzSeries);

            chart.ChartGroups[0].ChartData.Set = setPoint;

            chart.ChartArea.AxisX.AnnoMethod = C1.Win.C1Chart3D.AnnotationMethodEnum.Values;
            chart.ChartArea.AxisY.AnnoMethod = C1.Win.C1Chart3D.AnnotationMethodEnum.Values;

        }


// 2D rt and left axes
        public static void DoPlotMultiAxes(C1Chart chart, string title, string xTitle, string yTitle1, string yTitle2, List<double> xData, List<double> yData1, List<double> yData2)
        {
            //Compute y Min and Max
            DoPlotMultiAxes(chart, title, xTitle, yTitle1, yTitle2, ListMin(yData1), ListMax(yData1), ListMin(yData2), ListMax(yData2), xData, yData1, yData2);

        }

        public static void DoPlotMultiAxes(C1Chart chart, string title, string xTitle, string yTitle1, string yTitle2,
            double yMin1, double yMax1, double yMin2, double yMax2, List<double> xData, List<double> yData1, List<double> yData2)
        {
            //Master function, does the plotting
            int i;

            chart.ChartGroups.Group0.ChartType = Chart2DTypeEnum.XYPlot;

            chart.Header.Text = title;
            chart.Header.Visible = true;

            chart.ChartGroups.Group0.ChartData.SeriesList.Clear();
            chart.ChartGroups.Group1.ChartData.SeriesList.Clear();
            chart.ChartArea.AxisX.ValueLabels.Clear();

            chart.ChartArea.AxisX.Text = xTitle;
            chart.ChartArea.AxisX.AutoMax = false;
            chart.ChartArea.AxisX.AutoMin = false;
            chart.ChartArea.AxisX.Min = ListMin(xData);
            chart.ChartArea.AxisX.Max = ListMax(xData);

            chart.ChartArea.AxisY.Text = yTitle1;
            chart.ChartArea.AxisY.Min = yMin1;
            chart.ChartArea.AxisY.Max = yMax1;
            chart.ChartArea.AxisY.ForeColor = System.Drawing.Color.Red;

            chart.ChartArea.AxisY2.Text = yTitle2;
            chart.ChartArea.AxisY2.Min = yMin2;
            chart.ChartArea.AxisY2.Max = yMax2;
            chart.ChartArea.AxisY2.Visible = true;
            chart.ChartArea.AxisY2.ForeColor = System.Drawing.Color.DarkBlue;


            //plot it
            C1.Win.C1Chart.ChartDataSeries ds = new C1.Win.C1Chart.ChartDataSeries();
            chart.ChartGroups.Group0.ChartData.SeriesList.Add(ds);

            ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.None;
            //ds.SymbolStyle.Color = colorList[i % colorList.Count];
            ds.LineStyle.Thickness = 2;
            ds.LineStyle.Color = System.Drawing.Color.Red;


            C1.Win.C1Chart.ChartDataSeries ds2 = new C1.Win.C1Chart.ChartDataSeries();
            chart.ChartGroups.Group1.ChartData.SeriesList.Add(ds2);

            ds2.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.None;
            //ds.SymbolStyle.Color = colorList[i % colorList.Count];
            ds.LineStyle.Pattern = C1.Win.C1Chart.LinePatternEnum.Solid;
            ds2.LineStyle.Thickness = 2;
            ds2.LineStyle.Color = System.Drawing.Color.DarkBlue;


            for (i = 0; i < xData.Count; i++)
            {
                ds.X.Add(xData[i]);
                ds.Y.Add(yData1[i]);

                ds2.X.Add(xData[i]);
                ds2.Y.Add(yData2[i]);
            }

            chart.ChartArea.AxisX.AnnoMethod = C1.Win.C1Chart.AnnotationMethodEnum.ValueLabels;

        }

        public static void DoPlotScatter(C1Chart chart, string title, string xTitle, string yTitle, List<double> xData, List<double> yData)
        {
            //Compute y Min and Max
            DoPlotScatter(chart, title, xTitle, yTitle, ListMin(yData), ListMax(yData), xData, yData);
        }

        public static void DoPlotScatter(C1Chart chart, string title, string xTitle, string yTitle,
            double yMin, double yMax, List<double> xData, List<double> yData)
        {
            List<List<double>> newList = new List<List<double>>();
            newList.Add(yData);
            DoPlotScatter(chart, title, xTitle, yTitle, xData, newList);
        }

        public static void DoPlotScatter(C1Chart chart, string title, string xTitle, string yTitle, List<double> xData, List<List<double>> yData)
        {
            //Compute y Min and Max
            DoPlotScatter(chart, title, xTitle, yTitle, ListMin(yData), ListMax(yData), xData, yData);

        }
        
        public static void DoPlotScatter(C1Chart chart, string title, string xTitle, string yTitle,
            double yMin, double yMax, List<double> xData, List<List<double>> yData)
        {
            //Master function, does the plotting
            chart.ChartGroups.Group0.ChartType = Chart2DTypeEnum.XYPlot;

            chart.Header.Text = title;
            chart.Header.Visible = true;

            chart.ChartGroups.Group0.ChartData.SeriesList.Clear();
            chart.ChartGroups.Group1.ChartData.SeriesList.Clear();
            chart.ChartArea.AxisX.ValueLabels.Clear();

            chart.ChartArea.AxisX.Text = xTitle;
            chart.ChartArea.AxisX.AutoMax = false;
            chart.ChartArea.AxisX.AutoMin = false;
            chart.ChartArea.AxisX.Min = ListMin(xData);
            chart.ChartArea.AxisX.Max = ListMax(xData);

            chart.ChartArea.AxisY.Text = yTitle;
            chart.ChartArea.AxisY.Min = yMin;
            chart.ChartArea.AxisY.Max = yMax;

            //plot it
            for (int i = 0; i < yData.Count; i++)
            {
                C1.Win.C1Chart.ChartDataSeries ds = new C1.Win.C1Chart.ChartDataSeries();
                chart.ChartGroups.Group0.ChartData.SeriesList.Add(ds);

                ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Diamond;
                ds.SymbolStyle.Color = colorList[i % colorList.Length];
                ds.SymbolStyle.OutlineColor = colorList[i % colorList.Length];
                //ds.SymbolStyle.Color = colorList[i % colorList.Count];
                ds.LineStyle.Pattern = C1.Win.C1Chart.LinePatternEnum.None;


                for (int j = 0; j < xData.Count; j++)
                {
                    ds.X.Add(xData[j]);
                    ds.Y.Add(yData[i][j]);
                }

            }

            chart.ChartArea.AxisX.AnnoMethod = C1.Win.C1Chart.AnnotationMethodEnum.Values;
        }

        public static void DoPlotFreqHistogram(C1Chart chart, string title, string xTitle, string yTitle, 
            double binSize, bool cumulative, List<double> yData)
        {
            //Master function, does the plotting
            int i, j;

            double yDataMax = ListMax(yData);
            double yMax;

            //if (yDataMax < 1.0)
            //    yDataMax = 1.0;

            if (yDataMax < binSize)
                yMax = binSize;
            else
            {
                if (Math.Floor(yDataMax / binSize) == yDataMax / binSize)
                    yMax = yDataMax;
                else
                    yMax = binSize * (Math.Floor(yDataMax / binSize) + 1);
            }

            //calculate the bins
            int numBins = Convert.ToInt32(yMax / binSize);
            double[] binTops = new double[numBins];
            int[] binCounts = new int[numBins];

            for (i = 1; i <= numBins; i++)
            {
                binTops[i - 1] = binSize * i;
                binCounts[i - 1] = 0;
            }

            //now go through data and put it in the right bins
            for (i = 0; i < yData.Count; i++)
            {
                j = 0;
                while (yData[i] > binTops[j])
                    j++;

                binCounts[j]++;
            }

            if (cumulative)
            {
                for (i = 1; i < numBins; i++)
                    binCounts[i] += binCounts[i - 1];
            }


            chart.ChartGroups.Group0.ChartType = Chart2DTypeEnum.Bar;
            chart.ChartGroups.Group0.Bar.ClusterWidth = 100;

            chart.ChartGroups.Group0.ChartData.SeriesList.Clear();
            chart.ChartGroups.Group1.ChartData.SeriesList.Clear();
            chart.ChartArea.AxisX.ValueLabels.Clear();

            chart.Header.Text = title;
            chart.Header.Visible = true;

            chart.ChartArea.AxisY.Text = yTitle;
            chart.ChartArea.AxisY.Min = 0;
            chart.ChartArea.AxisY.AutoMax = true;

            chart.ChartArea.AxisX.Text = xTitle;
            chart.ChartArea.AxisX.AutoMax = true;
            chart.ChartArea.AxisX.Min = 0;


            //plot it
            C1.Win.C1Chart.ChartDataSeries ds = new C1.Win.C1Chart.ChartDataSeries();
            chart.ChartGroups.Group0.ChartData.SeriesList.Add(ds);

            ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.None;
            ds.FillStyle.Color1 = colorList[0];
            
            for (j = 0; j < numBins; j++)
            {
                ds.X.Add(binTops[j] - (0.5 * binSize));
                ds.Y.Add(binCounts[j]);
                //chart.ChartArea.AxisX.ValueLabels.Add(j, xData[j]);
            }

            chart.ChartArea.AxisX.AnnoMethod = C1.Win.C1Chart.AnnotationMethodEnum.Values;
        }

        public static double ListMin(List<double> list)
        {
            double d = list[0];

            for (int i = 1; i < list.Count; i++)
                d = Math.Min(d, list[i]);

            return d;
        }

        public static double ListMin(List<List<double>> list)
        {
            double d = list[0][0];

            for (int i = 0; i < list.Count; i++)
                for (int j = 0; j < list[i].Count; j++)
                    d = Math.Min(d, list[i][j]);

            return d;
        }

        public static double ListMax(List<double> list)
        {
            double d = list[0];

            for (int i = 1; i < list.Count; i++)
                d = Math.Max(d, list[i]);

            return d;
        }

        public static double ListMax(List<List<double>> list)
        {
            double d = list[0][0];

            for (int i = 0; i < list.Count; i++)
                for (int j = 0; j < list[i].Count; j++)
                    d = Math.Max(d, list[i][j]);

            return d;
        }

        public static double ArrayMax(double[] array)
        {
            double d = array[0];

            for (int i = 1; i < array.Length; i++)
                d = Math.Max(d, array[i]);

            return d;

        }

        public static double ArrayMin(double[] array)
        {
            double d = array[0];

            for (int i = 1; i < array.Length; i++)
                d = Math.Min(d, array[i]);

            return d;

        }

    }
}
