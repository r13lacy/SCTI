namespace MMMacroEntry
{
    partial class MMMacroEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required Macro for Designer support - do not modify
        /// the contents of this Macro with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnRun = new System.Windows.Forms.Button();
            this.BtnReadFile = new System.Windows.Forms.Button();
            this.GridGlobalMacro = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.GridPopMacro = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.GridIndMacro = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.GridGSVars = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.GridPSVars = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.GridISVars = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.lable1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.GridGlobalMacro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridPopMacro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridIndMacro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridGSVars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridPSVars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridISVars)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnRun
            // 
            this.BtnRun.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRun.Location = new System.Drawing.Point(984, 702);
            this.BtnRun.Margin = new System.Windows.Forms.Padding(4);
            this.BtnRun.Name = "BtnRun";
            this.BtnRun.Size = new System.Drawing.Size(87, 42);
            this.BtnRun.TabIndex = 5;
            this.BtnRun.Text = "Run!";
            this.BtnRun.UseVisualStyleBackColor = true;
            this.BtnRun.Click += new System.EventHandler(this.BtnRun_Click);
            // 
            // BtnReadFile
            // 
            this.BtnReadFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnReadFile.Location = new System.Drawing.Point(865, 11);
            this.BtnReadFile.Margin = new System.Windows.Forms.Padding(4);
            this.BtnReadFile.Name = "BtnReadFile";
            this.BtnReadFile.Size = new System.Drawing.Size(205, 28);
            this.BtnReadFile.TabIndex = 6;
            this.BtnReadFile.Text = "Read GlobalMacro File";
            this.BtnReadFile.UseVisualStyleBackColor = true;
            this.BtnReadFile.Click += new System.EventHandler(this.BtnReadFile_Click);
            // 
            // GridGlobalMacro
            // 
            this.GridGlobalMacro.AllowAddNew = true;
            this.GridGlobalMacro.AllowDelete = true;
            this.GridGlobalMacro.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.Rows;
            this.GridGlobalMacro.ColumnInfo = "2,1,0,0,0,85,Columns:0{Width:49;}\t1{Width:533;}\t";
            this.GridGlobalMacro.Location = new System.Drawing.Point(303, 50);
            this.GridGlobalMacro.Margin = new System.Windows.Forms.Padding(4);
            this.GridGlobalMacro.Name = "GridGlobalMacro";
            this.GridGlobalMacro.Rows.Count = 1;
            this.GridGlobalMacro.Rows.DefaultSize = 17;
            this.GridGlobalMacro.Size = new System.Drawing.Size(781, 184);
            this.GridGlobalMacro.TabIndex = 7;
            this.GridGlobalMacro.AfterDragRow += new C1.Win.C1FlexGrid.DragRowColEventHandler(this.GridGlobalMacro_AfterDragRow);
            this.GridGlobalMacro.AfterAddRow += new C1.Win.C1FlexGrid.RowColEventHandler(this.GridGlobalMacro_AfterAddRow);
            this.GridGlobalMacro.AfterDeleteRow += new C1.Win.C1FlexGrid.RowColEventHandler(this.GridGlobalMacro_AfterDeleteRow);
            this.GridGlobalMacro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GridGlobalMacro_KeyPress);
            // 
            // GridPopMacro
            // 
            this.GridPopMacro.AllowAddNew = true;
            this.GridPopMacro.AllowDelete = true;
            this.GridPopMacro.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.Rows;
            this.GridPopMacro.ColumnInfo = "2,1,0,0,0,85,Columns:0{Width:49;}\t1{Width:531;}\t";
            this.GridPopMacro.Location = new System.Drawing.Point(303, 278);
            this.GridPopMacro.Margin = new System.Windows.Forms.Padding(4);
            this.GridPopMacro.Name = "GridPopMacro";
            this.GridPopMacro.Rows.Count = 1;
            this.GridPopMacro.Rows.DefaultSize = 17;
            this.GridPopMacro.Size = new System.Drawing.Size(781, 169);
            this.GridPopMacro.TabIndex = 8;
            this.GridPopMacro.AfterDragRow += new C1.Win.C1FlexGrid.DragRowColEventHandler(this.GridPopMacro_AfterDragRow);
            this.GridPopMacro.AfterAddRow += new C1.Win.C1FlexGrid.RowColEventHandler(this.GridPopMacro_AfterAddRow);
            this.GridPopMacro.AfterDeleteRow += new C1.Win.C1FlexGrid.RowColEventHandler(this.GridPopMacro_AfterDeleteRow);
            this.GridPopMacro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GridPopMacro_KeyPress);
            // 
            // GridIndMacro
            // 
            this.GridIndMacro.AllowAddNew = true;
            this.GridIndMacro.AllowDelete = true;
            this.GridIndMacro.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.Rows;
            this.GridIndMacro.ColumnInfo = "2,1,0,0,0,85,Columns:0{Width:50;}\t1{Width:532;}\t";
            this.GridIndMacro.Location = new System.Drawing.Point(303, 487);
            this.GridIndMacro.Margin = new System.Windows.Forms.Padding(4);
            this.GridIndMacro.Name = "GridIndMacro";
            this.GridIndMacro.Rows.Count = 1;
            this.GridIndMacro.Rows.DefaultSize = 17;
            this.GridIndMacro.Size = new System.Drawing.Size(781, 206);
            this.GridIndMacro.TabIndex = 9;
            this.GridIndMacro.AfterDragRow += new C1.Win.C1FlexGrid.DragRowColEventHandler(this.GridIndMacro_AfterDragRow);
            this.GridIndMacro.AfterAddRow += new C1.Win.C1FlexGrid.RowColEventHandler(this.GridIndMacro_AfterAddRow);
            this.GridIndMacro.AfterDeleteRow += new C1.Win.C1FlexGrid.RowColEventHandler(this.GridIndMacro_AfterDeleteRow);
            this.GridIndMacro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GridIndMacro_KeyPress);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(865, 242);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(205, 28);
            this.button1.TabIndex = 10;
            this.button1.Text = "Read PopMacro File";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(865, 455);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(205, 28);
            this.button2.TabIndex = 11;
            this.button2.Text = "Read IndMacro File";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Save
            // 
            this.Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Save.Location = new System.Drawing.Point(792, 702);
            this.Save.Margin = new System.Windows.Forms.Padding(4);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(184, 42);
            this.Save.TabIndex = 12;
            this.Save.Text = "Save MMMacro File";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // GridGSVars
            // 
            this.GridGSVars.AllowAddNew = true;
            this.GridGSVars.AllowDelete = true;
            this.GridGSVars.ColumnInfo = "2,0,0,0,0,85,Columns:0{Name:\"Var\";Caption:\"GlobalVar\";}\t1{Name:\"Value\";Caption:\"V" +
    "alue\";}\t";
            this.GridGSVars.Location = new System.Drawing.Point(24, 50);
            this.GridGSVars.Margin = new System.Windows.Forms.Padding(4);
            this.GridGSVars.Name = "GridGSVars";
            this.GridGSVars.Rows.Count = 1;
            this.GridGSVars.Rows.DefaultSize = 17;
            this.GridGSVars.Size = new System.Drawing.Size(239, 184);
            this.GridGSVars.TabIndex = 13;
            // 
            // GridPSVars
            // 
            this.GridPSVars.AllowAddNew = true;
            this.GridPSVars.AllowDelete = true;
            this.GridPSVars.ColumnInfo = "2,0,0,0,0,85,Columns:0{Caption:\"PopVar\";}\t1{Caption:\"Value\";}\t";
            this.GridPSVars.Location = new System.Drawing.Point(24, 278);
            this.GridPSVars.Margin = new System.Windows.Forms.Padding(4);
            this.GridPSVars.Name = "GridPSVars";
            this.GridPSVars.Rows.Count = 1;
            this.GridPSVars.Rows.DefaultSize = 17;
            this.GridPSVars.Size = new System.Drawing.Size(240, 168);
            this.GridPSVars.TabIndex = 14;
            // 
            // GridISVars
            // 
            this.GridISVars.AllowAddNew = true;
            this.GridISVars.AllowDelete = true;
            this.GridISVars.ColumnInfo = "2,0,0,0,0,85,Columns:0{Caption:\"IndVar\";}\t1{Caption:\"Value\";}\t";
            this.GridISVars.Location = new System.Drawing.Point(24, 487);
            this.GridISVars.Margin = new System.Windows.Forms.Padding(4);
            this.GridISVars.Name = "GridISVars";
            this.GridISVars.Rows.Count = 1;
            this.GridISVars.Rows.DefaultSize = 17;
            this.GridISVars.Size = new System.Drawing.Size(239, 206);
            this.GridISVars.TabIndex = 15;
            // 
            // lable1
            // 
            this.lable1.AutoSize = true;
            this.lable1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lable1.Location = new System.Drawing.Point(20, 11);
            this.lable1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lable1.Name = "lable1";
            this.lable1.Size = new System.Drawing.Size(179, 25);
            this.lable1.TabIndex = 16;
            this.lable1.Text = "Shared Variables";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(569, 18);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 25);
            this.label1.TabIndex = 17;
            this.label1.Text = "Global Macro";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(569, 246);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 25);
            this.label2.TabIndex = 18;
            this.label2.Text = "Population Macro";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(569, 459);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 25);
            this.label3.TabIndex = 19;
            this.label3.Text = "Individual Macro";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(303, 702);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(184, 42);
            this.button3.TabIndex = 20;
            this.button3.Text = "Read MMMacro File";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // MMMacroEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1101, 745);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lable1);
            this.Controls.Add(this.GridISVars);
            this.Controls.Add(this.GridPSVars);
            this.Controls.Add(this.GridGSVars);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.GridIndMacro);
            this.Controls.Add(this.GridPopMacro);
            this.Controls.Add(this.GridGlobalMacro);
            this.Controls.Add(this.BtnReadFile);
            this.Controls.Add(this.BtnRun);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MMMacroEntry";
            this.Text = "MMMacro Entry";
            ((System.ComponentModel.ISupportInitialize)(this.GridGlobalMacro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridPopMacro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridIndMacro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridGSVars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridPSVars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridISVars)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnRun;
        private System.Windows.Forms.Button BtnReadFile;
        private C1.Win.C1FlexGrid.C1FlexGrid GridGlobalMacro;
        private C1.Win.C1FlexGrid.C1FlexGrid GridPopMacro;
        private C1.Win.C1FlexGrid.C1FlexGrid GridIndMacro;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Save;
        private C1.Win.C1FlexGrid.C1FlexGrid GridGSVars;
        private C1.Win.C1FlexGrid.C1FlexGrid GridPSVars;
        private C1.Win.C1FlexGrid.C1FlexGrid GridISVars;
        private System.Windows.Forms.Label lable1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button3;
    }
}

