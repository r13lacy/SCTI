using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using EvaluatorLibrary;

namespace MMMacroEntry
{
    public partial class MMMacroEntry : Form
    {
        public MMMacroEntry()
        {
            InitializeComponent();
        }

        private void BtnReadFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();

            dlg.Filter = "GlobalMacroFile (*.txt)|*.txt";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                StreamReader objReader;
                try
                {
                    objReader = new StreamReader(dlg.FileName);
                }
                catch
                {
                    throw new Exception("Evaluator.MacroFileReadFailed");
                }

                string sLine = "";
                int nLines = 0;
                char[] splits = { '=', ':', ';' }; // prior to 18 Dec 2014 this also included ',' -- which would mess up in EU
                char[] splits2 = { '=', ':', ';' , ','};

                while ((sLine = objReader.ReadLine()) != null)
                {
                    string[] ss;
                    if (sLine.ToUpper().StartsWith("SHARED"))
                    {
                        ss = sLine.Split(splits2);
                        int nrows = ss.GetUpperBound(0);
                        GridGSVars.Rows.Count = nrows + 2;
                        for (int i = 1; i <= nrows; i++)
                        {
                            GridGSVars[i, 0] = ss[i].ToUpper();
                        }
                    }
                    else if (sLine.ToUpper().StartsWith("VALS"))
                    {
                        ss = sLine.Split(splits);
                        int nrows = ss.GetUpperBound(0);
                        if (GridGSVars.Rows.Count <= nrows + 1) GridGSVars.Rows.Count = nrows + 2;
                        for (int i = 1; i <= nrows; i++)
                        {
                            GridGSVars[i, 1] = ss[i];
                        }
                    }

                    else if (sLine != null && sLine != "" && sLine.Trim() != "")
                    {
                        nLines++;
                        GridGlobalMacro.Rows.Count = nLines + 2;
                        GridGlobalMacro[nLines, 1] = sLine.ToUpper();
                        GridGlobalMacro[nLines, 0] = nLines;
                    }
                }
                objReader.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();

            dlg.Filter = "PopulationMacroFile (*.txt)|*.txt";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                StreamReader objReader;
                try
                {
                    objReader = new StreamReader(dlg.FileName);
                }
                catch
                {
                    throw new Exception("Evaluator.MacroFileReadFailed");
                }

                string sLine = "";
                int nLines = 0;
                char[] splits = { '=', ':', ';'};
                char[] splits2 = { '=', ':', ';' , ','};

                while ((sLine = objReader.ReadLine()) != null)
                {
                    string[] ss;
                    if (sLine.ToUpper().StartsWith("SHARED"))
                    {
                        ss = sLine.Split(splits2);
                        int nrows = ss.GetUpperBound(0);
                        GridPSVars.Rows.Count = nrows + 2;
                        for (int i = 1; i <= nrows; i++)
                        {
                            GridPSVars[i, 0] = ss[i].ToUpper();
                        }
                    }
                    else if (sLine.ToUpper().StartsWith("VALS"))
                    {
                        ss = sLine.Split(splits);
                        int nrows = ss.GetUpperBound(0);
                        if (GridPSVars.Rows.Count <= nrows + 1) GridPSVars.Rows.Count = nrows + 2;
                        for (int i = 1; i <= nrows; i++)
                        {
                            GridPSVars[i, 1] = ss[i];
                        }
                    }

                    else if (sLine != null && sLine != "" && sLine.Trim() != "")
                    {
                        nLines++;
                        GridPopMacro.Rows.Count = nLines + 2;
                        GridPopMacro[nLines, 1] = sLine.ToUpper();
                        GridPopMacro[nLines, 0] = nLines;
                    }
                }
                objReader.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();

            dlg.Filter = "IndividualMacroFile (*.txt)|*.txt";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                StreamReader objReader;
                try
                {
                    objReader = new StreamReader(dlg.FileName);
                }
                catch
                {
                    throw new Exception("Evaluator.MacroFileReadFailed");
                }

                string sLine = "";
                int nLines = 0;
                char[] splits = { '=', ':', ';'};
                char[] splits2 = { '=', ':', ';' , ','};

                while ((sLine = objReader.ReadLine()) != null)
                {
                    string[] ss;
                    if (sLine.ToUpper().StartsWith("SHARED"))
                    {
                        ss = sLine.Split(splits2);
                        int nrows = ss.GetUpperBound(0);
                        GridISVars.Rows.Count = nrows + 2;
                        for (int i = 1; i <= nrows; i++)
                        {
                            GridISVars[i, 0] = ss[i].ToUpper();
                        }
                    }
                    else if (sLine.ToUpper().StartsWith("VALS"))
                    {
                        ss = sLine.Split(splits);
                        int nrows = ss.GetUpperBound(0);
                        if (GridISVars.Rows.Count <= nrows + 1) GridISVars.Rows.Count = nrows + 2;
                        for (int i = 1; i <= nrows; i++)
                        {
                            GridISVars[i, 1] = ss[i];
                        }
                    }

                    else if (sLine != null && sLine != "" && sLine.Trim() != "")
                    {
                        nLines++;
                        GridIndMacro.Rows.Count = nLines + 2;
                        GridIndMacro[nLines, 1] = sLine.ToUpper();
                        GridIndMacro[nLines, 0] = nLines;
                    }
                }
                objReader.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            OpenFileDialog dlg = new OpenFileDialog();

            dlg.Filter = "IndividualMacroFile (*.txt)|*.txt";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                StreamReader objReader;
                try
                {
                    objReader = new StreamReader(dlg.FileName);
                }
                catch
                {
                    throw new Exception("Evaluator.MacroFileReadFailed");
                }

                string sLine = "";
                int nrows = 0;
                char[] splits = { '=', ':', ';' };
                char[] splits2 = { '=', ':', ';' , ','};

                string[] ss;
                while ((sLine = objReader.ReadLine()) != null)
                {
                    if (sLine.ToUpper().StartsWith("SHAREDGL"))
                    {
                        int nLines = 0;
                        ss = sLine.Split(splits2);
                        nrows = ss.GetUpperBound(0);
                        GridGSVars.Rows.Count = nrows + 2;
                        for (int i = 1; i <= nrows; i++)
                        {
                            GridGSVars[i, 0] = ss[i].ToUpper();
                        }

                        while ((sLine = objReader.ReadLine()) != null)
                        {
                            if (sLine.ToUpper().StartsWith("SHARED")) break;

                            if (sLine.ToUpper().StartsWith("VALS"))
                            {
                                ss = sLine.Split(splits);
                                nrows = ss.GetUpperBound(0);
                                if (GridGSVars.Rows.Count <= nrows + 1) GridGSVars.Rows.Count = nrows + 2;
                                for (int i = 1; i <= nrows; i++)
                                {
                                    GridGSVars[i, 1] = ss[i];
                                }
                            }

                            else if (sLine != null && sLine != "" && sLine.Trim() != "")
                            {
                                nLines++;
                                GridGlobalMacro.Rows.Count = nLines + 2;
                                GridGlobalMacro[nLines, 1] = sLine.ToUpper();
                                GridGlobalMacro[nLines, 0] = nLines;
                            }
                        }
                    }

                    if (sLine != null && sLine.ToUpper().StartsWith("SHAREDPOP"))
                    {
                        int nLines = 0;
                        ss = sLine.Split(splits2);
                        nrows = ss.GetUpperBound(0);
                        GridPSVars.Rows.Count = nrows + 2;
                        for (int i = 1; i <= nrows; i++)
                        {
                            GridPSVars[i, 0] = ss[i].ToUpper();
                        }

                        while ((sLine = objReader.ReadLine()) != null)
                        {
                            if (sLine.ToUpper().StartsWith("SHARED")) break;

                            if (sLine.ToUpper().StartsWith("VALS"))
                            {
                                ss = sLine.Split(splits);
                                nrows = ss.GetUpperBound(0);
                                if (GridPSVars.Rows.Count <= nrows + 1) GridPSVars.Rows.Count = nrows + 2;
                                for (int i = 1; i <= nrows; i++)
                                {
                                    GridPSVars[i, 1] = ss[i];
                                }
                            }

                            else if (sLine != null && sLine != "" && sLine.Trim() != "")
                            {
                                nLines++;
                                GridPopMacro.Rows.Count = nLines + 2;
                                GridPopMacro[nLines, 1] = sLine.ToUpper();
                                GridPopMacro[nLines, 0] = nLines;
                            }
                        }
                    }

                    if (sLine != null && sLine.ToUpper().StartsWith("SHAREDIND"))
                    {
                        int nLines = 0;
                        ss = sLine.Split(splits2);
                        nrows = ss.GetUpperBound(0);
                        GridISVars.Rows.Count = nrows + 2;
                        for (int i = 1; i <= nrows; i++)
                        {
                            GridISVars[i, 0] = ss[i].ToUpper();
                        }

                        while ((sLine = objReader.ReadLine()) != null)
                        {
                            if (sLine.ToUpper().StartsWith("SHARED")) break;

                            if (sLine.ToUpper().StartsWith("VALS"))
                            {
                                ss = sLine.Split(splits);
                                nrows = ss.GetUpperBound(0);
                                if (GridISVars.Rows.Count <= nrows + 1) GridISVars.Rows.Count = nrows + 2;
                                for (int i = 1; i <= nrows; i++)
                                {
                                    GridISVars[i, 1] = ss[i];
                                }
                            }

                            else if (sLine != null && sLine != "" && sLine.Trim() != "")
                            {
                                nLines++;
                                GridIndMacro.Rows.Count = nLines + 2;
                                GridIndMacro[nLines, 1] = sLine.ToUpper();
                                GridIndMacro[nLines, 0] = nLines;
                            }
                        }
                    }
                }
                objReader.Close();
            }
        }

        private void Save_Click(object sender, EventArgs e)
        {
            string folder = "";

            SaveFileDialog dlg = new SaveFileDialog();

            dlg.Filter = "MMMacroFile (*.txt)|*.txt";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string fname = dlg.FileName;
                StreamWriter objWriter;
                try
                {
                    objWriter = new StreamWriter(fname);
                }
                catch
                {
                    throw new Exception("Evaluator.MacroFileWriteFailed");
                }

                folder = dlg.FileName.Remove(fname.LastIndexOf('\\') + 1);

                string strvar = "SharedGlobalVars=";
                for (int i = 1; i < GridGSVars.Rows.Count; i++)
                {
                    if (GridGSVars[i, 0] == null || GridGSVars[i, 0].ToString().Trim() == "") continue;
                    if (i == 1) strvar = strvar + GridGSVars[i, 0];
                    else strvar = strvar + ";" + GridGSVars[i, 0]; // prior to 18 Dec 2014 this was a ',' delimiter
                }
                objWriter.WriteLine(strvar);

                strvar = "Vals=";
                for (int i = 1; i < GridGSVars.Rows.Count; i++)
                {
                    if (GridGSVars[i, 1] == null || GridGSVars[i, 1].ToString().Trim() == "") continue;
                    if (i == 1) strvar = strvar + GridGSVars[i, 1];
                    else strvar = strvar + ";" + GridGSVars[i, 1];
                }
                objWriter.WriteLine(strvar);

                for (int i = 1; i < GridGlobalMacro.Rows.Count; i++)
                {
                    if (GridGlobalMacro[i, 1] == null || GridGlobalMacro[i, 1].ToString().Trim() == "") continue;
                    objWriter.WriteLine(GridGlobalMacro[i, 1].ToString().Trim());
                }

                strvar = "SharedPopVars=";
                for (int i = 1; i < GridPSVars.Rows.Count; i++)
                {
                    if (GridPSVars[i, 0] == null || GridPSVars[i, 0].ToString().Trim() == "") continue;
                    if (i == 1) strvar = strvar + GridPSVars[i, 0];
                    else strvar = strvar + ";" + GridPSVars[i, 0];
                }
                objWriter.WriteLine(strvar);

                strvar = "Vals=";
                for (int i = 1; i < GridPSVars.Rows.Count; i++)
                {
                    if (GridPSVars[i, 1] == null || GridPSVars[i, 1].ToString().Trim() == "") continue;
                    if (i == 1) strvar = strvar + GridPSVars[i, 1];
                    else strvar = strvar + ";" + GridPSVars[i, 1];
                }
                objWriter.WriteLine(strvar);

                for (int i = 1; i < GridPopMacro.Rows.Count; i++)
                {
                    if (GridPopMacro[i, 1] == null || GridPopMacro[i, 1].ToString().Trim() == "") continue;
                    objWriter.WriteLine(GridPopMacro[i, 1].ToString().Trim());
                }

                strvar = "SharedIndVars=";
                for (int i = 1; i < GridISVars.Rows.Count; i++)
                {
                    if (GridISVars[i, 0] == null || GridISVars[i, 0].ToString().Trim() == "") continue;
                    if (i == 1) strvar = strvar + GridISVars[i, 0];
                    else strvar = strvar + ";" + GridISVars[i, 0];
                }
                objWriter.WriteLine(strvar);

                strvar = "Vals=";
                for (int i = 1; i < GridISVars.Rows.Count; i++)
                {
                    if (GridISVars[i, 1] == null || GridISVars[i, 1].ToString().Trim() == "") continue;
                    if (i == 1) strvar = strvar + GridISVars[i, 1];
                    else strvar = strvar + ";" + GridISVars[i, 1];
                }
                objWriter.WriteLine(strvar);

                for (int i = 1; i < GridIndMacro.Rows.Count; i++)
                {
                    if (GridIndMacro[i, 1] == null || GridIndMacro[i, 1].ToString().Trim() == "") continue;
                    objWriter.WriteLine(GridIndMacro[i, 1].ToString().Trim());
                }
                
                objWriter.Close();

      // now save specfile
    // removed 16 dec 2015 because this would declare the shared vars to be the same across macros that are used in MMs
                // better to just use the basic MMMacro.xml, and let MMMacro identify for MMM what is shared.

//                XmlDocument doc = new XmlDocument();

//                //XmlDeclaration xmlInfoNode = doc.CreateXmlDeclaration("1.0", null, null);
//                //doc.AppendChild(xmlInfoNode);

//                XmlElement topNode = doc.CreateElement("MAppSpecs");
//                doc.AppendChild(topNode);

//                XmlElement n;

//                n = doc.CreateElement("Name");
//                n.InnerText = "MMMacro";
//                topNode.AppendChild(n);

//                n = doc.CreateElement("Description");
//                n.InnerText = "Metamodel variable translation module";
//                topNode.AppendChild(n);

//                n = doc.CreateElement("DLL");
//                n.InnerText = Application.StartupPath + "\\MMMacroLib.dll"; 
//                // 16 dec 2015 this had not included the StartUp path, but that would have the dll in the projects folder (where it isn't)
//                topNode.AppendChild(n);

//                n = doc.CreateElement("NameSpace");
//                n.InnerText = "MMMacro.MMMacro";
//                topNode.AppendChild(n);

//                n = doc.CreateElement("Variables");
////                n.InnerText = "";
//                topNode.AppendChild(n);

//                XmlElement child;
//                XmlElement grandchild;

//                for (int i = 1; i < GridGSVars.Rows.Count; i++)
//                {
//                    if (GridGSVars[i, 0] == null || GridGSVars[i, 0].ToString().Trim() == "") continue;
//                    child = doc.CreateElement("Global");
//                    n.AppendChild(child);
//                    grandchild = doc.CreateElement("VarName");
//                    grandchild.InnerText = GridGSVars[i, 0].ToString();
//                    child.AppendChild(grandchild);
//                    grandchild = doc.CreateElement("Type");
//                    grandchild.InnerText = "System.Double";
//                    child.AppendChild(grandchild);
//                }

//                for (int i = 1; i < GridPSVars.Rows.Count; i++)
//                {
//                    if (GridPSVars[i, 0] == null || GridPSVars[i, 0].ToString().Trim() == "") continue;
//                    child = doc.CreateElement("Population");
//                    n.AppendChild(child);
//                    grandchild = doc.CreateElement("VarName");
//                    grandchild.InnerText = GridPSVars[i, 0].ToString();
//                    child.AppendChild(grandchild);
//                    grandchild = doc.CreateElement("Type");
//                    grandchild.InnerText = "System.Double";
//                    child.AppendChild(grandchild);
//                }

//                for (int i = 1; i < GridISVars.Rows.Count; i++)
//                {
//                    if (GridISVars[i, 0] == null || GridISVars[i, 0].ToString().Trim() == "") continue;
//                    child = doc.CreateElement("Individual");
//                    n.AppendChild(child);
//                    grandchild = doc.CreateElement("VarName");
//                    grandchild.InnerText = GridISVars[i, 0].ToString();
//                    child.AppendChild(grandchild);
//                    grandchild = doc.CreateElement("Type");
//                    grandchild.InnerText = "System.Double";
//                    child.AppendChild(grandchild);
//                }

//                n = doc.CreateElement("Functions");
//                topNode.AppendChild(n);

//                child = doc.CreateElement("Standard");
//                child.InnerText = "True";
//                n.AppendChild(child);

//                //string xmlfilename = dlg.FileName;
//                //xmlfilename = xmlfilename.Replace(".txt", ".xml");

//                doc.Save(folder + "MMMacro.xml");

            }
        }

        private void BtnRun_Click(object sender, EventArgs e)
        {
            List<string> vars = new List<string>();
            List<double> vals = new List<double>();
            List<string> steps = new List<string>();

            Macro glMacro = null;
            Macro popMacro = null;
            Macro indMacro = null;

            int gct = 0;
            int pct = 0;
            int ict = 0;

            if (GridGSVars.Rows.Count > 1)
            {
                for (int i = 1; i < GridGSVars.Rows.Count; i++)
                {
                    if (GridGSVars[i, 0] != null && GridGSVars[i, 0].ToString().Trim() != "")
                    {
                        string gv = GridGSVars[i, 0].ToString().ToUpper();
                        gv = gv.Replace("GS", "GV");
                        gv = gv.ToString().Replace("PS", "PV");
                        gv = gv.ToString().Replace("IS", "IV");

                        vars.Add(gv);
                        vals.Add(Convert.ToDouble(GridGSVars[i, 1].ToString()));
                        gct++;
                    }
                }
            }

            if (GridGlobalMacro.Rows.Count > 1)
            {
                for (int i = 1; i < GridGlobalMacro.Rows.Count; i++)
                {
                    if (GridGlobalMacro[i, 1] != null && GridGlobalMacro[i, 1].ToString().Trim() != "" && !GridGlobalMacro[i, 1].ToString().StartsWith("#") && !GridGlobalMacro[i, 1].ToString().StartsWith("*"))
                    {
                        string gv = GridGlobalMacro[i, 1].ToString().ToUpper();
                        gv = gv.Replace("GS", "GV");
                        gv = gv.Replace("PS", "PV");
                        gv = gv.ToString().Replace("IS", "IV");

                        steps.Add(gv);
                    }
                }

                if (steps.Count > 0)
                {
                    glMacro = new Macro(vars, vals, steps);
                    glMacro.RunMacro();
                }
            }

            // note that we are letting PopMacro continue to use GSVars specified above
            if (GridPSVars.Rows.Count > 1)
            {
                for (int i = 1; i < GridPSVars.Rows.Count; i++)
                {
                    if (GridPSVars[i, 0] != null && GridPSVars[i, 0].ToString().Trim() != "")
                    {
                        string pv = GridPSVars[i, 0].ToString().ToUpper();
                        pv = pv.Replace("GS", "GV");
                        pv = pv.Replace("PS", "PV");
                        pv = pv.ToString().Replace("IS", "IV");

                        vars.Add(pv);
                        vals.Add(Convert.ToDouble(GridPSVars[i, 1].ToString()));
                        pct++;
                    }
                }
            }

            if (GridPopMacro.Rows.Count > 1)
            {
                steps.Clear();
                for (int i = 1; i < GridPopMacro.Rows.Count; i++)
                {
                    if (GridPopMacro[i, 1] != null && GridPopMacro[i, 1].ToString().Trim() != "" && !GridPopMacro[i, 1].ToString().StartsWith("#") && !GridPopMacro[i, 1].ToString().StartsWith("*"))
                    {
                        string pv = GridPopMacro[i, 1].ToString().ToUpper();
                        pv = pv.Replace("GS", "GV");
                        pv = pv.Replace("PS", "PV");
                        pv = pv.ToString().Replace("IS", "IV");

                        steps.Add(pv);
                    }
                }

                if (steps.Count > 0)
                {
                    popMacro = new Macro(vars, vals, steps);
                    popMacro.RunMacro();
                }
            }

            // note that we are letting IndMacro continue to use PSVars and GSVars specified above
            if (GridISVars.Rows.Count > 1)
            {
                for (int i = 1; i < GridISVars.Rows.Count; i++)
                {
                    if (GridISVars[i, 0] != null && GridISVars[i, 0].ToString().Trim() != "")
                    {
                        string iv = GridISVars[i, 0].ToString().ToUpper();
                        iv = iv.Replace("GS", "GV");
                        iv = iv.Replace("PS", "PV");
                        iv = iv.ToString().Replace("IS", "IV");

                        vars.Add(iv);
                        vals.Add(Convert.ToDouble(GridISVars[i, 1].ToString()));
                        ict++;
                    }
                }
            }

            if (GridIndMacro.Rows.Count > 1)
            {
                steps.Clear();
                for (int i = 1; i < GridIndMacro.Rows.Count; i++)
                {
                    if (GridIndMacro[i, 1] != null && GridIndMacro[i, 1].ToString().Trim() != "" && !GridIndMacro[i, 1].ToString().StartsWith("#") && !GridIndMacro[i, 1].ToString().StartsWith("*"))
                    {
                        string iv = GridIndMacro[i, 1].ToString().ToUpper();
                        iv = iv.Replace("GS", "GV");
                        iv = iv.Replace("PS", "PV");
                        iv = iv.ToString().Replace("IS", "IV");

                        steps.Add(iv);
                    }
                }

                if (steps.Count > 0)
                {
                    indMacro = new Macro(vars, vals, steps);
                    indMacro.RunMacro();
                }
            }

            if(glMacro != null)
            for (int i = 0; i < gct; i++)
            {
                string valstr = glMacro.mVals[i].ToString();
                if (valstr.Length > 10) valstr = valstr.Remove(10);
                GridGSVars[i + 1, 1] = valstr;
            }

            if(popMacro != null)
            for (int i = 0; i < pct; i++)
            {
                string valstr = popMacro.mVals[gct + i].ToString();
                if (valstr.Length > 10) valstr = valstr.Remove(10);
                GridPSVars[i + 1, 1] = valstr;
            }

            if(indMacro != null)
            for (int i = 0; i < ict; i++)
            {
                string valstr = indMacro.mVals[gct + pct + i].ToString();
                if (valstr.Length > 10) valstr = valstr.Remove(10);
                GridISVars[i + 1, 1] = valstr;
            }
        }

        private void GridGlobalMacro_AfterAddRow(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            GridGlobalMacro[e.Row, 0] = e.Row;
        }
        private void GridPopMacro_AfterAddRow(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            GridPopMacro[e.Row, 0] = e.Row;
        }
        private void GridIndMacro_AfterAddRow(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            GridIndMacro[e.Row, 0] = e.Row;
        }

        private void GridGlobalMacro_KeyPress(object sender, KeyPressEventArgs e)
        {
            int r;
            if ((int)e.KeyChar == 9) // key 9 is ctrl-i  Use to trigger insert of a line
            {
                int rows = GridGlobalMacro.Rows.Count;
                r = GridGlobalMacro.Row;
                GridGlobalMacro.Rows.Count = rows + 1;
                for (int rr = rows - 1; rr > r; rr--) 
                    GridGlobalMacro[rr,1] = GridGlobalMacro[rr - 1,1];
                GridGlobalMacro[r, 1] = "";
                GridGlobalMacro[rows - 1, 0] = rows - 1;
            }
        }

        private void GridPopMacro_KeyPress(object sender, KeyPressEventArgs e)
        {
            int r;
            if ((int)e.KeyChar == 9) // key 9 is ctrl-i  Use to trigger insert of a line
            {
                int rows = GridPopMacro.Rows.Count;
                r = GridPopMacro.Row;
                GridPopMacro.Rows.Count = rows + 1;
                for (int rr = rows - 1; rr > r; rr--)
                    GridPopMacro[rr, 1] = GridPopMacro[rr - 1, 1];
                GridPopMacro[r, 1] = "";
                GridPopMacro[rows - 1, 0] = rows - 1;
            }
        }

        private void GridIndMacro_KeyPress(object sender, KeyPressEventArgs e)
        {
            int r;
            if ((int)e.KeyChar == 9) // key 9 is ctrl-i  Use to trigger insert of a line
            {
                int rows = GridIndMacro.Rows.Count;
                r = GridIndMacro.Row;
                GridIndMacro.Rows.Count = rows + 1;
                for (int rr = rows - 1; rr > r; rr--)
                    GridIndMacro[rr, 1] = GridIndMacro[rr - 1, 1];
                GridIndMacro[r, 1] = "";
                GridIndMacro[rows - 1, 0] = rows - 1;
            }
        }

        private void GridGlobalMacro_AfterDeleteRow(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            for (int r = 1; r < GridGlobalMacro.Rows.Count - 1; r++)
                GridGlobalMacro[r, 0] = r;
        }

        private void GridPopMacro_AfterDeleteRow(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            for (int r = 1; r < GridPopMacro.Rows.Count - 1; r++)
                GridPopMacro[r, 0] = r;
        }

        private void GridIndMacro_AfterDeleteRow(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            for (int r = 1; r < GridIndMacro.Rows.Count - 1; r++)
                GridIndMacro[r, 0] = r;
        }

        private void GridGlobalMacro_AfterDragRow(object sender, C1.Win.C1FlexGrid.DragRowColEventArgs e)
        {
            for (int r = 1; r < GridGlobalMacro.Rows.Count - 1; r++)
                GridGlobalMacro[r, 0] = r;
        }

        private void GridPopMacro_AfterDragRow(object sender, C1.Win.C1FlexGrid.DragRowColEventArgs e)
        {
            for (int r = 1; r < GridPopMacro.Rows.Count - 1; r++)
                GridPopMacro[r, 0] = r;
        }

        private void GridIndMacro_AfterDragRow(object sender, C1.Win.C1FlexGrid.DragRowColEventArgs e)
        {
            for (int r = 1; r < GridIndMacro.Rows.Count - 1; r++)
                GridIndMacro[r, 0] = r;
        }

    }
}
