namespace MacroEntry
{
    partial class MacroEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required Macro for Designer support - do not modify
        /// the contents of this Macro with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MacroEntry));
            this.BtnReadFile = new System.Windows.Forms.Button();
            this.BtnRun = new System.Windows.Forms.Button();
            this.GridVars = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.gridSteps = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.Save = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.GridVars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridSteps)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnReadFile
            // 
            this.BtnReadFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnReadFile.Location = new System.Drawing.Point(195, 4);
            this.BtnReadFile.Name = "BtnReadFile";
            this.BtnReadFile.Size = new System.Drawing.Size(154, 23);
            this.BtnReadFile.TabIndex = 1;
            this.BtnReadFile.Text = "Read Macro File";
            this.BtnReadFile.UseVisualStyleBackColor = true;
            this.BtnReadFile.Click += new System.EventHandler(this.BtnReadFile_Click);
            // 
            // BtnRun
            // 
            this.BtnRun.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRun.Location = new System.Drawing.Point(13, 3);
            this.BtnRun.Name = "BtnRun";
            this.BtnRun.Size = new System.Drawing.Size(65, 24);
            this.BtnRun.TabIndex = 4;
            this.BtnRun.Text = "Run!";
            this.BtnRun.UseVisualStyleBackColor = true;
            this.BtnRun.Click += new System.EventHandler(this.BtnRun_Click);
            // 
            // GridVars
            // 
            this.GridVars.AllowAddNew = true;
            this.GridVars.AllowDelete = true;
            this.GridVars.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.GridVars.ColumnInfo = resources.GetString("GridVars.ColumnInfo");
            this.GridVars.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.GridVars.ForeColor = System.Drawing.SystemColors.InfoText;
            this.GridVars.Location = new System.Drawing.Point(13, 31);
            this.GridVars.Name = "GridVars";
            this.GridVars.Rows.Count = 1;
            this.GridVars.Rows.DefaultSize = 19;
            this.GridVars.Size = new System.Drawing.Size(177, 519);
            this.GridVars.StyleInfo = resources.GetString("GridVars.StyleInfo");
            this.GridVars.TabIndex = 5;
            // 
            // gridSteps
            // 
            this.gridSteps.AllowAddNew = true;
            this.gridSteps.AllowDelete = true;
            this.gridSteps.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.Rows;
            this.gridSteps.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.gridSteps.ColumnInfo = "2,1,0,0,0,85,Columns:0{Width:56;Caption:\"Step #\";Style:\"DataType:System.Decimal;T" +
    "extAlign:RightCenter;\";}\t1{Width:534;Caption:\"Command\";Style:\"DataType:System.St" +
    "ring;TextAlign:LeftCenter;\";}\t";
            this.gridSteps.Location = new System.Drawing.Point(195, 31);
            this.gridSteps.Name = "gridSteps";
            this.gridSteps.Rows.Count = 1;
            this.gridSteps.Rows.DefaultSize = 17;
            this.gridSteps.Size = new System.Drawing.Size(597, 519);
            this.gridSteps.TabIndex = 6;
            this.gridSteps.AfterDragRow += new C1.Win.C1FlexGrid.DragRowColEventHandler(this.gridSteps_AfterDragRow);
            this.gridSteps.AfterAddRow += new C1.Win.C1FlexGrid.RowColEventHandler(this.gridSteps_AfterAddRow);
            this.gridSteps.AfterDeleteRow += new C1.Win.C1FlexGrid.RowColEventHandler(this.gridSteps_AfterDeleteRow);
            this.gridSteps.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.gridSteps_KeyPress);
            // 
            // Save
            // 
            this.Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Save.Location = new System.Drawing.Point(370, 4);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(123, 23);
            this.Save.TabIndex = 7;
            this.Save.Text = "Save Macro File";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // MacroEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(803, 562);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.gridSteps);
            this.Controls.Add(this.GridVars);
            this.Controls.Add(this.BtnRun);
            this.Controls.Add(this.BtnReadFile);
            this.Name = "MacroEntry";
            this.Text = "Macro Entry Form";
            ((System.ComponentModel.ISupportInitialize)(this.GridVars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridSteps)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnReadFile;
        private System.Windows.Forms.Button BtnRun;
        private C1.Win.C1FlexGrid.C1FlexGrid GridVars;
        private C1.Win.C1FlexGrid.C1FlexGrid gridSteps;
        private System.Windows.Forms.Button Save;
    }
}

