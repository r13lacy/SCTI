using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using EvaluatorLibrary;

namespace MacroEntry
{
    public partial class MacroEntry : Form
    {
        public MacroEntry()
        {
            InitializeComponent();

            gridSteps[1, 0] = 1;
        }

        private void BtnReadFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();

            dlg.Filter = "MacroFile (*.txt)|*.txt";

            if (dlg.ShowDialog() == DialogResult.OK)
            //                textBox1.Text = textBox1.Text + "FILE(" + dlg.FileName + ")";
            {
                StreamReader objReader;
                try
                {
                    objReader = new StreamReader(dlg.FileName);
                }
                catch
                {
                    throw new Exception("Evaluator.MacroFileReadFailed");
                }

                string sLine = "";
                int nLines = 0;
                char[] splits = { '=', ':', ';' };
                char[] splits2 = { '=', ':', ';' , ','};

                while ((sLine = objReader.ReadLine()) != null)
                {
                    string[] ss;
                    if (sLine.StartsWith("Shared"))
                    {
                        ss = sLine.Split(splits2);
                        int nrows = ss.GetUpperBound(0);
                        GridVars.Rows.Count = nrows + 2;
                        for (int i = 1; i <= nrows; i++)
                        {
                            GridVars[i, 0] = ss[i].ToUpper();
                        }
                    }
                    else if (sLine.StartsWith("Vals"))
                    {
                        ss = sLine.Split(splits);
                        int nrows = ss.GetUpperBound(0);
                        if(GridVars.Rows.Count <= nrows + 1) GridVars.Rows.Count = nrows + 2;
                        for (int i = 1; i <= nrows; i++)
                        {
                            GridVars[i, 1] = ss[i];
                        }
                    }

                    else if (sLine != null && sLine != "" && sLine.Trim() != "")
                    {
                        nLines++;
                        gridSteps.Rows.Count = nLines + 2;
                        gridSteps[nLines, 1] = sLine.ToUpper();
                        gridSteps[nLines, 0] = nLines;
                    }
                }
                objReader.Close();
            }
        }

        private void BtnRun_Click(object sender, EventArgs e)
        {
            List<string> vars = new List<string>();
            List<double> vals = new List<double>();
            List<string> steps = new List<string>();

            if (GridVars.Rows.Count < 2 || gridSteps.Rows.Count < 2) return;

            for (int i = 1; i < GridVars.Rows.Count; i++)
            {
                if (GridVars[i,0] != null && GridVars[i, 0].ToString().Trim() != "")
                {
                    vars.Add(GridVars[i, 0].ToString());
                    vals.Add(Convert.ToDouble(GridVars[i, 1].ToString()));
                }
            }

            for (int i = 1; i < gridSteps.Rows.Count; i++)
            {
                if (gridSteps[i,1] != null && gridSteps[i, 1].ToString().Trim() != "")
                {
                    if (gridSteps[i, 1].ToString().StartsWith("*") || gridSteps[i, 1].ToString().StartsWith("#")) continue;

                    steps.Add(gridSteps[i, 1].ToString().ToUpper());
                }
            }

            Macro mMacro = new Macro(vars, vals, steps);

            mMacro.RunMacro();
            for (int i = 0; i < vals.Count; i++)
            {
                vals[i] = mMacro.mVals[i];
                string valstr = vals[i].ToString();
                if (valstr.Length > 10) valstr = valstr.Remove(10);
                GridVars[i + 1, 1] = valstr;
            }
        }


        private void Save_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();

            dlg.Filter = "MacroFile (*.txt)|*.txt";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter objWriter;
                try
                {
                    objWriter = new StreamWriter(dlg.FileName);
                }
                catch
                {
                    throw new Exception("Evaluator.MacroFileWriteFailed");
                }

                string strvar = "SharedVars=";
                for (int i = 1; i < GridVars.Rows.Count; i++)
                {
                    if (GridVars[i, 0] == null || GridVars[i, 0].ToString().Trim() == "") continue;
                    if(i == 1) strvar = strvar + GridVars[i, 0];
                    else strvar = strvar + ";" + GridVars[i, 0];
                }
                objWriter.WriteLine(strvar);

                strvar = "Vals=";
                for (int i = 1; i < GridVars.Rows.Count; i++)
                {
                    if (GridVars[i, 1] == null || GridVars[i, 1].ToString().Trim() == "") continue;
                    if (i == 1) strvar = strvar + GridVars[i, 1];
                    else strvar = strvar + ";" + GridVars[i, 1];
                }
                objWriter.WriteLine(strvar);

                for (int i = 1; i < gridSteps.Rows.Count; i++)
                {
                    if (gridSteps[i, 1] == null || gridSteps[i, 1].ToString().Trim() == "") continue;
                    objWriter.WriteLine(gridSteps[i, 1].ToString().Trim());
                }

                objWriter.Close();
            }

        }

        private void gridSteps_AfterAddRow(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            gridSteps[e.Row, 0] = e.Row;
        }

        private void gridSteps_KeyPress(object sender, KeyPressEventArgs e)
        {
            int r;
            if ((int)e.KeyChar == 9) // key 9 is ctrl-i  Use to trigger insert of a line
            {
                int rows = gridSteps.Rows.Count;
                r = gridSteps.Row;
                gridSteps.Rows.Count = rows + 1;
                for (int rr = rows - 1; rr > r; rr--)
                    gridSteps[rr, 1] = gridSteps[rr - 1, 1];
                gridSteps[r, 1] = "";
                gridSteps[rows - 1, 0] = rows - 1;
            }
        }

        private void gridSteps_AfterDeleteRow(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            for(int r = 1; r < gridSteps.Rows.Count - 1; r++)
                gridSteps[r,0] = r;
        }

        private void gridSteps_AfterDragRow(object sender, C1.Win.C1FlexGrid.DragRowColEventArgs e)
        {
            for (int r = 1; r < gridSteps.Rows.Count - 1; r++)
                gridSteps[r, 0] = r;
        }

    }
}