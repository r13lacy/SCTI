using System;
using System.Collections.Generic;
//using System.Text;
using System.IO;
//using System.Threading;
//using System.Windows.Forms;
//using Microsoft.Office.Interop.Excel;

namespace EvaluatorLibrary
{
    public enum varType
    {
        DOUBLE,
        INT,
        NUM, // generic, double
        STRING,
        BOOL
    }

    public enum StepName
    {
        DO,
        WHILE,
        DOWHILE,
        IF,
        ELSE,
        CONTINUE,
        BREAK,
        GOTO,
        ASSIGN,
        END,
        RETURN
    }

    public struct step
    {
        public StepName sType;
        public int sReturn; // // for RETURN, index of return var, within list of extVars to be returned
                // or statement line for other end of block or loop or step
        public Evaluator stepEval;
    }

    public class Macro
    {
        public List<step> steps = new List<step>();
        public List<string> mVars = new List<string>();
        public List<double> mVals = new List<double>();
        private int nVars = 0; // number of external vars being passed to Macro
        private List<double> extVals;
        private List<List<double>> dlists = new List<List<double>>(); // for lists handled internally in Macro
        private string macroFilename = "";

        public Macro(List<string> vars, List<double> vals, List<string> stepStrings)
        {
            makeMacro(vars, vals, null, null, stepStrings);
        }

        public Macro(List<string> vars, List<double> vals, List<string> strvars, List<string> strvals, List<string> stepStrings)
        {
            makeMacro(vars, vals, strvars, strvals, stepStrings);
        }

        public Macro(string filename)
        {
            ReadMacro(filename);
            macroFilename = filename;
        }

        public Macro() // creates just a shell macro to be filled in otherwise
        {
        }

        // converts a string to upper case, except that it leaves untouched any text within quotes 
        public string toUpperString(string s)
        {
            // this method assumes that quotes are well matched! and that s doesn't start with a quote
            string newstring = "";

            string[] ss;
            ss = s.Split('\"');

            for (int i = 0; i < ss.Length; i++)
            {
                if (i % 2 == 0) newstring += (ss[i]).ToUpper();
                else newstring += "\"" + ss[i] + "\"";
            }

            return newstring;
        }


        //TODO deal with string vars
        public void makeMacro(List<string> vars, List<double> vals, List<string> strvars, List<string> strvals, List<string> stepStrings)
        {
            step step2;

            nVars = vars.Count;
            for (int i = vals.Count; i < nVars; i++) vals.Add(0.0);

            extVals = new List<double>();
            for (int i = 0; i < nVars; i++) extVals.Add(vals[i]);

            foreach (string s in vars)
            {
                mVars.Add(s);// note: Macro can add internal vars to mVars
            }

            foreach (double d in vals) if(mVals.Count < mVars.Count) mVals.Add(d);
//            for (int i = vals.Count; i < vars.Count; i++) mVals.Add(0.0);
            
            for (int i = 0; i < stepStrings.Count; i++)
            {
                if(stepStrings[i] != null && stepStrings[i].Trim() != "" && !stepStrings[i].StartsWith("*") && !stepStrings[i].StartsWith("#"))
                    processStep(toUpperString(stepStrings[i])); // this will add mVars for new variables encountered in step
            }

            if (steps[steps.Count - 1].sType != StepName.RETURN)
            {
                step step1 = new step();
                step1.sType = StepName.RETURN;
                step1.sReturn = steps.Count + 1;
                steps.Add(step1);
            }

            for (int i = 0; i < steps.Count; i++)
            {
                step2 = steps[i];

                if (step2.sType == StepName.RETURN) step2.sReturn = steps.Count - 1;
                else if (step2.sType == StepName.CONTINUE)
                {
                    for (int j = i - 1; j >= 0; j++)
                    {
                        if (steps[j].sType == StepName.DO || steps[j].sType == StepName.DOWHILE)
                        {
                            step2.sReturn = steps[j].sReturn;
                            steps.RemoveAt(i);
                            steps.Insert(i, step2);
                            break;
                        }
                    }
                }
                else if (step2.sType == StepName.BREAK)
                {
                    for (int j = i - 1; j >= 0; j++)
                    {
                        if (steps[j].sType == StepName.DO || steps[j].sType == StepName.DOWHILE)
                        {
                            step2.sReturn = 1 + steps[j].sReturn;
                            steps.RemoveAt(i);
                            steps.Insert(i, step2);
                            break;
                        }
                    }
                }

                if (steps[i].sReturn < 0)
                {
                    throw new Exception("Evaluator.ImproperMacroFlow");
                }

            }

            // if all mVars have been added, we can addSpecials now?
            foreach(step st in steps) 
            {
                if (st.stepEval != null)
                {
                    st.stepEval.clearSpecials();
                    foreach (string s in mVars) st.stepEval.addSpecial(s);
                }
            }

        }

        public void addSpecial(string s)
        {
            // add extra Specials
            foreach (step st in steps)
            {
                if (st.stepEval != null)
                {
                    st.stepEval.addSpecial(s);
                }
            }
        }

        public void addSynon(string s1, string s2)
        {
            // add extra Synonyms
            foreach (step st in steps)
            {
                if (st.stepEval != null)
                {
                    st.stepEval.addSynonymy(s1,s2);
                }
            }
        }

        public void makeMacro(List<string> vars, List<double> vals, List<string> stepStrings)
        {
            makeMacro(vars, vals, null, null, stepStrings);
        }

        public void ReadMacro(string MacroFile) 
        {
            int nrows;

            StreamReader objReader;
            try
            {
                objReader = new StreamReader(MacroFile);
            }
            catch
            {
                throw new Exception("Macro File Read Failed");
            }

            List<string> vars = new List<string>();
            List<double> vals = new List<double>();
            List<string> tsteps = new List<string>();

            string sLine = "";
            char[] splits = { '=', ':', ';'}; // , ',' }; // comma removed so as to not mess up in EU
            char[] splits2 = { '=', ':', ';' , ',' }; 
            string[] ss;

            while ((sLine = objReader.ReadLine()) != null)
            {
                sLine = toUpperString(sLine);

                if (sLine.StartsWith("SHARED"))
                {
                    ss = sLine.Split(splits2);
                    nrows = ss.GetUpperBound(0);
                    for (int i = 1; i <= nrows; i++)
                    {
                        vars.Add(ss[i]);
                    }
                }

                else if (sLine.StartsWith("VALS"))
                {
                    ss = sLine.Split(splits);
                    nrows = ss.GetUpperBound(0);
                    for (int i = 1; i <= nrows; i++)
                    {
                        vals.Add(Convert.ToDouble(ss[i].ToString()));
                    }
                }

                else
                {
                    if (sLine != null && sLine != "" && sLine.Trim() != "" && sLine[0] != '*' && sLine[0] != '#') 
                        tsteps.Add(sLine.ToString());
                }
            }

            makeMacro(vars, vals, tsteps);

            return;
        }

        public bool processStep(string stepStr)
        {
            char[] splits = {'=',' ','('};
            char[] trims2 = {'=',' '};
            char[] trims = {'(', ')', '[', ']', '{', '}',' ' };
            int i;
            int endct = 0;
            step step2;

            if (stepStr.StartsWith("FILE="))
            {
                StreamReader objReader;
                try
                {
                    objReader = new StreamReader(stepStr.Substring(5));
                }
                catch
                {
                    throw new Exception("Evaluator.MacroFileReadFailed");
                }

                string sLine = "";
                while (sLine != null)
                {
                    sLine = objReader.ReadLine();
                    sLine = toUpperString(sLine);
                    if (sLine != null && sLine.Trim() != "" && sLine[0] != '#' && sLine[0] != '*')
                    {
                        processStep(sLine);
                    }
                }
                objReader.Close();
            }
            else
            {
                try
                {
                    step step1 = new step();
                    step1.sReturn = -1;

                    string[] s2 = stepStr.Split(splits,StringSplitOptions.RemoveEmptyEntries);
                    switch (s2[0])
                    {
                        case "IF":
                            step1.sType = StepName.IF;
                            step1.stepEval = new Evaluator(stepStr.Substring(2).Trim());
                            break;
                        case "DO":
                            step1.sType = StepName.DO;
                            break;
                        case "DOWHILE":
                            step1.sType = StepName.DOWHILE;
                            step1.stepEval = new Evaluator(stepStr.Substring(7).Trim());
                            break;
                        case "WHILE":
                            step1.sType = StepName.WHILE;
                            step1.stepEval = new Evaluator(stepStr.Substring(5).Trim());
                            endct = 0;
                            for (i = steps.Count - 1; i >= 0; i--)
                            {
                                step2 = steps[i];
                                if (step2.sType == StepName.WHILE) endct++;
                                else if (step2.sType == StepName.DO)
                                {
                                    if (0 == endct)
                                    {
                                        step2.sReturn = steps.Count;
                                        step1.sReturn = i;
                                        steps.RemoveAt(i);
                                        steps.Insert(i, step2);
                                        break;
                                    }
                                    else endct--;
                                }
                            }
                            break;
                        case "GOTO":
                            step1.sType = StepName.GOTO;
                            step1.sReturn = -1 + Convert.ToInt32(stepStr.Substring(4).Trim(trims)); // 0-based
                            break;
                        case "END":
                        case "ENDWHILE":
                        case "ENDIF":
                            step1.sType = StepName.END;
                            endct = 0;
                            for (i = steps.Count - 1; i >= 0; i--)
                            {
                                step2 = steps[i];
                                if (step2.sType == StepName.END) endct++;
                                else
                                {
                                    if (step2.sType == StepName.DOWHILE)
                                    {
                                        if (0 == endct)
                                        {
                                            step1.sReturn = i;
                                            step2.sReturn = steps.Count + 1;
                                            steps.RemoveAt(i);
                                            steps.Insert(i, step2);
                                            break;
                                        }
                                        else endct--;
                                    }
                                    if (step2.sType == StepName.IF)
                                    {
                                        if (0 == endct)
                                        {
                                            step1.sReturn = steps.Count + 1;
                                            if (step2.sReturn < 0) step2.sReturn = steps.Count + 1;
                                            else
                                            { //  already set by an ELSE, swap sReturn with Else
                                                int elseI = step2.sReturn - 1;
                                                step step3 = steps[elseI]; //ELSE
                                                step2.sReturn = step3.sReturn;
                                                step3.sReturn = steps.Count + 1;

                                                steps.RemoveAt(elseI);  // this replacement was omitted before 8 Mar 2015
                                                steps.Insert(elseI, step3);
                                            }
                                            steps.RemoveAt(i);
                                            steps.Insert(i, step2);
                                            break;
                                        }
                                        else endct--;
                                    }
                                }
                            }
                            break;
                        case "ELSE":
                            step1.sType = StepName.ELSE;
                            for (i = steps.Count - 1; i >= 0; i--)
                            {
                                step2 = steps[i];
                                if (step2.sType == StepName.IF)
                                {
                                    step1.sReturn = steps.Count + 1;
                                    step2.sReturn = steps.Count + 1;
                                    steps.RemoveAt(i);
                                    steps.Insert(i, step2);
                                    break;
                                }
                            }
                            break;
                        case "BREAK":
                            step1.sType = StepName.BREAK;
                            break;
                        case "CONTINUE":
                        case "LOOP":
                            step1.sType = StepName.CONTINUE;
                            //for (i = steps.Count - 1; i >= 0; i--)
                            //{
                            //    if (steps[i].sType == StepName.DOWHILE || steps[i].sType == StepName.DO)
                            //    {
                            //        step1.sReturn = i;
                            //    }
                            //}
                            break;

                        case "RETURN":
                        case "QUIT":
                        case "EXIT":
                            step1.sType = StepName.RETURN;
//                            i = Convert.ToInt32(s2[1].Trim(trims));
                            step1.sReturn = steps.Count + 1;
                            break;

                        // FOR never completed. Just too messy and ugly. Let user do it in some other way. 
                        //case "FOR":
                        //    string s = stepStr.Substring(4);
                        //    // TODO
                        //    int parenct = 0;
                        //    int forparam = 0;
                        //    string s3;
                        //    int starti;
                        //    for (i = 0; i < s.Length; i++)
                        //    {
                        //        if (s[i] == '(' || s[i] == '{' || s[i] == '[') parenct++;
                        //        if (s[i] == ')' || s[i] == '}' || s[i] == ']') parenct--;
                        //        if (parenct == 0 && (s[i] == ' ' || s[i] == ';'))
                        //        {
                        //            if (forparam == 0)
                        //            {
                        //                s3 = s.Remove(i);
                        //                string[] s3s = s3.Split("="); 
                        //                step step2 = new step();
                        //                step2.sType = StepName.ASSIGN;
                        //                for (i = 0; i < mVars.Count; i++)
                        //                {
                        //                    if (s3s[0] == mVars[i])
                        //                    {
                        //                        step2.sReturn = i;
                        //                        break;
                        //                    }
                        //                }
                        //                if (i == mVars.Count)
                        //                {
                        //                    mVars.Add(s3s[0]);
                        //                    mVals.Add(0.0);
                        //                    step2.sReturn = i;
                        //                }
                        //                string seval = stepStr.Substring(1 + s3s[0].Length);
                        //                step2.stepEval = new Evaluator(seval);

                        //                steps.Add(step2);
                        //                forparam++;
                        //                starti = i + 1;
                        //            }
                        //            if (forparam == 1)
                        //            {
                        //                s3 = s.Substring(starti, i - starti);



                        //                starti = i + 1;
                        //            }
                        //            if (forparam == 2)
                        //            {
                        //                string[] s3s = s.Remove(i).Split("=");
                        //                step step2 = new step();
                        //                step2.sType = StepName.ASSIGN;
                        //                for (i = 0; i < mVars.Count; i++)
                        //                {
                        //                    if (s3s[0] == mVars[i])
                        //                    {
                        //                        step2.sReturn = i;
                        //                        break;
                        //                    }
                        //                }
                        //                if (i == mVars.Count)
                        //                {
                        //                    mVars.Add(s3s[0]);
                        //                    mVals.Add(0.0);
                        //                    step2.sReturn = i;
                        //                }
                        //                string seval = stepStr.Substring(1 + s3s[0].Length);
                        //                step2.stepEval = new Evaluator(seval);

                        //                steps.Add(step2);
                        //                forparam++;
                        //            }
                        //        }
                        //    }
                        //    break;

                        case "LIST":
                            step1.sType = StepName.ASSIGN;
                            i = Convert.ToInt32(s2[1].Trim(trims));
                            while (i > dlists.Count) dlists.Add(new List<double>());

                            step1.sReturn = mVars.Count;
                            mVars.Add("CT" + i.ToString());
                            mVals.Add(0.0);

                            int neq = stepStr.IndexOf('=');
                            string leval = "RETURNLIST(" + i.ToString() + ";" + stepStr.Substring(neq + 1).TrimStart(trims2) + ")";
                            step1.stepEval = new Evaluator(leval); 
                            break;

                        default: // an assignment
                            step1.sType = StepName.ASSIGN;
                            for (i = 0; i < mVars.Count; i++)
                            {
                                if (s2[0] == mVars[i])  // s2[0] = is var being assigned a value
                                {
                                    step1.sReturn = i;
                                    break;
                                }
                            }
                            if (i == mVars.Count)
                            {
                                mVars.Add(s2[0]);
                                mVals.Add(0.0);
                                step1.sReturn = i;
                            }
                            string seval = stepStr.Substring(1 + s2[0].Length).TrimStart(trims2);
                            step1.stepEval = new Evaluator(seval); // seval is RT side of assignment step 
                            break;
                    }
                    steps.Add(step1);
                }
                catch
                {
                    throw new Exception("MacroEvaluator.MacroFormatError");
                }
            }
            return true;
        } // end of ProcessStep()


        // passes all vars as specvars
        public List<double> RunMacro()
        {
            int i = 0;
            while(i < steps.Count)
            {
                step step1 = steps[i];

                switch (step1.sType)
                {
                    case StepName.IF:
                    case StepName.DOWHILE:
                        if (0 == step1.stepEval.doEval(null, mVals, null, null, null, dlists, null, null, null, null)) i = step1.sReturn;
                        else i++;
                        break;
                    case StepName.GOTO:
                    case StepName.CONTINUE:
                    case StepName.BREAK:
                    case StepName.END:
                        i = step1.sReturn;
                        break;
                    case StepName.ELSE:
                        i = step1.sReturn;
                        break;
                    case StepName.DO:
                        i++;
                        break;
                    case StepName.WHILE:
                        if (0 == step1.stepEval.doEval(null, mVals, null, null, null, dlists, null, null, null, null)) i++;
                        else i = step1.sReturn;
                        break;
                    case StepName.ASSIGN:
                        mVals[step1.sReturn] = step1.stepEval.doEval(null, mVals, null, null, null, dlists, null, null, null, null);
                        i++;
                        break;
                    case StepName.RETURN:
                        i = steps.Count; //  step1.sReturn;
                        break;
                }
            }

            for (i = 0; i < extVals.Count; i++)
            {
                extVals[i] = mVals[i];
            }

            return extVals;
        }

        // make a deep copy, with all elements copied rather than pointing to any common refs
        public Macro copyMacro()
        {
            Macro newmac = new Macro();

            foreach (step st in steps)
            {
                step newst = new step();
                newst.sReturn = st.sReturn;
                newst.sType = st.sType;
                newst.stepEval = st.stepEval.copyEval();
            }
            foreach (string s in mVars) newmac.mVars.Add(s);
            foreach (double d in mVals) newmac.mVals.Add(d);
            newmac.nVars = nVars;
            foreach (double d in extVals) newmac.extVals.Add(d);
            if(dlists != null) for (int i = 0; i < dlists.Count; i++)
            {
                List<double> dl = new List<double>();
                if (dlists[i] != null) for (int j = 0; j < dlists[i].Count; j++)
                    {
                        dl.Add(dlists[i][j]);
                    }
                newmac.dlists.Add(dl);
            }
            newmac.macroFilename = macroFilename;

            return newmac;
        }

        public override string ToString()
        {
            if (macroFilename == "") return ("MACRO");
            else return ("MACRO(\"" + macroFilename + "\")");
//            else return ("Macro(" + macroFilename + ")");  // were quotes omitted on purpose?
        }

    } 



    public enum FOOVAR
    {
        KON,
        VAR,
        GSVAR,
        PSVAR,
        ISVAR,
        SPECIAL,
        NUMVAR1,
        NUMVAR2,
        NUMVAR3,
        NUMLISTA,  // was PPSVAR
        NUMLISTB, // for ISHIST
        NUMLISTC, // for PSHIST 
        NUMLISTD, // for GSHIST
        GDIST,
        NUMSPECVAR,
        TIMESERIES,
        LOOKUP,
        FIND,
        SAMPLE,
        SSAMPLE,
        REMOVE,
        REMOVEALL,
        REMOVEAT,
        APPEND,
        PREPEND,
        INSERT,
        SCHOOSE,
        CHOOSE,
        SEQUENCE,
        COUNT,
        LISTA,
        LISTB,
        LISTC,
        LISTD,
        MAKELIST,
        RETURNLIST,
        SORT,
        SORTREV,
        REVERSE,
        SUBSET,

//        FILE,
        MAX,
        MIN,
        HIGH,
        LOW,
        SUM,
        PRODUCT,
        MEAN,
        MEDIAN,
        PERCENTILE,
        PRANK,
        PLUS,
        MINUS,
        MULTIPLY,
        DIVIDE,
        EQUALS,
        LESSTHAN,
        GREATERTHAN,
        LESSOREQUAL,
        GREATEROREQUAL,
        NOTEQUAL,
        COMPARE,
        NOT,
        AND,
        OR,
        NAND,
        NOR,
        IF,
        POW,
        EXP,
        SQRT,
        MOD,
        ABS,
        LN,
        LOG10,
        NEG,
        CEIL,
        FLOOR,
        ROUND,
        PROUND,
        RAND,
        NRAND,
        SRAND,
        SNRAND,
        POISSON,
        SPOISSON,
        POISSON1,
        SPOISSON1,
        UNIFORM,
        IUNIFORM,
        SUNIFORM,
        SIUNIFORM,
        GAMMA,
        SGAMMA,
        GAMMAM,
        SGAMMAM,
        BETA,
        SBETA,
        BETAM,
        SBETAM,
        BINOMIALN,
        SBINOMIALN,
        BINOMIALP,
        SBINOMIALP,
        DECAY,
        SDECAY,
        SIN,
        COS,
        TAN,
        ASIN,
        ACOS,
        ATAN,
        SINH,
        COSH,
        TANH,
        RADIANS,
        DEGREES,

        REVALVALS,
        REVALVALSN,

        TOSTRING,

        STRKON,
        STRVAR1,
        STRVAR2,
        STRVAR3,
        STRSPECVAR,

        RIGHT,
        LEFT,

    // caution: any variable requiring a numeric first param needs to be listed above here in the enum
        STRLENGTH,
        TONUM,
//        LTRIM,
//        RTRIM,
//        TRIM,

        STRCONTAINS,
        STRCOMP,
        STARTSWITH,
        ENDSWITH,
        STRCAT,

        REVAL,
        REVALVARS,
        REVALGS,
        REVALPS,
        REVALIS,
//        REVALVALS
        REVALN,
        REVALVARSN,
        REVALGSN,
        REVALPSN,
        REVALISN

    };

    public struct synonym {
        public string label;
        public string map;
    }

    public class Evaluator
    {
        List<FOOVAR> foo = new List<FOOVAR>();
        List<double> kon = new List<double>();
        List<string> strkon = new List<string>();
        List<int> ndx = new List<int>(); // note one index list is used for all vars, kons, strkons, etc. 

//        List<string> filelist = new List<string>(); // for series passed as files 

        private List<string> specials = new List<string>();
        private List<string> strspecials = new List<string>();

        private List<string> varList = new List<string>();

        private string mFuncStr;
        private string mPolish = "";
        private string mParenStr = ""; // do we want to store this, or just re-create it if asked?
//        private string mFileName = ""; // in case FILE used

        private List<synonym>mSynons = new List<synonym>();
        private int internalSynons = 0;

        private static Random newRand = new Random(); 

        // constructor
        public Evaluator(string fStr)
        {
//            mFuncStr = fStr.ToUpper().Trim();
            mFuncStr = toUpperString(fStr).Trim();

            // internal synonymies
            standardSynonyms();
            //addSynonymy("'F'", "0");
            //addSynonymy("'M'", "1");
            //addSynonymy("FEMALE", "0");
            //addSynonymy("MALE", "1");
            //addSynonymy("TRUE", "1");
            //addSynonymy("FALSE", "0");
            //addSynonymy("'E'", Convert.ToString(Math.E));
            //addSynonymy("PI", Convert.ToString(Math.PI));
            //addSynonymy("PLIST", "LIST");
            internalSynons = mSynons.Count;  // number of synonyms added by system, not under user control 
        }

        public override string ToString()
        {
            return mFuncStr;
        }

        public string toUpperString(string s)
        {
            // this method assumes that quotes are well matched! and that s doesn't start with a quote
            string newstring = "";

            string[] ss;
            ss = s.Split('\"');

            for(int i = 0; i < ss.Length; i++)
            {
                if (i % 2 == 0) newstring += (ss[i]).ToUpper();
                else newstring += "\"" + ss[i] + "\"";
            }

            return newstring;
        }

        // make a deep copy, with all elements copied rather than pointing to common refs
        public Evaluator copyEval()
        {
            Evaluator neweval = new Evaluator(mFuncStr);

            foreach (string s in specials) neweval.specials.Add(s);
            foreach (string s in strspecials) neweval.strspecials.Add(s);
            for (int i = internalSynons; i < mSynons.Count; i++) neweval.mSynons.Add(mSynons[i]);
//            foreach (synonym syn in mSynons) neweval.mSynons.Add(syn);

            neweval.Translate();

            return neweval;
        }


        private bool standardSynonyms() // these are defaults, but can be overridden by user
        {
            addSynonymy("'F'", "0");
            addSynonymy("'M'", "1");
            addSynonymy("FEMALE", "0");
            addSynonymy("MALE", "1");
            addSynonymy("TRUE", "1");
            addSynonymy("FALSE", "0");
            addSynonymy("'E'", Convert.ToString(Math.E));
            addSynonymy("PI", Convert.ToString(Math.PI));

            // new 10 Dec 2015
            addSynonymy("RUN", "R");
            addSynonymy("YEAR", "Y");
            addSynonymy("ITERATION","R");

            addSynonymy("GS", "NUMVAR1");
            addSynonymy("PS", "NUMVAR2");
            addSynonymy("IS", "NUMVAR3");

            return true;
        }

        public bool addVar(string varLabel, int vnum, varType vtype)
        {
            if (vtype == varType.DOUBLE || vtype == varType.INT)
            {
                if (vnum == 1) addSynonymy(varLabel, "NUMVAR1");
                if (vnum == 2) addSynonymy(varLabel, "NUMVAR2");
                if (vnum == 3) addSynonymy(varLabel, "NUMVAR3");

                if (vnum > 3) throw new Exception("Evaluator: Too many variable arrays");
            }
            if (vtype == varType.STRING)
            {
                if (vnum == 1) addSynonymy(varLabel, "STRVAR1");
                if (vnum == 2) addSynonymy(varLabel, "STRVAR2");
                if (vnum == 3) addSynonymy(varLabel, "STRVAR3");

                if (vnum > 3) throw new Exception("Evaluator: Too many variable arrays");
            }
            //if (vtype == varType.BOOL)
            //{
            //    if (vnum == 1) addSynonymy(varLabel, "BOOLVAR1");
            //    if (vnum == 2) addSynonymy(varLabel, "BOOLVAR2");
            //    if (vnum == 3) addSynonymy(varLabel, "BOOLVAR3");

            //    // TODO bools -- now what?
            //}

            return true;
        }


        private string[] stringSplit(string s, char[] delims) // don't split strings enclosed in quotes
        {
            List<string> slist = new List<string>();

            int place = 0; 

            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == '\"')
                {
                    place = i;
                    do i++;
                    while (i < s.Length && s[i] != '\"');
                    slist.Add(s.Substring(place, 1 + i - place));
                    place = i + 1;
                    continue;
                }

                foreach (char c in delims)
                    if (c == s[i])
                    {
                        if (place < i) slist.Add(s.Substring(place, i - place));
//                        else slist.Add("");  // omit blank entries
                        place = i + 1;
                        break;
                    }
            }
            if (place < s.Length) slist.Add(s.Substring(place, s.Length - place));

            return slist.ToArray();
        }


        // can't put translate into Evaluator constructor, because it needs Synonyms and Specials first
        public bool Translate()
        {
            int i;
            string s;
            string nums = ".,0123456789";
            char[] sp = { ' ' };

            toPolish(mFuncStr);
            if (mPolish == "")
            {
                throw new Exception("Evaluator: Failure to convert function to Polish notation");
            }

            try
            {
//                string[] sops = mPolish.Split(' ');
                string[] sops = stringSplit(mPolish, sp);

                foo.Clear();
                ndx.Clear();
                kon.Clear();
                strkon.Clear();
                varList.Clear();

                double tkon = 0.0;
                bool konWaiting = false;

                foreach (string sop in sops)
                {
                    if (sop == "") continue;

                    // Additional Variables
                    if (sop == "VAR")
                    {
                        if (!konWaiting)
                            throw new Exception("Evaluator.ImproperVarFormat");
                        foo.Add(FOOVAR.VAR);
                        int j = Convert.ToInt32(tkon);
                        ndx.Add(j + 25);
                        konWaiting = false;
                        s = "VAR(" + j.ToString() + ")";
                        if (!varList.Contains(s)) varList.Add(s);
                        continue;
                    }

                    if (sop.StartsWith("NUMVAR"))
                    {
                        int ct = 0;
                        if (!konWaiting)
                            throw new Exception("Evaluator.ImproperNumVarFormat");
                        int j = Convert.ToInt32(tkon);

                        if (sop == "NUMVAR1")
                        {
                            foo.Add(FOOVAR.NUMVAR1);
                            s = "NUMVAR1(" + j.ToString() + ")";
                            if (!varList.Contains(s)) varList.Add(s);
                        }
                        else if (sop == "NUMVAR2")
                        {
                            foo.Add(FOOVAR.NUMVAR2);
                            s = "NUMVAR2(" + j.ToString() + ")";
                            if (!varList.Contains(s)) varList.Add(s);
                        }
                        else if (sop == "NUMVAR3")
                        {
                            foo.Add(FOOVAR.NUMVAR3);
                            s = "NUMVAR3(" + j.ToString() + ")";
                            if (!varList.Contains(s)) varList.Add(s);
                        }
                        else
                        {
                            foo.Add(FOOVAR.VAR);
                            ct = 25;
                            s = "VAR(" + j.ToString() + ")";
                            if (!varList.Contains(s)) varList.Add(s);
                        }
                        ndx.Add(j + ct);
                        konWaiting = false;
                        continue;
                    }

                    if (sop == "GS")
                    {
                        if (!konWaiting)
                            throw new Exception("Evaluator.ImproperGSVarFormat");
                        foo.Add(FOOVAR.GSVAR);
                        int j = Convert.ToInt32(tkon);
                        ndx.Add(j);
                        konWaiting = false;
                        s = "GS" + j.ToString();
                        if (!varList.Contains(s)) varList.Add(s);
                        continue;
                    }

                    if (sop == "PS")
                    {
                        if (!konWaiting)
                            throw new Exception("Evaluator.ImproperPSVarFormat");
                        foo.Add(FOOVAR.PSVAR);
                        int j = Convert.ToInt32(tkon);
                        ndx.Add(j);
                        konWaiting = false;
                        s = "PS" + j.ToString();
                        if (!varList.Contains(s)) varList.Add(s);
                        continue;
                    }

                    //if (sop == "PPS" || sop == "NUMLISTA")
                    //{
                    //    if (!konWaiting)
                    //        throw new Exception("Evaluator.ImproperPPSVarFormat");
                    //    //                    foo.Add(FOOVAR.VAR);
                    //    int j1 = Convert.ToInt32(tkon);
                    //    int ct = ndx.Count - 1;
                    //    ndx[ct] = j1; // population
                    //    konWaiting = false;

                    //    // first PPS index is the element (population) within PPSx, but reversed in PPS(x;p) format
                    //    // as p is first, x is second coming off the KON list

                    //    if (foo[foo.Count - 1] != FOOVAR.KON)
                    //        throw new Exception("Evaluator.ImproperPPSVarFormat");
                    //    foo.RemoveAt(foo.Count - 1); // undo KON
                    //    ct = kon.Count - 1;
                    //    int j2 = Convert.ToInt32(kon[ct]); // PSvar
                    //    kon.RemoveAt(ct);
                    //    // second PPS index is the x of PPSx
                    //    ndx.Add(j2);

                    //    foo.Add(FOOVAR.NUMLISTA);

                    //    s = "PPS" + j2.ToString() + "(" + j1.ToString() + ")";
                    //    if (!varList.Contains(s)) varList.Add(s);

                    //    continue;
                    //}

                    if (sop.StartsWith("PPS")) // treat PPSn(x) as a function rather than a variable
                        // leave as an alternative to NUMLISTA
                    {
                        if (konWaiting) // the Popn
                        {
                            ndx.Add(kon.Count);
                            foo.Add(FOOVAR.KON);
                            kon.Add(tkon - 1); // make 0-based as NUMLISTA
                            konWaiting = false;
                        }

                        foo.Add(FOOVAR.NUMLISTA);
                        int j2 = Convert.ToInt32(sop.Substring(3)); // the PSvar
                        ndx.Add(j2);

                        continue;
                    }

                    //if (sop == "NUMLISTA") // version that is expressed as NUMLISTA(list;item)
                    //{
                    //    int ct = kon.Count - 1;
                    //    int j2 = Convert.ToInt32(kon[ct]);

                    //    kon[ct] = tkon;
                    //    konWaiting = false;

                    //    ndx.Add(j2);

                    //    foo.Add(FOOVAR.NUMLISTA);

                    //    continue;
                    //}
                    //else 
                        if (sop.StartsWith("NUMLISTA")) // treat PPSn(x) as a function rather than a variable
                    {
                        if (konWaiting) // the Popn
                        {
                            ndx.Add(kon.Count);
                            foo.Add(FOOVAR.KON);
                            kon.Add(tkon);
                            konWaiting = false;
                        }

                        foo.Add(FOOVAR.NUMLISTA);
                        int j2 = Convert.ToInt32(sop.Substring(8)); // the PSvar
                        ndx.Add(j2);

                        continue;
                    }

                    //if (sop == "NUMLISTB") // version that is expressed as NUMLISTB(list;item)
                    //{
                    //    int ct = kon.Count - 1;
                    //    int j2 = Convert.ToInt32(kon[ct]);

                    //    kon[ct] = tkon;
                    //    konWaiting = false;

                    //    ndx.Add(j2);

                    //    foo.Add(FOOVAR.NUMLISTB);

                    //    continue;
                    //}
                    //else 
                        if (sop.StartsWith("NUMLISTB")) 
                    {
                        if (konWaiting)
                        {
                            ndx.Add(kon.Count);
                            foo.Add(FOOVAR.KON);
                            kon.Add(tkon);
                            konWaiting = false;
                        }

                        foo.Add(FOOVAR.NUMLISTB);
                        int j2 = Convert.ToInt32(sop.Substring(8)); // the GSvar
                        ndx.Add(j2);

                        continue;
                    }

                    if (sop.StartsWith("GSHIST"))
                    {
                        if (konWaiting)
                        {
                            ndx.Add(kon.Count);
                            foo.Add(FOOVAR.KON);
                            kon.Add(tkon);
                            konWaiting = false;
                        }

                        foo.Add(FOOVAR.NUMLISTB);
                        int j2 = Convert.ToInt32(sop.Substring(6)); // the GSvar
                        ndx.Add(j2);

                        continue;
                    }

                    //if (sop == "GDIST")
                    //{
                    //    if (!konWaiting)
                    //        throw new Exception("Evaluator.ImproperGDISTFormat");
                    //    foo.Add(FOOVAR.GDIST);
                    //    int j = Convert.ToInt32(tkon);
                    //    ndx.Add(j);
                    //    konWaiting = false;
                    //    s = "GDIST";
                    //    if (!varList.Contains(s)) varList.Add(s);
                    //    continue;
                    //}

                    //if (sop == "NUMLISTC") // version that is expressed as NUMLISTC(list;item)
                    //{
                    //    int ct = kon.Count - 1;
                    //    int j2 = Convert.ToInt32(kon[ct]);
                        
                    //    kon[ct] = tkon; // item
                    //    konWaiting = false;

                    //    ndx.Add(j2); // list

                    //    foo.Add(FOOVAR.NUMLISTC);

                    //    continue;
                    //}
                    //else 
                        if (sop.StartsWith("NUMLISTC"))
                    {
                        if (konWaiting)
                        {
                            ndx.Add(kon.Count);
                            foo.Add(FOOVAR.KON);
                            kon.Add(tkon);
                            konWaiting = false;
                        }

                        foo.Add(FOOVAR.NUMLISTC);
                        int j2 = Convert.ToInt32(sop.Substring(8)); // the PSvar
                        ndx.Add(j2);

                        continue;
                    }

                    if (sop.StartsWith("PSHIST"))
                    {
                        if (konWaiting)
                        {
                            ndx.Add(kon.Count);
                            foo.Add(FOOVAR.KON);
                            kon.Add(tkon);
                            konWaiting = false;
                        }

                        foo.Add(FOOVAR.NUMLISTC);
                        int j2 = Convert.ToInt32(sop.Substring(6)); // the PSvar
                        ndx.Add(j2);

                        continue;
                    }

                    //if (sop == "NUMLISTD") // version that is expressed as NUMLISTD(list;item)
                    //{
                    //    int ct = kon.Count - 1;
                    //    int j2 = Convert.ToInt32(kon[ct]);

                    //    kon[ct] = tkon;
                    //    konWaiting = false;

                    //    ndx.Add(j2);

                    //    foo.Add(FOOVAR.NUMLISTD);

                    //    continue;
                    //}
                    //else 
                        if (sop.StartsWith("NUMLISTD"))
                    {
                        if (konWaiting)
                        {
                            ndx.Add(kon.Count);
                            foo.Add(FOOVAR.KON);
                            kon.Add(tkon);
                            konWaiting = false;
                        }

                        foo.Add(FOOVAR.NUMLISTD);
                        int j2 = Convert.ToInt32(sop.Substring(8)); // the ISvar
                        ndx.Add(j2);

                        continue;
                    }

                    if (sop.StartsWith("ISHIST"))
                    {
                        if (konWaiting)
                        {
                            ndx.Add(kon.Count);
                            foo.Add(FOOVAR.KON);
                            kon.Add(tkon);
                            konWaiting = false;
                        }

                        foo.Add(FOOVAR.NUMLISTD);
                        int j2 = Convert.ToInt32(sop.Substring(6)); // the ISvar
                        ndx.Add(j2);

                        continue;
                    }

                    if (sop == "IS")
                    {
                        if (!konWaiting)
                            throw new Exception("Evaluator.ImproperISVarFormat");
                        foo.Add(FOOVAR.ISVAR);
                        int j = Convert.ToInt32(tkon);
                        ndx.Add(j);
                        konWaiting = false;
                        s = "IS" + j.ToString();
                        if (!varList.Contains(s)) varList.Add(s);
                        continue;
                    }

                    if (sop == "LIST")
                    {
                        if (!konWaiting)
                            throw new Exception("Evaluator.ImproperLISTFormat");
                        foo.Add(FOOVAR.LISTA);
                        int j = Convert.ToInt32(tkon);
                        ndx.Add(j);
                        konWaiting = false;
                        s = "LIST(" + j.ToString() + ")";
                        if (!varList.Contains(s)) varList.Add(s);
                        continue;
                    }

                    if (sop == "LISTA")
                    {
                        if (!konWaiting)
                            throw new Exception("Evaluator.ImproperLISTFormat");
                        foo.Add(FOOVAR.LISTA);
                        int j = Convert.ToInt32(tkon);
                        ndx.Add(j);
                        konWaiting = false;
                        s = "LISTA(" + j.ToString() + ")";
                        if (!varList.Contains(s)) varList.Add(s);
                        continue;
                    }
                    if (sop.StartsWith("LISTA"))
                    {
                        if (konWaiting)
                        {
                            ndx.Add(kon.Count);
                            foo.Add(FOOVAR.KON);
                            kon.Add(tkon);
                            konWaiting = false;
                        }

                        foo.Add(FOOVAR.LISTA);
                        int j2 = Convert.ToInt32(sop.Substring(5)); 
                        ndx.Add(j2);

                        continue;
                    }

                    if (sop == "LISTB")
                    {
                        if (!konWaiting)
                            throw new Exception("Evaluator.ImproperLISTFormat");
                        foo.Add(FOOVAR.LISTB);
                        int j = Convert.ToInt32(tkon);
                        ndx.Add(j);
                        konWaiting = false;
                        s = "LISTB(" + j.ToString() + ")";
                        if (!varList.Contains(s)) varList.Add(s);
                        continue;
                    }
                    if (sop.StartsWith("LISTB"))
                    {
                        if (konWaiting)
                        {
                            ndx.Add(kon.Count);
                            foo.Add(FOOVAR.KON);
                            kon.Add(tkon);
                            konWaiting = false;
                        }

                        foo.Add(FOOVAR.LISTB);
                        int j2 = Convert.ToInt32(sop.Substring(5));
                        ndx.Add(j2);

                        continue;
                    }

                    if (sop == "LISTC")
                    {
                        if (!konWaiting)
                            throw new Exception("Evaluator.ImproperLISTFormat");
                        foo.Add(FOOVAR.LISTC);
                        int j = Convert.ToInt32(tkon);
                        ndx.Add(j);
                        konWaiting = false;
                        s = "LISTC(" + j.ToString() + ")";
                        if (!varList.Contains(s)) varList.Add(s);
                        continue;
                    }
                    if (sop.StartsWith("LISTC"))
                    {
                        if (konWaiting)
                        {
                            ndx.Add(kon.Count);
                            foo.Add(FOOVAR.KON);
                            kon.Add(tkon);
                            konWaiting = false;
                        }

                        foo.Add(FOOVAR.LISTC);
                        int j2 = Convert.ToInt32(sop.Substring(5));
                        ndx.Add(j2);

                        continue;
                    }

                    if (sop == "LISTD")
                    {
                        if (!konWaiting)
                            throw new Exception("Evaluator.ImproperLISTFormat");
                        foo.Add(FOOVAR.LISTD);
                        int j = Convert.ToInt32(tkon);
                        ndx.Add(j);
                        konWaiting = false;
                        s = "LISTD(" + j.ToString() + ")";
                        if (!varList.Contains(s)) varList.Add(s);
                        continue;
                    }
                    if (sop.StartsWith("LISTD"))
                    {
                        if (konWaiting)
                        {
                            ndx.Add(kon.Count);
                            foo.Add(FOOVAR.KON);
                            kon.Add(tkon);
                            konWaiting = false;
                        }

                        foo.Add(FOOVAR.LISTD);
                        int j2 = Convert.ToInt32(sop.Substring(5));
                        ndx.Add(j2);

                        continue;
                    }

                    if (sop.StartsWith("STRVAR"))
                    {
                        if (!konWaiting)
                            throw new Exception("Evaluator.ImproperStrVarFormat");
                        int j = Convert.ToInt32(tkon);

                        if (sop == "STRVAR1")
                        {
                            foo.Add(FOOVAR.STRVAR1);
                            s = "STRVAR1(" + j.ToString() + ")";
                            if (!varList.Contains(s)) varList.Add(s);
                        }
                        else if (sop == "STRVAR2")
                        {
                            foo.Add(FOOVAR.STRVAR2);
                            s = "STRVAR2(" + j.ToString() + ")";
                            if (!varList.Contains(s)) varList.Add(s);
                        }
                        else if (sop == "STRVAR3")
                        {
                            foo.Add(FOOVAR.STRVAR3);
                            s = "STRVAR3(" + j.ToString() + ")";
                            if (!varList.Contains(s)) varList.Add(s);
                        }

                        ndx.Add(j);
                        konWaiting = false;
                        continue;
                    }

                    // constants
                    if (konWaiting)
                    {
                        ndx.Add(kon.Count);
                        foo.Add(FOOVAR.KON);
                        kon.Add(tkon);
                        konWaiting = false;
                    }

                    // translate Specials
                    for (i = 0; i < specials.Count; i++)
                    {
                        if (sop == specials[i])
                        {
                            foo.Add(FOOVAR.SPECIAL);
                            ndx.Add(i);
                            if (!varList.Contains(sop)) varList.Add(sop);
                            break;
                        }
                    }
                    if (i < specials.Count) continue;

                    for (i = 0; i < strspecials.Count; i++)
                    {
                        if (sop == strspecials[i])
                        {
                            foo.Add(FOOVAR.STRSPECVAR);
                            ndx.Add(i);
                            if (!varList.Contains(sop)) varList.Add(sop);
                            break;
                        }
                    }
                    if (i < strspecials.Count) continue;

                    // string constants
                    if (sop[0] == '\"')
                    {
                        int slen = sop.Length;
                        string strsop = sop.Substring(1, slen - 2); // if strkon not ended with ", will lose a character
                        ndx.Add(strkon.Count);
                        foo.Add(FOOVAR.STRKON);
                        strkon.Add(strsop);
                        continue;
                    }

                    // constants
                    if (nums.Contains(sop.Substring(0, 1)))
                    {
                        konWaiting = true;
                        tkon = Convert.ToDouble(sop);
                        continue;
                    }

                    //A-Z variables
                    if (sop.Length == 1 && sop[0] >= 'A' && sop[0] <= 'Z')
                    {
                        foo.Add(FOOVAR.VAR);
                        ndx.Add(sop[0] - 'A');
                        if (!varList.Contains(sop)) varList.Add(sop);
                        continue;
                    }

                    // all other functions, including operators
                    foo.Add(footrans(sop));

                    // check string functions for proper param type
                    int fooct = foo.Count;
                    if (fooct < 2) continue;

                    FOOVAR foovar1 = foo[fooct - 1];
                    FOOVAR foovar2 = foo[fooct - 2];

                    bool isstr2 = false;
                    // FOOs that return strings
                    isstr2 = (foovar2 == FOOVAR.TOSTRING || foovar2 == FOOVAR.STRKON || foovar2 == FOOVAR.STRVAR1 || foovar2 == FOOVAR.STRVAR2 || foovar2 == FOOVAR.STRVAR3 || foovar2 == FOOVAR.STRSPECVAR || foovar2 == FOOVAR.STRCAT || foovar2 == FOOVAR.RIGHT || foovar2 == FOOVAR.LEFT);

                    if (foovar1 == FOOVAR.PLUS && isstr2) // convert "PLUS" to "STRCAT"
                    {
                        foovar1 = FOOVAR.STRCAT;
                        foo[fooct - 1] = foovar1;
                    }

                    if (foovar1 < FOOVAR.STRLENGTH)
                    // a foo that requires a numeric param
                    {
                        // things that return strings
                        if (isstr2) throw new Exception("Evaluator.Function has incorrect (string/num) parameter type.");
                    }
                    else
                    {
                        // requires a string first param
                        if (!isstr2) throw new Exception("Evaluator.Function has incorrect (string/num) parameter type.");
                    }
                }

                // any terminating constant
                if (konWaiting)
                {
                    ndx.Add(kon.Count);
                    foo.Add(FOOVAR.KON);
                    kon.Add(tkon);
                    konWaiting = false;
                }

                // back-translate synonyms in varList
                string[] ss;
                for (int iv = 0; iv < varList.Count; iv++)
                {
                    ss = varList[iv].Split('(');
                    for (int si = internalSynons; si < mSynons.Count; si++)
                    {
                        synonym syn = mSynons[si];
                        if (ss[0] == syn.map)
                        {
                            varList[iv] = varList[iv].Replace(syn.map, syn.label);
                            break;
                        }
                    }
                }
            }
            catch 
            {
                return false;
            }
            return true;
        }

        // accessors
        public string FuncStr { get { return mFuncStr; } set { mFuncStr = value; } }
        public string Polish { get { return mPolish; } }
        public string Parenthetical { get { return mParenStr; } }

        public bool contains(string sop)
        // check if func contains a var or op; useful for programs that need to provide special processing to make some vars available to Evaluator
        // e.g., in Vortex, if MK is used in a function, then MKs need to be calculated, otherwise not

        // note: this is checking sops AFTER synonymies are translated; use func.ToString().contains() to search funcStr
        {
            string[] sops = mPolish.Split(' ');
            foreach (string s in sops)
            {
                if (s == sop) return true;
            }
            return false;
        }

        public List<string> usedVars()
        {
            return varList;
        }


        public List<string> specialVars()
        {
            return specials;
        }

        public int addSpecial(string spec)
        {
            specials.Add(spec);

            return specials.Count;
        }

        public int addSpecial(string[] specs)
        {
            foreach(string s in specs)
                specials.Add(s);

            return specials.Count;
        }

        public bool clearSpecials()
        {
            specials.Clear();

            return true;
        }

        public int addNumSpecial(string spec)
        {
            specials.Add(spec);

            return specials.Count;
        }

        public int addNumSpecial(string[] specs)
        {
            foreach (string s in specs)
                specials.Add(s);

            return specials.Count;
        }

        public bool clearNumSpecials()
        {
            specials.Clear();

            return true;
        }

        public int addStringSpecial(string spec)
        {
            strspecials.Add(spec);

            return strspecials.Count;
        }

        public int addStringSpecial(string[] specs)
        {
            foreach (string s in specs)
                strspecials.Add(s);

            return strspecials.Count;
        }

        public bool clearStringSpecials()
        {
            strspecials.Clear();

            return true;
        }

        public int addSynonymy(string s1, string map) // s1 is the new name, map is the standard name to which it gets translated
        {
            removeSynonymy(s1); // just in case

            synonym syn = new synonym();
            syn.label = s1;
            syn.map = map;
            mSynons.Add(syn);

            return mSynons.Count - internalSynons;
        }

        public bool removeSynonymy(string s1)
        {
            for (int i = 0; i < mSynons.Count; i++)
            {
                synonym syn = mSynons[i];
                if (syn.label == s1) mSynons.Remove(syn);
            }

            return true;
        }

        public bool clearSynonymies()
        {
            mSynons.RemoveRange(internalSynons,mSynons.Count - internalSynons);

            return true;
        }

        public int numSynonymies { get { return mSynons.Count - internalSynons; } }

        public string[,] getSynonomies()
        {
            if (mSynons.Count == 0) return null;

            string[,] syns = new string[mSynons.Count,2];

            for (int i = 0; i < mSynons.Count; i++)
            {
                syns[i,0] = mSynons[i].label;
                syns[i,1] = mSynons[i].map;
            }

            return syns;
        }

        public string getSynonym(string syn) // finds the LAST syn label for a standard var
        {
            for (int i = mSynons.Count - 1; i >= 0; i--)
            {
                if (mSynons[i].map == syn) return mSynons[i].label;
            }

            return syn; // returns standard label if cannot find any syns
        }

        public string findSynonym(string syn)  // finds the standard name to which a syn is mapped
        {
            for (int i = 0; i < mSynons.Count; i++)
            {
                if (mSynons[i].label == syn) return mSynons[i].map;
            }

            return null;
        }

        private bool pieces(string instring, List<string> outs, char[] delims)
        { // similar to split, but keep the delimiters as pieces too
            outs.Clear();
            int pl = 0;
            for (int i = 0; i < instring.Length; i++)
            {
                // need to keep quoted strings together
                if(instring[i] == '\"')
                {
                    pl = i;
                    do i++;
                    while (i < instring.Length && instring[i] != '\"');
                    if (i == instring.Length)
                    { // didn't find it
                        outs.Add(instring.Substring(pl, i - pl) + ('\"').ToString());
                    }
                    else outs.Add(instring.Substring(pl, 1 + i - pl));
                    i++;
                    pl = i;
                    continue;
                }

                for (int j = 0; j <= delims.GetUpperBound(0); j++)
                {
                    if (instring[i] == delims[j])
                    {
                        if (i > pl) outs.Add(instring.Substring(pl, i - pl));
                        pl = i + 1;
                        outs.Add(instring.Substring(i, 1));
                        break;
                    }
                }
            }
            if (pl < instring.Length) outs.Add(instring.Substring(pl));

            return true;
        }

        private string addparens(string funcstr)
        { 
            string[] orderops = { " ", "^", "_", "!", "*/%", "+-", "<>{}", "=#", "&|" }; // initial op is just a dummy op to force parameter-requiring funcs to be dealt with first
            char[] delims = { ';', '(', ')', '_', '!', '^', '*', '/', '%', '+', '-', '<', '>', '{', '}', '=', '#', '&', '|' }; // , '$', '~'};

            string newstr = '(' + funcstr + ')';
            List<string> spieces = new List<string>();

            pieces(newstr,spieces,delims);
            for (int si = 0; si < spieces.Count; si++)
            {
                spieces[si] = spieces[si].Trim();
                if (spieces[si] == "") // 22 oct 2016 remove blank elements
                {
                    spieces.RemoveAt(si);
                    si--;
                }
            }

            foreach(string sop in orderops) {
                int sct = spieces.Count - 1;
                for(int i = 1; i < sct; i++) {
                    bool pfunc = false;
                    if (spieces[i].Length > 1 && i + 3 < spieces.Count && spieces[i + 1][0] == '(')
                    { // a parameter-requiring function
                        pfunc = true;
                    }

                    if(sop.Contains(spieces[i]) || pfunc) {
                        int leftop = 0; // place in spieces of foo to the left of op 
                        int rightop = 0;
                        if (spieces[i - 1][0] == ')')
                        {
                            int pct = 0; // # nested parens to be skipped over
                            for (int j = i - 2; j >= 0; j--)
                            {// find matching openparens
                                if (spieces[j][0] == ')') pct++;
                                else if (spieces[j][0] == '(')
                                {
                                    if (pct == 0)
                                    { // found it
                                        leftop = j;
                                        break;
                                    } 
                                    else pct--;
                                }
                            }
                        }
                        else
                        {
                            if (sop != "_" && !pfunc) 
                                leftop = i - 1;
                            else leftop = i;
                        }

                        if(spieces[i+1][0] == '(') { 
                            int pct = 0; // # nested parens to be skipped over
                            for(int j = i+2; j < spieces.Count; j++) {// find matching closeparens
                                if(spieces[j][0] == '(') pct++;
                                else if(spieces[j][0] == ')') {
                                    if (pct == 0) { rightop = j; break; } // found it
                                    else pct--;
                                }
                            }
                        }
                        else rightop = i+1;
                        
                        if(leftop == 0 || spieces[leftop - 1][0] != '(' || rightop == spieces.Count - 1 || spieces[rightop + 1][0] != ')') {
                            // need to insert parens
                            spieces.Insert(rightop + 1,")");
                            spieces.Insert(leftop, "(");
                            sct += 2;
                            i += 2;
                        }
                    }
                }
            }

            // now, reassemble newstr by putting pieces back together
            newstr = "";
            foreach (string s in spieces) newstr = newstr + s;

            mParenStr = newstr;

            return newstr;
        }

        private string popstring(Stack<string> strstack)
        {
            string tfoo;

            tfoo = strstack.Pop();
            if (tfoo != "(") return tfoo + " ";
            return "";
        }

        private bool inString(string s,char c) {
            foreach (char c1 in s) if (c1 == c) return true;
            return false;
        }


        private string toPolish(string funcstr)
        {
            try
            {
                Stack<string> strstack;
                // removed $ and ~ from delims, 17 Aug 2016
                string delims = " ;:{}[]()%+*-/_!=#^&|<>";
                char[] delimsp = { ' ', ';', ':', '{', '}', '[', ']', '(', ')', '%', '+', '*', '-', '/', '_', '!', '=', '#', '^', '&', '|', '<', '>' };
                char[] ops = { '%', '+', '*', '-', '/', '!', '=', '#', '^', '&', '|', '<', '>', '_' };
                string[] s;
                int pl = 0;

                strstack = new Stack<string>();
                mPolish = "";

                if (funcstr[0] == '=') funcstr = funcstr.Substring(1);

           // stuff moved below FILE, so that filename can be anything
                //if (!funcstr.Contains("\"")) funcstr = funcstr.Replace(" ", ""); // otherwise, messes up within strings -- fixed by keeping strings together
                //else { // TODO test  22 Oct 2016 -- awkward, but it should work
                //    string newstring = "";
                //    int quotes = 0;
                //    for (int i = 0; i < funcstr.Length; i++)
                //    {
                //        if (funcstr[i] == '"') quotes++;
                //        if (funcstr[i] != ' ' || quotes % 2 == 1) newstring = newstring + (funcstr[i]).ToString();
                //    }
                //    funcstr = newstring;
                //}

                //funcstr = funcstr.Replace('[', '(');
                //funcstr = funcstr.Replace('{', '(');
                //funcstr = funcstr.Replace(']', ')');
                //funcstr = funcstr.Replace('}', ')');
                //// need to do all of these here, rather than just in footran because these get used as delimiters in creating mPolish
                //funcstr = funcstr.Replace(">=", "}");
                //funcstr = funcstr.Replace("<=", "{");
                //funcstr = funcstr.Replace("!=", "#");
                //funcstr = funcstr.Replace("<>", "#");
                //funcstr = funcstr.Replace("==", "=");
                ////            funcstr = funcstr.Replace("NOT", "!");
                ////            funcstr = funcstr.Replace("OR", "|");
                ////            funcstr = funcstr.Replace("AND", "&");
                ////            funcstr = funcstr.Replace("NOR", "~");
                ////            funcstr = funcstr.Replace("NAND", "$"); 
                //funcstr = funcstr.Replace("||", "OR");
                //funcstr = funcstr.Replace("&&", "AND");
                //funcstr = funcstr.Replace("!|", "NOR");
                //funcstr = funcstr.Replace("!&", "NAND");

                // replace FILE(filename) with values  
                while (funcstr.Contains("FILE(")) // need to include the '(' in the Contains to avoid problems with R scripts
                {
                    int fnameStart = 5 + funcstr.IndexOf("FILE");
                    string filename = funcstr.Substring(fnameStart);
                    int fnameEnd = filename.IndexOf(')');
                    string newFuncStr = "";
                    if (filename.Length > fnameEnd + 1)
                        newFuncStr = filename.Substring(fnameEnd + 1); // last piece for unpacked func
                    filename = filename.Remove(fnameEnd).Trim('"'); // can put filename in quotes to preserve punctuation in it.

                    // read values from file and place into a delimited string
                    StreamReader objReader;
                    try
                    {
                        objReader = new StreamReader(filename);
                    }
                    catch
                    {
                        throw new Exception("Evaluator.ValuesFileReadFailed");
                    }

                    string valstring = "";
                    string sLine = "";
                    while (sLine != null)
                    {
                        sLine = objReader.ReadLine();
                        if (sLine != null && sLine.Trim() != "")
                        {
                            valstring = valstring + toUpperString(sLine) + ";"; // ToUpper just in case "values" are functions
                        }
                    }
                    objReader.Close();
                    valstring = valstring.Remove(valstring.Length - 1);  // get rid of trailing ';'

                    funcstr = funcstr.Remove(fnameStart - 5) + valstring + newFuncStr;
                }

                // replace FILECOL(filename;col) with values in col of file -- 20 Sept 2017
                // can't read functions within a file col, because messes up delimiters
                while (funcstr.Contains("FILECOL(")) 
                {
                    int fnameStart = 8 + funcstr.IndexOf("FILECOL");
                    string filename = funcstr.Substring(fnameStart);
                    int fnameEnd = filename.IndexOf(';');
                    int filecolEnd = filename.IndexOf(')');
                    string newFuncStr = "";
                    if (filename.Length > filecolEnd + 1)
                        newFuncStr = filename.Substring(filecolEnd + 1); // last piece for unpacked func
                    int colnum = Convert.ToInt32(filename.Substring(fnameEnd + 1, -1 + filecolEnd - fnameEnd));
                    filename = filename.Remove(fnameEnd).Trim('"'); // can put filename in quotes to preserve punctuation in it.

                    char[] coldelims = { ' ', ';', ':', '\t' };

                    // read values from file and place into a delimited string
                    StreamReader objReader;
                    try
                    {
                        objReader = new StreamReader(filename);
                    }
                    catch
                    {
                        throw new Exception("Evaluator.ValuesFileReadFailed");
                    }

                    string valstring = "";
                    string sLine = "";
                    while (sLine != null)
                    {
                        sLine = objReader.ReadLine();
                        if (sLine != null && sLine.Trim() != "")
                        {
                            string[] sCols = sLine.Split(coldelims, StringSplitOptions.RemoveEmptyEntries);
                            int incol = colnum;
                            if (incol > sCols.Length) incol = sCols.Length;
                            valstring = valstring + sCols[incol - 1] + ";"; 
                        }
                    }
                    objReader.Close();
                    valstring = valstring.Remove(valstring.Length - 1);  // get rid of trailing ';'

                    funcstr = funcstr.Remove(fnameStart - 8) + valstring + newFuncStr;
                }


                // replace FILEROW(filename;row) with values in row of file -- 20 Sept 2017
                // can't read functions within a file row, because messes up delimiters
                while (funcstr.Contains("FILEROW(")) 
                {
                    int fnameStart = 8 + funcstr.IndexOf("FILEROW");
                    string filename = funcstr.Substring(fnameStart);
                    int fnameEnd = filename.IndexOf(';');
                    int filerowEnd = filename.IndexOf(')');
                    string newFuncStr = "";
                    if (filename.Length > filerowEnd + 1)
                        newFuncStr = filename.Substring(filerowEnd + 1); // last piece for unpacked func
                    int rownum = Convert.ToInt32(filename.Substring(fnameEnd + 1, -1 + filerowEnd - fnameEnd));
                    filename = filename.Remove(fnameEnd).Trim('"'); // can put filename in quotes to preserve punctuation in it.

                    char[] rowdelims = { ' ', ';', ':', '\t' };

                    // read values from file and place into a delimited string
                    StreamReader objReader;
                    try
                    {
                        objReader = new StreamReader(filename);
                    }
                    catch
                    {
                        throw new Exception("Evaluator.ValuesFileReadFailed");
                    }

                    string valstring = "";
                    string sLine = "";
                    int row = 0;
                    while (sLine != null)
                    {
                        sLine = objReader.ReadLine();
                        if (sLine != null && sLine.Trim() != "")
                        {
                            row++;
                            if (row == rownum)
                            {
                                string[] svals = sLine.Split(rowdelims, StringSplitOptions.RemoveEmptyEntries);
                                foreach (string ss in svals) valstring = valstring + ss + ";";
                                break;
                            }
                        }
                    }
                    objReader.Close();
                    valstring = valstring.Remove(valstring.Length - 1);  // get rid of trailing ';'

                    funcstr = funcstr.Remove(fnameStart - 8) + valstring + newFuncStr;
                }


                // replace FILECELL(filename;row;col) with value in row,col of file -- 20 Sept 2017
                // can't read functions within a file, because messes up delimiters
                while (funcstr.Contains("FILECELL(")) 
                {
                    int fnameStart = 9 + funcstr.IndexOf("FILECELL");
                    string filename = funcstr.Substring(fnameStart);
                    int fnameEnd = filename.IndexOf(';');
                    int filerowEnd = filename.IndexOf(')');
                    string newFuncStr = "";
                    if (filename.Length > filerowEnd + 1)
                        newFuncStr = filename.Substring(filerowEnd + 1); // last piece for unpacked func

                    string[] scell = filename.Remove(filerowEnd).Split(';');
                    int rownum = Convert.ToInt32(scell[1].Trim());
                    int colnum = Convert.ToInt32(scell[2].Trim());

                    filename = filename.Remove(fnameEnd).Trim('"'); // can put filename in quotes to preserve punctuation in it.

                    char[] rowdelims = { ' ', ';', ':', '\t' };

                    // read values from file and place into a delimited string
                    StreamReader objReader;
                    try
                    {
                        objReader = new StreamReader(filename);
                    }
                    catch
                    {
                        throw new Exception("Evaluator.ValuesFileReadFailed");
                    }

                    string valstring = "";
                    string sLine = "";
                    int row = 0;
                    while (sLine != null)
                    {
                        sLine = objReader.ReadLine();
                        if (sLine != null && sLine.Trim() != "")
                        {
                            row++;
                            if (row == rownum)
                            {
                                string[] svals = sLine.Split(rowdelims, StringSplitOptions.RemoveEmptyEntries);
                                valstring = svals[colnum - 1];
                                break;
                            }
                        }
                    }
                    objReader.Close();

                    funcstr = funcstr.Remove(fnameStart - 9) + valstring + newFuncStr;
                }


                if (!funcstr.Contains("\""))
                {
                    funcstr = funcstr.Replace(" ", ""); // otherwise, messes up within strings -- fixed by keeping strings together

                    funcstr = funcstr.Replace('[', '(');
                    funcstr = funcstr.Replace('{', '(');
                    funcstr = funcstr.Replace(']', ')');
                    funcstr = funcstr.Replace('}', ')');
                    funcstr = funcstr.Replace(">=", "}");
                    funcstr = funcstr.Replace("<=", "{");
                    funcstr = funcstr.Replace("!=", "#");
                    funcstr = funcstr.Replace("<>", "#");
                    funcstr = funcstr.Replace("==", "=");
                    funcstr = funcstr.Replace("||", " OR ");
                    funcstr = funcstr.Replace("&&", " AND ");
                    funcstr = funcstr.Replace("!|", " NOR ");
                    funcstr = funcstr.Replace("!&", " NAND ");
                    funcstr = funcstr.Replace("&", " AND ");
                }
                else {
                    string newstring = "";
                    int quotes = 0;
                    for (int i = 0; i < funcstr.Length; i++)
                    {
                        if (funcstr[i] == '"') quotes++;

                        if (quotes % 2 == 0) // outside of quoted string
                        {
                            if (funcstr[i] != ' ')
                            { // these put here so as to avoid replacements if within a quoted string
                                if (funcstr[i] == '[' || funcstr[i] == '{') newstring = newstring + "(";
                                else if (funcstr[i] == ']' || funcstr[i] == '}') newstring = newstring + ")";
                                else if (funcstr.Substring(i).StartsWith(">=")) { newstring = newstring + "}"; i++; }
                                else if (funcstr.Substring(i).StartsWith("<=")) { newstring = newstring + "{"; i++; }
                                else if (funcstr.Substring(i).StartsWith("!=")) { newstring = newstring + "#"; i++; }
                                else if (funcstr.Substring(i).StartsWith("<>")) { newstring = newstring + "#"; i++; }
                                else if (funcstr.Substring(i).StartsWith("==")) { newstring = newstring + "="; i++; }
                                else if (funcstr.Substring(i).StartsWith("||")) { newstring = newstring + " OR "; i++; }
                                else if (funcstr.Substring(i).StartsWith("&&")) { newstring = newstring + " AND "; i++; }
                                else if (funcstr.Substring(i).StartsWith("!|")) { newstring = newstring + " NOR "; i++; }
                                else if (funcstr.Substring(i).StartsWith("!&")) { newstring = newstring + " NAND "; i++; }
                                else if (funcstr[i] == '&') newstring = newstring + " AND ";
                                else newstring = newstring + (funcstr[i]).ToString();
                            }
                        }
                        else
                        {
                            newstring = newstring + (funcstr[i]).ToString();
                        }
                    }
                    funcstr = newstring;
                }

                //funcstr = funcstr.Replace('[', '(');
                //funcstr = funcstr.Replace('{', '(');
                //funcstr = funcstr.Replace(']', ')');
                //funcstr = funcstr.Replace('}', ')');

                // need to do all of these here, rather than just in footran because these get used as delimiters in creating mPolish
                //funcstr = funcstr.Replace(">=", "}");
                //funcstr = funcstr.Replace("<=", "{");
                //funcstr = funcstr.Replace("!=", "#");
                //funcstr = funcstr.Replace("<>", "#");
                //funcstr = funcstr.Replace("==", "=");
                ////            funcstr = funcstr.Replace("NOT", "!");
                ////            funcstr = funcstr.Replace("OR", "|");
                ////            funcstr = funcstr.Replace("AND", "&");
                ////            funcstr = funcstr.Replace("NOR", "~");
                ////            funcstr = funcstr.Replace("NAND", "$"); 
                //funcstr = funcstr.Replace("||", "OR");
                //funcstr = funcstr.Replace("&&", "AND");
                //funcstr = funcstr.Replace("!|", "NOR");
                //funcstr = funcstr.Replace("!&", "NAND");


                // distinguish '-' from '_'
                // or do we want to change it to 0-x ?
                bool jop = true;
                for (int i = 0; i < funcstr.Length; i++)
                {
                    int k;

                    if(funcstr[i] == '\"' ) // need to keep quoted strings together
                    {
                        do i++;
                        while (i < funcstr.Length && funcstr[i] != '\"'); // find closing quote
                        i++; // move on to next place in funcstr
                        if (i >= funcstr.Length) break; // didn't find it or it was at the end
                    }

                    for (k = 0; k < delims.Length; k++)
                    {
                        if (delims[k] == funcstr[i]) k = 100; // found an operator
                    }
                    if (k < 99) // not an operator
                    {
                        jop = false;
                        continue;
                    }

                    if (funcstr[i] == '-' && jop && (i == 0 || funcstr[i - 1] != ')'))
                    {
                        funcstr = funcstr.Substring(0, i) + "_" + funcstr.Substring(i + 1);
                    }
                    jop = true;
                }

                funcstr = addparens(funcstr);

                //            bool timeseries = false;

                List<int> opens = new List<int>();
                List<int> cts = new List<int>();

                while (pl < funcstr.Length)
                {

                    if (funcstr[pl] == '\"') // need to keep quoted strings together
                    {
                        int i = pl;
                        do i++;
                        while (i < funcstr.Length && funcstr[i] != '\"'); // find closing quote

                        i++; // move on to next place in funcstr
                        string tstring = funcstr.Substring(pl, i - pl);

                        pl = i;

                        // 9 Dec 2016 replaced strstack.Push with direct adddition to mPolish, 
                        //    so that it works to include a quoted string in a list, as in REVALVALS
                        // Don't think that it will mess up anything, 
                        //    as quoted string should always be treated like a simple var?
//                        strstack.Push(tstring);

                        mPolish = mPolish + tstring + " ";
                        // now pop back through any awaiting functions
                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);

                        continue;
                    }

                    if (funcstr[pl] == ' ' || funcstr[pl] == ';' || funcstr[pl] == ':')
                    {
                        pl++;

                        for (int i = 0; i < cts.Count; i++)
                        {
                            if (opens[i] == 1) cts[i]++; // adding up list items
                        }

                        continue;
                    }
                    if (funcstr[pl] == ')')
                    {
                        for (int i = 0; i < cts.Count; i++)
                        {
                            if (opens[i] == 1)
                            {// closing parens
                                mPolish = mPolish + Convert.ToString(cts[i]) + " "; // this is where counts of list are pushed onto stack
                                cts.RemoveAt(i); 
                                opens.RemoveAt(i);
                                i--; // so as to not step forward one i in loop
                            }
                            else opens[i]--;
                        }

                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);

                        // now pop the opening parens
                        if (strstack.Count > 0) mPolish = mPolish + popstring(strstack);

                        // now pop back through any awaiting functions
                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);
                        pl++;
                        continue;
                    }

                    if (funcstr[pl] == '(')
                    {
                        for (int i = 0; i < cts.Count; i++)
                        {
                            opens[i]++;
                        }

                        strstack.Push("(");
                        pl++;
                        continue;
                    }

                    string pbuff = funcstr.Substring(pl);

                    if (inString(delims, pbuff[0]))
                    {
                        pbuff = pbuff.Substring(0, 1);
                        strstack.Push(pbuff);
                        pl++;
                        continue;
                    }

                    s = pbuff.Split(delimsp);
                    pbuff = s[0];
                    pl += pbuff.Length;

                    // translate Synonyms
                    for (int i = 0; i < mSynons.Count; i++)
                    {
                        if (pbuff == mSynons[i].label) pbuff = mSynons[i].map;
                    }

                    // check for Specials
                    bool sfound = false;
                    for (int i = 0; i < specials.Count; i++)
                    {
                        if (pbuff == specials[i])
                        {
                            mPolish = mPolish + pbuff + " ";
                            // now pop back through any awaiting functions
                            while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);
                            sfound = true;
                            break;
                        }
                    }
                    if (sfound) continue;

                    if (pbuff.Length == 1 || inString(".,0123456789\"", pbuff[0])
                        // functions that take no operand 
                        || pbuff == "RAND" || pbuff == "NRAND" 
                        )
                    {
                        mPolish = mPolish + pbuff + " ";
                        // now pop back through any awaiting functions
                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);
                    }

                        // a bunch that don't need special processing, and can be confused with those below.
                    else if (pbuff == "LISTA" || pbuff == "LISTB" || pbuff == "LISTC" || pbuff == "LISTD") strstack.Push(pbuff);

                    else if (pbuff.Length > 5 && pbuff.StartsWith("LISTA"))
                    {
                        mPolish = mPolish + pbuff.Substring(5) + " LISTA ";
                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);
                    }
                    else if (pbuff.Length > 5 && pbuff.StartsWith("LISTB"))
                    {
                        mPolish = mPolish + pbuff.Substring(5) + " LISTB ";
                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);
                    }
                    else if (pbuff.Length > 5 && pbuff.StartsWith("LISTC"))
                    {
                        mPolish = mPolish + pbuff.Substring(5) + " LISTC ";
                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);
                    }
                    else if (pbuff.Length > 5 && pbuff.StartsWith("LISTD"))
                    {
                        mPolish = mPolish + pbuff.Substring(5) + " LISTD ";
                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);
                    }

                    else if (pbuff.Length > 5 && pbuff.StartsWith("GDIST"))
                    {
                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);
                        strstack.Push("GDIST");
                        strstack.Push(pbuff.Substring(5));
//                        mPolish = mPolish + pbuff.Substring(5) + " GDIST ";
                    }

                    else if (pbuff.Length > 3 && pbuff.StartsWith("VAR"))
                    {
                        mPolish = mPolish + pbuff.Substring(3) + " VAR ";
                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);
                    }

                    else if (pbuff.Length > 2 && pbuff.StartsWith("IS"))
                    {
                        mPolish = mPolish + pbuff.Substring(2) + " IS ";
                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);
                    }
                    else if (pbuff.Length > 2 && pbuff.StartsWith("PS"))
                    {
                        mPolish = mPolish + pbuff.Substring(2) + " PS ";
                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);
                    }
                    else if (pbuff.Length > 2 && pbuff.StartsWith("GS"))
                    {
                        mPolish = mPolish + pbuff.Substring(2) + " GS ";
                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);
                    }
                    else if (pbuff.Length > 4 && pbuff.StartsWith("LIST")) // && !pbuff.StartsWith("LISTRETURN"))
                    {
                        mPolish = mPolish + pbuff.Substring(4) + " LIST ";
                        while (strstack.Count > 0 && strstack.Peek()[0] != '(') mPolish = mPolish + popstring(strstack);
                    }
                    else
                    { // operators that take a list for the operands; need to determine number of list items
                        if (pbuff == "TIMESERIES" ||
                            pbuff == "CHOOSE" ||
                            pbuff == "MAKELIST" ||
                            pbuff == "HIGH" ||
                            pbuff == "LOW" ||
                            pbuff == "MEAN" ||
                            pbuff == "MEDIAN" ||
                            pbuff == "COUNT" ||
                            pbuff == "SORT" ||
                            pbuff == "SORTREV" ||
                            pbuff == "REVERSE" ||
                            pbuff == "PRODUCT" ||
                            pbuff == "SUM"
                            )
                        {
                            cts.Add(1); // start counting list items
                            opens.Add(0);
                        }

                        else if (pbuff == "LOOKUP" || // ones that have an extra param not be counted in the list
                            pbuff == "SCHOOSE" ||
                            pbuff == "FIND" ||
                            pbuff == "RETURNLIST" ||
                            pbuff == "REMOVE" ||
                            pbuff == "REMOVEALL" ||
                            pbuff == "REMOVEAT" ||
                            pbuff == "APPEND" ||
                            pbuff == "PREPEND" ||
                            pbuff == "SAMPLE" ||
                            pbuff == "PERCENTILE" ||
                            pbuff == "PRANK" 
                            || pbuff == "REVALVALS" 
                            )
                        {
                            cts.Add(0); // start counting list items
                            opens.Add(0);
                        }

                        else if (pbuff == "SUBSET" || pbuff == "SSAMPLE" || pbuff == "INSERT") // have two params to be skipped in counting
                        {
                            cts.Add(-1); // start counting list items
                            opens.Add(0);
                        }

                        strstack.Push(pbuff);
                    }
                }

                while (strstack.Count > 0)
                {
                    mPolish = mPolish + popstring(strstack);
                }
            }
            catch
            {
                throw new Exception("Evaluator: Failure to convert function to Polish notation");
            }

            return mPolish;
        }

        private FOOVAR footrans(string foo)
        {
            switch (foo)
            {
                case "+":
                    return FOOVAR.PLUS;
                case "-":
                    return FOOVAR.MINUS;
                case "*":
                    return FOOVAR.MULTIPLY;
                case "/":
                    return FOOVAR.DIVIDE;
                case "MAX":
                    return FOOVAR.MAX;
                case "MIN":
                    return FOOVAR.MIN;
                case "=":
                    return FOOVAR.EQUALS;
                case "<":
                    return FOOVAR.LESSTHAN;
                case "{":
                    return FOOVAR.LESSOREQUAL;
                case ">":
                    return FOOVAR.GREATERTHAN;
                case "}":
                    return FOOVAR.GREATEROREQUAL;
                case "#":
                    return FOOVAR.NOTEQUAL;
                case "!":
                case "NOT":
                    return FOOVAR.NOT;
                case "&":
                case "AND":
                    return FOOVAR.AND;
                case "|":
                case "OR":
                    return FOOVAR.OR;
                case "$":
                case "NAND":
                    return FOOVAR.NAND;
                case "~":
                case "NOR":
                    return FOOVAR.NOR;
                case "IF":
                    return FOOVAR.IF;
                case "^":
                case "POW":
                    return FOOVAR.POW;
                case "EXP":
                    return FOOVAR.EXP;
                case "SQR":
                case "SQRT":
                    return FOOVAR.SQRT;
                case "%":
                case "MOD":
                    return FOOVAR.MOD;
                case "ABS":
                    return FOOVAR.ABS;
                case "LOGE":
                case "LOG":
                case "LN":
                    return FOOVAR.LN;
                case "LOG10":
                    return FOOVAR.LOG10;
                case "_":
                case "NEG":
                    return FOOVAR.NEG;
                case "COMPARE":
                    return FOOVAR.COMPARE;
                case "CEIL":
                    return FOOVAR.CEIL;
                case "FLOOR":
                    return FOOVAR.FLOOR;
                case "ROUND":
                    return FOOVAR.ROUND;
                case "PROUND":
                    return FOOVAR.PROUND;
                case "RAND":
                    return FOOVAR.RAND;
                case "SRAND":
                    return FOOVAR.SRAND;
                case "NRAND":
                    return FOOVAR.NRAND;
                case "SNRAND":
                    return FOOVAR.SNRAND;
                case "POISSON":
                    return FOOVAR.POISSON;
                case "SPOISSON":
                    return FOOVAR.SPOISSON;
                case "DECAY":
                    return FOOVAR.DECAY;
                case "SDECAY":
                    return FOOVAR.SDECAY;
                case "UNIFORM":
                case "URAND":
                    return FOOVAR.UNIFORM;
                case "IUNIFORM":
                case "IURAND":
                case "IRAND":
                    return FOOVAR.IUNIFORM;
                case "SUNIFORM":
                case "SURAND":
                    return FOOVAR.SUNIFORM;
                case "SIUNIFORM":
                case "SIURAND":
                case "SIRAND":
                    return FOOVAR.SIUNIFORM;
                case "BINOMIALP":
                    return FOOVAR.BINOMIALP;
                case "SBINOMIALP":
                    return FOOVAR.SBINOMIALP;
                case "BINOMIALN":
                    return FOOVAR.BINOMIALN;
                case "SBINOMIALN":
                    return FOOVAR.SBINOMIALN;
                case "BETA":
                    return FOOVAR.BETA;
                case "SBETA":
                    return FOOVAR.SBETA;
                case "BETAM":
                    return FOOVAR.BETAM;
                case "SBETAM":
                    return FOOVAR.SBETAM;
                case "GAMMA":
                    return FOOVAR.GAMMA;
                case "SGAMMA":
                    return FOOVAR.SGAMMA;
                case "GAMMAM":
                    return FOOVAR.GAMMAM;
                case "SGAMMAM":
                    return FOOVAR.SGAMMAM;
                case "SIN":
                    return FOOVAR.SIN;
                case "COS":
                    return FOOVAR.COS;
                case "TAN":
                    return FOOVAR.TAN;
                case "ASIN":
                    return FOOVAR.ASIN;
                case "ACOS":
                    return FOOVAR.ACOS;
                case "ATAN":
                    return FOOVAR.ATAN;
                case "SINH":
                    return FOOVAR.SINH;
                case "COSH":
                    return FOOVAR.COSH;
                case "TANH":
                    return FOOVAR.TANH;
                case "DEGREES":
                    return FOOVAR.DEGREES;
                case "RADIANS":
                    return FOOVAR.RADIANS;
                case "VAR":
                    return FOOVAR.VAR;
                case "KON":
                    return FOOVAR.KON;
                case "LOW":
                    return FOOVAR.LOW;
                case "HIGH":
                    return FOOVAR.HIGH;
                case "MEDIAN":
                    return FOOVAR.MEDIAN;
                case "AVERAGE":
                case "AVG":
                case "MEAN":
                    return FOOVAR.MEAN;
                case "PRODUCT":
                    return FOOVAR.PRODUCT;
                case "SUM":
                    return FOOVAR.SUM;
                case "LOOKUP":
                    return FOOVAR.LOOKUP;
                case "SEQ":
                case "SEQUENCE":
                    return FOOVAR.SEQUENCE;
                case "PICK":
                case "CHOOSE":
                    return FOOVAR.CHOOSE;
                case "SCHOOSE":
                    return FOOVAR.SCHOOSE;
                case "FIND":
                    return FOOVAR.FIND;
                case "SAMPLE":
                    return FOOVAR.SAMPLE;
                case "SSAMPLE":
                    return FOOVAR.SSAMPLE;
                case "APPEND":
                    return FOOVAR.APPEND;
                case "PREPEND":
                    return FOOVAR.PREPEND;
                case "INSERT":
                    return FOOVAR.INSERT;
                case "REMOVE":
                    return FOOVAR.REMOVE;
                case "REMOVEALL":
                    return FOOVAR.REMOVEALL;
                case "REMOVEAT":
                    return FOOVAR.REMOVEAT;
                case "COUNT":
                    return FOOVAR.COUNT;
                case "SUBSET":
                    return FOOVAR.SUBSET;
                case "SORT":
                    return FOOVAR.SORT;
                case "SORTREV":
                    return FOOVAR.SORTREV;
                case "REVERSE":
                    return FOOVAR.REVERSE;
                case "PERCENTILE":
                case "PERCENTILEVAL":
                    return FOOVAR.PERCENTILE;
                case "PERCENTILERANK":
                case "PRANK":
                    return FOOVAR.PRANK;
                case "RETURNLIST":
                    return FOOVAR.RETURNLIST;
                case "MAKELIST":
                    return FOOVAR.MAKELIST;
                //case "LIST":
                //    return FOOVAR.LIST;
                //case "FILE":
                //    return FOOVAR.FILE;
                case "TIMESERIES":
                    return FOOVAR.TIMESERIES; 
                case "GDIST":
                    return FOOVAR.GDIST;

                case "REVAL":
                    return FOOVAR.REVAL;
                case "REVALGS":
                    return FOOVAR.REVALGS;
                case "REVALPS":
                    return FOOVAR.REVALPS;
                case "REVALIS":
                    return FOOVAR.REVALIS;
                case "REVALVARS":
                    return FOOVAR.REVALVARS;
                case "REVALVALS":
                    return FOOVAR.REVALVALS;

                case "REVALN":
                    return FOOVAR.REVALN;
                case "REVALGSN":
                    return FOOVAR.REVALGSN;
                case "REVALPSN":
                    return FOOVAR.REVALPSN;
                case "REVALISN":
                    return FOOVAR.REVALISN;
                case "REVALVARSN":
                    return FOOVAR.REVALVARSN;
                case "REVALVALSN":
                    return FOOVAR.REVALVALSN;

                case "STRKON":
                    return FOOVAR.STRKON;
                case "LENGTH":
                case "LEN":
                case "STRLEN":
                    return FOOVAR.STRLENGTH;
                case "STRCOMP":
                    return FOOVAR.STRCOMP;
                case "CONTAINS":
                case "STRCONTAINS":
                    return FOOVAR.STRCONTAINS;
                case "STRCAT":
                    return FOOVAR.STRCAT;
                //case "LTRIM":
                //    return FOOVAR.LTRIM;
                //case "RTRIM":
                //    return FOOVAR.RTRIM;
                //case "TRIM":
                //    return FOOVAR.TRIM;
                case "RIGHT":
                    return FOOVAR.RIGHT;
                case "LEFT":
                    return FOOVAR.LEFT;
                case "STARTSWITH":
                    return FOOVAR.STARTSWITH;
                case "ENDSWITH":
                    return FOOVAR.ENDSWITH;
                case "TONUM":
                    return FOOVAR.TONUM;
                case "TOSTRING":
                    return FOOVAR.TOSTRING;

                default:
                    throw new Exception("Evaluator.UnrecognizedOperator: " + foo);
            }
        }

        private double prandn()
        //  Routine for calculating normally distributed random deviates.
        //    Generates random numbers by the polar algorithm supplied by A.
        //    Latour. 1986. Polar normal distribution. Byte, August 1986, pp. 131-132. 
        {
            double v1,v2,s;

            do
            {
                v1 = 2.0 * newRand.NextDouble() - 1.0;
                v2 = 2.0 * newRand.NextDouble() - 1.0;
                s = v1 * v1 + v2 * v2;
            }
            while (s >= 1.0);

        // Note: s = 0.00 is very unlikely, but not impossible 
             if(s > 0.000) s = v1 * Math.Sqrt((-2.0) * Math.Log(s) / s);
             else s = 0.0;

             return(s);
        }

        private double prandn(int seed)
        {
            double s,v1,v2;

            try
            {
                Random rand1 = new Random(seed);

                do
                {
                    v1 = 2.0 * rand1.NextDouble() - 1.0;
                    v2 = 2.0 * rand1.NextDouble() - 1.0;
                    s = v1 * v1 + v2 * v2;
                }
                while (s >= 1.0);

                // Note: s = 0.00 is very unlikely, but not impossible 
                if (s > 0.0) s = v1 * Math.Sqrt((-2.0) * Math.Log(s) / s);
                else s = 0.0;
            }
            catch // a math error somehow?
            {
                s = 0.0;
            }
            return (s);
        }

        // exponential decay 
        private double decay(double p)
        {
            if (p <= 0.0) return 0.0;

            int d = 1;
            while (newRand.NextDouble() > p) d++;

            return (double) d;
        }

        private double sdecay(double p, int seed)
        {
            if (p <= 0.0) return 0.0;

            Random rand1 = new Random(seed);

            int d = 1;
            while (rand1.NextDouble() > p) d++;

            return (double)d;
        }

        private double poissonmean = 0.0;
        public List<double> cumPoisson; // made public so UI can display it if desired

        // determine Poisson disribution for mean m
        private bool setPoisson(double m)
        {
            double cum = 0.0;
            poissonmean = m;
            int facti = 1;

            cumPoisson = new List<double>();
            cum = Math.Exp(-m);
            cumPoisson.Add(cum);

            for (int i = 1; i < 100 * m; i++)
            {
                facti *= i;
                cum += Math.Pow(m, i) * Math.Exp(-m) / facti;
                cumPoisson.Add(cum);

                if (cum >= 0.999999) break;
            }
            return true;
        }

        private int getPoisson(double m)
        {
            int i = 0;

            double r = newRand.NextDouble(); 

            if (m != poissonmean) setPoisson(m);

            for (i = 0; i < cumPoisson.Count; i++)
            {
                if (r < cumPoisson[i]) break;
            }

            return i;
        }

        private int poissonvalue = 0;
        private int poissonseed = 0;

        private int getPoisson(double m, int seed)
        {
            if (m == poissonmean && seed == poissonseed) return poissonvalue; // for speed

            int i = 0;

            Random rand1 = new Random(seed);
            double r = rand1.NextDouble();

            if (m != poissonmean) setPoisson(m);

            for (i = 0; i < cumPoisson.Count; i++)
            {
                if (r < cumPoisson[i]) break;
            }
            
            poissonvalue = i;
            poissonseed = seed;

            return i;
        }

        private double poisson1mean = 0.0;
        public List<double> cumPoisson1; // made public so UI can display it if desired

        // determine 0-truncated Poisson distribution for mean m
        private bool setPoisson1(double m)
        {
            double cum = 0.0;
            poisson1mean = m;
            int facti = 1;

            cumPoisson1 = new List<double>();
            double bin0 = 1.0 - Math.Exp(-m);

            for (int i = 1; i < 100 * m; i++)
            {
                facti *= i;
                cum += Math.Pow(m, i) * Math.Exp(-m) / (facti * bin0);
                cumPoisson1.Add(cum);

                if (cum >= 0.999999) break;
            }
            return true;
        }

        private int getPoisson1(double m)
        {
            int i = 0;

            double r = newRand.NextDouble();

            if (m != poisson1mean) setPoisson1(m);

            for (i = 0; i < cumPoisson1.Count; i++)
            {
                if (r < cumPoisson1[i]) break;
            }

            return i + 1;
        }

        private int poisson1value = 0;
        private int poisson1seed = 0;

        private int getPoisson1(double m, int seed)
        {
            if (m == poisson1mean && seed == poisson1seed) return poisson1value; // for speed

            int i = 0;

            Random rand1 = new Random(seed);
            double r = rand1.NextDouble();

            if (m != poisson1mean) setPoisson1(m);

            for (i = 0; i < cumPoisson1.Count; i++)
            {
                if (r < cumPoisson1[i]) break;
            }

            poisson1value = i + 1;
            poisson1seed = seed;

            return poisson1value;
        }

        private double uLow = 0;
        private double uHigh = 0;
        private int uSeed = 0;
        private double uValue = 0;

        private double getUniform(double low, double high, int seed)
        {
            if (low == uLow && high == uHigh && seed == uSeed) return uValue; // for speed

            Random rand1 = new Random(seed);
            double r = rand1.NextDouble();

            uValue = low + (high - low) * r;
            uLow = low;
            uHigh = high;
            uSeed = seed;

            return uValue;
        }

        private double getUniform(double low, double high)
        {
            double r = newRand.NextDouble();

            double dval = low + (high - low) * r;

            return dval;
        }

        private int uiLow = 0;
        private int uiHigh = 0;
        private int uiSeed = 0;
        private int uiValue = 0;

        private int getUniformInt(int low, int high, int seed)
        {
            if (low == uiLow && high == uiHigh && seed == uiSeed) return uiValue; // for speed

            Random rand1 = new Random(seed);
            uiValue = rand1.Next(low, 1 + high);

            uiHigh = high;
            uiLow = low;
            uiSeed = seed;

            return uiValue;
        }

        private int getUniformInt(int low, int high)
        {
            int ival = newRand.Next(low, 1 + high);

            return ival;
        }


        private double binomn(double p, int n)
        {
            int j;

            double r = newRand.NextDouble();

            double q = 1.0 - p;
            double pq = p / q;
            int n1 = n + 1;
            double prob = Math.Pow(q, (double)n);
            double sum = prob;

            if (r < sum) return 0.0;

            for (j = 1; j < n1; j++)
            {
                prob *= pq * (double)(n1 - j) / (double)j;
                sum += prob;
                if (r < sum) break;
            }

//            prob = (double)(j - 1) / (double)n;

            return (double)j;
        }

        private double binomp(double p, int n)
        {
            int j;

            double r = newRand.NextDouble();

            double q = 1.0 - p;
            double pq = p / q;
            int n1 = n + 1;
            double prob = Math.Pow(q, (double)n);
            double sum = prob;

            if (r < sum) return 0.0;

            for (j = 1; j < n1; j++)
            {
                prob *= pq * (double)(n1 - j) / (double)j;
                sum += prob;
                if (r < sum) break;
            }

            return (double)j / (double)n;
        }

        private double sbinomn(double p, int n, int seed)
        {
            int j;

            Random rand1 = new Random(seed);
            double r = rand1.NextDouble();

            double q = 1.0 - p;
            double pq = p / q;
            int n1 = n + 1;
            double prob = Math.Pow(q, (double)n);
            double sum = prob;

            if (r < sum) return 0.0;

            for (j = 1; j < n1; j++)
            {
                prob *= pq * (double)(n1 - j) / (double)j;
                sum += prob;
                if (r < sum) break;
            }

            //            prob = (double)(j - 1) / (double)n;

            return (double)j;
        }

        private double sbinomp(double p, int n, int seed)
        {
            int j;

            Random rand1 = new Random(seed);
            double r = rand1.NextDouble();

            double q = 1.0 - p;
            double pq = p / q;
            int n1 = n + 1;
            double prob = Math.Pow(q, (double)n);
            double sum = prob;

            if (r < sum) return 0.0;

            for (j = 1; j < n1; j++)
            {
                prob *= pq * (double)(n1 - j) / (double)j;
                sum += prob;
                if (r < sum) break;
            }

            return (double)j / (double)n;
        }



        private double gamma(double alpha, double beta, int seed)
        {
            Random rand1 = new Random(seed);

            double X = 0.0;
            int k = (int)alpha;
            double g = alpha - k;

            double prod = 1.0;
            for (int i = 0; i < k; i++) prod *= rand1.NextDouble();

            if (k > 0) X = -Math.Log(prod);

            if (g < 0.001) return beta * X;

            // else
            double a = g;
            double b = 1.0 - g;
            double y = 1.0;
            double z = 1.0;
            double ia = 1.0 / a;
            double ib = 1.0 / b;

            while (y + z > 1.0)
            {
                y = Math.Pow(rand1.NextDouble(), ia);
                z = Math.Pow(rand1.NextDouble(), ib);
            }

            double Y = y / (y + z);
            double Z = -Math.Log(rand1.NextDouble());

            return beta * (X + Y * Z);
        }

        // returns a Gamma distributed random deviate
        private double gamma(double alpha, double beta)
        {
            double X = 0.0;
            int k = (int)alpha;
            double g = alpha - k;

            double prod = 1.0;
            for (int i = 0; i < k; i++) prod *= newRand.NextDouble();

            if (k > 0) X = -Math.Log(prod);

            if (g < 0.001) return beta * X;

            // else
            double a = g;
            double b = 1.0 - g;
            double y = 1.0;
            double z = 1.0;
            double ia = 1.0 / a;
            double ib = 1.0 / b;

            while (y + z > 1.0)
            {
                y = Math.Pow(newRand.NextDouble(), ia);
                z = Math.Pow(newRand.NextDouble(), ib);
            }

            double Y = y / (y + z);
            double Z = -Math.Log(newRand.NextDouble());

            return beta * (X + Y * Z);
        }

        private double gammam(double mean, double sd, int seed)
        {
            if (sd <= 0.0) return mean;

            double beta = sd * sd / mean;
            double alpha = mean / beta;

            Random rand1 = new Random(seed);

            double X = 0.0;
            int k = (int)alpha;
            double g = alpha - k;

            double prod = 1.0;
            for (int i = 0; i < k; i++) prod *= rand1.NextDouble();

            if (k > 0) X = -Math.Log(prod);

            if (g < 0.001) return beta * X;

            // else
            double a = g;
            double b = 1.0 - g;
            double y = 1.0;
            double z = 1.0;
            double ia = 1.0 / a;
            double ib = 1.0 / b;

            while (y + z > 1.0)
            {
                y = Math.Pow(rand1.NextDouble(), ia);
                z = Math.Pow(rand1.NextDouble(), ib);
            }

            double Y = y / (y + z);
            double Z = -Math.Log(rand1.NextDouble());

            return beta * (X + Y * Z);
        }

        private double gammam(double mean, double sd)
        {
            if (sd <= 0.0) return mean;

            double beta = sd * sd / mean;
            double alpha = mean / beta;

            double X = 0.0;
            int k = (int)alpha;
            double g = alpha - k;

            double prod = 1.0;
            for (int i = 0; i < k; i++) prod *= newRand.NextDouble();

            if (k > 0) X = -Math.Log(prod);

            if (g < 0.001) return beta * X;

            // else
            double a = g;
            double b = 1.0 - g;
            double y = 1.0;
            double z = 1.0;
            double ia = 1.0 / a;
            double ib = 1.0 / b;

            while (y + z > 1.0)
            {
                y = Math.Pow(newRand.NextDouble(), ia);
                z = Math.Pow(newRand.NextDouble(), ib);
            }

            double Y = y / (y + z);
            double Z = -Math.Log(newRand.NextDouble());

            return beta * (X + Y * Z);
        }

        // returns a Beta distributed random deviate
        private double betam(double mean, double sd, int seed)
        {
            if (mean <= 0.0) return 0.0;
            if (mean >= 1.0) return 1.0;
            if (sd <= 0.0) return mean;

            double var = sd * sd;
            double vlimit = mean * (1.0 - mean);

//            if (var == 0.0) return mean;
            if (var < 0.004 * vlimit) return mean + sd * prandn(seed); // use normal to avoid overflow problems in beta
//            if (var < 0.04 * vlimit) return mean + sd * prandn(seed); // use normal to avoid overflow problems in beta

            Random rand1 = new Random(seed);

            if (var >= 0.99 * vlimit) // 0.99 to avoid overflow problems
            {
                return ((mean > rand1.NextDouble()) ? 1.0 : 0.0); // if SD too large, return either 0 or 1
            }

            try
            {

                double a = vlimit / var - 1.0;
                double b = (1.0 - mean) * a;
                a *= mean;

                int k1 = (int)a;
                int k2 = (int)b;

                double Y = 1.0;
                double Z = 1.0;

                if (k1 == 0 && k2 == 0)
                {
                    double ia = 1.0 / a;
                    double ib = 1.0 / b;

                    while (Y + Z > 1.0)
                    {
                        Y = Math.Pow(rand1.NextDouble(), ia);
                        Z = Math.Pow(rand1.NextDouble(), ib);
                    }
                }
                else
                {
                    Y = gamma(a, 1.0, rand1.Next());
                    Z = gamma(b, 1.0, rand1.Next());
                }

                return Y / (Y + Z);
            }
            catch  // probably a math error due to overflow
            {
                return ((mean > rand1.NextDouble()) ? 1.0 : 0.0); 
            }
        }
        
        private double betam(double mean, double sd)
        {
            if (mean <= 0.0) return 0.0;
            if (mean >= 1.0) return 1.0;
            if (sd <= 0.0) return mean;

            double var = sd * sd;
            double vlimit = mean * (1.0 - mean);

            if (var < 0.004 * vlimit) return mean + sd * prandn(); // use normal to avoid overflow problems in beta
//            if (var < 0.04 * vlimit) return mean + sd * prandn(); // use normal to avoid overflow problems in beta

            if (var >= 0.99 * vlimit) // 0.99 to avoid overflow problems
            {
                return ((mean > newRand.NextDouble()) ? 1.0 : 0.0); // if SD too large, return either 0 or 1
            }

            try
            {
                double a = vlimit / var - 1.0;
                double b = (1.0 - mean) * a;
                a *= mean;

                int k1 = (int)a;
                int k2 = (int)b;

                double Y = 1.0;
                double Z = 1.0;

                if (k1 == 0 && k2 == 0)
                {
                    double ia = 1.0 / a;
                    double ib = 1.0 / b;

                    while (Y + Z > 1.0)
                    {
                        Y = Math.Pow(newRand.NextDouble(), ia);
                        Z = Math.Pow(newRand.NextDouble(), ib);
                    }
                }
                else
                {
                    Y = gamma(a, 1.0);
                    Z = gamma(b, 1.0);
                }

                return Y / (Y + Z);
            }
            catch
            {
                return ((mean > newRand.NextDouble()) ? 1.0 : 0.0);
            }
        }

        private double beta(double a, double b, int seed)
        {
            double mean = a / (a + b);
            double var = a * b / ((a + b)*(a + b)*(a + b + 1));
            double sd = Math.Sqrt(var);

            if (mean <= 0.0) return 0.0;
            if (mean >= 1.0) return 1.0;

            double vlimit = mean * (1.0 - mean);

            //            if (var == 0.0) return mean;
//            if (var < 0.04 * vlimit) return mean + sd * prandn(seed); // use normal to avoid overflow problems in beta
            if (var < 0.004 * vlimit) return mean + sd * prandn(seed); // use normal to avoid overflow problems in beta

            Random rand1 = new Random(seed);

            if (var >= 0.99 * vlimit) // 0.99 to avoid overflow problems
            {
                return ((mean > rand1.NextDouble()) ? 1.0 : 0.0); // if SD too large, return either 0 or 1
            }

            try
            {
                int k1 = (int)a;
                int k2 = (int)b;

                double Y = 1.0;
                double Z = 1.0;

                if (k1 == 0 && k2 == 0)
                {
                    double ia = 1.0 / a;
                    double ib = 1.0 / b;

                    while (Y + Z > 1.0)
                    {
                        Y = Math.Pow(rand1.NextDouble(), ia);
                        Z = Math.Pow(rand1.NextDouble(), ib);
                    }
                }
                else
                {
                    Y = gamma(a, 1.0, rand1.Next());
                    Z = gamma(b, 1.0, rand1.Next());
                }

                return Y / (Y + Z);
            }
            catch  // probably a math error due to overflow
            {
                return ((mean > rand1.NextDouble()) ? 1.0 : 0.0);
            }
        }

        private double beta(double a, double b)
        {
            double mean = a / (a + b);
            double var = a * b / ((a + b) * (a + b) * (a + b + 1));
            double sd = Math.Sqrt(var);

            if (mean <= 0.0) return 0.0;
            if (mean >= 1.0) return 1.0;

            double vlimit = mean * (1.0 - mean);

            if (var < 0.004 * vlimit) return mean + sd * prandn(); // use normal to avoid overflow problems in beta
//            if (var < 0.04 * vlimit) return mean + sd * prandn(); // use normal to avoid overflow problems in beta

            if (var >= 0.99 * vlimit) // 0.99 to avoid overflow problems
            {
                return ((mean > newRand.NextDouble()) ? 1.0 : 0.0); // if SD too large, return either 0 or 1
            }

            try
            {
                int k1 = (int)a;
                int k2 = (int)b;

                double Y = 1.0;
                double Z = 1.0;

                if (k1 == 0 && k2 == 0)
                {
                    double ia = 1.0 / a;
                    double ib = 1.0 / b;

                    while (Y + Z > 1.0)
                    {
                        Y = Math.Pow(newRand.NextDouble(), ia);
                        Z = Math.Pow(newRand.NextDouble(), ib);
                    }
                }
                else
                {
                    Y = gamma(a, 1.0);
                    Z = gamma(b, 1.0);
                }

                return Y / (Y + Z);
            }
            catch
            {
                return ((mean > newRand.NextDouble()) ? 1.0 : 0.0);
            }
        }


        // returns the value in dlist that is at the ptile percentile
        private double getPercentile(double ptile, List<double> dlist) 
        {
            if (dlist == null || dlist.Count == 0) return (0.0);

            dlist.Sort();
            double d = ((double)dlist.Count * ptile * 0.01 + 0.9999);
            int place = (int)d;   //((double)dlist.Count * ptile * 0.01 + 0.9999);
            if (place < 1) place = 1;
            if (place > dlist.Count) place = dlist.Count;

            return dlist[place - 1];
        }

        // returns the percentile (rank) of pval in dlist, even if pval is not in dlist
        //private double getPrank2(double pval, List<double> dlist)
        //{
        //    double prank;

        //    if (dlist == null || dlist.Count == 0) return (-1.0);

        //    dlist.Sort();
        //    int ct = dlist.Count;
        //    if (pval < dlist[0]) return(0.0);
        //    if (pval > dlist[ct - 1]) return(100.0);

        //    int i;
        //    for (i = 0; i < dlist.Count; i++) if (pval < dlist[i]) break;
        //    prank = (double)i;
        //    if (pval > dlist[i - 1]) prank += (pval - dlist[i - 1]) / (dlist[i] - dlist[i - 1]); // in between two values
        //    prank -= 0.5;

        //    prank = 100.0 * prank / (double)(dlist.Count);

        //    return prank;
        //}


        // returns the percentile (rank) of pval in dlist, even if pval is not in dlist
        // probably much faster than method above, because doesn't need to sort
        private double getPrank(double pval, List<double> dlist)
        {
            if (dlist == null || dlist.Count == 0) return (-1.0);

            double ct = 0.0;
            for (int i = 0; i < dlist.Count; i++)
            {
                if (pval > dlist[i]) ct += 1.0;
                else if (pval == dlist[i]) ct += 0.5;
            }

            return 100.0 * ct / (double)(dlist.Count);
        }


        //possible var values
        //List<double> vars = new List<double>();
        //List<double> gsvars = new List<double>();
        //List<double> psvars = new List<double>();
        //List<List<double>> ppsvars = new List<List<double>>();
        //List<double> isvars = new List<double>();
        //List<double> specialvars = new List<double>();

        public bool checkEval()
            // do a test run to see if calculations OK
            // note that even a failure of checkEval doesn't necessarily mean that there is a problem. 
            //The math could fail with all variables = 10. (e.g., A/(B-C) is a divide by zero)
        {
//            if (foo[0] == FOOVAR.TIMESERIES) return true;

            try
            {
                List<double> vars = new List<double>();
                List<double> specialvars = new List<double>();
                List<double> gsvars = new List<double>();
                List<double> psvars = new List<double>();
                List<double> isvars = new List<double>();
                List<List<double>> numlist1 = new List<List<double>>();
                List<List<double>> numlist2 = new List<List<double>>();
                List<List<double>> numlist3 = new List<List<double>>();
                List<List<double>> numlist4 = new List<List<double>>();

                List<string> strspecvars = new List<string>();
                List<string> s1vars = new List<string>();
                List<string> s2vars = new List<string>();
                List<string> s3vars = new List<string>();

                int ndex = 0;
                for (int i = 0; i < 26; i++) vars.Add(10.0);
                foreach (FOOVAR fop in foo)
                {
                    if (fop == FOOVAR.KON) ndex++;
                    else if (fop == FOOVAR.VAR)
                    {
                        while (ndx[ndex] >= vars.Count) vars.Add(10.0);
                        ndex++;
                    }
                    else if (fop == FOOVAR.NUMVAR1 || fop == FOOVAR.GSVAR)
                    {
                        while (ndx[ndex] > gsvars.Count) gsvars.Add(10.0);
                        ndex++;
                    }
                    else if (fop == FOOVAR.NUMVAR2 || fop == FOOVAR.PSVAR)
                    {
                        while (ndx[ndex] > psvars.Count) psvars.Add(10.0);
                        ndex++;
                    }
                    else if (fop == FOOVAR.NUMVAR3 || fop == FOOVAR.ISVAR)
                    {
                        while (ndx[ndex] > isvars.Count) isvars.Add(10.0);
                        ndex++;
                    }
                    else if (fop == FOOVAR.SPECIAL)
                    {
                        while (ndx[ndex] >= specialvars.Count) specialvars.Add(10.0);
                        ndex++;
                    }

                    else if (fop == FOOVAR.NUMLISTA)
                    {
                        int dex2 = ndx[ndex++];  // the PSvar
                        while (dex2 > numlist1.Count)
                        {
                            List<double> ppslist = new List<double>();
                            numlist1.Add(ppslist);
                        }
                        while (100 > numlist1[dex2 - 1].Count) // should be plenty?
                        {
                            numlist1[dex2 - 1].Add(10.0);
                        }
                    }

                    //else if (fop == FOOVAR.PPSVAR)
                    //{
                    //    int dex1 = ndx[ndex++];  // the pop
                    //    int dex2 = ndx[ndex++];  // the PSvar
                    //    while (dex2 > ppsvars.Count)
                    //    {
                    //        List<double> ppslist = new List<double>();
                    //        ppsvars.Add(ppslist);
                    //    }
                    //    while (dex1 > ppsvars[dex2 - 1].Count)
                    //    {
                    //        ppsvars[dex2 - 1].Add(10.0);
                    //    }
                    //}

                    else if (fop == FOOVAR.NUMLISTB)
                    {
                        int dex2 = ndx[ndex++];  
                        while (dex2 > numlist2.Count)
                        {
                            List<double> ppslist = new List<double>();
                            numlist2.Add(ppslist);
                        }
                        while (100 > numlist2[dex2 - 1].Count) // should be plenty?
                        {
                            numlist2[dex2 - 1].Add(10.0);
                        }
                    }

                    else if (fop == FOOVAR.NUMLISTC)
                    {
                        //                    int dex1 = ndx[ndex++];  // the pop
                        int dex2 = ndx[ndex++];  // the PSvar
                        while (dex2 > numlist3.Count)
                        {
                            List<double> ppslist = new List<double>();
                            numlist3.Add(ppslist);
                        }
                        while (100 > numlist3[dex2 - 1].Count) // should be plenty?
                        {
                            numlist3[dex2 - 1].Add(10.0);
                        }
                    }

                    else if (fop == FOOVAR.NUMLISTD)
                    {
                        int dex2 = ndx[ndex++]; 
                        while (dex2 > numlist4.Count)
                        {
                            List<double> ppslist = new List<double>();
                            numlist4.Add(ppslist);
                        }
                        while (100 > numlist4[dex2 - 1].Count) // should be plenty?
                        {
                            numlist4[dex2 - 1].Add(10.0);
                        }
                    }

                    else if (fop == FOOVAR.GDIST)
                    {
//                        int dex2 = ndx[ndex++];
                        while (100 > numlist3.Count)
                        {
                            List<double> ppslist = new List<double>();
                            numlist3.Add(ppslist);
                        }
                        for (int i = 0; i < numlist3.Count; i++)
                        {
                            while (100 > numlist3[i].Count) // should be plenty?
                            {
                                numlist3[i].Add(10.0);
                            }
                        }
                    }

                    else if (fop == FOOVAR.LISTA)
                    {
                        int dex2 = ndx[ndex++];
                        while (dex2 > numlist1.Count)
                        {
                            List<double> numslist = new List<double>();
                            numlist1.Add(numslist);
                        }
                        while (5 > numlist1[dex2 - 1].Count)  // 5 is just a test size of the list for checkEval
                        {
                            numlist1[dex2 - 1].Add(10.0);
                        }
                    }

                    else if (fop == FOOVAR.LISTB)
                    {
                        int dex2 = ndx[ndex++];
                        while (dex2 > numlist2.Count)
                        {
                            List<double> numslist = new List<double>();
                            numlist2.Add(numslist);
                        }
                        while (5 > numlist2[dex2 - 1].Count)  // 5 is just a test size of the list for checkEval
                        {
                            numlist2[dex2 - 1].Add(10.0);
                        }
                    }
                    else if (fop == FOOVAR.LISTC)
                    {
                        int dex2 = ndx[ndex++];
                        while (dex2 > numlist3.Count)
                        {
                            List<double> numslist = new List<double>();
                            numlist3.Add(numslist);
                        }
                        while (5 > numlist3[dex2 - 1].Count)  // 5 is just a test size of the list for checkEval
                        {
                            numlist3[dex2 - 1].Add(10.0);
                        }
                    }

                    else if (fop == FOOVAR.LISTD)
                    {
                        int dex2 = ndx[ndex++];
                        while (dex2 > numlist4.Count)
                        {
                            List<double> numslist = new List<double>();
                            numlist4.Add(numslist);
                        }
                        while (5 > numlist4[dex2 - 1].Count)  // 5 is just a test size of the list for checkEval
                        {
                            numlist4[dex2 - 1].Add(10.0);
                        }
                    }

                    else if (fop == FOOVAR.STRVAR1)
                    {
                        while (ndx[ndex] > s1vars.Count) s1vars.Add("STRING1");
                        ndex++;
                    }
                    else if (fop == FOOVAR.STRVAR2)
                    {
                        while (ndx[ndex] > s2vars.Count) s2vars.Add("STRING2");
                        ndex++;
                    }
                    else if (fop == FOOVAR.STRVAR3)
                    {
                        while (ndx[ndex] > s3vars.Count) s3vars.Add("STRING3");
                        ndex++;
                    }
                    else if (fop == FOOVAR.STRSPECVAR)
                    {
                        while (ndx[ndex] >= strspecvars.Count) strspecvars.Add("SPECIALSTRING");
                        ndex++;
                    }
                }

                doStringEval(vars, specialvars, gsvars, psvars, isvars, numlist1, numlist2, numlist3, numlist4, strspecvars, s1vars, s2vars, s3vars);
            }

            catch
            { // what happens if doEval catches an error condition?
                return false;
            }

            return true;
        }

        // versions with no string vars
        private object doEvil(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, List<List<double>> n2dvars,
             List<List<double>> list1vars, List<List<double>> list2vars, List<List<double>> list3vars)
        {
            return doEvil(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, list1vars, list2vars, list3vars, null, null, null, null); 
        }

        private object doEvil(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, List<List<double>> n2dvars,
             List<List<double>> list1vars, List<List<double>> list2vars)
        {
            return doEvil(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, list1vars, list2vars, null, null, null, null, null); 
        }

        private object doEvil(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, List<List<double>> n2dvars,
             List<List<double>> list1vars)
        {
            return doEvil(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, list1vars, null, null, null, null, null, null); 
        }

        private object doEvil(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, List<List<double>> n2dvars)
        {
            return doEvil(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, null, null, null, null, null, null, null); 
        }

        // prior full version, before 3 Lists added
        private object doEvil(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, List<List<double>> n2dvars,
             string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            return doEvil(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, null, null, null, specstrvars, s1vars, s2vars, s3vars); 
        }


        // full version! with everything including the kitchen sink
            // keep n2dvars as a List so can manipulate it with list operations
        private object doEvil(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, List<List<double>> n2dvars,
             List<List<double>> list2vars, List<List<double>> list3vars, List<List<double>> list4vars,
            string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            Stack<double>opstack = new Stack<double>();
            Stack<string>strstack = new Stack<string>();
            int indx = 0;
            double op1, op2, op3;
            string str1, str2;
            int i1;

//            if (foo.Count == 0) Translate(); // in case not yet translated

            try
            {
                //if(foo.Count == 1 && foo[0] == FOOVAR.KON) return(kon[0].ToString());
                //if(foo.Count == 1 && foo[0] == FOOVAR.STRKON) return (strkon[0]);

                for(int ifoo = 0; ifoo < foo.Count; ifoo++)
                {
                    FOOVAR fop = foo[ifoo];

                    switch (fop)
                    {
                        case FOOVAR.VAR:
                            try
                            {
                                op1 = vars[ndx[indx++]];
                            }
                            catch
                            {
                                op1 = 0.0;
//                                throw new Exception("Evaluator.Missing variable value for: " + mFuncStr);
                            }
                            opstack.Push(op1);
                            break;

                        case FOOVAR.KON:
                            opstack.Push(kon[ndx[indx++]]);
                            break;

                        case FOOVAR.SPECIAL:
                            try
                            {
                                op1 = specialvars[ndx[indx++]];
                            }
                            catch
                            {
                                op1 = 0.0;
//                                throw new Exception("Evaluator.Missing Special var value for: " + mFuncStr);
                            }

                            opstack.Push(op1);
                            break;

                // note: GSx, PSx, ISx labels were all 1-based
                        case FOOVAR.GSVAR:
                        case FOOVAR.NUMVAR1:
                            try
                            {
                                op1 = n1vars[ndx[indx++] - 1];
                            }
                            catch
                            {
                                op1 = 0.0;
//                                throw new Exception("Evaluator.Missing Var value in: " + mFuncStr);
                            }

                            opstack.Push(op1);
                            break;

                        case FOOVAR.PSVAR:
                        case FOOVAR.NUMVAR2:
                            try
                            {
                                op1 = n2vars[ndx[indx++] - 1];
                            }
                            catch 
                            {
                                op1 = 0.0;
//                                throw new Exception("Evaluator.Missing Var value in: " + mFuncStr);
                            }
                            opstack.Push(op1);
                            break;

                        case FOOVAR.ISVAR:
                        case FOOVAR.NUMVAR3:
                            try
                            {
                                op1 = n3vars[ndx[indx++] - 1];
                            }
                            catch
                            {
                                op1 = 0.0;
//                                throw new Exception("Evaluator.Missing Var value in: " + mFuncStr);
                            }

                            opstack.Push(op1);
                            break;

                        case FOOVAR.NUMLISTA:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // popn; 
//                                op1 = n2dvars[ndx[indx] - 1][i1];
                                int i5 = ndx[indx] - 1; // which list
                                if (i5 >= n2dvars.Count || i1 >= n2dvars[i5].Count) op1 = 0.0;
                                else op1 = n2dvars[i5][i1];
                            }
                            catch
                            {
                                op1 = 0.0; 
                            }

                            opstack.Push(op1);
                            indx++;
                            break;

                        case FOOVAR.NUMLISTB:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // which element
                                int i5 = ndx[indx] - 1; // which list
                                if (i5 >= list2vars.Count || i1 >= list2vars[i5].Count) op1 = 0.0;
                                else op1 = list2vars[i5][i1];
                            }
                            catch
                            {
                                op1 = 0.0; // list didn't exist or didn't have the requested element
                            }

                            opstack.Push(op1);
                            indx++;
                            break;

                        case FOOVAR.NUMLISTC:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // which element
                                int i5 = ndx[indx] - 1; // which list
                                if (i5 >= list3vars.Count || i1 >= list3vars[i5].Count) op1 = 0.0;
                                else op1 = list3vars[i5][i1];
                            }
                            catch
                            {
                                op1 = 0.0; 
                            }

                            opstack.Push(op1);
                            indx++;
                            break;

                        case FOOVAR.NUMLISTD:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // which element
                                int i5 = ndx[indx] - 1; // which list
                                if (i5 >= list4vars.Count || i1 >= list4vars[i5].Count) op1 = 0.0;
                                else op1 = list4vars[i5][i1];
                            }
                            catch
                            {
                                op1 = 0.0; 
                            }

                            opstack.Push(op1);
                            indx++;
                            break;

                        case FOOVAR.GDIST:
                            try
                            {
                                int i5 = (int)Math.Round(opstack.Pop()); // pstates
                                i1 = (int)Math.Round(opstack.Pop()); // 2nd param
                                i5 += (int)Math.Round(opstack.Pop()); // 1st param
                                if (i5 > list3vars.Count || i1 > list3vars[i5 - 1].Count) op1 = 0.0;
                                else op1 = list3vars[i5 - 1][i1 - 1];

                                //int i5 = ndx[indx] - 1; // pstates
                                //i1 = (int)Math.Round(opstack.Pop()); // 2nd param
                                //i5 += (int)Math.Round(opstack.Pop()); // 1st param
                                //if (i5 >= list3vars.Count || i1 >= list3vars[i5].Count) op1 = 0.0;
                                //else op1 = list3vars[i5][i1];
                            }
                            catch
                            {
                                op1 = 0.0;
                            }

                            opstack.Push(op1);
//                            indx++;       // removed 16 Sept 2016
                            break;

                        case FOOVAR.PLUS:
                            opstack.Push(opstack.Pop() + opstack.Pop());
                            break;

                        case FOOVAR.MINUS:
                            op1 = opstack.Pop();
                            op2 = opstack.Pop();
                            opstack.Push(op2 - op1);
                            break;

                        case FOOVAR.MULTIPLY:
                            opstack.Push(opstack.Pop() * opstack.Pop());
                            break;

                        case FOOVAR.DIVIDE:
                            op1 = opstack.Pop();
                            op2 = opstack.Pop();
                            try
                            {
                                opstack.Push(op2 / op1);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Divide by zero in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.NEG:
                            opstack.Push(-opstack.Pop());
                            break;

                        case FOOVAR.AND:
                            op1 = opstack.Pop();
                            op2 = opstack.Pop();
                            if ((op1 != 0) && (op2 != 0)) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.OR:
                            op1 = opstack.Pop();
                            op2 = opstack.Pop();
                            if ((op1 != 0) || (op2 != 0)) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.COMPARE:
                            op1 = opstack.Pop();
                            op2 = opstack.Pop();
                            if (op1 > op2) opstack.Push(-1.0);
                            else if (op1 < op2) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.EQUALS:
                            if (opstack.Pop() == opstack.Pop()) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.NOTEQUAL:
                            if (opstack.Pop() != opstack.Pop()) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.GREATEROREQUAL: // note: second operand comes off of the stack first
                            if (opstack.Pop() <= opstack.Pop()) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.GREATERTHAN:
                            if (opstack.Pop() < opstack.Pop()) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.LESSOREQUAL:
                            if (opstack.Pop() >= opstack.Pop()) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.LESSTHAN:
                            if (opstack.Pop() > opstack.Pop()) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.NOT:
                            if (opstack.Pop() == 0.0) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.NAND:
                            op1 = opstack.Pop();
                            op2 = opstack.Pop();
                            if(!(op1 != 0 && op2 != 0)) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.NOR:
                            op1 = opstack.Pop();
                            op2 = opstack.Pop();
                            if (!(op1 != 0 || op2 != 0)) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.IF:
                            op1 = opstack.Pop();
                            op2 = opstack.Pop();
                            op3 = opstack.Pop();

                            if (op3 == 0) opstack.Push(op1);
                            else opstack.Push(op2);
                            break;

                        case FOOVAR.SEQUENCE:
                            op1 = opstack.Pop();
                            op2 = opstack.Pop();
                            op3 = opstack.Pop();

                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                            i1 = 0;
                            for (double dseq = op3; dseq <= op2; dseq += op1)
                            {
                                opstack.Push(dseq);
                                i1++;
                            }

                            opstack.Push((double)i1);

                            break;

                        case FOOVAR.COUNT:
                            double dct = Math.Round(opstack.Pop());
                            for (int i = 0; i < dct; i++) opstack.Pop();
                            opstack.Push(dct);

                            break;

                        case FOOVAR.LOOKUP:
                            try
                            {
                                i1 = (int) Math.Round(opstack.Pop()); // list ct
                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // note: list is in reverse order now
                                int i2 = (int) Math.Round(opstack.Pop()); // item
                                if (i2 < 1) i2 = 1;  // 12 June 2017 was setting min to 0  
                                else if (i2 > i1) i2 = i1;
                                opstack.Push(oplist[i1 - i2]);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid LOOKUP in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.FIND:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // note: list is in reverse order now
                                double dd = opstack.Pop(); // search item
                                
                                int ip;
                                for (ip = i1 - 1; ip >= 0; ip--) if (oplist[ip] == dd) break;

                                if (ip >= 0) opstack.Push((double)(i1 - ip));
                                else opstack.Push(0.0);

                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid FIND in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.SAMPLE: 
                            try
                            {
                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                i1 = (int)Math.Round(opstack.Pop()); // list ct;
                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // note: list is in reverse order now
                                int i2 = (int)Math.Round(opstack.Pop()); // number to pick
                                if (i2 < 0) i2 = 0;
                                else if (i2 > i1) i2 = i1;

                                for (int i4 = 0; i4 < i2; i4++)
                                {
                                    int i3 = newRand.Next(i1);
                                    opstack.Push(oplist[i3]);
                                    oplist.RemoveAt(i3);
                                    i1--;
                                }

                                opstack.Push((double)i2); // new list count
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid SAMPLE in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.SSAMPLE:
                            try
                            {
                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                i1 = (int)Math.Round(opstack.Pop()); // list ct;
                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // note: list is in reverse order now
                                int i2 = (int)Math.Round(opstack.Pop()); // number of items to pick
                                if (i2 < 0) i2 = 0;
                                else if (i2 > i1) i2 = i1;

                                Random srands = new Random(adjustSeed(opstack.Pop()));

                                for(int i4 = 0; i4 < i2; i4++)
                                {
                                    int i3 = srands.Next(i1);
                                    opstack.Push(oplist[i3]);
                                    oplist.RemoveAt(i3);
                                    i1--;
                                }

                                opstack.Push((double)i2); // new list count
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid SSAMPLE in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.PREPEND:
                            try
                            {
                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                i1 = (int)Math.Round(opstack.Pop()); // old list ct;

                                opstack.Push((double)(i1 + 1));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid PREPEND in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.APPEND:
                            try
                            {
                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                i1 = (int)Math.Round(opstack.Pop()); // old list ct;

                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop());

                                double dval = opstack.Pop(); // number to append

                                for (int lct = oplist.Count - 1; lct >= 0; lct--) opstack.Push(oplist[lct]);

                                opstack.Push(dval);
                                opstack.Push((double)(i1 + 1));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid APPEND in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.INSERT:
                            try
                            {
                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                i1 = (int)Math.Round(opstack.Pop()); // list ct;
                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop());

                                int pl = -1 + (int)Math.Round(opstack.Pop()); // place to insert, 0-based
                                double dval = opstack.Pop(); // number to insert

                                if (pl < 0) pl = 0;
                                if (pl > i1) pl = i1;

                                pl = i1 - pl; // place to insert, in reverse order list
                                if (pl == i1) opstack.Push(dval);

                                for (int lct = oplist.Count - 1; lct >= 0; lct--) // push in reverse order that they were popped
                                {
                                    opstack.Push(oplist[lct]);
                                    if (lct == pl) opstack.Push(dval);
                                }

                                opstack.Push((double)(i1 + 1)); // new list count
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid INSERT in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.REMOVEAT:
                            try
                            {
                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                i1 = (int)Math.Round(opstack.Pop()); // old list ct;
                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // in reverse order now

                                int pl = i1 - (int)Math.Round(opstack.Pop()); // place to remove, in reverse order list

                                if (pl >= 0 && pl < i1) i1--;  // new list count; don't adjust if place was out of range

                                for (int lct = oplist.Count - 1; lct >= 0; lct--) // push in reverse order that they were popped
                                {
                                    if (lct == pl) continue;
                                    opstack.Push(oplist[lct]);
                                }

                                opstack.Push((double)i1); // new list count
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REMOVEAT in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.REMOVE:
                            try
                            {
                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                i1 = (int)Math.Round(opstack.Pop()); // old list ct;
                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // in reverse order now

                                double rem = opstack.Pop(); // val to remove
                                bool remflag = true; // still searching?

                                for (int lct = oplist.Count - 1; lct >= 0; lct--) // push in reverse order that they were popped
                                {
                                    if (remflag && oplist[lct] == rem) { i1--; remflag = false; continue;}
                                    opstack.Push(oplist[lct]);
                                }

                                opstack.Push((double)i1); // new list count
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REMOVE in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.REMOVEALL:
                            try
                            {
                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                i1 = (int)Math.Round(opstack.Pop()); // old list ct;
                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // in reverse order now

                                double rem = opstack.Pop(); // val to remove

                                for (int lct = oplist.Count - 1; lct >= 0; lct--) // push in reverse order that they were popped
                                {
                                    if (oplist[lct] == rem) { i1--; continue; }
                                    opstack.Push(oplist[lct]);
                                }

                                opstack.Push((double)i1); // new list count
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REMOVEALL in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.TIMESERIES:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // note: list is in reverse order now
                                int i2 = (int)vars['Y' - 'A'];
                                if (i2 < 0) i2 = 0;
                                else if (i2 > i1) i2 = i1;
                                opstack.Push(oplist[i1 - i2]);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid TIMESERIES in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.CHOOSE:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // note: list is in reverse order now
                                int i2 = newRand.Next(i1);
                                opstack.Push(oplist[i2]);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid CHOOSE in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.SCHOOSE:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // note: list is in reverse order now

                                Random srands = new Random(adjustSeed(opstack.Pop()));
                                int i2 = srands.Next(i1);
                                opstack.Push(oplist[i2]);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid SCHOOSE in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.MAX:
                            opstack.Push(Math.Max(opstack.Pop(),opstack.Pop()));
                            break;

                        case FOOVAR.MIN:
                            opstack.Push(Math.Min(opstack.Pop(), opstack.Pop()));
                            break;

                        case FOOVAR.HIGH:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                double high = opstack.Pop();
                                for (int lct = 1; lct < i1; lct++)
                                {
                                    high = Math.Max(high, opstack.Pop());
                                }
                                opstack.Push(high);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid HIGH in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.LOW:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                double low = opstack.Pop();
                                for (int lct = 1; lct < i1; lct++)
                                {
                                    low = Math.Min(low, opstack.Pop());
                                }
                                opstack.Push(low);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid LOW in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.MEAN:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                double mean = opstack.Pop();
                                for (int lct = 1; lct < i1; lct++)
                                {
                                    mean += opstack.Pop();
                                }
                                opstack.Push(mean / (double) i1);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid MEAN in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.SUM:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                double sum = opstack.Pop();
                                for (int lct = 1; lct < i1; lct++)
                                {
                                    sum += opstack.Pop();
                                }
                                opstack.Push(sum);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid SUM in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.MAKELIST: 
                            try
                            {
                                //i1 = (int)Math.Round(opstack.Pop()); // list ct
                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                //List<double> dsort = new List<double>();

                                //for (int lct = 0; lct < i1; lct++)
                                //{
                                //    dsort.Add(opstack.Pop());
                                //}
                                //foreach (double dd in dsort) opstack.Push(dd);
                                //opstack.Push((double)i1);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid MAKELIST in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.SORT:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                List<double> dsort = new List<double>();

                                for (int lct = 0; lct < i1; lct++)
                                {
                                    dsort.Add(opstack.Pop());
                                }
                                dsort.Sort();
                                foreach(double dd in dsort) opstack.Push(dd);
                                opstack.Push((double)i1);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid SORT in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.SORTREV:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                List<double> dsort = new List<double>();

                                for (int lct = 0; lct < i1; lct++)
                                {
                                    dsort.Add(opstack.Pop());
                                }
                                dsort.Sort();
                                for(int lct = i1 - 1; lct >= 0; lct--) opstack.Push(dsort[lct]);
                                opstack.Push((double)i1);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid SORTREV in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.REVERSE:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                List<double> dsort = new List<double>();

                                for (int lct = 0; lct < i1; lct++)
                                {
                                    dsort.Add(opstack.Pop());
                                }
                                for (int lct = 0; lct < i1; lct++) opstack.Push(dsort[lct]);
                                opstack.Push((double)i1);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid SORT in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.PERCENTILE:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // note: list is in reverse order now

                                double dvar = opstack.Pop();

                                opstack.Push(getPercentile(dvar,oplist));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid PERCENTILE in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.PRANK:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // note: list is in reverse order now

                                double dvar = opstack.Pop();

                                opstack.Push(getPrank(dvar, oplist));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid PERCENTILERANK in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.LISTA:
                            try
                            {
                                int ilist = ndx[indx++] - 1;

                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                // 21 June 2017  -- in case there is no list! make a list of {-1}
                                if (n2dvars[ilist] == null || n2dvars[ilist].Count < 1)
                                {
                                    opstack.Push(-1.0);
                                    opstack.Push(1.0);
                                }
                                else {
                                    foreach (double dd in n2dvars[ilist])
                                    {
                                        opstack.Push(dd);
                                    }
                                    opstack.Push(n2dvars[ilist].Count); // put real count back in 
                                }
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid LIST in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.LISTB:
                            try
                            {
                                int ilist = ndx[indx++] - 1;

                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                // 21 June 2017  -- in case there is no list! make a list of {-1}
                                if (list2vars[ilist] == null || list2vars[ilist].Count < 1)
                                {
                                    opstack.Push(-1.0);
                                    opstack.Push(1.0);
                                }
                                else {
                                    foreach (double dd in list2vars[ilist])
                                    {
                                        opstack.Push(dd);
                                    }
                                    opstack.Push(list2vars[ilist].Count); // put real count back in 
                                }
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid LIST in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.LISTC:
                            try
                            {
                                int ilist = ndx[indx++] - 1;

                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                // 21 June 2017  -- in case there is no list! make a list of {-1}
                                if (list3vars[ilist] == null || list3vars[ilist].Count < 1)
                                {
                                    opstack.Push(-1.0);
                                    opstack.Push(1.0);
                                }
                                else {
                                    foreach (double dd in list3vars[ilist])
                                    {
                                        opstack.Push(dd);
                                    }
                                    opstack.Push(list3vars[ilist].Count); // put real count back in 
                                }
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid LIST in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.LISTD:
                            try
                            {
                                int ilist = ndx[indx++] - 1;

                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo

                                // 12 June 2017  -- in case there is no list! make a list of {-1}
                                if (list4vars[ilist] == null || list4vars[ilist].Count < 1)
                                {
                                    opstack.Push(-1.0);
                                    opstack.Push(1.0);
                                }
                                else {
                                    foreach (double dd in list4vars[ilist])
                                    {
                                        opstack.Push(dd);
                                    }
                                    opstack.Push(list4vars[ilist].Count); // put real count back in 
                                }
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid LIST in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.RETURNLIST:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct

                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // note: list is in reverse order now

                                i1 = (int)Math.Round(opstack.Pop()); // now, List n
                                while(n2dvars.Count < i1) n2dvars.Add(new List<double>());
                                i1--; // 0-based
                                n2dvars[i1].Clear();

                                for (int lct = oplist.Count - 1; lct >= 0; lct--)
                                {
                                    n2dvars[i1].Add(oplist[lct]);
                                }

                                opstack.Push(oplist.Count); // return ct 
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid RETURNLIST in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.SUBSET:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct

                                List<double> oplist = new List<double>();
                                for (int lct = 0; lct < i1; lct++) oplist.Add(opstack.Pop()); // note: list is in reverse order now

                                int nd = (int)Math.Round(opstack.Pop());
                                int strt = (int)Math.Round(opstack.Pop());
                                if (strt < 1) strt = 1;
                                if (strt > i1) strt = i1;
                                if (nd > i1) nd = i1;
                                if (nd < strt) nd = strt;

                                for(int lct = i1 - strt; lct >= i1 - nd; lct--) opstack.Push(oplist[lct]);

                                opstack.Push(1 + nd - strt); // put new count back in 
                                indx++; // skip over count of 1 from surrounding function
                                ifoo++; // skip over KON foo
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid SUBSET in: " + mFuncStr);
                            }

                            break;

                        case FOOVAR.PRODUCT: 
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                double sum = opstack.Pop();
                                for (int lct = 1; lct < i1; lct++)
                                {
                                    sum *= opstack.Pop();
                                }
                                opstack.Push(sum);
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid PRODUCT in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.MEDIAN:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                List<double> medianList = new List<double>();
                                for (int lct = 0; lct < i1; lct++)
                                {
                                    medianList.Add(opstack.Pop());
                                }
                                medianList.Sort();
                                int i2 = i1 / 2;
                                if (i1 % 2 == 1)
                                {
                                    opstack.Push(medianList[i2]); // remember list is 0-based
                                }
                                else
                                {
                                    opstack.Push(0.5*(medianList[i2-1] + medianList[i2]));
                                }
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid MEDIAN in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.SQRT:
                            opstack.Push(Math.Sqrt(opstack.Pop()));
                            break;

                        case FOOVAR.EXP:
                            opstack.Push(Math.Exp(opstack.Pop()));
                            break;

                        case FOOVAR.LN:
                            opstack.Push(Math.Log(opstack.Pop()));
                            break;

                        case FOOVAR.LOG10:
                            opstack.Push(Math.Log10(opstack.Pop()));
                            break;

                        case FOOVAR.POW:
                            op1 = opstack.Pop();
                            op2 = opstack.Pop();
                            opstack.Push(Math.Pow(op2,op1));
                            break;

                        case FOOVAR.ABS:
                            opstack.Push(Math.Abs(opstack.Pop()));
                            break;

                        case FOOVAR.MOD:
                            op1 = opstack.Pop();
                            op2 = opstack.Pop();
                            opstack.Push(op2 % op1);
                            break;

                        case FOOVAR.RAND:
                            opstack.Push(newRand.NextDouble());
                            break;

                        case FOOVAR.SRAND:
                            Random srands4 = new Random(adjustSeed(opstack.Pop()));
                            opstack.Push(srands4.NextDouble());
                            break;

                        case FOOVAR.NRAND:
                            opstack.Push(prandn());
                            break;

                        case FOOVAR.SNRAND:
                            opstack.Push(prandn(adjustSeed(opstack.Pop())));
                            break;

                        case FOOVAR.POISSON:
                            opstack.Push((double)getPoisson(opstack.Pop()));
                            break;

                        case FOOVAR.SPOISSON1:
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push((double)getPoisson1(op1,adjustSeed(op2)));
                            break;

                        case FOOVAR.POISSON1:
                            opstack.Push((double)getPoisson1(opstack.Pop()));
                            break;

                        case FOOVAR.SPOISSON:
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push((double)getPoisson(op1, adjustSeed(op2)));
                            break;

                        case FOOVAR.SDECAY:
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push((double)sdecay(op1, adjustSeed(op2)));
                            break;

                        case FOOVAR.DECAY:
                            op1 = opstack.Pop();
                            opstack.Push((double)decay(op1));
                            break;

                        case FOOVAR.UNIFORM:
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(getUniform(op1,op2));
                            break;

                        case FOOVAR.IUNIFORM:
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push((double)getUniformInt((int)op1, (int)op2));
                            break;

                        case FOOVAR.SUNIFORM:
                            op3 = opstack.Pop();
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(getUniform(op1, op2, adjustSeed(op3)));
                            break;

                        case FOOVAR.SIUNIFORM:
                            op3 = opstack.Pop();
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push((double)getUniformInt((int)op1, (int)op2, adjustSeed(op3)));
                            break;

                        case FOOVAR.BINOMIALN:
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(binomn(op1, (int)op2));
                            break;

                        case FOOVAR.SBINOMIALN:
                            op3 = opstack.Pop();
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(sbinomn(op1, (int)op2, adjustSeed(op3)));
                            break;

                        case FOOVAR.BINOMIALP:
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(binomp(op1, (int)op2));
                            break;

                        case FOOVAR.SBINOMIALP:
                            op3 = opstack.Pop();
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(sbinomp(op1, (int)op2, adjustSeed(op3)));
                            break;

                        case FOOVAR.BETA:
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(beta(op1, op2));
                            break;

                        case FOOVAR.SBETA:
                            op3 = opstack.Pop();
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(beta(op1, op2, adjustSeed(op3)));
                            break;

                        case FOOVAR.BETAM:
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(betam(op1, op2));
                            break;

                        case FOOVAR.SBETAM:
                            op3 = opstack.Pop();
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(betam(op1, op2, adjustSeed(op3)));
                            break;

                        case FOOVAR.GAMMA:
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(gamma(op1, op2));
                            break;

                        case FOOVAR.SGAMMA:
                            op3 = opstack.Pop();
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(gamma(op1, op2, adjustSeed(op3)));
                            break;

                        case FOOVAR.GAMMAM:
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(gammam(op1, op2));
                            break;

                        case FOOVAR.SGAMMAM:
                            op3 = opstack.Pop();
                            op2 = opstack.Pop();
                            op1 = opstack.Pop();
                            opstack.Push(gammam(op1, op2, adjustSeed(op3)));
                            break;

                        case FOOVAR.ROUND:
                            opstack.Push(Math.Round(opstack.Pop()));
                            break;

                        case FOOVAR.PROUND: // probabilistic rounding
                            op1 = opstack.Pop();
                            int iop = (int) op1;
                            op2 = op1 - (double)iop;
                            if(op2 > 0.00001 && newRand.NextDouble() < op2) iop++;
                            opstack.Push((double)iop);
                            break;

                        case FOOVAR.CEIL:
                            opstack.Push(Math.Ceiling(opstack.Pop()));
                            break;

                        case FOOVAR.FLOOR:
                            opstack.Push(Math.Floor(opstack.Pop()));
                            break;

                        case FOOVAR.SIN:
                            opstack.Push(Math.Sin(opstack.Pop()));
                            break;

                        case FOOVAR.COS:
                            opstack.Push(Math.Cos(opstack.Pop()));
                            break;

                        case FOOVAR.TAN:
                            opstack.Push(Math.Tan(opstack.Pop()));
                            break;

                        case FOOVAR.ASIN:
                            opstack.Push(Math.Asin(opstack.Pop()));
                            break;

                        case FOOVAR.ATAN:
                            opstack.Push(Math.Atan(opstack.Pop()));
                            break;

                        case FOOVAR.ACOS:
                            opstack.Push(Math.Acos(opstack.Pop()));
                            break;

                        case FOOVAR.TANH:
                            opstack.Push(Math.Tanh(opstack.Pop()));
                            break;

                        case FOOVAR.COSH:
                            opstack.Push(Math.Cosh(opstack.Pop()));
                            break;

                        case FOOVAR.SINH:
                            opstack.Push(Math.Sinh(opstack.Pop()));
                            break;

                        case FOOVAR.DEGREES:
                            opstack.Push(180.0 * opstack.Pop() / Math.PI);
                            break;

                        case FOOVAR.RADIANS:
                            opstack.Push(Math.PI * opstack.Pop() / 180.0);
                            break;

                        // string functions
                        case FOOVAR.STRKON:
                            strstack.Push(strkon[ndx[indx++]]);
                            break;

                        case FOOVAR.STRSPECVAR:
                            try
                            {
                                str1 = strspecials[ndx[indx++]].Replace(" ","");
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Missing Special var value for: " + mFuncStr);
                            }
                            strstack.Push(str1);
                            break;

                        case FOOVAR.STRVAR1:
                            try
                            {
                                str1 = s1vars[ndx[indx++] - 1].Replace(" ", "");
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Missing Var value in: " + mFuncStr);
                            }
                            strstack.Push(str1);
                            break;

                        case FOOVAR.STRVAR2:
                            try
                            {
                                str1 = s2vars[ndx[indx++] - 1].Replace(" ", "");
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Missing Var value in: " + mFuncStr);
                            }
                            strstack.Push(str1);
                            break;

                        case FOOVAR.STRVAR3:
                            try
                            {
                                str1 = s3vars[ndx[indx++] - 1].Replace(" ", "");
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Missing Var value in: " + mFuncStr);
                            }
                            strstack.Push(str1);
                            break;

                        case FOOVAR.STRLENGTH:
                            str1 = strstack.Pop();
                            opstack.Push(str1.Length);
                            break;

                        case FOOVAR.STRCOMP:
                            str2 = strstack.Pop();
                            str1 = strstack.Pop(); // note: second param pops off first
                            i1 = str1.CompareTo(str2); // just what does this return?
                            opstack.Push((double) i1);
                            break;

                        case FOOVAR.STRCONTAINS:
                            str2 = strstack.Pop();
                            str1 = strstack.Pop();
                            if (str1.Contains(str2)) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.STRCAT:
                            str2 = strstack.Pop();
                            str1 = strstack.Pop();
                            strstack.Push(str1 + str2);
                            break;

                        //case FOOVAR.LTRIM:
                        //    str1 = strstack.Pop();
                        //    strstack.Push(str1.TrimStart(' '));
                        //    break;

                        //case FOOVAR.RTRIM:
                        //    str1 = strstack.Pop();
                        //    strstack.Push(str1.TrimEnd(' '));
                        //    break;

                        //case FOOVAR.TRIM:
                        //    str1 = strstack.Pop();
                        //    strstack.Push(str1.Trim());
                        //    break;

                        case FOOVAR.RIGHT:
                            str1 = strstack.Pop();
                            op1 = opstack.Pop();
                            i1 = str1.Length - (int) op1;
                            strstack.Push(str1.Remove(0,i1));
                            break;

                        case FOOVAR.LEFT:
                            str1 = strstack.Pop();
                            op1 = opstack.Pop();
                            i1 = (int)op1;
                            strstack.Push(str1.Remove(i1));
                            break;

                        case FOOVAR.STARTSWITH:
                            str2 = strstack.Pop();
                            str1 = strstack.Pop();
                            if (str1.StartsWith(str2)) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.ENDSWITH:
                            str2 = strstack.Pop();
                            str1 = strstack.Pop();
                            if (str1.EndsWith(str2)) opstack.Push(1.0);
                            else opstack.Push(0.0);
                            break;

                        case FOOVAR.TONUM:
                            str1 = strstack.Pop();
                            op1 = Convert.ToDouble(str1);
                            opstack.Push(op1);
                            break;

                        case FOOVAR.TOSTRING:
                            op1 = opstack.Pop();
                            str1 = op1.ToString();
                            strstack.Push(str1);
                            break;


// stuff for R scripts // TODO test!
                        case FOOVAR.REVALVALS:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                string rstring = strstack.Pop();

                                List<double> rvals = new List<double>();
                                for (int lct = 0; lct < i1; lct++) // note reversed order of list when popped
                                {
                                    rvals.Add(opstack.Pop()); 
                                }
                                rvals.Reverse(); // fixes the order

                                opstack.Push(R.Reval(rstring, rvals));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REVALVALS in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.REVAL:
                            try
                            {
                                string rstring = strstack.Pop();
                                opstack.Push(R.Reval(rstring, false));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REVAL in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.REVALVARS:
                            try
                            {
                                makeVarLabels(vars.Length);
                                string rstring = strstack.Pop();
                                opstack.Push(R.Reval(rstring, VarLabels, vars));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REVALVARS in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.REVALGS:
                            try
                            {
                                makeVarLabels(vars.Length);
                                makeGSvarLists(n1vars.Length);
                                string rstring = strstack.Pop();
                                opstack.Push(R.Reval(rstring, GSsyns, VarLabels, n1vars, vars));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REVALGS in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.REVALPS:
                            try
                            {
                                makeVarLabels(vars.Length);
                                makeGSvarLists(n1vars.Length);
                                makePSvarLists(n2vars.Length);
                                string rstring = strstack.Pop();
                                opstack.Push(R.Reval(rstring, GSsyns, PSsyns, VarLabels, n1vars, n2vars, vars));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REVALPS in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.REVALIS:
                            try
                            {
                                makeVarLabels(vars.Length);
                                makeGSvarLists(n1vars.Length);
                                makePSvarLists(n2vars.Length);
                                makeISvarLists(n3vars.Length);
                                string rstring = strstack.Pop();
                                opstack.Push(R.Reval(rstring, GSsyns, PSsyns, ISsyns, VarLabels, n1vars, n2vars, n3vars, vars));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REVALIS in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.REVALVALSN:
                            try
                            {
                                i1 = (int)Math.Round(opstack.Pop()); // list ct
                                string rstring = strstack.Pop();

                                List<double> rvals = new List<double>();
                                for (int lct = 0; lct < i1; lct++) // note reversed order of list when popped
                                {
                                    rvals.Add(opstack.Pop());
                                }
                                rvals.Reverse(); // fixes the order

                                opstack.Push(R.RevalN(rstring, rvals));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REVALVALS in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.REVALN:
                            try
                            {
                                string rstring = strstack.Pop();
                                opstack.Push(R.RevalN(rstring));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REVALN in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.REVALVARSN:
                            try
                            {
                                makeVarLabels(vars.Length);
                                string rstring = strstack.Pop();
                                opstack.Push(R.RevalN(rstring, VarLabels, vars));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REVALVARSN in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.REVALGSN:
                            try
                            {
                                makeVarLabels(vars.Length);
                                makeGSvarLists(n1vars.Length);
                                string rstring = strstack.Pop();
                                opstack.Push(R.RevalN(rstring, GSsyns, VarLabels, n1vars, vars));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REVALGSN in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.REVALPSN:
                            try
                            {
                                makeVarLabels(vars.Length);
                                makeGSvarLists(n1vars.Length);
                                makePSvarLists(n2vars.Length);
                                string rstring = strstack.Pop();
                                opstack.Push(R.RevalN(rstring, GSsyns, PSsyns, VarLabels, n1vars, n2vars, vars));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REVALPSN in: " + mFuncStr);
                            }
                            break;

                        case FOOVAR.REVALISN:
                            try
                            {
                                makeVarLabels(vars.Length);
                                makeGSvarLists(n1vars.Length);
                                makePSvarLists(n2vars.Length);
                                makeISvarLists(n3vars.Length);
                                string rstring = strstack.Pop();
                                opstack.Push(R.RevalN(rstring, GSsyns, PSsyns, ISsyns, VarLabels, n1vars, n2vars, n3vars, vars));
                            }
                            catch
                            {
                                throw new Exception("Evaluator.Invalid REVALISN in: " + mFuncStr);
                            }
                            break;


                        default:
                            throw new Exception("Evaluator.UnrecognizedFunction");
                            
                    }
                }
            }
            catch
            {
                throw new Exception("Evaluator.UnableToEvaluateFunction " + mFuncStr);
            }

            if (opstack.Count == 1)
            {
                return opstack.Pop();
            }
            else if (strstack.Count != 1)
            {
                throw new Exception("Evaluator.ImproperNesting");
            }

            return strstack.Pop();
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars,
            List<List<double>> n2dvars, List<List<double>> list2vars, List<List<double>> list3vars, List<List<double>> list4vars,
            List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            if (foo.Count == 0) Translate(); // in case not yet translated
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return (kon[0].ToString());
            if (foo.Count == 1 && foo[0] == FOOVAR.STRKON) return (strkon[0]);

            double[] avars = null;
            if (vars != null)
            {
                avars = new double[vars.Count];
                vars.CopyTo(avars);
            }
            double[] aspecvars = null;
            if (specialvars != null)
            {
                aspecvars = new double[specialvars.Count];
                specialvars.CopyTo(aspecvars);
            }
            double[] an1vars = null;
            if (n1vars != null)
            {
                an1vars = new double[n1vars.Count];
                n1vars.CopyTo(an1vars);
            }
            double[] an2vars = null;
            if (n2vars != null)
            {
                an2vars = new double[n2vars.Count];
                n2vars.CopyTo(an2vars);
            }
            double[] an3vars = null;
            if (n3vars != null)
            {
                an3vars = new double[n3vars.Count];
                n3vars.CopyTo(an3vars);
            }
            string[] aspecstrvars = null;
            if (specstrvars != null)
            {
                aspecstrvars = new string[specstrvars.Count];
                specstrvars.CopyTo(aspecstrvars);
            }
            string[] as1vars = null;
            if (s1vars != null)
            {
                as1vars = new string[s1vars.Count];
                s1vars.CopyTo(as1vars);
            }
            string[] as2vars = null;
            if (s2vars != null)
            {
                as2vars = new string[s2vars.Count];
                s2vars.CopyTo(as2vars);
            }
            string[] as3vars = null;
            if (s3vars != null)
            {
                as3vars = new string[s3vars.Count];
                s3vars.CopyTo(as3vars);
            }

            // make a copy to protect original
            //List<List<double>> an2dvars = new List<List<double>>();
            //if (n2dvars != null)
            //{
            //    foreach (List<double> lvars in n2dvars)
            //    {
            //        List<double> d1vars = new List<double>();
            //        if (lvars != null)
            //        {
            //            foreach (double dd in lvars)
            //            {
            //                d1vars.Add(dd);
            //            }
            //        }
            //        an2dvars.Add(d1vars);
            //    }
            //}

            object res = doEvil(avars, aspecvars, an1vars, an2vars, an3vars, n2dvars, list2vars, list3vars, list4vars, aspecstrvars, as1vars, as2vars, as3vars);

            return res.ToString();
        }


        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars,
            List<List<double>> n2dvars,
            List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            return doStringEval(vars, specialvars, n1vars, n2vars, n3vars,
            n2dvars, null, null, null, 
            specstrvars, s1vars, s2vars, s3vars);
        }        
        
        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars,
            List<List<double>> n2dvars, List<List<double>> list2vars, List<List<double>> list3vars, List<List<double>> list4vars,
            List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            if (foo.Count == 0) Translate(); // in case not yet translated
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];
            if (foo.Count == 1 && foo[0] == FOOVAR.STRKON) return (Convert.ToDouble(strkon[0]));

            double[] avars = null;
            if (vars != null)
            {
                avars = new double[vars.Count];
                vars.CopyTo(avars);
            }
            double[] aspecvars = null;
            if (specialvars != null)
            {
                aspecvars = new double[specialvars.Count];
                specialvars.CopyTo(aspecvars);
            }
            double[] an1vars = null;
            if (n1vars != null)
            {
                an1vars = new double[n1vars.Count];
                n1vars.CopyTo(an1vars);
            }
            double[] an2vars = null;
            if (n2vars != null)
            {
                an2vars = new double[n2vars.Count];
                n2vars.CopyTo(an2vars);
            }
            double[] an3vars = null;
            if (n3vars != null)
            {
                an3vars = new double[n3vars.Count];
                n3vars.CopyTo(an3vars);
            }
            string[] aspecstrvars = null;
            if (specstrvars != null)
            {
                aspecstrvars = new string[specstrvars.Count];
                specstrvars.CopyTo(aspecstrvars);
            }
            string[] as1vars = null;
            if (s1vars != null)
            {
                as1vars = new string[s1vars.Count];
                s1vars.CopyTo(as1vars);
            }
            string[] as2vars = null;
            if (s2vars != null)
            {
                as2vars = new string[s2vars.Count];
                s2vars.CopyTo(as2vars);
            }
            string[] as3vars = null;
            if (s3vars != null)
            {
                as3vars = new string[s3vars.Count];
                s3vars.CopyTo(as3vars);
            }

            // make a copy to protect original
            //List<List<double>> an2dvars = new List<List<double>>();
            //if (n2dvars != null)
            //{
            //    foreach (List<double> lvars in n2dvars)
            //    {
            //        List<double> d1vars = new List<double>();
            //        if (lvars != null)
            //        {
            //            foreach (double dd in lvars)
            //            {
            //                d1vars.Add(dd);
            //            }
            //        }
            //        an2dvars.Add(d1vars);
            //    }
            //}

            object res = doEvil(avars, aspecvars, an1vars, an2vars, an3vars, n2dvars, list2vars, list3vars, list4vars, aspecstrvars, as1vars, as2vars, as3vars);

            if (res.GetType() == typeof(double)) return (double)res;
            else return Convert.ToDouble(res);
        }


        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars,
            List<List<double>> n2dvars,
            List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            return doEval(vars, specialvars, n1vars, n2vars, n3vars,
            n2dvars, null, null, null,
            specstrvars, s1vars, s2vars, s3vars);
        }        
        
        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, double[,] n2dvars,
            List<List<double>> list2vars, List<List<double>> list3vars, List<List<double>> list4vars,
            string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            if (foo.Count == 0) Translate(); // in case not yet translated
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return (kon[0].ToString());
            if (foo.Count == 1 && foo[0] == FOOVAR.STRKON) return (strkon[0]);

            // make a copy to protect original -- needed?
            List<List<double>> an2dvars = new List<List<double>>();
            if (n2dvars != null)
            {
                for (int i = 0; i < n2dvars.GetLength(0); i++)
                {
                    List<double> d1vars = new List<double>();
                    for (int j = 0; j < n2dvars.GetLength(1); j++)
                    {
                        d1vars.Add(n2dvars[i, j]);
                    }
                    an2dvars.Add(d1vars);
                }
            }

            object res = doEvil(vars, specialvars, n1vars, n2vars, n3vars, an2dvars, list2vars, list3vars, list4vars, specstrvars, s1vars, s2vars, s3vars);

            return res.ToString();
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, double[,] n2dvars,
            string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            if (foo.Count == 0) Translate(); // in case not yet translated
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return (kon[0].ToString());
            if (foo.Count == 1 && foo[0] == FOOVAR.STRKON) return (strkon[0]);

            // make a copy to protect original
            List<List<double>> an2dvars = new List<List<double>>();
            if (n2dvars != null)
            {
                for (int i = 0; i < n2dvars.GetLength(0); i++)
                {
                    List<double> d1vars = new List<double>();
                    for (int j = 0; j < n2dvars.GetLength(1); j++)
                    {
                        d1vars.Add(n2dvars[i, j]);
                    }
                    an2dvars.Add(d1vars);
                }
            }

            object res = doEvil(vars, specialvars, n1vars, n2vars, n3vars, an2dvars, specstrvars, s1vars, s2vars, s3vars);

            return res.ToString();
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, double[,] n2dvars,
            List<List<double>> list2vars, List<List<double>> list3vars, List<List<double>> list4vars,
            string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            if (foo.Count == 0) Translate(); // in case not yet translated
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];
            if (foo.Count == 1 && foo[0] == FOOVAR.STRKON) return (Convert.ToDouble(strkon[0]));

            // make a copy to protect original -- why?
            List<List<double>> an2dvars = new List<List<double>>();
            if (n2dvars != null)
            {
                for (int i = 0; i < n2dvars.GetLength(0); i++)
                {
                    List<double> d1vars = new List<double>();
                    for (int j = 0; j < n2dvars.GetLength(1); j++)
                    {
                        d1vars.Add(n2dvars[i, j]);
                    }
                    an2dvars.Add(d1vars);
                }
            }

            //List<List<double>> a2dvars = new List<List<double>>();
            //if (list2vars != null)
            //{
            //    for (int i = 0; i < list2vars.Count; i++)
            //    {
            //        List<double> d1vars = new List<double>();
            //        if (list2vars[i] != null) for (int j = 0; j < list2vars[i].Count; j++)
            //            {
            //                d1vars.Add(list2vars[i][j]);
            //            }
            //        a2dvars.Add(d1vars);
            //    }
            //}

            //List<List<double>> a3dvars = new List<List<double>>();
            //if (list3vars != null)
            //{
            //    for (int i = 0; i < list2vars.Count; i++)
            //    {
            //        List<double> d1vars = new List<double>();
            //        if (list3vars[i] != null) for (int j = 0; j < list3vars[i].Count; j++)
            //            {
            //                d1vars.Add(list3vars[i][j]);
            //            }
            //        a3dvars.Add(d1vars);
            //    }
            //}

            //List<List<double>> a4dvars = new List<List<double>>();
            //if (list4vars != null)
            //{
            //    for (int i = 0; i < list4vars.Count; i++)
            //    {
            //        List<double> d1vars = new List<double>();
            //        if (list4vars[i] != null) for (int j = 0; j < list4vars[i].Count; j++)
            //            {
            //                d1vars.Add(list4vars[i][j]);
            //            }
            //        a4dvars.Add(d1vars);
            //    }
            //}


            object res = doEvil(vars, specialvars, n1vars, n2vars, n3vars, an2dvars, list2vars,list3vars, list4vars, specstrvars, s1vars, s2vars, s3vars);

            if (res.GetType() == typeof(double)) return (double)res;
            else return Convert.ToDouble(res);
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, double[,] n2dvars,
    List<List<double>> list2vars, List<List<double>> list3vars, List<List<double>> list4vars)
        {
            return doEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars,
            list2vars, list3vars, list4vars, null, null, null, null);
        }


        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, double[,] n2dvars,
            string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {

         return doEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, null, null, null, 
            specstrvars, s1vars, s2vars, s3vars);

            //if (foo.Count == 0) Translate(); // in case not yet translated
            //if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];
            //if (foo.Count == 1 && foo[0] == FOOVAR.STRKON) return (Convert.ToDouble(strkon[0]));

            //// make a copy to protect original
            //List<List<double>> an2dvars = new List<List<double>>();
            //if (n2dvars != null)
            //{
            //    for (int i = 0; i < n2dvars.GetLength(0); i++)
            //    {
            //        List<double> d1vars = new List<double>();
            //        for (int j = 0; j < n2dvars.GetLength(1); j++)
            //        {
            //            d1vars.Add(n2dvars[i, j]);
            //        }
            //        an2dvars.Add(d1vars);
            //    }
            //}

            //object res = doEvil(vars, specialvars, n1vars, n2vars, n3vars, an2dvars, specstrvars, s1vars, s2vars, s3vars);

            //if (res.GetType() == typeof(double)) return (double)res;
            //else return Convert.ToDouble(res);
        }

        // version that doesn't use n2dvars
        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars,
            string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            if (foo.Count == 0) Translate(); // in case not yet translated
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];
            if (foo.Count == 1 && foo[0] == FOOVAR.STRKON) return (Convert.ToDouble(strkon[0]));

            object res = doEvil(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, s1vars, s2vars, s3vars);

            if (res.GetType() == typeof(double)) return (double)res;
            else return Convert.ToDouble(res);
        }

        // version that doesn't use n2dvars
        public double doEval1D(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars)
        {
            if (foo.Count == 0) Translate(); // in case not yet translated
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];
            if (foo.Count == 1 && foo[0] == FOOVAR.STRKON) return (Convert.ToDouble(strkon[0]));

            object res = doEvil(vars, specialvars, n1vars, n2vars, n3vars, null);

            if (res.GetType() == typeof(double)) return (double)res;
            else return Convert.ToDouble(res);
        }


        // Full version that uses List<List>> for n2dvars, and other List<List<double>>s
        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, List<List<double>> n2dvars,
            List<List<double>> list2vars, List<List<double>> list3vars, List<List<double>> list4vars,
            string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            if (foo.Count == 0) Translate(); // in case not yet translated
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];
            if (foo.Count == 1 && foo[0] == FOOVAR.STRKON) return (Convert.ToDouble(strkon[0]));

            // make a deep copy to protect original
            List<List<double>> an2dvars = new List<List<double>>();
            if (n2dvars != null)
            {
                for (int i = 0; i < n2dvars.Count; i++)
                {
                    List<double> d1vars = new List<double>();
                    if(n2dvars[i] != null) for (int j = 0; j < n2dvars[i].Count; j++)
                    {
                        d1vars.Add(n2dvars[i][j]);
                    }
                    an2dvars.Add(d1vars);
                }
            }

            //List<List<double>> a2dvars = new List<List<double>>();
            //if (list2vars != null)
            //{
            //    for (int i = 0; i < list2vars.Count; i++)
            //    {
            //        List<double> d1vars = new List<double>();
            //        if (list2vars[i] != null) for (int j = 0; j < list2vars[i].Count; j++)
            //            {
            //                d1vars.Add(list2vars[i][j]);
            //            }
            //        a2dvars.Add(d1vars);
            //    }
            //}

            //List<List<double>> a3dvars = new List<List<double>>();
            //if (list3vars != null)
            //{
            //    for (int i = 0; i < list2vars.Count; i++)
            //    {
            //        List<double> d1vars = new List<double>();
            //        if (list3vars[i] != null) for (int j = 0; j < list3vars[i].Count; j++)
            //            {
            //                d1vars.Add(list3vars[i][j]);
            //            }
            //        a3dvars.Add(d1vars);
            //    }
            //}

            //List<List<double>> a4dvars = new List<List<double>>();
            //if (list4vars != null)
            //{
            //    for (int i = 0; i < list4vars.Count; i++)
            //    {
            //        List<double> d1vars = new List<double>();
            //        if (list4vars[i] != null) for (int j = 0; j < list4vars[i].Count; j++)
            //            {
            //                d1vars.Add(list4vars[i][j]);
            //            }
            //        a4dvars.Add(d1vars);
            //    }
            //}


            object res = doEvil(vars, specialvars, n1vars, n2vars, n3vars, an2dvars, list2vars, list3vars, list4vars,
                specstrvars, s1vars, s2vars, s3vars);

            if (res.GetType() == typeof(double)) return (double)res;
            else return Convert.ToDouble(res);
        }

        // old version that uses List<List>> for n2dvars, but no futher such lists
        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, List<List<double>> n2dvars,
            string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            if (foo.Count == 0) Translate(); // in case not yet translated
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];
            if (foo.Count == 1 && foo[0] == FOOVAR.STRKON) return (Convert.ToDouble(strkon[0]));

            // make a deep copy to protect original
            List<List<double>> an2dvars = new List<List<double>>();
            if (n2dvars != null)
            {
                for (int i = 0; i < n2dvars.Count; i++)
                {
                    List<double> d1vars = new List<double>();
                    if (n2dvars[i] != null) for (int j = 0; j < n2dvars[i].Count; j++)
                        {
                            d1vars.Add(n2dvars[i][j]);
                        }
                    an2dvars.Add(d1vars);
                }
            }

            object res = doEvil(vars, specialvars, n1vars, n2vars, n3vars, an2dvars, null, null, null,
                specstrvars, s1vars, s2vars, s3vars);

            if (res.GetType() == typeof(double)) return (double)res;
            else return Convert.ToDouble(res);
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, double[,] n2dvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, null, null, null, null, null, null, null));
        }


        // scramble the seed a bit, to prevent sequential seeds
        private int adjustSeed(double seed)
        {
            long iseed = (long)seed;

            if (iseed > 5000) iseed = iseed % 4982; // get tseed into a reasonable range of ints
            if (iseed < -5000) iseed = iseed % 4829; // get tseed into a reasonable range of ints
            iseed = 103L + (iseed + 3) * (iseed + 7); // make seed big, and break up any sequence
            if (iseed > 65000) iseed = iseed % 64471; // prevent int overflows

            return (int)iseed;
        }


        public double doEval(int indx)
            // a simple way to fetch values from a time series or sequence
        {
            if (indx >= kon.Count) indx = kon.Count - 1;
                //throw new Exception("Evaluator.Lookup index exceeded table");

            return (kon[indx]);
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<List<double>> n2dvars, List<string> specstrvars, List<string> s1vars, List<string> s2vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, specstrvars, s1vars, s2vars, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<List<double>> n2dvars, List<string> specstrvars, List<string> s1vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, specstrvars, s1vars, null, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<List<double>> n2dvars, List<string> specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, specstrvars, null, null, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<List<double>> n2dvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, null, null, null, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, s1vars, s2vars, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<string> specstrvars, List<string> s1vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, s1vars, null, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<string> specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, null, null, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, null, null, specstrvars, s1vars, s2vars, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<string> specstrvars, List<string> s1vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, null, null, specstrvars, s1vars, null, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<string> specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, null, null, specstrvars, null, null, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, null, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, null, null, null, specstrvars, s1vars, s2vars, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<string> specstrvars, List<string> s1vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, null, null, null, specstrvars, s1vars, null, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<string> specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, null, null, null, specstrvars, null, null, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, null, null, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<string> specstrvars, List<string> s1vars, List<string> s2vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, null, null, null, null, specstrvars, s1vars, s2vars, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<string> specstrvars, List<string> s1vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, null, null, null, null, specstrvars, s1vars, null, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<string> specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, null, null, null, null, specstrvars, null, null, null));
        }

        public double doEval(List<double> vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, null, null, null, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public double doEval(List<double> vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, null, null, null, null, null, specstrvars, s1vars, s2vars, null));
        }

        public double doEval(List<double> vars, List<string> specstrvars, List<string> s1vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, null, null, null, null, null, specstrvars, s1vars, null, null));
        }

        public double doEval(List<double> vars, List<string> specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, null, null, null, null, null, specstrvars, null, null, null));
        }

        
        public double doEval(List<double> vars, List<double> specialvars, List<double> gsvars, List<double> psvars, List<double> isvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, gsvars, psvars, isvars, null, null, null, null, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> gsvars, List<double> psvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, gsvars, psvars, null, null, null, null, null, null));
        }

        public double doEval(List<double> vars, List<double> specialvars, List<double> gsvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, gsvars, null, null, null, null, null, null, null));
        }

        public double doEval(List<double> vars, List<double> specialvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, null, null, null, null, null, null, null, null));
        }

        public double doEval(List<double> vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, null, null, null, null, null, null, null, null, null));
        }

        // following version uses no default var names, just whatever the caller passes to it
        public double doEval(List<string> varnames, List<double> specialvars, List<string> strvarnames, List<string> strspecialvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            specials = varnames;
            strspecials = strvarnames;
            return (doEval(null, specialvars, null, null, null, null, strspecialvars, null, null, null));
        }

        public double doEval(List<string> varnames, List<double> specialvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            specials = varnames;
            return (doEval(null, specialvars, null, null, null, null, null, null, null, null));
        }

        public double doEval(List<string> varnames, List<string> specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            strspecials = varnames;
            return (doEval(null, null, null, null, null, null, specstrvars, null, null, null));
        }

  // variants of doStringEval ...

        public string doStringEval(int indx)
        // a simple way to fetch values from a time series or sequence
        {
            if (indx >= strkon.Count) indx = strkon.Count - 1;
            //throw new Exception("Evaluator.Lookup index exceeded table");

            return (strkon[indx]);
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<List<double>> n2dvars, List<string> specstrvars, List<string> s1vars, List<string> s2vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, specstrvars, s1vars, s2vars, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<List<double>> n2dvars, List<string> specstrvars, List<string> s1vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, specstrvars, s1vars, null, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<List<double>> n2dvars, List<string> specstrvars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, specstrvars, null, null, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<List<double>> n2dvars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, null, null, null, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, s1vars, s2vars, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<string> specstrvars, List<string> s1vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, s1vars, null, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<double> n3vars, List<string> specstrvars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, null, null, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, null, null, specstrvars, s1vars, s2vars, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<string> specstrvars, List<string> s1vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, null, null, specstrvars, s1vars, null, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<double> n2vars, List<string> specstrvars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, null, null, specstrvars, null, null, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            return (doStringEval(vars, specialvars, n1vars, null, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars)
        {
            return (doStringEval(vars, specialvars, n1vars, null, null, null, specstrvars, s1vars, s2vars, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<string> specstrvars, List<string> s1vars)
        {
            return (doStringEval(vars, specialvars, n1vars, null, null, null, specstrvars, s1vars, null, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> n1vars, List<string> specstrvars)
        {
            return (doStringEval(vars, specialvars, n1vars, null, null, null, specstrvars, null, null, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            return (doStringEval(vars, specialvars, null, null, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<string> specstrvars, List<string> s1vars, List<string> s2vars)
        {
            return (doStringEval(vars, specialvars, null, null, null, null, specstrvars, s1vars, s2vars, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<string> specstrvars, List<string> s1vars)
        {
            return (doStringEval(vars, specialvars, null, null, null, null, specstrvars, s1vars, null, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<string> specstrvars)
        {
            return (doStringEval(vars, specialvars, null, null, null, null, specstrvars, null, null, null));
        }

        public string doStringEval(List<double> vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars, List<string> s3vars)
        {
            return (doStringEval(vars, null, null, null, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public string doStringEval(List<double> vars, List<string> specstrvars, List<string> s1vars, List<string> s2vars)
        {
            return (doStringEval(vars, null, null, null, null, null, specstrvars, s1vars, s2vars, null));
        }

        public string doStringEval(List<double> vars, List<string> specstrvars, List<string> s1vars)
        {
            return (doStringEval(vars, null, null, null, null, null, specstrvars, s1vars, null, null));
        }

        public string doStringEval(List<double> vars, List<string> specstrvars)
        {
            return (doStringEval(vars, null, null, null, null, null, specstrvars, null, null, null));
        }


        public string doStringEval(List<double> vars, List<double> specialvars, List<double> gsvars, List<double> psvars, List<double> isvars)
        {
            return (doStringEval(vars, specialvars, gsvars, psvars, isvars, null, null, null, null, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> gsvars, List<double> psvars)
        {
            return (doStringEval(vars, specialvars, gsvars, psvars, null, null, null, null, null, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars, List<double> gsvars)
        {
            return (doStringEval(vars, specialvars, gsvars, null, null, null, null, null, null, null));
        }

        public string doStringEval(List<double> vars, List<double> specialvars)
        {
            return (doStringEval(vars, specialvars, null, null, null, null, null, null, null, null));
        }

        public string doStringEval(List<double> vars)
        {
            return (doStringEval(vars, null, null, null, null, null, null, null, null, null));
        }

        // following version uses no default var names, just whatever the caller passes to it
        public string doStringEval(List<string> varnames, List<double> specialvars, List<string> strvarnames, List<string> strspecialvars)
        {
            specials = varnames;
            strspecials = strvarnames;
            return (doStringEval(null, specialvars, null, null, null, null, strspecialvars, null, null, null));
        }

        public string doStringEval(List<string> varnames, List<double> specialvars)
        {
            specials = varnames;
            return (doStringEval(null, specialvars, null, null, null, null, null, null, null, null));
        }

        public string doStringEval(List<string> varnames, List<string> specstrvars)
        {
            strspecials = varnames;
            return (doStringEval(null, null, null, null, null, null, specstrvars, null, null, null));
        }


// array param versions

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, double[,] n2dvars, string[] specstrvars, string[] s1vars, string[] s2vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, specstrvars, s1vars, s2vars, null));
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, double[,] n2dvars, string[] specstrvars, string[] s1vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, specstrvars, s1vars, null, null));
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, double[,] n2dvars, string[] specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0]; 

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, specstrvars, null, null, null));
        }

        //public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        //{
        //    if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

        //    return (doEval(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, s1vars, s2vars, s3vars));
        //}

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, string[] specstrvars, string[] s1vars, string[] s2vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, specstrvars, s1vars, s2vars, null));
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, string[] specstrvars, string[] s1vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, specstrvars, s1vars, null, null));
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, string[] specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, n3vars, specstrvars, null, null, null));
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, string[] specstrvars, string[] s1vars, string[] s2vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, null, specstrvars, s1vars, s2vars, null));
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, string[] specstrvars, string[] s1vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, null, specstrvars, s1vars, null, null));
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, string[] specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, n2vars, null, specstrvars, null, null, null));
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, string[] specstrvars, string[] s1vars, string[] s2vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, null, null, specstrvars, s1vars, s2vars, null));
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, string[] specstrvars, string[] s1vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, null, null, specstrvars, s1vars, null, null));
        }

        public double doEval(double[] vars, double[] specialvars, double[] n1vars, string[] specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, n1vars, null, null, specstrvars, null, null, null));
        }

        public double doEval(double[] vars, double[] specialvars, string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, null, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public double doEval(double[] vars, double[] specialvars, string[] specstrvars, string[] s1vars, string[] s2vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, null, null, null, specstrvars, s1vars, s2vars, null));
        }

        public double doEval(double[] vars, double[] specialvars, string[] specstrvars, string[] s1vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, null, null, null, specstrvars, s1vars, null, null));
        }

        public double doEval(double[] vars, double[] specialvars, string[] specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, specialvars, null, null, null, specstrvars, null, null, null));
        }

        public double doEval(double[] vars, string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, null, null, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public double doEval(double[] vars, string[] specstrvars, string[] s1vars, string[] s2vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, null, null, null, null, specstrvars, s1vars, s2vars, null));
        }

        public double doEval(double[] vars, string[] specstrvars, string[] s1vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, null, null, null, null, specstrvars, s1vars, null, null));
        }

        public double doEval(double[] vars, string[] specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval(vars, null, null, null, null, specstrvars, null, null, null));
        }


        public double doEval(double[] vars, double[] specialvars, double[] gsvars, double[] psvars, double[] isvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval1D(vars, specialvars, gsvars, psvars, isvars));
        }

        public double doEval(double[] vars, double[] specialvars, double[] gsvars, double[] psvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval1D(vars, specialvars, gsvars, psvars, null));
        }

        public double doEval(double[] vars, double[] specialvars, double[] gsvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval1D(vars, specialvars, gsvars, null, null));
        }

        public double doEval(double[] vars, double[] specialvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval1D(vars, specialvars, null, null, null));
        }

        public double doEval(double[] vars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            return (doEval1D(vars, null, null, null, null));
        }

        // following version uses no default var names, just whatever the caller passes to it
        public double doEval(string[] varnames, double[] specialvars, string[] strvarnames, string[] strspecialvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            specials.Clear();
            foreach (string s in varnames) specials.Add(s);
            strspecials.Clear();
            foreach (string s in strvarnames) strspecials.Add(s);
            return (doEval(null, specialvars, null, null, null, strspecialvars, null, null, null));
        }

        public double doEval(string[] varnames, double[] specialvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            specials.Clear();
            foreach (string s in varnames) specials.Add(s);

            return (doEval1D(null, specialvars, null, null, null));
        }

        public double doEval(string[] varnames, string[] specstrvars)
        {
            if (foo.Count == 1 && foo[0] == FOOVAR.KON) return kon[0];

            specials.Clear();
            foreach (string s in varnames) specials.Add(s);

            return (doEval(null, null, null, null, null, specstrvars, null, null, null));
        }

        // variants of doStringEval ...

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, double[,] n2dvars, string[] specstrvars, string[] s1vars, string[] s2vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, specstrvars, s1vars, s2vars, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, double[,] n2dvars, string[] specstrvars, string[] s1vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, specstrvars, s1vars, null, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, double[,] n2dvars, string[] specstrvars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, specstrvars, null, null, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, double[,] n2dvars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, n2dvars, null, null, null, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, string[] specstrvars, string[] s1vars, string[] s2vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, s1vars, s2vars, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, string[] specstrvars, string[] s1vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, s1vars, null, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, double[] n3vars, string[] specstrvars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, n3vars, null, specstrvars, null, null, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, string[] specstrvars, string[] s1vars, string[] s2vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, null, null, specstrvars, s1vars, s2vars, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, string[] specstrvars, string[] s1vars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, null, null, specstrvars, s1vars, null, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, double[] n2vars, string[] specstrvars)
        {
            return (doStringEval(vars, specialvars, n1vars, n2vars, null, null, specstrvars, null, null, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            return (doStringEval(vars, specialvars, n1vars, null, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, string[] specstrvars, string[] s1vars, string[] s2vars)
        {
            return (doStringEval(vars, specialvars, n1vars, null, null, null, specstrvars, s1vars, s2vars, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, string[] specstrvars, string[] s1vars)
        {
            return (doStringEval(vars, specialvars, n1vars, null, null, null, specstrvars, s1vars, null, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] n1vars, string[] specstrvars)
        {
            return (doStringEval(vars, specialvars, n1vars, null, null, null, specstrvars, null, null, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            return (doStringEval(vars, specialvars, null, null, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public string doStringEval(double[] vars, double[] specialvars, string[] specstrvars, string[] s1vars, string[] s2vars)
        {
            return (doStringEval(vars, specialvars, null, null, null, null, specstrvars, s1vars, s2vars, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, string[] specstrvars, string[] s1vars)
        {
            return (doStringEval(vars, specialvars, null, null, null, null, specstrvars, s1vars, null, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, string[] specstrvars)
        {
            return (doStringEval(vars, specialvars, null, null, null, null, specstrvars, null, null, null));
        }

        public string doStringEval(double[] vars, string[] specstrvars, string[] s1vars, string[] s2vars, string[] s3vars)
        {
            return (doStringEval(vars, null, null, null, null, null, specstrvars, s1vars, s2vars, s3vars));
        }

        public string doStringEval(double[] vars, string[] specstrvars, string[] s1vars, string[] s2vars)
        {
            return (doStringEval(vars, null, null, null, null, null, specstrvars, s1vars, s2vars, null));
        }

        public string doStringEval(double[] vars, string[] specstrvars, string[] s1vars)
        {
            return (doStringEval(vars, null, null, null, null, null, specstrvars, s1vars, null, null));
        }

        public string doStringEval(double[] vars, string[] specstrvars)
        {
            return (doStringEval(vars, null, null, null, null, null, specstrvars, null, null, null));
        }


        public string doStringEval(double[] vars, double[] specialvars, double[] gsvars, double[] psvars, double[] isvars)
        {
            return (doStringEval(vars, specialvars, gsvars, psvars, isvars, null, null, null, null, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] gsvars, double[] psvars)
        {
            return (doStringEval(vars, specialvars, gsvars, psvars, null, null, null, null, null, null));
        }

        public string doStringEval(double[] vars, double[] specialvars, double[] gsvars)
        {
            return (doStringEval(vars, specialvars, gsvars, null, null, null, null, null, null, null));
        }

        public string doStringEval(double[] vars, double[] specialvars)
        {
            return (doStringEval(vars, specialvars, null, null, null, null, null, null, null, null));
        }

        public string doStringEval(double[] vars)
        {
            return (doStringEval(vars, null, null, null, null, null, null, null, null, null));
        }

        // following version uses no default var names, just whatever the caller passes to it
        public string doStringEval(string[] varnames, double[] specialvars, string[] strvarnames, string[] strspecialvars)
        {
            specials.Clear();
            foreach (string s in varnames) specials.Add(s);
            strspecials.Clear();
            foreach (string s in strvarnames) strspecials.Add(s);

            return (doStringEval(null, specialvars, null, null, null, null, strspecialvars, null, null, null));
        }

        public string doStringEval(string[] varnames, double[] specialvars)
        {
            specials.Clear();
            foreach (string s in varnames) specials.Add(s);
            return (doStringEval(null, specialvars, null, null, null, null, null, null, null, null));
        }

        public string doStringEval(string[] varnames, string[] specstrvars)
        {
            specials.Clear();
            foreach (string s in varnames) specials.Add(s);

            return (doStringEval(null, null, null, null, null, null, specstrvars, null, null, null));
        }


        // new stuff useful for calling R scripts -- 16 Aug 2016
        //List<string> GSlabels = new List<string>();
        //List<string> PSlabels = new List<string>();
        //List<string> ISlabels = new List<string>();
        List<string> GSsyns = new List<string>();
        List<string> PSsyns = new List<string>();
        List<string> ISsyns = new List<string>();
        List<string> VarLabels = new List<string>();

        private bool makeGSvarLists(int ct)
        {
//            GSlabels.Clear();
            GSsyns.Clear();

            for (int i = 0; i < ct; i++)
            {
                string lbl = "GS" + (i + 1).ToString();
//                GSlabels.Add(lbl);
                GSsyns.Add(getSynonym(lbl));
            }

            return true;
        }


        // this version of GSvarLists includes standard vars
        //private bool makeGSvarLists(int ct1, int ct2)
        //{
        //    GSlabels.Clear();
        //    GSsyns.Clear();
        //    varvals = new double[ct1 + ct2];

        //    for(int i = 0; i < ct1; i++)
        //    {
        //        string lbl = "GS" + (i + 1).ToString();
        //        GSlabels.Add(lbl);
        //        GSsyns.Add(getSynonym(lbl));
        //    }

        //    for (int i = 0; i < 26; i++)
        //    {
        //        char vlbl = Convert.ToChar('A' + i);
        //        GSlabels.Add(vlbl.ToString());
        //    }
        //    for (int i = 26; i < ct2; i++)
        //        GSlabels.Add("VAR" + (i - 25).ToString());

        //    return true;
        //}

        private bool makePSvarLists(int ct)
        {
//            PSlabels.Clear();
            PSsyns.Clear();

            for (int i = 0; i < ct; i++)
            {
                string lbl = "PS" + (i + 1).ToString();
//                PSlabels.Add(lbl);
                PSsyns.Add(getSynonym(lbl));
            }

            return true;
        }

        //private bool makePSvarLists(int ct1, int ct2, int ct3)
        //{
        //    PSlabels.Clear();
        //    PSsyns.Clear();

        //    for (int i = 0; i < ct2; i++)
        //    {
        //        string lbl = "PS" + (i + 1).ToString();
        //        PSlabels.Add(lbl);
        //        PSsyns.Add(getSynonym(lbl));
        //    }

        //    for (int i = 0; i < ct1; i++)
        //    {
        //        string lbl = "GS" + (i + 1).ToString();
        //        PSlabels.Add(lbl);
        //        PSsyns.Add(getSynonym(lbl));
        //    }

        //    for (int i = 0; i < 26; i++)
        //    {
        //        char vlbl = Convert.ToChar('A' + i);
        //        PSlabels.Add(vlbl.ToString());
        //    }
        //    for (int i = 26; i < ct3; i++)
        //        PSlabels.Add("VAR" + (i - 25).ToString());

        //    return true;
        //}

        private bool makeISvarLists(int ct)
        {
//            ISlabels.Clear();
            ISsyns.Clear();

            for (int i = 0; i < ct; i++)
            {
                string lbl = "IS" + (i + 1).ToString();
//                ISlabels.Add(lbl);
                ISsyns.Add(getSynonym(lbl));
            }

            return true;
        }

        //private bool makeISvarLists(int ct1, int ct2, int ct3, int ct4)
        //{
        //    ISlabels.Clear();
        //    ISsyns.Clear();

        //    for (int i = 0; i < ct3; i++)
        //    {
        //        string lbl = "IS" + (i + 1).ToString();
        //        ISlabels.Add(lbl);
        //        ISsyns.Add(getSynonym(lbl));
        //    }

        //    for (int i = 0; i < ct2; i++)
        //    {
        //        string lbl = "PS" + (i + 1).ToString();
        //        ISlabels.Add(lbl);
        //        ISsyns.Add(getSynonym(lbl));
        //    }

        //    for (int i = 0; i < ct1; i++)
        //    {
        //        string lbl = "GS" + (i + 1).ToString();
        //        ISlabels.Add(lbl);
        //        ISsyns.Add(getSynonym(lbl));
        //    }

        //    for (int i = 0; i < 26; i++)
        //    {
        //        char vlbl = Convert.ToChar('A' + i);
        //        ISlabels.Add(vlbl.ToString());
        //    }
        //    for (int i = 26; i < ct4; i++)
        //        ISlabels.Add("VAR" + (i - 25).ToString());

        //    return true;
        //}

        private bool makeVarLabels(int ct)
        {
            VarLabels.Clear();
            for (int i = 0; i < 26; i++)
            {
                char vlbl = Convert.ToChar('A' + i);
                VarLabels.Add(vlbl.ToString());
            }
            for(int i = 26; i < ct; i++)
                VarLabels.Add("VAR" + (i - 25).ToString());

            return true;
        }
        

    }

}
