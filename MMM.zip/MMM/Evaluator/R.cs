﻿using System;
using System.Collections.Generic;
using System.IO;
using RDotNet;

namespace EvaluatorLibrary
{
    public static class R
    // I think that it will work best to make this a static class, and not have multiple instances of engine opened within projects, but wee need to think about this.

    // If an R Evaluate crashes, is there a way to fetch the error message from R engine to be displayed to the user?

    {
        public static REngine engine;

        //public R(string filename) // to be used only if class is not static
        //{
        //    if (engine == null)
        //    {
        //        REngine.SetEnvironmentVariables();
        //        engine = REngine.GetInstance();
        //    }

        //    StreamReader Rfilestream;
        //    string sline;

        //    using (Rfilestream = new StreamReader(filename))
        //    {
        //        while (null != (sline = Rfilestream.ReadLine().Trim()))
        //        {
        //            if (sline == "" || sline[0] == '#') continue; // blank line or comment

        //            engine.Evaluate(sline); // what does this return on error?
        //        }
        //        Rfilestream.Close();
        //    }
        //}

        private static List<string> currentRmacro; // keep this stored, because often we will run the same starting script many times over
        private static string macroFile; // ditto, don't want to re-read the file each time.

        public static double Rmacro(string rmfile)
        {
            if (engine == null)
            {
                REngine.SetEnvironmentVariables();
                engine = REngine.GetInstance();
            }

            if (rmfile != macroFile)
            {
                macroFile = rmfile;
                StreamReader Rfilestream;
                string sline;
                currentRmacro = new List<string>();

                using (Rfilestream = new StreamReader(rmfile))
                {
                    while (null != (sline = Rfilestream.ReadLine()))
                    {
                        sline = sline.Trim();
                        if (sline == "" || sline[0] == '#') continue; // blank line or comment

                        currentRmacro.Add(sline);
                    }
                    Rfilestream.Close();
                }
            }

            int lastline = currentRmacro.Count - 1;
            for (int i = 0; i < lastline; i++) engine.Evaluate(currentRmacro[i]);
            double rval = (engine.Evaluate(currentRmacro[lastline]).AsNumeric())[0];
            
            return rval;
        }

        public static double Reval(string evalR, bool returnN)
            // note: this can be used with R scripts that don't require input, 
            // including when prior input already populated rdata
        {
            double val = 0.0;

            if (engine == null && !engine.IsRunning)
            {
                REngine.SetEnvironmentVariables();
                engine = REngine.GetInstance();
            }

            SymbolicExpression se = null;
            try
            {
                se = engine.Evaluate(evalR);

                if (returnN) val = (se.AsNumeric())[0];
                else return val = 1;

                //val = (engine.Evaluate(evalR).AsNumeric())[0]; // what is returned if this fails?
            }
            catch { return 0; }

            return val;
        }

        public static double RevalN(string evalR)
        {
            return Reval(evalR, true);
        }

        public static double Reval(string evalR)
        {
            return Reval(evalR, false);
        }


        public static double Reval(string evalR, double[] vals)
        {
            return Reval(evalR, null, vals, false);
        }
        public static double RevalN(string evalR, double[] vals)
        {
            return Reval(evalR, null, vals, true);
        }

        public static double Reval(string evalR, List<double> vals)
        {
            return Reval(evalR, null, vals.ToArray(), false);
        }

        public static double RevalN(string evalR, List<double> vals)
        {
            return Reval(evalR, null, vals.ToArray(), true);
        }

        public static double Reval(string evalR, List<string> vars, List<double> vals)
        {
            return Reval(evalR, vars, vals.ToArray(), false);
        }

        public static double RevalN(string evalR, List<string> vars, List<double> vals)
        {
            return Reval(evalR, vars, vals.ToArray(), true);
        }

        // versions that accept multiple lists, for GS, PS, and IS vars
        public static double Reval(string evalR, List<string> vars1, List<string> vars2, double[] vals1, double[] vals2)
        {
            List<string> vars = new List<string>();
            double[] vals = new double[vals1.Length + vals2.Length];

            foreach (string s in vars1) vars.Add(s);
            foreach (string s in vars2) vars.Add(s);

            for (int i = 0; i < vals1.Length; i++) vals[i] = vals1[i];
            for (int i = 0; i < vals2.Length; i++) vals[i + vals1.Length] = vals2[i];

            return Reval(evalR, vars, vals, false);
        }

        public static double RevalN(string evalR, List<string> vars1, List<string> vars2, double[] vals1, double[] vals2)
        {
            List<string> vars = new List<string>();
            double[] vals = new double[vals1.Length + vals2.Length];

            foreach (string s in vars1) vars.Add(s);
            foreach (string s in vars2) vars.Add(s);

            for (int i = 0; i < vals1.Length; i++) vals[i] = vals1[i];
            for (int i = 0; i < vals2.Length; i++) vals[i + vals1.Length] = vals2[i];

            return Reval(evalR, vars, vals, true);
        }

        public static double Reval(string evalR, List<string> vars1, List<string> vars2, List<string> vars3, double[] vals1, double[] vals2, double[] vals3)
        {
            List<string> vars = new List<string>();
            double[] vals = new double[vals1.Length + vals2.Length + vals3.Length];

            foreach (string s in vars1) vars.Add(s);
            foreach (string s in vars2) vars.Add(s);
            foreach (string s in vars3) vars.Add(s);

            for (int i = 0; i < vals1.Length; i++) vals[i] = vals1[i];
            for (int i = 0; i < vals2.Length; i++) vals[i + vals1.Length] = vals2[i];
            for (int i = 0; i < vals3.Length; i++) vals[i + vals1.Length + vals2.Length] = vals3[i];

            return Reval(evalR, vars, vals, false);
        }
        public static double RevalN(string evalR, List<string> vars1, List<string> vars2, List<string> vars3, double[] vals1, double[] vals2, double[] vals3)
        {
            List<string> vars = new List<string>();
            double[] vals = new double[vals1.Length + vals2.Length + vals3.Length];

            foreach (string s in vars1) vars.Add(s);
            foreach (string s in vars2) vars.Add(s);
            foreach (string s in vars3) vars.Add(s);

            for (int i = 0; i < vals1.Length; i++) vals[i] = vals1[i];
            for (int i = 0; i < vals2.Length; i++) vals[i + vals1.Length] = vals2[i];
            for (int i = 0; i < vals3.Length; i++) vals[i + vals1.Length + vals2.Length] = vals3[i];

            return Reval(evalR, vars, vals, true);
        }


        public static double Reval(string evalR, List<string> vars1, List<string> vars2, List<string> vars3, List<string> vars4, double[] vals1, double[] vals2, double[] vals3, double[] vals4)
        {
            List<string> vars = new List<string>();
            double[] vals = new double[vals1.Length + vals2.Length + vals3.Length + vals4.Length];

            foreach (string s in vars1) vars.Add(s);
            foreach (string s in vars2) vars.Add(s);
            foreach (string s in vars3) vars.Add(s);
            foreach (string s in vars4) vars.Add(s);

            for (int i = 0; i < vals1.Length; i++) vals[i] = vals1[i];
            for (int i = 0; i < vals2.Length; i++) vals[i + vals1.Length] = vals2[i];
            for (int i = 0; i < vals3.Length; i++) vals[i + vals1.Length + vals2.Length] = vals3[i];
            for (int i = 0; i < vals4.Length; i++) vals[i + vals1.Length + vals2.Length + vals3.Length] = vals4[i];

            return Reval(evalR, vars, vals, false);
        }

        public static double RevalN(string evalR, List<string> vars1, List<string> vars2, List<string> vars3, List<string> vars4, double[] vals1, double[] vals2, double[] vals3, double[] vals4)
        {
            List<string> vars = new List<string>();
            double[] vals = new double[vals1.Length + vals2.Length + vals3.Length + vals4.Length];

            foreach (string s in vars1) vars.Add(s);
            foreach (string s in vars2) vars.Add(s);
            foreach (string s in vars3) vars.Add(s);
            foreach (string s in vars4) vars.Add(s);

            for (int i = 0; i < vals1.Length; i++) vals[i] = vals1[i];
            for (int i = 0; i < vals2.Length; i++) vals[i + vals1.Length] = vals2[i];
            for (int i = 0; i < vals3.Length; i++) vals[i + vals1.Length + vals2.Length] = vals3[i];
            for (int i = 0; i < vals4.Length; i++) vals[i + vals1.Length + vals2.Length + vals3.Length] = vals4[i];

            return Reval(evalR, vars, vals, true);
        }


        public static double RevalN(string evalR, List<string> vars, double[] vals)
        {
            return Reval(evalR, vars, vals, true);
        }

        public static double Reval(string evalR, List<string> vars, double[] vals)
        {
            return Reval(evalR, vars, vals, false);
        }

        public static double Reval(string evalR, List<string> vars, double[] vals, bool returnN)
        {
            double val = 0.0;

            if (engine == null)
            {
                REngine.SetEnvironmentVariables();
                engine = REngine.GetInstance();
            }

            // load vars into dataframe
            string sdata = "";
            for (int i = 0; i < vals.Length; i++)
            {
                if (vars == null || vars.Count <= i) sdata += "VAR" + (i + 1).ToString() + "="; // or do we want A, B, C, etc.?
                else sdata += vars[i] + "=";
                // what will happen if a var label isn't valid in an R data frame?

                sdata += vals[i].ToString() + ",";
            }

            sdata = sdata.TrimEnd(',');
            engine.Evaluate("RDATA=data.frame(" + sdata + ")");
            // user will need to know that RDATA holds the data, unless we make separate gsdata, psdata, isdata, etc.

            SymbolicExpression se = null;
            try
            {
                se = engine.Evaluate(evalR);

                if (returnN) val = (se.AsNumeric())[0];
                else return val = 1;
            }
            catch { return 0; }

            return val;
        }


    }
}
