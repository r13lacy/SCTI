namespace MeMoMa
{
    partial class frmSimOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSimOptions));
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.fgVars = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.label1 = new System.Windows.Forms.Label();
            this.radioRealTime = new System.Windows.Forms.RadioButton();
            this.radioEachIteration = new System.Windows.Forms.RadioButton();
            this.radioNone = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.fgApps = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.radioEndIterations = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.fgVars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgApps)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(287, 588);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(76, 30);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(371, 588);
            this.btnOK.Margin = new System.Windows.Forms.Padding(4);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(76, 30);
            this.btnOK.TabIndex = 8;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // fgVars
            // 
            this.fgVars.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.Rows;
            this.fgVars.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.ColumnsUniform;
            this.fgVars.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.fgVars.ColumnInfo = "2,0,0,0,0,85,Columns:0{Width:261;Caption:\"Variable\";}\t1{Width:39;Caption:\"Plot\";S" +
    "tyle:\"DataType:System.Boolean;TextAlign:LeftCenter;ImageAlign:CenterCenter;\";Sty" +
    "leFixed:\"TextAlign:CenterCenter;\";}\t";
            this.fgVars.ExtendLastCol = true;
            this.fgVars.Location = new System.Drawing.Point(16, 31);
            this.fgVars.Margin = new System.Windows.Forms.Padding(4);
            this.fgVars.Name = "fgVars";
            this.fgVars.Rows.DefaultSize = 17;
            this.fgVars.Size = new System.Drawing.Size(429, 425);
            this.fgVars.TabIndex = 10;
            this.fgVars.CellChecked += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgVars_CellChecked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(431, 17);
            this.label1.TabIndex = 11;
            this.label1.Text = "Which variables would you like to plot (population and global only)?";
            // 
            // radioRealTime
            // 
            this.radioRealTime.AutoSize = true;
            this.radioRealTime.Checked = true;
            this.radioRealTime.Location = new System.Drawing.Point(16, 482);
            this.radioRealTime.Margin = new System.Windows.Forms.Padding(4);
            this.radioRealTime.Name = "radioRealTime";
            this.radioRealTime.Size = new System.Drawing.Size(200, 21);
            this.radioRealTime.TabIndex = 12;
            this.radioRealTime.TabStop = true;
            this.radioRealTime.Text = "Show plot lines in real time.";
            this.radioRealTime.UseVisualStyleBackColor = true;
            // 
            // radioEachIteration
            // 
            this.radioEachIteration.AutoSize = true;
            this.radioEachIteration.Location = new System.Drawing.Point(16, 511);
            this.radioEachIteration.Margin = new System.Windows.Forms.Padding(4);
            this.radioEachIteration.Name = "radioEachIteration";
            this.radioEachIteration.Size = new System.Drawing.Size(301, 21);
            this.radioEachIteration.TabIndex = 13;
            this.radioEachIteration.Text = "Show plot lines at the end of each iteration.";
            this.radioEachIteration.UseVisualStyleBackColor = true;
            // 
            // radioNone
            // 
            this.radioNone.AutoSize = true;
            this.radioNone.Location = new System.Drawing.Point(16, 564);
            this.radioNone.Margin = new System.Windows.Forms.Padding(4);
            this.radioNone.Name = "radioNone";
            this.radioNone.Size = new System.Drawing.Size(171, 21);
            this.radioNone.TabIndex = 14;
            this.radioNone.Text = "Do not show plot lines.";
            this.radioNone.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 350);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(438, 17);
            this.label2.TabIndex = 16;
            this.label2.Text = "From which of these applications would you like output files created?";
            this.label2.Visible = false;
            // 
            // fgApps
            // 
            this.fgApps.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.Rows;
            this.fgApps.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.ColumnsUniform;
            this.fgApps.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.fgApps.ColumnInfo = resources.GetString("fgApps.ColumnInfo");
            this.fgApps.ExtendLastCol = true;
            this.fgApps.Location = new System.Drawing.Point(16, 369);
            this.fgApps.Margin = new System.Windows.Forms.Padding(4);
            this.fgApps.Name = "fgApps";
            this.fgApps.Rows.DefaultSize = 17;
            this.fgApps.Size = new System.Drawing.Size(429, 186);
            this.fgApps.TabIndex = 15;
            this.fgApps.Visible = false;
            // 
            // radioEndIterations
            // 
            this.radioEndIterations.AutoSize = true;
            this.radioEndIterations.Location = new System.Drawing.Point(16, 539);
            this.radioEndIterations.Margin = new System.Windows.Forms.Padding(4);
            this.radioEndIterations.Name = "radioEndIterations";
            this.radioEndIterations.Size = new System.Drawing.Size(291, 21);
            this.radioEndIterations.TabIndex = 17;
            this.radioEndIterations.Text = "Show plot lines at the end of all iterations.";
            this.radioEndIterations.UseVisualStyleBackColor = true;
            // 
            // frmSimOptions
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(460, 633);
            this.Controls.Add(this.radioEndIterations);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.radioNone);
            this.Controls.Add(this.radioEachIteration);
            this.Controls.Add(this.radioRealTime);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.fgVars);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.fgApps);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmSimOptions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Simulation Options";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmSimOptions_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.fgVars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgApps)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOK;
        private C1.Win.C1FlexGrid.C1FlexGrid fgVars;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioRealTime;
        private System.Windows.Forms.RadioButton radioEachIteration;
        private System.Windows.Forms.RadioButton radioNone;
        private System.Windows.Forms.Label label2;
        private C1.Win.C1FlexGrid.C1FlexGrid fgApps;
        private System.Windows.Forms.RadioButton radioEndIterations;
    }
}