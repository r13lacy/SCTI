using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.XPath;

namespace MeMoMa
{
    public class MModelStepGroup : MModelStep
    {
        #region MModelStep Members

        private int NumTimeSteps = 1;

        public List<MModelStep> SubSteps = new List<MModelStep>();

        public int GetNumTimeSteps()
        {
            return NumTimeSteps;
        }

        public void SetNumTimeSteps(int numTimeSteps)
        {
            NumTimeSteps = numTimeSteps;
        }

        public bool Simulate(MMMCore.MDataSet dataSet, int iteration, int year)
        {
            for (int i = 0; i < NumTimeSteps; i++)
            {
                for (int j = 0; j < SubSteps.Count; j++)
                    if (!SubSteps[j].Simulate(dataSet, iteration, year))
                        return false;
            }


            return true;
        }

        public bool WriteResults()
        {
            for (int i = 0; i < SubSteps.Count; i++)
                if (!SubSteps[i].WriteResults())
                    return false;

            return true;
        }


        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {

            XmlElement groupNode = doc.CreateElement("Group");
            iNode.AppendChild(groupNode);
            
            XmlElement n = doc.CreateElement("NumTimeSteps");
            n.InnerText = NumTimeSteps.ToString();
            groupNode.AppendChild(n);

            if (SubSteps.Count > 0)
            {
                n = doc.CreateElement("Substeps");
                groupNode.AppendChild(n);

                for (int i = 0; i < SubSteps.Count; i++)
                    SubSteps[i].ToXML(n, doc);
            }

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("NumTimeSteps");
            if (iter.MoveNext())
                NumTimeSteps = Convert.ToInt32(iter.Current.Value);

            iter = n.Select("Substeps");

            if (iter.MoveNext())
            {
                iter = iter.Current.Clone().SelectChildren(XPathNodeType.All);

                while (iter.MoveNext())
                {
                    if (iter.Current.Name == "Group")
                    {
                        MModelStepGroup msg = new MModelStepGroup();
                        msg.LoadXML(iter.Current.Clone(), folderLocation);
                        SubSteps.Add(msg);
                    }
                    else if (iter.Current.Name == "Break")
                    {
                        MModelStepBreak brk = new MModelStepBreak();
                        brk.LoadXML(iter.Current.Clone(), folderLocation);
                        SubSteps.Add(brk);
                    }
                    else if (iter.Current.Name == "Input")
                    {
                        MModelStepInput inp = new MModelStepInput();
                        inp.LoadXML(iter.Current.Clone(), folderLocation);
                        SubSteps.Add(inp);
                    }
                    else if (iter.Current.Name == "Output")
                    {
                        MModelStepOutput o = new MModelStepOutput();
                        o.LoadXML(iter.Current.Clone(), folderLocation);
                        SubSteps.Add(o);
                    }
                    else if (iter.Current.Name == "Evaluator")
                    {
                        MModelStepEvaluator ev = new MModelStepEvaluator();
                        ev.LoadXML(iter.Current.Clone(), folderLocation);
                        SubSteps.Add(ev);
                    }
                    else if (iter.Current.Name == "Step")
                    {
                        XPathNodeIterator it2 = iter.Current.Clone().SelectChildren(XPathNodeType.All);

                        //app index
                        it2.MoveNext();
                        int i = Convert.ToInt32(it2.Current.Value);

                        MModelStepApp msa = new MModelStepApp();
                        msa.App = MModel.MasterAppList[i];

                        it2.MoveNext();
                        msa.SetNumTimeSteps(Convert.ToInt32(it2.Current.Value));

                        SubSteps.Add(msa);


                    }

                }

            }

            return true;
        }

        #endregion
    }
}
