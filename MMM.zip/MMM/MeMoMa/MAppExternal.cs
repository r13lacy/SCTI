using System;
using System.Collections.Generic;
using System.Windows.Forms;
using RLink;
using MMMCore;
using Google.Protobuf;
using System.Xml;
using System.Xml.XPath;
using System.Reflection;
using System.IO;

namespace MeMoMa
{
    public class MAppExternal : MApp
    {
        // The MVariable lists are used for input/output of what variables are shared with MMM
        // can be read from spec files, or added by Initialization() of models.
        private List<MVariable> GlobalVariables = new List<MVariable>();
        private List<MVariable> PopulationVariables = new List<MVariable>();
        private List<MVariable> IndividualVariables = new List<MVariable>();

        private string ProjectFile;

        private string Name;
        private string Description;

        public string SpecFile;

        public string DLLFile;
        public string LibNameSpace;
        public bool IsStandard = false;

//        private bool FirstRun = true;

        private int AppIndex = -1;

        //private bool DoOutput;

        private Assembly Lib = null;
        private object LibObj = null;

        // so we can implement non-standard functions
        public string InitFunction = "Initialize";
        public string SimFunction = "Simulate";
        public string Year0Function = "SimYear0";
        public string CloseFunction = "CloseDLL";

        // in case External App needs them
        public int numYears, numIterations;

        private int appStepCount;
        public void SetAppStepCount(int val) { appStepCount = val; }
        public int GetAppStepCount() { return appStepCount; }
        public string userData;

        public MAppExternal()
        {
            userData = Application.LocalUserAppDataPath.Substring(0, Application.LocalUserAppDataPath.LastIndexOf("\\"));
        }


        public MAppExternal(string specFileName)
        {
            userData = Application.LocalUserAppDataPath.Substring(0, Application.LocalUserAppDataPath.LastIndexOf("\\"));

            LoadSpecFile(specFileName);
        }

        //public ~MAppExternal()
        //{

        //}

        private void LoadSpecFile(string fileName)
        {
            SpecFile = fileName;

            //XML Load File
            XmlDocument doc = new XmlDocument();

            //make sure it is a valid document
            doc.Load(fileName);

            //doc is loaded, start reading

            XPathNavigator Nav = doc.CreateNavigator();
            XPathNodeIterator iter;

            //get the project name, if it has one
            iter = Nav.SelectChildren("MAppSpecs", "");

            if (!iter.MoveNext())
                return;


            iter = Nav.Select("MAppSpecs/Name");
            if (iter.Count == 0) throw new Exception("Name field not defined");
            iter.MoveNext();
            this.Name = iter.Current.Value;

            iter = Nav.Select("MAppSpecs/Description");
            if (iter.Count == 0) throw new Exception("Description field not defined");
            iter.MoveNext();
            this.Description = iter.Current.Value;

            iter = Nav.Select("MAppSpecs/DLL");
            if (iter.Count == 0) throw new Exception("DLL field not defined");
            iter.MoveNext();
            this.DLLFile = iter.Current.Value;

            iter = Nav.Select("MAppSpecs/NameSpace");
            if (iter.Count == 0) throw new Exception("NameSpace field not defined");
            iter.MoveNext();
            this.LibNameSpace = iter.Current.Value;

            iter = Nav.Select("MAppSpecs/Variables/Individual");
            while (iter.MoveNext())
            {
                string Ivar = "";
                XPathNodeIterator iter2 = iter.Current.Select("VarName");
                if (iter2.MoveNext()) Ivar = iter2.Current.Value;

                Type tt = typeof(string);
                iter2 = iter.Current.Select("Type");
                if (iter2.MoveNext()) tt = JPUtils.stringToType(iter2.Current.Value);

                IndividualVariables.Add(new MVariable(Ivar, tt, "", false));
            }

            iter = Nav.Select("MAppSpecs/Variables/Global");
            while (iter.MoveNext())
            {
                string Gvar = "";
                XPathNodeIterator iter2 = iter.Current.Select("VarName");
                if (iter2.MoveNext()) Gvar = iter2.Current.Value;

                Type tt = typeof(double);
                iter2 = iter.Current.Select("Type");
                if (iter2.MoveNext()) tt = JPUtils.stringToType(iter2.Current.Value);

                GlobalVariables.Add(new MVariable(Gvar, tt, "", false));
            }
            //while (iter.MoveNext())
            //{
            //    GlobalVariables.Add(new MVariable(iter.Current.Value, typeof(string), "", false));

            //    //do description, type, etc
            //}

            iter = Nav.Select("MAppSpecs/Variables/Population");
            while (iter.MoveNext())
            {
                string Pvar = "";
                XPathNodeIterator iter2 = iter.Current.Select("VarName");
                if (iter2.MoveNext()) Pvar = iter2.Current.Value;

                Type tt = typeof(string);
                iter2 = iter.Current.Select("Type");
                if (iter2.MoveNext()) tt = JPUtils.stringToType(iter2.Current.Value);

                PopulationVariables.Add(new MVariable(Pvar, tt, "", false));
            }

            iter = Nav.Select("MAppSpecs/Functions/Standard");
            if (iter.MoveNext())
            {
                char c = iter.Current.Value[0];
                this.IsStandard = (c == 'T' || c == 't' || c == '1');
            }

            if (!this.IsStandard)
            {
                //read in function strings
                iter = Nav.Select("MAppSpecs/Functions/Initialize");
                if (iter.MoveNext())
                {
                    this.InitFunction = iter.Current.Value.Trim();
                }
                iter = Nav.Select("MAppSpecs/Functions/Simulate");
                if (iter.MoveNext())
                {
                    this.SimFunction = iter.Current.Value.Trim();
                }
                iter = Nav.Select("MSystemAppSpecs/Functions/Year0");
                if (iter.MoveNext())
                {
                    this.Year0Function = iter.Current.Value.Trim();
                    if (this.Year0Function == "none" || this.Year0Function == "") this.Year0Function = null;
                }
                iter = Nav.Select("MAppSpecs/Functions/Close");
                if (iter.MoveNext())
                {
                    this.CloseFunction = iter.Current.Value.Trim();
                }

            }
            else
            {
                //what do we need to do for a standard library? probably nothing
            }

            try
            {
                Lib = Assembly.LoadFrom(DLLFile);
            }
            catch
            {
                Lib = Assembly.LoadFrom(Application.StartupPath + "\\" + DLLFile); 
            }
            LibObj = Lib.CreateInstance(LibNameSpace);

        }

        //public void SetDoOutput(bool output) { DoOutput = output; }
        //public bool GetDoOutput() { return DoOutput; }


        public int GetAppIndex()
        {
            return AppIndex;
        }

        public void SetAppIndex(int index)
        {
            AppIndex = index;
        }

        public void SaveToXML(string fileName)
        {
            XmlDocument doc = new XmlDocument();
            int i;


            //add top node and name as attrib
            XmlElement topNode = doc.CreateElement("MAppSpecs");
            doc.AppendChild(topNode);

            XmlElement n = doc.CreateElement("Name");
            n.InnerText = this.Name;
            topNode.AppendChild(n);

            n = doc.CreateElement("Description");
            n.InnerText = this.Description;
            topNode.AppendChild(n);

            n = doc.CreateElement("DLL");
            n.InnerText = this.DLLFile;
            topNode.AppendChild(n);

            n = doc.CreateElement("NameSpace");
            n.InnerText = this.LibNameSpace;
            topNode.AppendChild(n);

            n = doc.CreateElement("Variables");
            topNode.AppendChild(n);

            for (i = 0; i < IndividualVariables.Count; i++)
            {
                XmlElement nn = doc.CreateElement("Individual");
//                nn.InnerText = IndividualVariables[i].Name;
                n.AppendChild(nn);

                XmlElement nn2 = doc.CreateElement("VarName");
                nn2.InnerText = IndividualVariables[i].Name.ToString();
                nn.AppendChild(nn2);

                nn2 = doc.CreateElement("Type");
                nn2.InnerText = IndividualVariables[i].VariableType.ToString();
                nn.AppendChild(nn2);
            }


            for (i = 0; i < PopulationVariables.Count; i++)
            {
                XmlElement nn = doc.CreateElement("Population");
//                nn.InnerText = PopulationVariables[i].Name;
                n.AppendChild(nn);

                XmlElement nn2 = doc.CreateElement("VarName");
                nn2.InnerText = PopulationVariables[i].Name.ToString();
                nn.AppendChild(nn2);

                nn2 = doc.CreateElement("Type");
                nn2.InnerText = PopulationVariables[i].VariableType.ToString();
                nn.AppendChild(nn2);
            }

            for (i = 0; i < GlobalVariables.Count; i++)
            {
                XmlElement nn = doc.CreateElement("Global");
                //nn.InnerText = GlobalVariables[i].Name;
                n.AppendChild(nn);

                XmlElement nn2 = doc.CreateElement("VarName");
                nn2.InnerText = GlobalVariables[i].Name.ToString();
                nn.AppendChild(nn2);

                nn2 = doc.CreateElement("Type");
                nn2.InnerText = GlobalVariables[i].VariableType.ToString();
                nn.AppendChild(nn2);
            }


            n = doc.CreateElement("Functions");
            topNode.AppendChild(n);

            if (this.IsStandard)
            {
                XmlElement nn = doc.CreateElement("Standard");
                nn.InnerText = "True";
                n.AppendChild(nn);
            }
            else
            {
                XmlElement nn = doc.CreateElement("Standard");
                nn.InnerText = "False";
                n.AppendChild(nn);
                nn = doc.CreateElement("Initialize");
                nn.InnerText = InitFunction;
                n.AppendChild(nn);
                nn = doc.CreateElement("Simulate");
                nn.InnerText = SimFunction;
                n.AppendChild(nn);
                nn = doc.CreateElement("Year0");
                if (Year0Function == null) nn.InnerText = "none";
                else nn.InnerText = Year0Function;
                n.AppendChild(nn);
                nn = doc.CreateElement("Close");
                nn.InnerText = CloseFunction;
                n.AppendChild(nn);
            }

            doc.Save(fileName);
            
        }


        public override string ToString()
        {
            return GetName() + " - " + GetDescription();
        }


        //INHERITED FROM MApp
        public string GetName()
        {
            return this.Name;
        }

        public string GetDescription()
        {
            return this.Description;
        }

        public List<MVariable> GetGlobalVariables()
        {
            return GlobalVariables;
        }

        // Sets by Bob

        public void SetNumYears(int val) { numYears = val; }
        public void SetNumIter(int val) { numIterations = val; }

        public void SetName(string name)
        {
            Name = name;
        }

        public void SetDescription(string descr)
        {
            Description = descr;
        }

        public void SetGlobalVariables(List<MVariable> vlist)
        {
            GlobalVariables = vlist;
        }

        public string GetProjectFile()
        {
            return ProjectFile;
        }

        public void SetProjectFile(string fileName)
        {
            ProjectFile = fileName;
        }

        public List<MVariable> GetPopulationVariables()
        {
            return PopulationVariables;
        }

        public List<MVariable> GetIndividualVariables()
        {
            return IndividualVariables;
        }

        public void SetPopulationVariables(List<MVariable> vlist)
        {
            PopulationVariables = vlist;
        }

        public void SetIndividualVariables(List<MVariable> vlist)
        {
            IndividualVariables = vlist;
        }


        public bool Init(MDataSet dataSet, int totalTimeStepsToRun)
        {
            Type t = Lib.GetType(LibNameSpace);

            MethodInfo mm;
            ParameterInfo[] pp;

            try
            {
                mm = t.GetMethod(InitFunction);
                pp = mm.GetParameters();

                //the first param is either the dataset or population...  find out which
                if (pp[0].ParameterType.FullName == "MMMCore.MDataSet")
                {
                    if (pp.Length == 4)
                    {
                        mm.Invoke(LibObj, new object[4] { dataSet, ProjectFile, numIterations, numYears });
                    }
                    else if (pp.Length == 5)
                    {
                        mm.Invoke(LibObj, new object[5] { dataSet, ProjectFile, numIterations, numYears, totalTimeStepsToRun });
                    }
                    else mm.Invoke(LibObj, new object[2] { dataSet, ProjectFile });
                }
                else if (pp[0].ParameterType.FullName == "MMMCore.MPopulation")
                {
                    if (pp.Length == 4)
                    {
                        mm.Invoke(LibObj, new object[4] { dataSet.Populations[0], ProjectFile, numIterations, numYears });
                    }
                    else if (pp.Length == 5)
                    {
                        mm.Invoke(LibObj, new object[5] { dataSet.Populations[0], ProjectFile, numIterations, numYears, totalTimeStepsToRun });
                    }
                    else mm.Invoke(LibObj, new object[2] { dataSet.Populations[0], ProjectFile });
                }
                else if (pp[0].ParameterType.BaseType.Name.StartsWith("IMessage")) // need to check if it's a protobuf object. they won't necessarily put it in the RLink namespace
                {
                    ProjMessage sendToExternal = SerializeData(dataSet);
                    ProjMessage fromExternal = null;
                    // Need to make it so the signature for the external app returns a projMessage
                    if (pp.Length == 4)
                    {
                       fromExternal = (ProjMessage)mm.Invoke(LibObj, new object[4] { sendToExternal, ProjectFile, numIterations, numYears });
                    }
                    else if (pp.Length == 5)
                    {
                        fromExternal = (ProjMessage)mm.Invoke(LibObj, new object[5] { sendToExternal, ProjectFile, numIterations, numYears, totalTimeStepsToRun });
                    }
                    else fromExternal = (ProjMessage)mm.Invoke(LibObj, new object[2] { sendToExternal, ProjectFile });

                    if (fromExternal != null) // if their init() method didn't do something with the data, we'll just leave it as it was
                    {
                        DeSerializeData(dataSet, fromExternal);
                    }
                    
                    // If it is null, then the init() didn't work (equivalent of returning false for other external app init() methods)
                }
                else // assume it is passing a file
                {
                    //                    string filename = "xchangefile.txt";
                    string filename = ProjectFile.Substring(0, ProjectFile.LastIndexOf('\\') + 1) + "xchangefile.txt";

                    WriteDataFile(dataSet, filename, numIterations, numYears, totalTimeStepsToRun);
                    // note: most init functions wouldn't need the dataSet, but it shouldn't hurt, and some might

                    if (pp.Length == 4)
                    {
                        mm.Invoke(LibObj, new object[4] { filename, ProjectFile, numIterations, numYears });
                    }
                    else if (pp.Length == 5)
                    {
                        mm.Invoke(LibObj, new object[5] { filename, ProjectFile, numIterations, numYears, totalTimeStepsToRun });
                    }
                    else mm.Invoke(LibObj, new object[2] { filename, ProjectFile });

                    ReadDataFile(dataSet, filename);
                }
            }
            catch { return false; }

            return true;
        }


        public bool DoTurn(MDataSet dataSet, int numTimeSteps, int iteration, int year)
        {
            Type t = Lib.GetType(LibNameSpace);

            MethodInfo mm;
            ParameterInfo[] pp;
            
            // moved to Init
//            if (FirstRun)
//            {
//                mm = t.GetMethod(InitFunction);
//                pp = mm.GetParameters();

//                //the first param is either the dataset or population...  find out which
//                if (pp[0].ParameterType.FullName == "MMMCore.MDataSet")
//                {
//                    if (pp.Length == 4)
//                    {
//                        mm.Invoke(LibObj, new object[4] { dataSet, ProjectFile, numIterations, numYears });
//                    }
//                    else if (pp.Length == 5)
//                    {
//                        mm.Invoke(LibObj, new object[5] { dataSet, ProjectFile, numIterations, numYears, numTimeSteps });
//                    }
//                    else mm.Invoke(LibObj, new object[2] { dataSet, ProjectFile });
//                }
//                else if (pp[0].ParameterType.FullName == "MMMCore.MPopulation")
//                {
//                    if (pp.Length == 4)
//                    {
//                        mm.Invoke(LibObj, new object[4] { dataSet.Populations[0], ProjectFile, numIterations, numYears });
//                    }
//                    else if (pp.Length == 5)
//                    {
//                        mm.Invoke(LibObj, new object[5] { dataSet.Populations[0], ProjectFile, numIterations, numYears, numTimeSteps });
//                    }
//                    else mm.Invoke(LibObj, new object[2] { dataSet.Populations[0], ProjectFile });
//                }
//                else // assume it is passing a file
//                {
////                    string filename = "xchangefile.txt";
//                    string filename = ProjectFile.Substring(0, ProjectFile.LastIndexOf('\\') + 1) + "xchangefile.txt";

//                    WriteDataFile(dataSet, filename, iteration, year, numTimeSteps); 
//                    // note: most init functions wouldn't need the dataSet, but it shouldn't hurt, and some might

//                    if (pp.Length == 4)
//                    {
//                        mm.Invoke(LibObj, new object[4] { filename, ProjectFile, numIterations, numYears });
//                    }
//                    else if (pp.Length == 5)
//                    {
//                        mm.Invoke(LibObj, new object[5] { filename, ProjectFile, numIterations, numYears, numTimeSteps });
//                    }
//                    else mm.Invoke(LibObj, new object[2] { filename, ProjectFile });

//                    ReadDataFile(dataSet, filename);
//                }

//                FirstRun = false;

//            } 

                mm = t.GetMethod(SimFunction); 

                pp = mm.GetParameters();

                //the first param is either the dataset or population... or a filename ... find out which
                if (pp[0].ParameterType.FullName == "MMMCore.MDataSet")
                    return Convert.ToBoolean(mm.Invoke(LibObj, new object[4] { dataSet, iteration, year, numTimeSteps }));
                else if (pp[0].ParameterType.FullName == "MMMCore.MPopulation")
                    return Convert.ToBoolean(mm.Invoke(LibObj, new object[4] { dataSet.Populations[0], iteration, year, numTimeSteps }));
                else if (pp[0].ParameterType.BaseType.Name.StartsWith("IMessage")) // need to check if it's a protobuf object
                {
                    ProjMessage sendToExternal = SerializeData(dataSet);
                    ProjMessage fromExternal = null;
                    // Need to make it so the signature for the external app returns a projMessage
                    // IMessage MData, int iter, int year, int numTimeSteps
                    try
                    {
                        fromExternal = (ProjMessage)mm.Invoke(LibObj, new object[4] { sendToExternal, iteration, year, numTimeSteps });
                        DeSerializeData(dataSet, fromExternal);
                        return true;
                    }
                    catch 
                    {
                        return false;
                    }
                }

            else // assume it is passing a filename 
            {
//                    string filename = "xchangefile.txt";
                    string filename = ProjectFile.Substring(0, ProjectFile.LastIndexOf('\\') + 1) + "xchangefile.txt";

                    WriteDataFile(dataSet, filename, iteration, year, numTimeSteps);
                    Convert.ToBoolean(mm.Invoke(LibObj, new object[4] { filename, iteration, year, numTimeSteps }));
                    ReadDataFile(dataSet, filename);
                }                    
//            }

            return true;
        }


        // 19 dec 2014
        public bool DoYear0(MDataSet dataSet, int iteration)
        {
            if (Year0Function == null || Year0Function == "" || Year0Function == "none") return true;

            try
            {
                Type t = Lib.GetType(LibNameSpace);

                MethodInfo mm;
                ParameterInfo[] pp;

                mm = t.GetMethod(Year0Function);

                pp = mm.GetParameters();

                if (pp[0].ParameterType.FullName == "MMMCore.MDataSet")
                {
                    if (pp[1].ParameterType.FullName == "MMMCore.MPopulation")
                    {
                        return Convert.ToBoolean(mm.Invoke(LibObj, new object[3] { dataSet, dataSet.Populations[0], iteration }));
                    }
                    else
                    {
                        return Convert.ToBoolean(mm.Invoke(LibObj, new object[2] { dataSet, iteration }));
                    }
                }
                else if (pp[0].ParameterType.FullName == "MMMCore.MPopulation")
                {
                    return Convert.ToBoolean(mm.Invoke(LibObj, new object[2] { dataSet.Populations[0], iteration }));
                }
                else // assume it is passing a filename 
                {
                    //string filename = "xchangefile.txt";
                    string filename = ProjectFile.Substring(0, ProjectFile.LastIndexOf('\\') + 1) + "xchangefile.txt";

                    WriteDataFile(dataSet, filename, iteration, 0, 1);  // not needed before Year0 setup?

                    bool a = Convert.ToBoolean(mm.Invoke(LibObj, new object[2] { filename, iteration }));

                    ReadDataFile(dataSet, filename);
                    return a;
                }
            }
            catch (Exception ex)
            {
                var mes = ex.Message;
                return false;
            }
        }



        // note that there is a very similar function in MDataSet, but it outputs all vars, not just those in MAppExternal

        public void WriteDataFile(MDataSet dataSet, string fileLocation, int iteration, int year, int numTimeSteps)
        {
            WriteDataFile(dataSet, fileLocation, iteration, year, numTimeSteps, false);
        }

        public void WriteDataFile(MDataSet dataSet, string fileLocation, int iteration, int year, int numTimeSteps, bool popbase)
        {
            //Creator = MMM ...
            //Iteration = 1, Year = 50, Timesteps = 5
            //GlobalVariables, NumGS Vars = 2
            //GS1, GS2
            //1.0000,2.0000
            //PopulationVariables, NumPS Vars = 2, Population 1: PopName
            //PS1,PS2
            //22.000000; 11.000000
            //PopulationSize = 100
            //AgeStructure
            //Females: 12;22;33
            //Males: 32;12;11
            //IndividualVariables, NumISVars = 2
            //Name,Index,Age,Sex,Var1,Var2
            //33;0;11688;0;33.00000000;34.00000000
            //35;1;11688;1;33.00000000;34.00000000
            //PopulationVariables, NumPS Vars = 2, Population 2: PopName
            //PS1,PS2
            //222.000000; 111.000000
            //IndividualVariables, NumISVars = 2
            //Name,Index,Age,Sex,Var1,Var2
            //33;0;11688;0;33.00000000;34.00000000
            //35;1;11688;1;33.00000000;34.00000000

            using (StreamWriter writer = new StreamWriter(fileLocation, false))
            {

                writer.WriteLine("MData File Created by MMM - " + DateTime.Now.ToLongDateString());
                writer.WriteLine("Iteration = " + iteration.ToString() + ", Year = " + year.ToString() + ", Timesteps = " + numTimeSteps.ToString());
                writer.WriteLine("GlobalVariables, NumGSVars = " + GlobalVariables.Count.ToString());

                if (GlobalVariables.Count > 0)
                {
                    writer.Write(GlobalVariables[0].Name);
                    for (int j = 1; j < GlobalVariables.Count; j++)
                    {
                        writer.Write("," + GlobalVariables[j].Name);
                    }
                    writer.WriteLine();

                    // New
                    writer.Write(GlobalVariables[0].GetType().ToString());
                    for (int j = 1; j < GlobalVariables.Count; j++)
                    {
                        writer.Write("," + GlobalVariables[j].GetType().ToString());
                    }
                    writer.WriteLine();

                    string sGV = "";
                    int[] GVs = new int[GlobalVariables.Count];
                    for (int i = 0; i < GlobalVariables.Count; i++)
                    {
                        GVs[i] = dataSet.GetVarIndex(GlobalVariables[i].Name); // note: GlobalVariables within MAppExternal might be a subset of all GSvars in MData
                        //                    if (GVs[i] >= 0) sGV += dataSet.Vars[GVs[i]] + ";";
                        if (GVs[i] >= 0) sGV += dataSet.GetVarVal(GVs[i]) + ";";
                        else sGV += "0;";
                    }
                    writer.WriteLine(sGV.Trim(';'));
                }

                for (int p = 0; p < dataSet.Populations.Count; p++)
                {
                    MPopulation mpop = dataSet.Populations[p];

                    writer.WriteLine("PopulationVariables, NumPSVars = " + PopulationVariables.Count.ToString() + ", Population " + (p + 1).ToString() + ": " + mpop.Name);

                    if (PopulationVariables.Count > 0)
                    {
                        writer.Write(PopulationVariables[0].Name);
                        for (int j = 1; j < PopulationVariables.Count; j++)
                            writer.Write("," + PopulationVariables[j].Name);
                        writer.WriteLine();

                        string sPV = "";
                        int[] PVs = new int[PopulationVariables.Count];
                        for (int i = 0; i < PopulationVariables.Count; i++)
                        {
                            PVs[i] = mpop.GetVarIndex(PopulationVariables[i].Name);
                            if (PVs[i] >= 0) sPV += mpop.Vars[PVs[i]] + ";";
                            else sPV += "0;";
                        }
                        writer.WriteLine(sPV.Trim(';'));
                    }

                    writer.WriteLine("PopulationSize = " + mpop.Nindividuals.ToString());
                    //if (mpop.Females.Count > 0 || mpop.Males.Count > 0)
                    //{
                        writer.WriteLine("AgeStructure");
                        string tally = "Females: ";
                        for (int j = 0; j < mpop.Females.Count; j++) tally += mpop.Females[j].ToString() + ";";
                        writer.WriteLine(tally.Trim(';'));
                        tally = "Males: ";
                        for (int j = 0; j < mpop.Males.Count; j++) tally += mpop.Males[j].ToString() + ";";
                        writer.WriteLine(tally.Trim(';'));
                    //}

                    if (!popbase && IndividualVariables.Count > 1) // check of .Count will often catch popbased programs that didn't declare popbase
                    {
                        writer.WriteLine("IndividualVariables, NumISVars = " + IndividualVariables.Count.ToString());

                        writer.Write(IndividualVariables[0].Name);
                        for (int j = 1; j < IndividualVariables.Count; j++)
                            writer.Write("," + IndividualVariables[j].Name);
                        writer.Write(writer.NewLine);

                        if (mpop.IndList.Count > 0)
                        {
                            int[] varInds = new int[IndividualVariables.Count];
                            for (int j = 0; j < IndividualVariables.Count; j++)
                                varInds[j] = mpop.GetIndividualVarIndex(IndividualVariables[j].Name);

                            for (int m = 0; m < mpop.IndList.Count; m++)
                            {
                                string sLine = "";

                                for (int j = 0; j < varInds.Length; j++)
                                    sLine += ";" + mpop.IndList[m].Vars[varInds[j]];

                                writer.WriteLine(sLine.Substring(1));
                            }
                        }
                    }
                }
                writer.Close();
            }
        }

        private void ReadDataFile(MDataSet dataSet, string fileLocation)
        {
            int lIndex;
            int popIndex = 0;

            List<string> lines = JPUtils.ReadFileToList(fileLocation);

            string[] ss, ss1, ss2;
            char[] delims = { ',', ' ', ';', '\t', '=' }; // don't use commas to separate numbers, EU format problem
            char[] delims1 = { ' ', ';', '\t' }; // don't use commas to separate numbers, EU format problem

            //GLOBAL VARS
            lIndex = 2;
            if (lines.Count > lIndex + 1 && lines[lIndex].StartsWith("GlobalVar") && !lines[++lIndex].StartsWith("PopulationVar")) // otherwise, no GSvars
            {
                ss = lines[lIndex].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                ss2 = lines[++lIndex].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                ss1 = lines[++lIndex].Split(delims1, StringSplitOptions.RemoveEmptyEntries);

                for (int j = 0; j < ss.Length; j++)
                {
                    string ssName = ss[j].Trim();
                    string ssVal = "0";
                    string ssType = "double";
                    Type tt = typeof(double);

                    if (ss1.Length > j) ssVal = ss1[j].Trim();
                    if (ss2.Length > j)
                    {
                        ssType = ss2[j].Trim();
                        tt = JPUtils.stringToType(ssType);
                    }

                    int k = MVariable.VarListIndexOf(GlobalVariables, ssName);
                    if (k < 0)
                        GlobalVariables.Add(new MVariable(ssName, tt, "", false)); // add to MApp if missing
                        //GlobalVariables.Add(new MVariable(ssName, typeof(string), "", false)); // add to MApp if missing

                    k = dataSet.GetVarIndex(ssName); // add to MData if missing
                    if (k < 0) dataSet.AddVar(ssName, ssVal, tt);
                    else dataSet.SetVarVal(k, ssVal);
                    //else dataSet.Vars[k] = ssVal;
                }
                ++lIndex;
            }

            //Population VARS
            while (lines.Count > lIndex + 1 && lines[lIndex].StartsWith("PopulationVar") && !lines[++lIndex].StartsWith("IndividualVar")) // otherwise, no PSvars
            {
                MPopulation mpop = dataSet.Populations[popIndex++];


                ss = lines[lIndex].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                ss2 = lines[++lIndex].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                ss1 = lines[++lIndex].Split(delims1, StringSplitOptions.RemoveEmptyEntries);

                //make sure has pop vars
                for (int j = 0; j < ss.Length; j++)
                {
                    string ssName = ss[j].Trim();
                    string ssVal = "0";
                    string ssType = "string"; // temporary
                    Type tt = typeof(string);

                    if (ss1.Length > j) ssVal = ss1[j].Trim();

                    if (ss2.Length > j)
                    {
                        ssType = ss2[j].Trim();
                        tt = JPUtils.stringToType(ssType);
                    }

                    int k = MVariable.VarListIndexOf(PopulationVariables, ssName);
                    if (k < 0)
                        PopulationVariables.Add(new MVariable(ssName, tt, "", false));

                    k = mpop.GetVarIndex(ssName);
                    if (k < 0) mpop.AddVar(ssName, ssVal, tt);
                    else mpop.Vars[k] = ssVal;
                }
                                
                ++lIndex;

                // Read age structure, for pop-based models

                if (lines[lIndex].StartsWith("PopulationSize"))
                {
                    if (lines.Count > lIndex)
                    {
                        ss = lines[lIndex++].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                        mpop.Nindividuals = Convert.ToInt32(ss[1]);
                    }
                }

                mpop.Females.Clear();
                mpop.Males.Clear();
                if (lines[lIndex++].StartsWith("AgeStructure"))
                {
                    if (lines.Count > lIndex)
                    {
                        ss = lines[lIndex++].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                        for (int j = 1; j < ss.Length; j++) mpop.Females.Add(Convert.ToInt32(ss[j]));
                    }

                    if (lines.Count > lIndex)
                    {
                        ss = lines[lIndex++].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                        for (int j = 1; j < ss.Length; j++) mpop.Males.Add(Convert.ToInt32(ss[j]));
                    }

//                    mpop.Count();
                }
                if (mpop.Females.Count > 0 || mpop.Males.Count > 0) mpop.Count(); 
                // otherwise assume that model didn't pass back age-sex structure

                //IND VARS, embedded within mpop
                //                if (!popbase)
                //                {
                int namePlace = 0;
                if (lines.Count > lIndex + 1 && lines[lIndex].StartsWith("IndividualVar") && !lines[++lIndex].StartsWith("PopulationVar")) // otherwise, no Individuals
                {
                    ss = lines[lIndex].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                    ss2 = lines[++lIndex].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                    int[] inds = new int[ss.Length];

                    //make sure has ind vars
                    for (int j = 0; j < ss.Length; j++)
                    {
                        string ssName = ss[j].Trim();
                        string ssType = "string";
                        Type tt = typeof(string);

                        if (ss2.Length > j)
                        {
                            ssType = ss2[j].Trim();
                            tt = JPUtils.stringToType(ssType);
                        }

                        //add var to individual vars if need to
                        if (MVariable.VarListIndexOf(IndividualVariables, ssName) < 0)
                            IndividualVariables.Add(new MVariable(ssName, tt, "", false));

                        int k = mpop.GetIndividualVarIndex(ssName);
                        if (k < 0) mpop.AddIndVar(ssName, "-1", tt);
                        inds[j] = k;

                        if (ssName == "Name") namePlace = j;
                    }


                    bool[] used = new bool[mpop.IndList.Count];
                    for (int m = 0; m < mpop.IndList.Count; m++) used[m] = false;
                    int mi = 0;

                    while (lines.Count > ++lIndex && !lines[lIndex].StartsWith("PopulationVar")) // otherwise, end of individuals in that pop
                    {
                        ss1 = lines[lIndex].Split(delims1); // don't remove empty entries, because indVars can be empty

                        string ssName = ss[namePlace].Trim();

                        int pos = mpop.GetMIndividualIndexFromName(mi, ssName);

                        MIndividual individual = null;

                        if (pos < 0)
                        {
                            individual = new MIndividual(mpop);
                        }
                        else
                        {
                            individual = mpop.IndList[pos];
                            used[pos] = true;
                            mi++;
                        }

                        for (int j = 0; j < ss1.Length; j++)
                        {
                            individual.Vars[inds[j]] = ss1[j];
                        }
                    }

                    //clean up lists -- remove missing animals from the list
                    if (used.Length > 0)
                    {
                        for (int j = used.Length - 1; j >= 0; j--)
                            if (!used[j]) mpop.IndList.RemoveAt(j);
                    }

                    mpop.tallyPopulation();
                }
                //                }
            }
        }

        // methods to serialize and deserialize protobuf format files
        /// <summary>
        /// Compress MMM's current working data into protobuf format. Uses MMMProto.proto
        /// </summary>
        /// <param name="dataSet">MMM's current working data.</param>
        public ProjMessage SerializeData(MDataSet dataSet)
        {
            string ProjectDir = ProjectFile.Substring(0, ProjectFile.LastIndexOf("\\"));

            // Serialize the data (but only the variables this app has access to)
            // See the proto message definition file: MMMProto.proto located in MMM install directory
            ProjMessage myProjMessage = new ProjMessage();
            if (GlobalVariables.Count >0)
            {
                for (int i = 0; i < GlobalVariables.Count; i++)
                {
                    // GSVarNames = Global State Var names for the project
                    myProjMessage.GSVarNames.Add(GlobalVariables[i].Name);
                    // GSVars = Global State Var values for the project
                    // Have to get the correct index for each var
                    int gsvarIndex = dataSet.GetVarIndex(GlobalVariables[i].Name);
                    myProjMessage.GSVars.Add(dataSet.Vars[gsvarIndex].ToString());
                }
            }
            for (int i = 0; i < dataSet.Populations.Count; i++)
            {
                PopMessage myPopMessage = new PopMessage();
                if (PopulationVariables.Count >0)
                {
                    for (int j = 0; j < PopulationVariables.Count; j++)
                    {
                        // PopVarNames = Population Var names for this population
                        myPopMessage.PopVarNames.Add(PopulationVariables[j].ToString());

                        // PopVars = Population Var values for this population
                        // Add the pop var value if that var exists for that pop; else add 0
                        if (dataSet.Populations[i].GetVarIndex(PopulationVariables[j].ToString()) >= 0)
                        {
                            // Have to get the correct index for each var
                            int psvarIndex = dataSet.Populations[i].GetVarIndex(PopulationVariables[j].Name);
                            myPopMessage.PopVars.Add(dataSet.Populations[i].Vars[psvarIndex].ToString());
                        }
                        else
                            myPopMessage.PopVars.Add("0");
                    }
                }
                if (IndividualVariables.Count >0)
                {
                    for (int j = 0; j < IndividualVariables.Count; j++)
                    {
                        // IndivVarNames = Individual Var names for individuals in this pop
                        myPopMessage.IndivVarNames.Add(dataSet.Populations[i].IndVarNames[j]);
                        myPopMessage.IndivVarNames.Add(IndividualVariables[j].Name);
                    }
                    for (int j = 0; j < dataSet.Populations[i].IndList.Count; j++)
                    {
                        IndivMessage myIndivMessage = new IndivMessage();
                        for (int k = 0; k < IndividualVariables.Count; k++)
                        {
                            // MyVars = Individual Var values for this individual
                            // Have to get the correct index for each var
                            int indvarIndex = dataSet.Populations[i].GetIndividualVarIndex(IndividualVariables[k].Name);
                            myIndivMessage.MyVars.Add(dataSet.Populations[i].IndList[j].Vars[indvarIndex].ToString());
                        }
                        myPopMessage.MyIndivs.Add(myIndivMessage);
                    }
                }
                myProjMessage.MyPops.Add(myPopMessage);
            }
            // Serialized data is saved in the ProjectDir as tempData.dat
            // ProjectDir is the directory where your project file is (set by interaction with the GUI).
            // If you don't have a project file, you'll need to adjust the code to set the project directory
            using (var writer = File.Create(ProjectDir + "\\tempData.dat"))
            {
                myProjMessage.WriteTo(writer);
            }
            return myProjMessage;
        }

        /// <summary>
        /// Read protobuf serialized data back into MMM's working data class.
        /// </summary>
        /// <param name="MMsData">MMM's working data, passed as a param to DoTurn.</param>
        /// <param name="modifiedData">IMessage in the format of MMMProto.proto.</param>
        public void DeSerializeData(MDataSet MMsData, IMessage modifiedData)
        {
            // 9-26-16: I've modified the following lines to use a ProjMessage passed as a parameter or return statement
            // from the external app's method instead of saved as a file.

            //string ProjectDir = ProjectFile.Substring(0, ProjectFile.LastIndexOf("\\"));

            //// Read it from where external model saved it
            //if (!File.Exists(ProjectDir + "\\tempData.dat"))
            //{
            //    MessageBox.Show("File " + ProjectDir + "\\tempData.dat" + " not found. Using data pre-model run");
            //    return;
            //}

            //byte[] input = File.ReadAllBytes(ProjectDir + "\\tempData.dat");
            //importThisProj = ProjMessage.Parser.ParseFrom(input);
            // clear the byte[]
            //Array.Clear(input, 0, input.Length);

            ProjMessage importThisProj;
            importThisProj = (ProjMessage)modifiedData;

            /* Put the serialized data back into MDataSet. 
            * See comments in SerializeData() for definitions of variable names.
            * 
            * This code looks to find MMM's index for the variables from the serialized data and adds the serialized data variables to MMsData
            * if it can't find them. It replaces MMsData's values for the variables that were passed to the model with the values in the 
            * model's output serialized data.
            * 
            * I'm pretty sure all the ToString()'s are superfluous since the data should come out of the proto message as strings,
            * but I'm leaving them there just in case.
            */

            // Global Vars
            if (GlobalVariables.Count >0)
            {
                for (int i = 0; i < GlobalVariables.Count; i++)
                {
                    // Have to get the correct index for each var
                    int gsvarIndex = MMsData.GetVarIndex(GlobalVariables[i].Name); ;
                    if (gsvarIndex > -1)
                        MMsData.Vars[gsvarIndex] = importThisProj.GSVars[i].ToString();
                    else
                    {
                        // Add the variable and its name to the appropriate lists
                        MMsData.VarNames.Add(GlobalVariables[i].Name);
                        MMsData.Vars.Add(GlobalVariables[i]);
                    }
                }
            }

            // Population Vars
            for (int i = 0; i < MMsData.Populations.Count; i++)
            {
                if (PopulationVariables.Count >0)
                {
                    for (int j = 0; j < PopulationVariables.Count; j++)
                    {
                        // Have to get the correct index for each var
                        int psvarIndex = MMsData.Populations[i].GetVarIndex(PopulationVariables[j].Name);
                        if (psvarIndex > -1)
                            MMsData.Populations[i].Vars[psvarIndex] = importThisProj.MyPops[i].PopVars[j].ToString();
                        else
                        {
                            // Add the variable name to the list of pop vars for this pop
                            MMsData.Populations[i].VarNames.Add(PopulationVariables[j].Name);
                            // Add the var value
                            MMsData.Populations[i].Vars.Add(PopulationVariables[j].ToString());
                        }
                    }
                }

                // Individual Vars
                if (IndividualVariables.Count >0)
                {
                    for (int k = 0; k < IndividualVariables.Count; k++)
                    {
                        // Have to get the correct index for each var
                        int indvarIndex = MMsData.Populations[i].GetIndividualVarIndex(IndividualVariables[k].Name);
                        if (indvarIndex > -1)
                        {
                            for (int l = 0; l < MMsData.Populations[i].IndList.Count; l++)
                            {
                                MMsData.Populations[i].IndList[l].Vars[indvarIndex] = importThisProj.MyPops[i].MyIndivs[l].MyVars[k].ToString();
                            }
                        }
                        else
                        {
                            // Add the variable name to the list of individual vars for that pop
                            MMsData.Populations[i].IndVarNames.Add(IndividualVariables[k].Name);
                            // Add the variable value for each individual
                            for (int l = 0; l < MMsData.Populations[i].IndList.Count; l++)
                            {
                                MMsData.Populations[i].IndList[l].Vars.Add(importThisProj.MyPops[i].MyIndivs[l].MyVars[k].ToString());
                            }

                        }
                    }
                }
            }
        }


        public bool WriteResults()
        { 
            Type t = Lib.GetType(LibNameSpace);
            MethodInfo mm;

            mm = t.GetMethod(CloseFunction);

            return Convert.ToBoolean(mm.Invoke(LibObj, null));

        }

        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("External");
            iNode.AppendChild(appNode);

            XmlElement n = doc.CreateElement("AppSpecFile");
            n.InnerText = SpecFile.Substring(SpecFile.LastIndexOf("\\") + 1);
            appNode.AppendChild(n);
            
            n = doc.CreateElement("ProjectFile");
            n.InnerText = ProjectFile;
            //n.InnerText = ProjectFile.Substring(ProjectFile.LastIndexOf("\\") + 1);
            appNode.AppendChild(n);

            return true;
        }


        public bool ToXMLShort(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("External");
            appNode.InnerText = AppIndex.ToString();
            iNode.AppendChild(appNode);

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("AppSpecFile");
            if (iter.MoveNext())
                LoadSpecFile(userData + "\\" + iter.Current.Value);

            iter = n.Select("ProjectFile");
            if (iter.MoveNext())
            {
                ProjectFile = iter.Current.Value;
                if (!ProjectFile.Contains("\\")) ProjectFile = folderLocation + "\\" + ProjectFile;
            }
            //ProjectFile = folderLocation + "\\" + iter.Current.Value;

            return true;
        }

    }
}
