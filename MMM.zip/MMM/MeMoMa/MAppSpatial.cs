using System.Collections.Generic;

using System.Xml;
using System.Xml.XPath;

using MMMCore;

namespace MeMoMa
{
    public class MAppSpatial : MApp
    {

        private List<MVariable> GlobalVariables = new List<MVariable>();
        private List<MVariable> PopulationVariables = new List<MVariable>();
        private List<MVariable> IndividualVariables = new List<MVariable>();

        private string ProjectFile;

        private MetaSpatial.Meta SpatialLib = null;

        private bool FirstRun = true;

        public int PopStartIndex, NumPops;

        private int AppIndex;
//        private bool DoOutput;


        public MAppSpatial()
        {
            PopulationVariables.Add(new MVariable("Landscape Width", typeof(int), "Width of the landscape", false));
            PopulationVariables.Add(new MVariable("Landscape Height", typeof(int), "Height of the landscape", false));
            IndividualVariables.Add(new MVariable("X", typeof(int), "Location of the individual", false));
            IndividualVariables.Add(new MVariable("Y", typeof(int), "Location of the individual", false));

        }


        public override string ToString()
        {
            return GetName() + " - " + GetDescription();
        }


        //public void SetDoOutput(bool output) { DoOutput = output; }
        //public bool GetDoOutput() { return DoOutput; }

        //INHERITED FROM MApp

        // Bob -- in case needed
        private int appStepCount;
        public void SetAppStepCount(int val) { appStepCount = val; }
        public int GetAppStepCount() { return appStepCount; }

        public string GetName()
        {
            return "Spatial";
        }

        public string GetDescription()
        {
            return "Stochastic Dispersal Model";
        }

        public string GetProjectFile()
        {
            return ProjectFile;
        }

        public void SetProjectFile(string fileName)
        {
            ProjectFile = fileName;
        }

        public List<MVariable> GetGlobalVariables()
        {
            return GlobalVariables;
        }

        public List<MVariable> GetPopulationVariables()
        {
            return PopulationVariables;
        }

        public List<MVariable> GetIndividualVariables()
        {
            return IndividualVariables;
        }


        int currentIteration = -1;

        public bool DoTurn(MDataSet dataSet, int numTimeSteps, int iteration, int year)
        {
            if (FirstRun)
            {
                SpatialLib = new MetaSpatial.Meta();

//                if (!SpatialLib.LoadProject(ProjectFile))
//                    return false;

                FirstRun = false;
                currentIteration = -1;
            }

            // Bob's attempt to reset locations for each iteration
            if (currentIteration != iteration) // a new iteration is about to start
            {
                if (!SpatialLib.LoadProject(ProjectFile))
                    return false;

                currentIteration = iteration;
            }


            //check if extinct, if so, no spatial!
            bool[] extinct = new bool[NumPops];
            int exCount = 0;
            for (int i = 0; i < NumPops; i++)
            {
                if (dataSet.Populations[i + PopStartIndex].IndList.Count == 0)
                {
                    extinct[i] = (dataSet.Populations[i + PopStartIndex].IndList.Count == 0);
                    exCount++;
                }
            }

            if (exCount == NumPops)
                return true;

            //make sure pop has individual vars
            for (int i = PopStartIndex; i < PopStartIndex + NumPops; i++)
            {
                //for (int k = 0; k < IndividualVariables.Count; k++)
                //{
                //    for (int j = 0; j < dataSet.Populations[i].IndList.Count; j++)
                //    {

                //        if (dataSet.Populations[i].IndList[j].VarNames.IndexOf(IndividualVariables[k].Name) < 0)
                //        {
                //            dataSet.Populations[i].IndList[j].VarNames.Add(IndividualVariables[k].Name);
                //            dataSet.Populations[i].IndList[j].Vars.Add("0");
                //            dataSet.Populations[i].IndList[j].VarTypes.Add(IndividualVariables[k].VariableType);
                //        }
                //    }
                //}
                for (int k = 0; k < IndividualVariables.Count; k++)
                {
                    if (dataSet.Populations[i].GetIndividualVarIndex(IndividualVariables[k].Name) < 0)
                    {
                        dataSet.Populations[i].AddIndVar(IndividualVariables[k].Name, "0",IndividualVariables[k].VariableType);
                    }
                }
            }


            List<MPopulation> pops = new List<MPopulation>();

            for (int i = PopStartIndex; i < PopStartIndex + NumPops; i++)
                pops.Add(dataSet.Populations[i]);

            return SpatialLib.Simulate(pops, numTimeSteps);

        }

        public bool WriteResults()
        {
            return SpatialLib.Close();

        }

        public int GetAppIndex()
        {
            return AppIndex;
        }

        public void SetAppIndex(int index)
        {
            AppIndex = index;
        }

        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Spatial");
            iNode.AppendChild(appNode);

            XmlElement n = doc.CreateElement("ProjectFile");
            n.InnerText = ProjectFile;
            //n.InnerText = ProjectFile.Substring(ProjectFile.LastIndexOf("\\") + 1);
            appNode.AppendChild(n);

            return true;
        }

        public bool ToXMLShort(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Spatial");
            appNode.InnerText = AppIndex.ToString();
            iNode.AppendChild(appNode);

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("ProjectFile");
            if (iter.MoveNext())
            {
                ProjectFile = iter.Current.Value;
                if (!ProjectFile.Contains("\\")) ProjectFile = folderLocation + "\\" + ProjectFile;
            }
            //ProjectFile = folderLocation + "\\" + iter.Current.Value;

            return true;
        }

    }
}
