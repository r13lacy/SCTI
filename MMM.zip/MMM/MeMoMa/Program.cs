using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Net;
using System.Text;
using System.Reflection;
using SCTI;

namespace MeMoMa
{
    static class Program
    {
        static string userData;
        public static bool isExiting = false;
        public static string MeMoMaVersion = "1.0.0"; // will be updated below

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]

        static void Main(string[] args)
        {
            bool quiet = false;

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // 17 Nov 2017
            string v = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();
            v = v.Substring(0, v.LastIndexOf("."));
            DateTime tdate = File.GetLastWriteTime(Application.ExecutablePath);
            string exedate = tdate.ToString("yyyyMMdd");
            MeMoMaVersion = v + "." + exedate; // DateCompiled().ToString("yyyyMMdd");


            // path for storing special files such as recent.txt and apps.l
            userData = Application.LocalUserAppDataPath.Substring(0, Application.LocalUserAppDataPath.LastIndexOf("\\"));

            // note that xml's for external programs and apps.l should be in userData, so always read/write accessible 
            // put MMMacro.xml into userData, if necessary; should happen only the first time that MMM is run.
            if (!File.Exists(userData + "\\MMMacro.xml") && !File.Exists(userData + "\\apps.l")) 
            {
                makeMMMacroXML();
                    StreamWriter w = new StreamWriter(userData + "\\apps.l");
                    w.WriteLine(userData + "\\MMMacro.xml");
                    w.Close();
            }

            List<MApp> m_SystemApps = new List<MApp>();
            List<MApp> m_Apps = new List<MApp>();

            m_SystemApps.Add(new MAppVortex());
            m_SystemApps.Add(new MAppOutbreak());
//            m_SystemApps.Add(new MAppSimSimba());

            m_Apps.Add(new MAppSpatial());
            m_Apps.Add(new MAppPathHistory());
            //m_Apps.Add(new MAppOutbreak());
            m_Apps.Add(new MAppOutbreak2());
            //m_Apps.Add(new MAppBecky());
            //m_Apps.Add(new MAppInfector());
            //m_Apps.Add(new MAppVaccinator());
            m_Apps.Add(new MAppRLink());    // Is this the right place, or is there a list of modifier models to add it to?

            //load from apps files
            if (File.Exists(userData + "\\sysapps.l"))
            {
                List<string> appList = JPUtils.ReadFileToList(userData + "\\sysapps.l");

                for (int i = 0; i < appList.Count; i++)
                {
                    if (File.Exists(appList[i]))
                        m_SystemApps.Add(new MSystemAppExternal(appList[i]));
                }
            }

            if (File.Exists(userData + "\\apps.l"))
            {
                List<string> appList = JPUtils.ReadFileToList(userData + "\\apps.l");

                for (int i = 0; i < appList.Count; i++)
                {
                    if (File.Exists(appList[i]))
                        m_Apps.Add(new MAppExternal(appList[i]));
                }
            }

            if (args.Length == 0)
            {
                MMMHelp.FindReader();

                // use version.txt as a way to see if it is time to show Acknowledgements again
                // vfile won't exist just after upgrade to new version
                string vfile = Application.LocalUserAppDataPath + "\\version.txt";
                if (!File.Exists(vfile)) // || File.GetLastWriteTime(vfile) < DateTime.Today.AddDays(-90.0))
                {
                    frmSCTI2 frm = new frmSCTI2(true);
                    frm.ShowDialog();

                    StreamWriter writer = new StreamWriter(vfile, false);
                    writer.WriteLine(Application.ProductVersion);
                    writer.Close();
                }
                else
                {
                    int daysSinceOpen = (int)((DateTime.Today - File.GetLastAccessTime(vfile)).TotalDays); // 28 June 2017
                    if (daysSinceOpen > 30)
                    {
                        checkUpdates(false);

                        frmSCTI2 frm = new frmSCTI2(false);
                        frm.ShowDialog();
                        File.SetLastAccessTime(vfile, DateTime.Now);
                    }
                }

                if (new frmStart(m_SystemApps, m_Apps, userData).ShowDialog() == DialogResult.OK)
                    Application.Run(new frmModelSelection(m_SystemApps, m_Apps, userData));
            }
            else //run from command line with project file as argument
            {
                if (args.Length > 1 && args[1].ToLower().StartsWith("quiet")) quiet = true;

                MModel m = new MModel();
                if (!m.LoadXML(args[0]))
                    throw new Exception("The file '" + args[0] + "' does not exist.");
                else
                {
                    MModel.LoadData(m, null);
                    m.Simulate();
                    if(!quiet) Console.WriteLine("Done!");
                }
            }
        }

        // 17 Nov 2017
        public static bool checkUpdates(bool menu)
        {
            try
            {
                WebClient ftpRequest = new WebClient();
                ftpRequest.Credentials = new NetworkCredential("vortex10@vortex10.org", "vor10tex");
                byte[] buf = ftpRequest.DownloadData("ftp://ftp.vortex10.org/MeMoMaVersion.txt");

                string v = Encoding.ASCII.GetString(buf, 0, buf.Length);

                ftpRequest.Dispose();

                string[] sUpdate = v.Split('.');
                string[] sCurrent = MeMoMaVersion.Split('.');

                if ((Convert.ToInt32(sUpdate[0]) > Convert.ToInt32(sCurrent[0]))
                    || (Convert.ToInt32(sUpdate[1]) > Convert.ToInt32(sCurrent[1]))
                    || (Convert.ToInt32(sUpdate[2]) > Convert.ToInt32(sCurrent[2]))
                    || (Convert.ToInt32(sUpdate[3]) > Convert.ToInt32(sCurrent[3])))
                {
                    MessageBox.Show("A newer version of MetaModel Manager is available at www.vortex10.org/MeMoMa.aspx !", "Update Check");
                    return true;
                }
            }
            catch
            {
                if(menu) MessageBox.Show("Unable to connect to the web server to check for updates.");
                return false;
            }

            if(menu) MessageBox.Show("You are using the most current version of MetaModel Manager. Thank you for checking.", "Update check");

            return false;
        }



        static void makeMMMacroXML()
        {
            XmlDocument doc = new XmlDocument();

            //add top node and name as attrib
            XmlElement topNode = doc.CreateElement("MAppSpecs");
            doc.AppendChild(topNode);

            XmlElement n = doc.CreateElement("Name");
            n.InnerText = "MMMacro";
            topNode.AppendChild(n);

            n = doc.CreateElement("Description");
            n.InnerText = "MetaModel variable translation module";
            topNode.AppendChild(n);

            n = doc.CreateElement("DLL");
            n.InnerText = "MMMacroLib.dll"; // Application.StartupPath + "\\MMMacroLib.dll";
            // problem if assign to startupPath here, if user installs a new version somewhere else
            // because the MMMacro.xml with the old StartupPath will remain in place after a new installation
            // so insert StartupPath if needed when DLL is read
            topNode.AppendChild(n);

            n = doc.CreateElement("NameSpace");
            n.InnerText = "MMMacro.MMMacro";
            topNode.AppendChild(n);

            n = doc.CreateElement("Variables");
            topNode.AppendChild(n);

            n = doc.CreateElement("Functions");
            topNode.AppendChild(n);

                XmlElement nn = doc.CreateElement("Standard");
                nn.InnerText = "True";
                n.AppendChild(nn);

            doc.Save(userData + "\\MMMacro.xml");
        }
    }
}