﻿using System.Windows.Forms;

namespace MeMoMa
{
    public partial class frmSCTI : Form
    {
        public frmSCTI()
        {
            InitializeComponent();
        }

        private void frmSCTI_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("SCTI");
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            Close();
        }
    }
}
