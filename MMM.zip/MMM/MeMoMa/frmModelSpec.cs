using System;
using System.Windows.Forms;

namespace MeMoMa
{
    public partial class frmModelSpec : Form
    {
        private MSystemAppExternal sapp = null;
        public frmModelSpec(MSystemAppExternal a)
        {
            InitializeComponent();

            sapp = a;

            txtName.Text = sapp.GetName();
            txtDescription.Text = sapp.GetDescription();
            txtDLL.Text = sapp.DLLFile;
            txtNameSpace.Text = sapp.LibNameSpace;

            fgFunctions.Rows.Count = 5;

            //fill in funs
            fgFunctions[1, 0] = "bool Initialize()";
            //fgFunctions[2, 0] = "bool GetProjectFile(string fileName)";
            //fgFunctions[3, 0] = "List<MPopulation> GetPopulations()";
            //fgFunctions[4, 0] = "bool SetPopulations(List<MPopulation> pops)";
            fgFunctions[2, 0] = "bool Simulate(int numTimeSteps)";
            fgFunctions[3, 0] = "bool Year0Sim() [can be none]";
            fgFunctions[4, 0] = "bool CloseDLL()";

            //fill in table
            fgFunctions[1, 1] = sapp.InitFunction;
            //fgFunctions[2, 1] = sapp.GetProjectFunction;
            //fgFunctions[3, 1] = "GetPopulations";
            //fgFunctions[4, 1] = "SetPopulations";
            fgFunctions[2, 1] = sapp.SimFunction;
            if (sapp.Year0Function == null) fgFunctions[3, 1] = "";
            else fgFunctions[3, 1] = sapp.Year0Function;
            fgFunctions[4, 1] = sapp.CloseFunction;

            if (sapp.IsStandard)
            {
                radioStandard.Checked = true;
                fgFunctions.Enabled = false;
            }
            else
            {
                radioStandard.Checked = false;
                fgFunctions.Enabled = true;
            }
        }

        private MAppExternal app = null;
        public frmModelSpec(MAppExternal a)
        {
            InitializeComponent();

            app = a;

            txtName.Text = app.GetName();
            txtDescription.Text = app.GetDescription();
            txtDLL.Text = app.DLLFile;
            txtNameSpace.Text = app.LibNameSpace;

            fgFunctions.Rows.Count = 5;

            //fill in funs
            fgFunctions[1, 0] = "bool Initialize()";
            //fgFunctions[2, 0] = "bool GetProjectFile(string fileName)"; 
            //fgFunctions[3, 0] = "List<MPopulation> GetPopulations()";
            //fgFunctions[4, 0] = "bool SetPopulations(List<MPopulation> pops)";
            fgFunctions[2, 0] = "bool Simulate(int numTimeSteps)";
            fgFunctions[3, 0] = "bool Year0Sim() [can be none]";
            fgFunctions[4, 0] = "bool CloseDLL()";

            //fill in table 
            fgFunctions[1, 1] = app.InitFunction;
            //fgFunctions[2, 1] = app.GetProjectFunction;
            //fgFunctions[3, 1] = "GetPopulations";
            //fgFunctions[4, 1] = "SetPopulations";
            fgFunctions[2, 1] = app.SimFunction;
            if (app.Year0Function == null) fgFunctions[3, 1] = "";
            else fgFunctions[3, 1] = app.Year0Function;
            fgFunctions[4, 1] = app.CloseFunction;

            if (app.IsStandard)
            {
                radioStandard.Checked = true;
                //                fgFunctions.Rows.Count = 1;
                fgFunctions.Enabled = false;
            }
            else
            {
                radioStandard.Checked = false;
                fgFunctions.Enabled = true;

                //fgFunctions.Rows.Count = 7;

            }

        }

        private void frmModelSpec_Load(object sender, EventArgs e)
        {
        }

        private void radioStandard_CheckedChanged(object sender, EventArgs e)
        {
            fgFunctions.Enabled = !radioStandard.Checked;
            if (radioStandard.Checked)
            {
                fgFunctions[1, 1] = "Initialize";
                fgFunctions[2, 1] = "Simulate";
                fgFunctions[3, 1] = "Year0Sim";
                fgFunctions[4, 1] = "CloseDLL";
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (sapp != null)
            {
                // transfer settings into app 
                sapp.SetName(txtName.Text);
                sapp.SetDescription(txtDescription.Text);
                sapp.DLLFile = txtDLL.Text;
                sapp.LibNameSpace = txtNameSpace.Text;
                sapp.IsStandard = radioStandard.Checked;
                if (!sapp.IsStandard)
                {
                    sapp.InitFunction = fgFunctions[1, 1].ToString().Trim();
                    sapp.SimFunction = fgFunctions[2, 1].ToString().Trim();
                    sapp.Year0Function = fgFunctions[3, 1].ToString().Trim();
                    sapp.CloseFunction = fgFunctions[4, 1].ToString().Trim();
                }
                else
                {
                    sapp.InitFunction = "Initialize";
                    sapp.SimFunction = "Simulate";
                    sapp.Year0Function = "Year0Sim";
                    sapp.CloseFunction = "CloseDLL";
                }
                if (sapp.Year0Function == "") sapp.Year0Function = null;
            }

            if (app != null)
            {
                // transfer settings into app 
                app.SetName(txtName.Text);
                app.SetDescription(txtDescription.Text);
                app.DLLFile = txtDLL.Text;
                app.LibNameSpace = txtNameSpace.Text;
                app.IsStandard = radioStandard.Checked;
                if (!app.IsStandard)
                {
                    app.InitFunction = fgFunctions[1, 1].ToString().Trim();
                    app.SimFunction = fgFunctions[2, 1].ToString().Trim();
                    app.Year0Function = fgFunctions[3, 1].ToString().Trim();
                    app.CloseFunction = fgFunctions[4, 1].ToString().Trim();

                    //fgFunctions[2, 1] = "LoadProjectFile"; // how are these used? are these used? // TODO
                    //fgFunctions[3, 1] = "GetPopulations";
                    //fgFunctions[4, 1] = "SetPopulations";
                }
                else
                {
                    app.InitFunction = "Initialize";
                    app.SimFunction = "Simulate";
                    app.Year0Function = "Year0Sim";
                    app.CloseFunction = "CloseDLL";
                }
                if (app.Year0Function == "") app.Year0Function = null;
            }

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.InitialDirectory = Application.StartupPath;
            dlg.Filter = "Model dll File (*.dll)|*.dll";

            if (dlg.ShowDialog() == DialogResult.OK)
                txtDLL.Text = dlg.FileName;
        }

        private void frmModelSpec_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("ModelSpec");
        }

    }
}