using System;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;


namespace MeMoMa
{

    public static class MMMHelp
    {
        private static string m_HelpFile = Application.StartupPath + "\\MMMmanual.pdf";
        private static string m_AcrobatReader = null;

        // replace numbered enum with use of nameddest's
        //public enum HelpSections
        //{
        //    // set these codes to be set to the appropriate page numbers in the manual
        //    Start = 5,
        //    ModelSelection = 4,
        //    ModelSpecs = 10,
        //    ManageModels = 12,
        //    DataSet = 18,
        //    StepOrder = 70,
        //    Input = 70,
        //    Output = 70,
        //    Break = 70,
        //    Evaluator = 70,
        //    GraphOptions = 70,
        //    Simulate = 70,
        //    DataViewer = 70,
        //    PopView = 70
        //}


        public static void FindReader()
        {
//            return; // temporary, until manual is written

            try
            {
                FileAssociation fa = new FileAssociation();
                string s = fa.Get(".pdf");
                m_AcrobatReader = s; 
            }
            catch
            {
                m_AcrobatReader = null;
            }
        }

        // go to a destination rather than a page number
        // note, they must be named destinations, not just bookmarks
        public static void LaunchHelp(string bookmark)
        {
            if (m_AcrobatReader == null) MessageBox.Show("Cannot start Acrobat Reader to open Help file. Install Acrobat Reader to use Help.");
            else if (bookmark == null) startHelp(m_HelpFile);
            else
            {
                try
                {
                    Process.Start(m_AcrobatReader, "/A \"nameddest=" + bookmark + "\" \"" + m_HelpFile + "\"");
                } // will go to start of doc if can't find nameddest
                catch
                {
                    startHelp(m_HelpFile);  // get here only if acrobat failed to open file
                }
            }
        }


        private static void startHelp(string filename)
        {
            try
            {
                Process.Start(m_AcrobatReader, "/A \"nameddest=" + "ToC" + "\" \"" + filename + "\"");
                //Process.Start(filename);
            }
            catch
            {
                MessageBox.Show("Cannot start Acrobat Reader to open Help file. Either Acrobat Reader or " + filename + " is missing.");
            }
        }

    }



   public class FileAssociation
   {
       public FileAssociation()
       { }

       [DllImport("Shlwapi.dll", SetLastError = true, CharSet = CharSet.Auto)]
       static extern uint AssocQueryString(AssocF flags, AssocStr str, string pszAssoc, string pszExtra, [Out] StringBuilder pszOut, [In][Out] ref uint pcchOut);

       public string Get(string doctype)
       {
           uint pcchOut = 0;
           AssocQueryString(AssocF.Verify, AssocStr.Executable, doctype, null, null, ref pcchOut);
           StringBuilder pszOut = new StringBuilder((int)pcchOut);
           AssocQueryString(AssocF.Verify, AssocStr.Executable, doctype, null, pszOut, ref pcchOut);
           string doc = pszOut.ToString();
           return doc;
       }
   }


   [Flags]

   public enum AssocF
   {
       Init_NoRemapCLSID = 0x1,
       Init_ByExeName = 0x2,
       Open_ByExeName = 0x2,
       Init_DefaultToStar = 0x4,
       Init_DefaultToFolder = 0x8,
       NoUserSettings = 0x10,
       NoTruncate = 0x20,
       Verify = 0x40,
       RemapRunDll = 0x80,
       NoFixUps = 0x100,
       IgnoreBaseClass = 0x200
   }


   public enum AssocStr
   {
       Command = 1,
       Executable,
       FriendlyDocName,
       FriendlyAppName,
       NoOpen,
       ShellNewValue,
       DDECommand,
       DDEIfExec,
       DDEApplication,
       DDETopic
   }

}
