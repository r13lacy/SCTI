namespace MeMoMa
{
    partial class frmModels
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lstApps = new System.Windows.Forms.ListBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnMod = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnAddSysXML = new System.Windows.Forms.Button();
            this.btnModSys = new System.Windows.Forms.Button();
            this.btnDelSys = new System.Windows.Forms.Button();
            this.btnAddSys = new System.Windows.Forms.Button();
            this.lstSysApps = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(757, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(652, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Currently loaded additional MODIFIER models -- Double-Click on any for more info " +
    "or to make changes";
            // 
            // lstApps
            // 
            this.lstApps.FormattingEnabled = true;
            this.lstApps.ItemHeight = 16;
            this.lstApps.Location = new System.Drawing.Point(760, 46);
            this.lstApps.Margin = new System.Windows.Forms.Padding(4);
            this.lstApps.Name = "lstApps";
            this.lstApps.Size = new System.Drawing.Size(643, 276);
            this.lstApps.TabIndex = 1;
            this.lstApps.DoubleClick += new System.EventHandler(this.lstApps_DoubleClick);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(760, 330);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(73, 27);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(963, 330);
            this.btnDel.Margin = new System.Windows.Forms.Padding(4);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(73, 27);
            this.btnDel.TabIndex = 3;
            this.btnDel.Text = "Delete";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(1345, 348);
            this.btnOK.Margin = new System.Windows.Forms.Padding(4);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(76, 30);
            this.btnOK.TabIndex = 4;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnMod
            // 
            this.btnMod.Location = new System.Drawing.Point(1044, 330);
            this.btnMod.Margin = new System.Windows.Forms.Padding(4);
            this.btnMod.Name = "btnMod";
            this.btnMod.Size = new System.Drawing.Size(73, 27);
            this.btnMod.TabIndex = 5;
            this.btnMod.Text = "Modify";
            this.btnMod.UseVisualStyleBackColor = true;
            this.btnMod.Click += new System.EventHandler(this.btnMod_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(841, 330);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 27);
            this.button1.TabIndex = 6;
            this.button1.Text = "Add From XML";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnAddSysXML
            // 
            this.btnAddSysXML.Location = new System.Drawing.Point(97, 330);
            this.btnAddSysXML.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddSysXML.Name = "btnAddSysXML";
            this.btnAddSysXML.Size = new System.Drawing.Size(113, 27);
            this.btnAddSysXML.TabIndex = 12;
            this.btnAddSysXML.Text = "Add From XML";
            this.btnAddSysXML.UseVisualStyleBackColor = true;
            this.btnAddSysXML.Click += new System.EventHandler(this.btnAddSysXML_Click);
            // 
            // btnModSys
            // 
            this.btnModSys.Location = new System.Drawing.Point(300, 330);
            this.btnModSys.Margin = new System.Windows.Forms.Padding(4);
            this.btnModSys.Name = "btnModSys";
            this.btnModSys.Size = new System.Drawing.Size(73, 27);
            this.btnModSys.TabIndex = 11;
            this.btnModSys.Text = "Modify";
            this.btnModSys.UseVisualStyleBackColor = true;
            this.btnModSys.Click += new System.EventHandler(this.btnModSys_Click);
            // 
            // btnDelSys
            // 
            this.btnDelSys.Location = new System.Drawing.Point(219, 330);
            this.btnDelSys.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelSys.Name = "btnDelSys";
            this.btnDelSys.Size = new System.Drawing.Size(73, 27);
            this.btnDelSys.TabIndex = 10;
            this.btnDelSys.Text = "Delete";
            this.btnDelSys.UseVisualStyleBackColor = true;
            this.btnDelSys.Click += new System.EventHandler(this.btnDelSys_Click);
            // 
            // btnAddSys
            // 
            this.btnAddSys.Location = new System.Drawing.Point(16, 330);
            this.btnAddSys.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddSys.Name = "btnAddSys";
            this.btnAddSys.Size = new System.Drawing.Size(73, 27);
            this.btnAddSys.TabIndex = 9;
            this.btnAddSys.Text = "Add";
            this.btnAddSys.UseVisualStyleBackColor = true;
            this.btnAddSys.Click += new System.EventHandler(this.btnAddSys_Click);
            // 
            // lstSysApps
            // 
            this.lstSysApps.FormattingEnabled = true;
            this.lstSysApps.ItemHeight = 16;
            this.lstSysApps.Location = new System.Drawing.Point(16, 46);
            this.lstSysApps.Margin = new System.Windows.Forms.Padding(4);
            this.lstSysApps.Name = "lstSysApps";
            this.lstSysApps.Size = new System.Drawing.Size(636, 276);
            this.lstSysApps.TabIndex = 8;
            this.lstSysApps.DoubleClick += new System.EventHandler(this.lstSysApps_DoubleClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 26);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(643, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "Currently loaded additional SYSTEM models -- Double-Click on any for more info or" +
    " to make changes";
            // 
            // frmModels
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1437, 389);
            this.Controls.Add(this.btnAddSysXML);
            this.Controls.Add(this.btnModSys);
            this.Controls.Add(this.btnDelSys);
            this.Controls.Add(this.btnAddSys);
            this.Controls.Add(this.lstSysApps);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnMod);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lstApps);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmModels";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Manage Additional Models";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmModels_KeyUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstApps;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnMod;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnAddSysXML;
        private System.Windows.Forms.Button btnModSys;
        private System.Windows.Forms.Button btnDelSys;
        private System.Windows.Forms.Button btnAddSys;
        private System.Windows.Forms.ListBox lstSysApps;
        private System.Windows.Forms.Label label2;
    }
}