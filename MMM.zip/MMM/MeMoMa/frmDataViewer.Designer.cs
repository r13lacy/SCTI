namespace MeMoMa
{
    partial class frmDataViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnStopSim = new System.Windows.Forms.Button();
            this.btnViewPop = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.fgGlobalVars = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.fgPops = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.pnlBottom.SuspendLayout();
            this.pnlTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgGlobalVars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgPops)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            this.pnlBottom.Controls.Add(this.btnStopSim);
            this.pnlBottom.Controls.Add(this.btnViewPop);
            this.pnlBottom.Controls.Add(this.btnOK);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 483);
            this.pnlBottom.Margin = new System.Windows.Forms.Padding(4);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(964, 43);
            this.pnlBottom.TabIndex = 1;
            // 
            // btnStopSim
            // 
            this.btnStopSim.Location = new System.Drawing.Point(172, 7);
            this.btnStopSim.Margin = new System.Windows.Forms.Padding(4);
            this.btnStopSim.Name = "btnStopSim";
            this.btnStopSim.Size = new System.Drawing.Size(184, 28);
            this.btnStopSim.TabIndex = 4;
            this.btnStopSim.Text = "Stop Simulation";
            this.btnStopSim.UseVisualStyleBackColor = true;
            this.btnStopSim.Click += new System.EventHandler(this.btnStopSim_Click);
            // 
            // btnViewPop
            // 
            this.btnViewPop.Location = new System.Drawing.Point(16, 7);
            this.btnViewPop.Margin = new System.Windows.Forms.Padding(4);
            this.btnViewPop.Name = "btnViewPop";
            this.btnViewPop.Size = new System.Drawing.Size(148, 28);
            this.btnViewPop.TabIndex = 1;
            this.btnViewPop.Text = "Show Population";
            this.btnViewPop.UseVisualStyleBackColor = true;
            this.btnViewPop.Click += new System.EventHandler(this.btnViewPop_Click);
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(716, 7);
            this.btnOK.Margin = new System.Windows.Forms.Padding(4);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(103, 28);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.fgGlobalVars);
            this.pnlTop.Controls.Add(this.panel1);
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Margin = new System.Windows.Forms.Padding(4);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(964, 151);
            this.pnlTop.TabIndex = 2;
            // 
            // fgGlobalVars
            // 
            this.fgGlobalVars.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.fgGlobalVars.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.fgGlobalVars.ColumnInfo = "10,0,0,0,0,85,Columns:";
            this.fgGlobalVars.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.fgGlobalVars.Location = new System.Drawing.Point(0, 39);
            this.fgGlobalVars.Margin = new System.Windows.Forms.Padding(4);
            this.fgGlobalVars.Name = "fgGlobalVars";
            this.fgGlobalVars.Rows.Count = 2;
            this.fgGlobalVars.Rows.DefaultSize = 17;
            this.fgGlobalVars.Size = new System.Drawing.Size(964, 86);
            this.fgGlobalVars.TabIndex = 1;
            this.fgGlobalVars.BeforeEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgGlobalVars_BeforeEdit);
            this.fgGlobalVars.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgGlobalVars_AfterEdit);
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 125);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(964, 26);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Global Variables";
            // 
            // fgPops
            // 
            this.fgPops.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.fgPops.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.fgPops.ColumnInfo = "10,0,0,0,0,85,Columns:";
            this.fgPops.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fgPops.Location = new System.Drawing.Point(0, 151);
            this.fgPops.Margin = new System.Windows.Forms.Padding(4);
            this.fgPops.Name = "fgPops";
            this.fgPops.Rows.DefaultSize = 17;
            this.fgPops.Size = new System.Drawing.Size(964, 332);
            this.fgPops.TabIndex = 3;
            this.fgPops.BeforeEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgPops_BeforeEdit);
            this.fgPops.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgPops_AfterEdit);
            this.fgPops.DoubleClick += new System.EventHandler(this.fgPops_DoubleClick);
            // 
            // frmDataViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(964, 526);
            this.Controls.Add(this.fgPops);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.pnlBottom);
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmDataViewer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmDataViewer";
            this.Load += new System.EventHandler(this.frmDataViewer_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmDataViewer_KeyUp);
            this.pnlBottom.ResumeLayout(false);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgGlobalVars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgPops)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Panel pnlTop;
        private C1.Win.C1FlexGrid.C1FlexGrid fgPops;
        private System.Windows.Forms.Button btnViewPop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnStopSim;
        private C1.Win.C1FlexGrid.C1FlexGrid fgGlobalVars;
        private System.Windows.Forms.Panel panel1;
    }
}