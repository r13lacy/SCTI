using System;
using System.Collections.Generic;
using System.Windows.Forms;
using SCTI;
using System.IO;

namespace MeMoMa
{
    public partial class frmStart : Form
    {
        private List<MApp> Apps;
        private List<MApp> SysApps;
        public string AppPath; // note AppPath is userData

        public frmStart(List<MApp> sapps, List<MApp> apps, string appPath)
        {
            InitializeComponent();

            SysApps = sapps;
            Apps = apps;
            AppPath = appPath;

            label3.Text = "version " + Program.MeMoMaVersion;
        }

        private void lnkNew_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.DialogResult = DialogResult.OK;

        }

        private void lnkQuit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void lnkOpen_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "MMM Project File (*.mmmm)|*.mmmm";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                MModel model = new MModel();

                if (model.LoadXML(dlg.FileName))
                {
                    Cursor.Current = Cursors.WaitCursor; // it can take a while to load if the component projects are big.
                    frmDataSet frmDS = new frmDataSet(model);
                    Cursor.Current = Cursors.Default;

                    frmDS.ShowDialog();

                }
                else
                    MessageBox.Show("The file you have selected is either not a valid MMM project file or it has been corrupted.");
            }
        }

        private void lnkModels_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new frmModels(SysApps, Apps).ShowDialog();

            //rewrite apps.l file

            StreamWriter w = new StreamWriter(AppPath + "\\apps.l");

            for (int i = 0; i < Apps.Count; i++)
            {
                if (Apps[i].GetType() == typeof(MAppExternal))
                {
                    w.WriteLine(AppPath + "\\" + ((MAppExternal)Apps[i]).GetName() + ".xml");
                    ((MAppExternal)Apps[i]).SaveToXML(AppPath + "\\" + ((MAppExternal)Apps[i]).GetName() + ".xml");
                }
            }
            w.Close();

            //rewrite sapps.l file

            w = new StreamWriter(AppPath + "\\sysapps.l");

            for (int i = 0; i < SysApps.Count; i++)
            {
                if (SysApps[i].GetType() == typeof(MSystemAppExternal))
                {
                    w.WriteLine(AppPath + "\\" + ((MSystemAppExternal)SysApps[i]).GetName() + ".xml");
                    ((MSystemAppExternal)SysApps[i]).SaveToXML(AppPath + "\\" + ((MSystemAppExternal)SysApps[i]).GetName() + ".xml");
                }
            }
            w.Close();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new AboutBox1().Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmSCTI2 frm = new frmSCTI2(true);
            frm.ShowDialog();
        }

        private void frmStart_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("Start"); 
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            Program.checkUpdates(true);

            Cursor.Current = Cursors.Default;
        }
    }
}