using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using MMMCore;

namespace MeMoMa
{
    public class MModel
    {
        public static List<MApp> MasterAppList = new List<MApp>();
        public List<MSystemApp> SystemApps = new List<MSystemApp>();
        public List<MModelStep> OrderedSteps = new List<MModelStep>();

        public List<string> PlotVarList = new List<string>();
        public int PlotShowAllIter = 0; //0 = real time, 1 = end of iter, 2 = none, 3 = end of all iterations.

        public MDataSet DataSet = null;

        public string Name = "";

        public int Years
        {
            get { return DataSet.Years; } 
            set { DataSet.Years = value; }
        }
        public int Iterations
        {
            get { return DataSet.Iterations; }
            set { DataSet.Iterations = value; }
        }

//        public int Years = 10;
//        public int Iterations = 1;

        private List<System.Drawing.Color> colorList = new List<System.Drawing.Color>();
//        private int lineCount = 0;

        private double[][] plotData = null;
        private List<string> plotNames = new List<string>();
        private List<char> plotType = new List<char>();
//        private List<int> plotN = new List<int>();

        private double[][][] allPlotData = null;
        private int iterCt;

        public bool saved = false;

        public MModel()
        {
            //colors
            colorList.Add(System.Drawing.Color.Blue);
            colorList.Add(System.Drawing.Color.Red);
            colorList.Add(System.Drawing.Color.LimeGreen);
            colorList.Add(System.Drawing.Color.DarkViolet);
            colorList.Add(System.Drawing.Color.Black);
            colorList.Add(System.Drawing.Color.DeepSkyBlue);
            colorList.Add(System.Drawing.Color.LightSeaGreen);
        }

        public bool LoadXML(string fileName)
        {
            //load a project from an existing xml project file

			XmlDocument doc = new XmlDocument();

			//make sure it is a valid document
			try { doc.Load(fileName); }
			catch { return false; }

            Name = fileName.Replace(".mmmm", "");

			//doc is loaded, start reading

            // create DataSet now, so that Years and Iterations can be accessed in it
            DataSet = new MDataSet();

            XPathNavigator Nav = doc.CreateNavigator();
			XPathNodeIterator iter;

			//get the project name, if it has one
			iter = Nav.SelectChildren("MMMProject", "");

			if ( !iter.MoveNext() )
				return false;

            iter = Nav.Select("MMMProject/Years");
            if (iter.MoveNext())
                Years = Convert.ToInt32(iter.Current.Value);

            iter = Nav.Select("MMMProject/Iterations");
            if (iter.MoveNext())
                Iterations = Convert.ToInt32(iter.Current.Value);

			//get the notes
			iter = Nav.Select("MMMProject/SystemAppList");
            if (!iter.MoveNext())
                return false;

            iter = iter.Current.Clone().SelectChildren(XPathNodeType.All);

            while (iter.MoveNext())
            {
                if (iter.Current.Name == "Vortex")
                {
                    MAppVortex v = new MAppVortex();
                    v.LoadXML(iter.Current.Clone(), new FileInfo(fileName).DirectoryName);
                    SystemApps.Add(v);
                }

                if (iter.Current.Name == "Outbreak")
                {
                    MAppOutbreak v = new MAppOutbreak();
                    v.LoadXML(iter.Current.Clone(), new FileInfo(fileName).DirectoryName);
                    SystemApps.Add(v);
                }

                //if (iter.Current.Name == "SimSimba")
                //{
                //    MAppSimSimba s = new MAppSimSimba();
                //    s.LoadXML(iter.Current.Clone(), new FileInfo(fileName).DirectoryName);
                //    SystemApps.Add(s);
                //}

                if (iter.Current.Name == "ExtSystem")
                {
                    MSystemAppExternal s = new MSystemAppExternal();
                    s.LoadXML(iter.Current.Clone(), new FileInfo(fileName).DirectoryName);
                    SystemApps.Add(s);
                }
            }

            //process app list into the arrays...  we will need the indexes in a moment
            for (int i = 0; i < SystemApps.Count; i++)
            {
                SystemApps[i].SetAppIndex(MasterAppList.Count);
                MasterAppList.Add(SystemApps[i]);
                for (int j = 0; j < SystemApps[i].SubModels().Count; j++)
                {
                    SystemApps[i].SubModels()[j].SetAppIndex(MasterAppList.Count);
                    MasterAppList.Add(SystemApps[i].SubModels()[j]);
                }
            }


            //load steps
            //get the notes
			iter = Nav.Select("MMMProject/StepList");
            if (!iter.MoveNext())
                return false;

            iter = iter.Current.Clone().SelectChildren(XPathNodeType.All);

            while (iter.MoveNext())
            {
                MModelStepSystemGroup mssg = new MModelStepSystemGroup();
                mssg.LoadXML(iter.Current.Clone(), new FileInfo(fileName).DirectoryName);
                OrderedSteps.Add(mssg);
            }

            // added by Bob
            iter = Nav.Select("MMMProject/PlotList");
            if (iter.MoveNext())
            {
                PlotVarList = new List<string>();  
                XPathNodeIterator iterSteps = iter.Current.Select("PlotVar");
                while (iterSteps.MoveNext())
                    PlotVarList.Add(iterSteps.Current.Value);
            }

            //DataSet = new MDataSet();

            saved = true;

            return true;
        }

        public bool SaveXML(string fileName)
        {

            Name = fileName.Replace(".mmmm", "");

            XmlDocument doc = new XmlDocument();

            XmlDeclaration xmlInfoNode = doc.CreateXmlDeclaration("1.0", null, null);
            doc.AppendChild(xmlInfoNode);

            XmlElement topNode = doc.CreateElement("MMMProject");
            doc.AppendChild(topNode);

            XmlElement n;
            int i;

            n = doc.CreateElement("Years");
            n.InnerText = Years.ToString();
            topNode.AppendChild(n);

            n = doc.CreateElement("Iterations");
            n.InnerText = Iterations.ToString();
            topNode.AppendChild(n);

            n = doc.CreateElement("SystemAppList");
            topNode.AppendChild(n);

            for (i = 0; i < SystemApps.Count; i++)
                SystemApps[i].ToXML(n, doc);

            n = doc.CreateElement("StepList");
            topNode.AppendChild(n);

            for (i = 0; i < OrderedSteps.Count; i++)
                OrderedSteps[i].ToXML(n, doc);

            // Added by Bob, so we don't have to keep re-entering what vars to plot
            n = doc.CreateElement("PlotList");
            topNode.AppendChild(n);

            XmlElement n2;
            for (i = 0; i < PlotVarList.Count; i++)
            {
                n2 = doc.CreateElement("PlotVar");
                n2.InnerText = PlotVarList[i];
                n.AppendChild(n2);
            }

            doc.Save(fileName);

            saved = true;

            return true;
        }

        public static void LoadData(MModel model, C1.Win.C1FlexGrid.C1FlexGrid fgPops)
        {
            MDataSet ds = model.DataSet;

            int numPops = 1;
            List<string> popNames = new List<string>();
            List<int> popSizes = new List<int>();
            model.DataSet.Populations.Clear();

            int k;
            int zz;
            int p = 0;

        // special stuff needed by built-in system models
            for (int i = 0; i < model.SystemApps.Count; i++)
            {

                if (model.SystemApps[i].GetType() == typeof(MAppVortex))
                {
                    vortex10lib.v10Project v = new vortex10lib.v10Project(model.SystemApps[i].GetProjectFile(), false);

                    int sindex = v.scenarioNames.IndexOf(model.SystemApps[i].GetScenarioName());
                    if (sindex != model.SystemApps[i].GetScenarioIndex())
                    {
                        if (MessageBox.Show("Vortex Scenario name does not match index. Do you want to reset the index?", "Vortex model warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            model.SystemApps[i].SetScenarioIndex(sindex);
                            model.saved = false;
                        }
                    }

                    bool b = v.Initialize(model.SystemApps[i].GetProjectFile(), model.SystemApps[i].GetScenarioIndex(), 1, 1);
                    vortex10lib.Scenario sc = v.MMscenario; //v.scenes[model.SystemApps[i].GetScenarioIndex()];

                    numPops = sc.nPops;
                    model.SystemApps[i].SetNumPops(numPops);

                    for (zz = 0; zz < sc.PSNames.Length; zz++)
                        model.SystemApps[i].GetPopulationVariables().Add(new MVariable(sc.PSNames[zz], typeof(string), "", false));

                    //pop labels

                    popNames = new List<string>();
                    popSizes = new List<int>();

                    for (k = 0; k < numPops; k++)
                    {
                        popNames.Add(sc.pops[k].name);
                        popSizes.Add(sc.pops[k].N0);

                        //add to dataset
                        model.DataSet.Populations.Add(new MPopulation());

                        //name the population.  first, see if there are any previous system apps of the same kind, if so, need to name with a (1), etc.
                        int prevCount = 0, afterCount = 0;

                        for (zz = 0; zz < i; zz++)
                            if (model.SystemApps[zz].GetType() == model.SystemApps[i].GetType())
                                prevCount++;

                        for (zz = i; zz < model.SystemApps.Count; zz++)
                            if (model.SystemApps[zz].GetType() == model.SystemApps[i].GetType())
                                afterCount++;

                        model.DataSet.Populations[model.DataSet.Populations.Count - 1].Name =
                            model.SystemApps[i].GetProjectName() + " [" + ((MAppVortex)model.SystemApps[i]).ScenarioName + "] - " + sc.pops[k].name;

                    }

                    for (zz = 0; zz < sc.GSNames.Length; zz++)
                        model.SystemApps[i].GetGlobalVariables().Add(new MVariable(sc.GSNames[zz], typeof(string), "", false));

                    for (zz = 0; zz < sc.ISNames.Length; zz++)
                        model.SystemApps[i].GetIndividualVariables().Add(new MVariable(sc.ISNames[zz], typeof(string), "", false));

                }
                //else if (model.SystemApps[i].GetType() == typeof(MAppSimSimba))
                //{
                //    model.DataSet.Populations.Add(new MPopulation());
                //    model.DataSet.Populations[model.DataSet.Populations.Count - 1].Name = "Main Population";
                //    popNames = new List<string>();
                //    popSizes = new List<int>();
                //    popNames.Add("Main Population");

                //    numPops = 1;
                //    model.SystemApps[i].SetNumPops(numPops);

                //    //get popsize
                //    List<string> fi = JPUtils.ReadFileToList(((MAppSimSimba)model.SystemApps[i]).PopFile);

                //    int fiCount = 0;
                //    for (k = 0; k < fi.Count; k++)
                //        if (fi[k].StartsWith("L")) fiCount++;


                //    popSizes.Add(fiCount);
                //}

                else if (model.SystemApps[i].GetType() == typeof(MAppOutbreak))
                {
                    model.DataSet.Populations.Add(new MPopulation());
                    model.DataSet.Populations[model.DataSet.Populations.Count - 1].Name = "Main Population";
                    popNames = new List<string>();
                    popSizes = new List<int>();
                    popNames.Add("Main Population");

                    numPops = 1;
                    model.SystemApps[i].SetNumPops(numPops);

                    //get popsize and Dz tag
                    int nct = 0;
                    string dztag = "";
                    List<string> fi = JPUtils.ReadFileToList(((MAppOutbreak)model.SystemApps[i]).GetProjectFile());
                    for (k = 0; k < fi.Count; k++)
                    {
                        if (fi[k].Contains("<Name>"))
                        {
                            int istart = fi[k].IndexOf("<Name>") + 6;
                            int iend = fi[k].IndexOf("</Name>");

                            string oname = (fi[k]).Substring(istart, iend - istart);
                            ((MAppOutbreak)model.SystemApps[i]).ProjectName = oname;
                        }
                        else if (fi[k].Contains("<DzTag>"))
                        {
                            int istart = fi[k].IndexOf("<DzTag>") + 7;
                            int iend = fi[k].IndexOf("</DzTag>");

                            if(iend > 0) dztag = (fi[k]).Substring(istart, iend - istart).Trim();
                            else dztag = (fi[k]).Substring(istart).Trim();
                        }
                        else if (fi[k].Contains("<InitN>"))
                        {
                            int istart = fi[k].IndexOf("<InitN>") + 7;
                            int iend = fi[k].IndexOf("</InitN>");

                            string snct = (fi[k]).Substring(istart, iend - istart);
                            nct = Convert.ToInt32(snct);

                            break;
                        }
                    }
                    ((MAppOutbreak)model.SystemApps[i]).dzTag = dztag;
                    ((MAppOutbreak)model.SystemApps[i]).SetPopulationVariables();
                    ((MAppOutbreak)model.SystemApps[i]).SetIndividualVariables();

                    popSizes.Add(nct);
                }
                else if (model.SystemApps[i].GetName() == "MetaPop")
                {
                    popNames = new List<string>();
                    popSizes = new List<int>();

                    var externalApp = (MSystemAppExternal)model.SystemApps[i];

                    List<string> fi = JPUtils.ReadFileToList(externalApp.GetProjectFile());
                    for (k = 44; k < fi.IndexOf("Migration"); k++)
                    {
                        var popData = fi[k].Split(',');
                        popNames.Add(popData[0]);
                        popSizes.Add(Convert.ToInt32(popData[3]));
                        model.DataSet.Populations.Add(new MPopulation());
                        model.DataSet.Populations[model.DataSet.Populations.Count - 1].Name = popData[0];
                    }

                    numPops = k - 44;
                    model.SystemApps[i].SetNumPops(numPops);

                    //((MSystemAppExternal)model.SystemApps[i]).SetPopulationVariables();
                    //((MSystemAppExternal)model.SystemApps[i]).SetIndividualVariables();
                    if (string.IsNullOrEmpty(externalApp.ProjectName))
                    {
                        externalApp.ProjectName = fi[1];
                    }

                    // by Bob. This puts RAMAS MP Years and Iterations into MeMoMa project
                    model.Years = Convert.ToInt32(fi[7]);
                    model.Iterations = Convert.ToInt32(fi[6]);
                }

                else if (model.SystemApps[i].GetType() == typeof(MSystemAppExternal))
                {
                    model.DataSet.Populations.Add(new MPopulation());
                    model.DataSet.Populations[model.DataSet.Populations.Count - 1].Name = "Main Population";
                    popNames = new List<string>();
                    popSizes = new List<int>();
                    popNames.Add("Main Population");

                    var externalApp = (MSystemAppExternal)model.SystemApps[i];

                    numPops = 1;
                    model.SystemApps[i].SetNumPops(numPops);
                    int nct = 0;

                    List<string> fi = JPUtils.ReadFileToList(externalApp.GetProjectFile());
                    for (k = 0; k < fi.Count; k++)
                    {
                        if (fi[k].Contains("<Name>"))
                        {
                            int istart = fi[k].IndexOf("<Name>") + 6;
                            int iend = fi[k].IndexOf("</Name>");

                            string oname = (fi[k]).Substring(istart, iend - istart);
                            externalApp.ProjectName = oname;
                        }
                        else if (fi[k].Contains("<InitN>"))
                        {
                            int istart = fi[k].IndexOf("<InitN>") + 7;
                            int iend = fi[k].IndexOf("</InitN>");

                            string snct = (fi[k]).Substring(istart, iend - istart);
                            nct = Convert.ToInt32(snct);

                            break;
                        }
                    }
                    //((MSystemAppExternal)model.SystemApps[i]).SetPopulationVariables();
                    //((MSystemAppExternal)model.SystemApps[i]).SetIndividualVariables();
                    if (string.IsNullOrEmpty(externalApp.ProjectName))
                    {
                        externalApp.ProjectName = "Project " + i;
                    }
                    popSizes.Add(nct);
                }


                if (fgPops != null)
                {
                    for (k = 0; k < numPops; k++)
                    {
                        int r = fgPops.Rows.Add().Index;
                        //if (model.SystemApps[i].GetType() == typeof(MAppVortex))
                        //    fgPops[r, 0] = model.SystemApps[i].GetProjectName() + " [" + ((MAppVortex)model.SystemApps[i]).ScenarioName + "] - " + popNames[k];
                        //else

                        fgPops[r, 0] = model.SystemApps[i].GetProjectName() + " - " + popNames[k];

                        fgPops[r, 1] = popSizes[k];

                    }
                }


                model.SystemApps[i].SetStartingPopIndex(p);
                p += model.SystemApps[i].GetNumPops();

// special stuff needed by built-in modifier models

                for (k = 0; k < model.SystemApps[i].SubModels().Count; k++)
                {
                    if (model.SystemApps[i].SubModels()[k].GetType() == typeof(MAppSpatial))
                    {
                        ((MAppSpatial)model.SystemApps[i].SubModels()[k]).PopStartIndex = model.SystemApps[i].GetStartingPopIndex();
                        ((MAppSpatial)model.SystemApps[i].SubModels()[k]).NumPops = numPops;
                    }
                    else if (model.SystemApps[i].SubModels()[k].GetType() == typeof(MAppPathHistory))
                    {
                        ((MAppPathHistory)model.SystemApps[i].SubModels()[k]).PopStartIndex = model.SystemApps[i].GetStartingPopIndex();
                        ((MAppPathHistory)model.SystemApps[i].SubModels()[k]).NumPops = numPops;
                    }
                    //else if (model.SystemApps[i].SubModels()[k].GetType() == typeof(MAppOutbreak))
                    //{
                    //    ((MAppOutbreak)model.SystemApps[i].SubModels()[k]).PopStartIndex = model.SystemApps[i].GetStartingPopIndex();
                    //    ((MAppOutbreak)model.SystemApps[i].SubModels()[k]).NumPops = numPops;
                    //}
                    else if (model.SystemApps[i].SubModels()[k].GetType() == typeof(MAppOutbreak2))
                    {
                        ((MAppOutbreak2)model.SystemApps[i].SubModels()[k]).PopStartIndex = model.SystemApps[i].GetStartingPopIndex();
                        ((MAppOutbreak2)model.SystemApps[i].SubModels()[k]).NumPops = numPops;

                        //get dzTag, and create state variables
                        string dztag = "";
                        List<string> fi = JPUtils.ReadFileToList(((MAppOutbreak2)model.SystemApps[i].SubModels()[k]).GetProjectFile());
                        for (int j = 0; j < fi.Count; j++)
                        {
                            if (fi[j].Contains("<DzTag>"))
                            {
                                int istart = fi[j].IndexOf("<DzTag>") + 7;
                                int iend = fi[j].IndexOf("</DzTag>");

                                if(iend > 0) dztag = (fi[j]).Substring(istart, iend - istart).Trim();
                                else dztag = (fi[j]).Substring(istart); // in case </DzTag is on next line in file
                                break;
                            }
                        }
                        ((MAppOutbreak2)model.SystemApps[i].SubModels()[k]).dzTag = dztag;
                        ((MAppOutbreak2)model.SystemApps[i].SubModels()[k]).SetPopulationVariables();
                        ((MAppOutbreak2)model.SystemApps[i].SubModels()[k]).SetIndividualVariables();
                    }

                        // added 13 Dec 2015 to show MMMacro shared vars in UI
                    else if (model.SystemApps[i].SubModels()[k].GetName() == "MMMacro")
                    {
                        char[] delims = { '=', ';', ',' };
                        string[] ss;

                        List<string> fi = JPUtils.ReadFileToList(((MAppExternal)model.SystemApps[i].SubModels()[k]).GetProjectFile());
                        for (int j = 0; j < fi.Count; j++)
                        {
                            if (fi[j].Contains("SharedGlobal"))
                            {
                                ss = fi[j].Split(delims,StringSplitOptions.RemoveEmptyEntries);
                                for (int i1 = 1; i1 < ss.Length; i1++)
                                {
                                    model.SystemApps[i].SubModels()[k].GetGlobalVariables().Add(new MVariable(ss[i1], typeof(string), "", false));
                                }
                            }
                            else if (fi[j].Contains("SharedPop"))
                            {
                                ss = fi[j].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                                for (int i1 = 1; i1 < ss.Length; i1++)
                                {
                                    model.SystemApps[i].SubModels()[k].GetPopulationVariables().Add(new MVariable(ss[i1], typeof(string), "", false));
                                }
                            }
                            else if (fi[j].Contains("SharedInd"))
                            {
                                ss = fi[j].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                                for (int i1 = 1; i1 < ss.Length; i1++)
                                {
                                    model.SystemApps[i].SubModels()[k].GetIndividualVariables().Add(new MVariable(ss[i1], typeof(string), "", false));
                                }
                            }
                        }

                    }

                    //else if (model.SystemApps[i].SubModels()[k].GetType() == typeof(MAppBecky))
                    //{
                    //    //BECKY ONLY WORKS WITH ONE POPULATION FOR THE TIME BEING!!!!!!
                    //    //((MAppBecky)model.SystemApps[i].SubModels()[k]).NumPops = numPops;

                    //}
                    //else if (model.SystemApps[i].SubModels()[k].GetType() == typeof(MAppInfector))
                    //{
                    //    //Infector works with one population at a time only

                    //}
                    //else if (model.SystemApps[i].SubModels()[k].GetType() == typeof(MAppVaccinator))
                    //{
                    //    ((MAppVaccinator)model.SystemApps[i].SubModels()[k]).PopStartIndex = model.SystemApps[i].GetStartingPopIndex();
                    //    ((MAppVaccinator)model.SystemApps[i].SubModels()[k]).NumPops = numPops;

                    //}
                }
            }
        }


        public void SimulateFromThread(object chart)
        {
            Simulate((C1.Win.C1Chart.C1Chart)chart, null, null);
        }

        public bool Simulate()
        {
            return Simulate(null, null, null);
        }

        private void CleanDataSet()
        {
            DataSet.VarNames.Clear();
            DataSet.Vars.Clear();
            DataSet.VarTypes.Clear();

            //clean out pops
            for (int i = 0; i < DataSet.Populations.Count; i++)
            {
                DataSet.Populations[i].VarNames.Clear();
                DataSet.Populations[i].Vars.Clear();
                DataSet.Populations[i].VarTypes.Clear();
                DataSet.Populations[i].IndList.Clear();
            }
        }

        //recursive function for getting the instances of the app for letting it know how many times it will run
        //the return is whether or not it found the app
        private bool GetNumTimeStepsForApp(MModelStep step, MSystemApp sysApp, ref int stepCount, int multLevel)
        {
            int myMult = multLevel;
            if (step.GetType() == typeof(MModelStepSystemGroup))
            {
                myMult *= step.GetNumTimeSteps();

                for (int i = 0; i < ((MModelStepSystemGroup)step).SubSteps.Count; i++)
                    if (GetNumTimeStepsForApp(((MModelStepSystemGroup)step).SubSteps[i], sysApp, ref stepCount,  myMult))
                        return true;
            }
            else if (step.GetType() == typeof(MModelStepGroup))
            {
                myMult *= step.GetNumTimeSteps();

                for (int i = 0; i < ((MModelStepGroup)step).SubSteps.Count; i++)
                    if (GetNumTimeStepsForApp(((MModelStepGroup)step).SubSteps[i], sysApp, ref stepCount, myMult))
                        return true;
            }
            else if (step.GetType() == typeof(MModelStepApp))
            {
                if (((MModelStepApp)step).App == sysApp) //this is it
                {
                    stepCount += (step.GetNumTimeSteps() * myMult);
                    return true;
                }
            }
            else
            {
                return false;
            }

            return false;
        }


        // version for use with modifier Apps ...

        //recursive function for getting the instances of the app for letting it know how many times it will run
        //the return is whether or not it found the app
        private bool GetNumTimeStepsForApp(MModelStep step, MApp mApp, ref int stepCount, int multLevel)
        {
            int myMult = multLevel;
            if (step.GetType() == typeof(MModelStepSystemGroup))
            {
                myMult *= step.GetNumTimeSteps();

                for (int i = 0; i < ((MModelStepSystemGroup)step).SubSteps.Count; i++)
                    if (GetNumTimeStepsForApp(((MModelStepSystemGroup)step).SubSteps[i], mApp, ref stepCount, myMult))
                        return true;
            }
            else if (step.GetType() == typeof(MModelStepGroup))
            {
                myMult *= step.GetNumTimeSteps();

                for (int i = 0; i < ((MModelStepGroup)step).SubSteps.Count; i++)
                    if (GetNumTimeStepsForApp(((MModelStepGroup)step).SubSteps[i], mApp, ref stepCount, myMult))
                        return true;
            }
            else if (step.GetType() == typeof(MModelStepApp))
            {
                if (((MModelStepApp)step).App == mApp) //this is it
                {
                    stepCount += (step.GetNumTimeSteps() * myMult);
                    return true;
                }
            }
            else
            {
                return false;
            }

            return false;
        }


        public bool assignNYearsNIterations()
        {
            // added by Bob, in case needed by Modifier App or Outbreak

            for (int i = 0; i < SystemApps.Count; i++)
            {
                SystemApps[i].SetNumYears(Years);
                SystemApps[i].SetNumIter(Iterations);

                for (int k = 0; k < SystemApps[i].SubModels().Count; k++)
                {
                    if (SystemApps[i].SubModels()[k].GetType() == typeof(MAppExternal))
                    {
                        ((MAppExternal)SystemApps[i].SubModels()[k]).SetNumIter(Iterations);
                        ((MAppExternal)SystemApps[i].SubModels()[k]).SetNumYears(Years);
                    }
                    if (SystemApps[i].SubModels()[k].GetType() == typeof(MAppOutbreak2))
                    {
                        ((MAppOutbreak2)SystemApps[i].SubModels()[k]).SetNumIter(Iterations);
                        ((MAppOutbreak2)SystemApps[i].SubModels()[k]).SetNumYears(Years);
                    }
                }
            }

            return true;
        }


        
        public bool Simulate(C1.Win.C1Chart.C1Chart chart, ProgressBar prg, Label lbl)
        {
            int i;

            if (prg != null)
            {
                prg.Value = 0;
                prg.Maximum = Iterations * Years;
            }

            DateTime startTime = DateTime.Now;

            // inserted because Outbreak and maybe ExternalApps need to know nYears, and nIterations
            assignNYearsNIterations();

            //init
            for (i = 0; i < SystemApps.Count; i++)
            {
                int appStepCount = 0, multLevel = 1;
                for (int j = 0; j < OrderedSteps.Count; j++)
                {
                    if (GetNumTimeStepsForApp(OrderedSteps[j], SystemApps[i], ref appStepCount, multLevel))
                    {
                        SystemApps[i].SetAppStepCount(appStepCount); // in case needed by App, put into interface
                        break;
                    }
                }

                SystemApps[i].Init(DataSet, appStepCount * Years);
                
                for (int k = 0; k < (SystemApps[i].SubModels()).Count; k++)
                {
                    int subAppStepCount = 0;
                    MApp subApp = (SystemApps[i].SubModels())[k];

                    for (int j = 0; j < OrderedSteps.Count; j++)
                    {
                        if (GetNumTimeStepsForApp(OrderedSteps[j], subApp, ref subAppStepCount, multLevel))
                        {
                            subApp.SetAppStepCount(subAppStepCount);
                            break;
                        }
                    }

                    if (subApp.GetType() == typeof(MAppExternal))
                    {
                        ((MAppExternal)subApp).Init(DataSet, subAppStepCount * Years);
                    }

                }
            }


            //try
            //{

                double seconds = 0;

                for (int it = 0; it < Iterations; it++)
                {
                    DateTime dt = DateTime.Now;

                    //make sure starts with a clean slate each time
                    CleanDataSet();

                    iterCt = it;

                    // do initial Year 0 setup of populations in system apps
                    for (i = 0; i < SystemApps.Count; i++)
                    {
                        if (SystemApps[i].GetType() == typeof(MAppVortex))
                            ((MAppVortex)SystemApps[i]).DoYear0(DataSet, it);
                        else if (SystemApps[i].GetType() == typeof(MAppOutbreak))
                            ((MAppOutbreak)SystemApps[i]).DoYear0(DataSet, it);
                        //else if (SystemApps[i].GetName() == "Outbreak3")   // TEMP! -- for testing Outbreak3 as an external SysApp
                        //    ((MSystemAppExternal)SystemApps[i]).DoYear0(DataSet, it);
                        else if (SystemApps[i].GetType() == typeof(MSystemAppExternal))   
                            ((MSystemAppExternal)SystemApps[i]).DoYear0(DataSet, it);
                    }

                    //// 19 dec 2014
                    //// do initial Year 0 setup of populations in modifier apps, so that they can add vars to MData
                    for (i = 0; i < SystemApps.Count; i++)
                    {
                        for (int k = 0; k < (SystemApps[i].SubModels()).Count; k++)
                        {
                            MApp subApp = (SystemApps[i].SubModels())[k];
                            if (subApp.GetType() == typeof(MAppExternal))
                            { 
                                ((MAppExternal)subApp).DoYear0(DataSet, it);
                            }
                        }
                    }

                    if (chart != null)
                    {
                        if (PlotShowAllIter == 0)
                            PlotN(chart, it, 0);
                        else if (PlotShowAllIter == 1) // this was commented out in some versions, why?
                            PrepPlotData();
                    }


                    for (int y = 0; y < Years; y++)
                    {
                        for (i = 0; i < OrderedSteps.Count; i++)
                        {
                            if (!OrderedSteps[i].Simulate(DataSet, it, y))
                                return false;
                        }


                        if (chart != null)
                        {
                            if (PlotShowAllIter == 0)
                                PlotN(chart, it, y + 1);
                            else if (PlotShowAllIter == 1) // was commented out in some versions, why?
                                StorePlotData(y + 1);
                        }

                        if (prg != null)
                            prg.Value = (it * Years) + y + 1; 

                    }

                    if (chart != null && PlotShowAllIter == 1)
                        PlotStoredData(chart, it);

                    if (chart != null && PlotShowAllIter == 3)
                        PlotStoredData(chart, -it);


                    TimeSpan span = DateTime.Now.Subtract(dt);
                    seconds += span.Seconds + ((double)span.Milliseconds / 1000);

                    if (lbl != null)
                    {
                        lbl.Text = "Iterations completed = " + (it + 1).ToString() +  "      Mean time per iteration = " + ((double)(seconds / (it + 1))).ToString("0.00") + "s";
                        lbl.Refresh();
                    }
                }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}

                if (chart != null && PlotShowAllIter == 3)
                {
                    chart.Repaint = true;
                    chart.Refresh();
                }

                
            //write results
            for (i = 0; i < OrderedSteps.Count; i++)
            {
                if (!OrderedSteps[i].WriteResults())
                    return false;

            }

            if (prg != null)
                prg.Value = 0;

            TimeSpan finalSpan = DateTime.Now.Subtract(startTime);

            if (lbl != null)
            {

                string s = "Total time for simulation = ";

                if (finalSpan.Days > 0)
                    s += finalSpan.Days.ToString() + "d " + finalSpan.Hours.ToString() + "h " + finalSpan.Minutes.ToString() + "m";
                else if (finalSpan.Hours > 0)
                    s += finalSpan.Hours.ToString() + "h " + finalSpan.Minutes.ToString() + "m " + finalSpan.Seconds.ToString() + "s";
                else if (finalSpan.Minutes > 0)
                    s += finalSpan.Minutes.ToString() + "m " + finalSpan.Seconds.ToString() + "s";
                else
                    s += finalSpan.Seconds.ToString() + "." + finalSpan.Milliseconds.ToString() + "s";


                s += " (Mean time per iteration = " + ((double)(seconds / (Iterations))).ToString("0.00") + "s)";

                lbl.Text = s;
                lbl.Refresh();
            }

            return true;

        }

        private int PrepPlotNames()
        {
            plotNames.Clear();
            plotType.Clear();

            for (int j = 0; j < PlotVarList.Count; j++)
            {
                if (PlotVarList[j].StartsWith("N"))
                {
                    plotNames.Add(PlotVarList[j].Substring(2));
                    plotType.Add('N');

                    //for (i = 0; i < DataSet.Populations.Count; i++)
                    //{
                    //    if (PlotVarList[j] == "N." + DataSet.Populations[i].Name)
                    //    {
                    //        plotN.Add(i);
                    //        break;
                    //    }
                    //}
                }

                else if (PlotVarList[j].StartsWith("G"))
                {
                    int vi = DataSet.GetVarIndex(PlotVarList[j].Substring(7));

                    if (vi >= 0)
                    {
                        plotNames.Add("Global:" + PlotVarList[j].Substring(7));
                        plotType.Add('G');
                    }
                }
                else
                {
                    for (int i = 0; i < DataSet.Populations.Count; i++)
                    {
                        int vi = DataSet.Populations[i].GetVarIndex(PlotVarList[j].Substring(11));
                        if (vi >= 0)
                        {
                            plotNames.Add(DataSet.Populations[i].Name + ":" + PlotVarList[j].Substring(11));
                            plotType.Add('P');
                        }
                    }
                }
            }

            int ct = plotNames.Count; 
            plotData = new double[ct][];

            allPlotData = new double[Iterations][][];
            for (int i = 0; i < Iterations; i++)
            {
                allPlotData[i] = new double[ct][];
                for (int j = 0; j < ct; j++)
                {
                    allPlotData[i][j] = new double[Years + 1];
                }
            }

            for (int i = 0; i < ct; i++)
            {
                plotData[i] = new double[Years + 1];
            }

            return ct;
        }

        private void PrepPlotData()
        {
            if (plotNames.Count == 0) //hasn't yet been initialized
            {
                int ct = PrepPlotNames();

                //for (int j = 0; j < PlotVarList.Count; j++)
                //{
                //    if (PlotVarList[j].StartsWith("N"))
                //    {
                //        plotNames.Add(PlotVarList[j].Substring(2));
                //        plotType.Add('N');

                //        //for (i = 0; i < DataSet.Populations.Count; i++)
                //        //{
                //        //    if (PlotVarList[j] == "N." + DataSet.Populations[i].Name)
                //        //    {
                //        //        plotN.Add(i);
                //        //        break;
                //        //    }
                //        //}
                //    }

                //    else if (PlotVarList[j].StartsWith("G"))
                //    {
                //        int vi = DataSet.VarNames.IndexOf(PlotVarList[j].Substring("global.".Length));

                //        if (vi >= 0)
                //        {
                //            plotNames.Add("Global: " + PlotVarList[j].Substring("global.".Length));
                //            plotType.Add('G');
                //        }
                //    }
                //    else
                //    {
                //        for (i = 0; i < DataSet.Populations.Count; i++)
                //        {
                //            int vi = DataSet.Populations[i].VarNames.IndexOf(PlotVarList[j].Substring("population.".Length));
                //            if (vi >= 0)
                //            {
                //                plotNames.Add(DataSet.Populations[i].Name + ": " + PlotVarList[j].Substring("population.".Length));
                //                plotType.Add('P');
                //            }
                //        }
                //    }
                //}

                //plotData = new double[ct][];

                //allPlotData = new double[Iterations][][];
                //for (int i = 0; i < Iterations; i++)
                //{
                //    allPlotData[i] = new double[ct][];
                //    for (int j = 0; j < ct; j++)
                //    {
                //        allPlotData[i][j] = new double[Years + 1];
                //    }
                //}

            }

            //for (int i = 0; i < plotNames.Count; i++)
            //{
            //    plotData[i] = new double[Years + 1];
            //}

            StorePlotData(0);
        }


        private double MissingVal = -999.999;


        private void StorePlotData(int year)
        {
            int i, lineCount = 0;
            
            for (int j = 0; j < plotNames.Count; j++)
            {
                if (plotType[j] == 'N')
                {
                    for (i = 0; i < DataSet.Populations.Count; i++)
                    {
                        if (plotNames[j] == DataSet.Populations[i].Name)
                        {
                            plotData[lineCount++][year] = DataSet.Populations[i].Nindividuals;  //IndList.Count;
                            break;
                        }
                    }
                }
                else if (plotType[j] == 'G')
                {
                    int vi = DataSet.GetVarIndex(plotNames[j].Substring(7));
                    double val = MissingVal;
                    if (vi >= 0)
                    {
                        try
                        {
                            val = Convert.ToDouble(DataSet.Vars[vi]);
                        }
                        catch
                        {
                            val = MissingVal;
                        }
                        plotData[lineCount++][year] = val;
                    }
                }
                else
                {
                    for (i = 0; i < DataSet.Populations.Count; i++)
                    {
                        if (!plotNames[j].StartsWith(DataSet.Populations[i].Name)) continue; 
                        int vi = DataSet.Populations[i].GetVarIndex(plotNames[j].Substring((DataSet.Populations[i].Name + ":").Length));
                        double val = MissingVal;
                        if (vi >= 0)
                        {
                            try
                            {
                                val = Convert.ToDouble(DataSet.Populations[i].Vars[vi]);
                            }
                            catch
                            {
                                val = MissingVal;
                            }
                            plotData[lineCount++][year] = val;
                            break;
                        }

                    }
                }
            }

            //for (int j = 0; j < PlotVarList.Count; j++)
            //{
            //    if (PlotVarList[j].StartsWith("N"))
            //    {
            //        for (i = 0; i < DataSet.Populations.Count; i++)
            //        {
            //            if (PlotVarList[j] == "N." + DataSet.Populations[i].Name)
            //            {
            //                plotData[lineCount++][year] = DataSet.Populations[i].IndList.Count;
            //                break;
            //            }
            //        }
            //    }
            //    else if (PlotVarList[j].StartsWith("G"))
            //    {
            //        int vi = DataSet.VarNames.IndexOf(PlotVarList[j].Substring("global.".Length));
            //        double val = MissingVal;
            //        if (vi >= 0)
            //        {
            //            try
            //            {
            //                val = Convert.ToDouble(DataSet.Vars[vi]);
            //            }
            //            catch
            //            {
            //                val = MissingVal;
            //            }
            //            plotData[lineCount++][year] = val;
            //        }
            //    }
            //    else
            //    {
            //        for (i = 0; i < DataSet.Populations.Count; i++)
            //        {
            //            int vi = DataSet.Populations[i].VarNames.IndexOf(PlotVarList[j].Substring("population.".Length));
            //            double val = MissingVal;
            //            if (vi >= 0)
            //            {
            //                try
            //                {
            //                    val = Convert.ToDouble(DataSet.Populations[i].Vars[vi]);
            //                }
            //                catch
            //                {
            //                    val = MissingVal;
            //                }
            //                plotData[lineCount++][year] = val;
            //            }
            //        }
            //    }
            //}

            for (i = 0; i < lineCount; i++)
            {
                allPlotData[iterCt][i][year] = plotData[i][year];
            }


        }

        private void PlotStoredData(C1.Win.C1Chart.C1Chart chart, int iteration)
        {
            //int lineIndex = chart.ChartGroups.Group0.ChartData.SeriesList.Count - lineCount;
            //int colorIndex = DataSet.Populations.Count;
  
            int i;

            for (i = 0; i < plotNames.Count; i++)
            {
                C1.Win.C1Chart.ChartDataSeries ds = new C1.Win.C1Chart.ChartDataSeries();
                chart.ChartGroups.Group0.ChartData.SeriesList.Add(ds);
                ds.Label = plotNames[i];
                ds.LegendEntry = (iteration == 0);

                if (plotType[i] == 'G')
                    ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Diamond;
                else if (plotType[i] == 'P')
                    ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Box;
                else
                    ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Dot;

                ds.SymbolStyle.Color = colorList[i % colorList.Count];
                ds.SymbolStyle.Size = 1;
                ds.LineStyle.Thickness = 1;
                ds.LineStyle.Color = colorList[i % colorList.Count];

                for (int j = 0; j <= Years; j++)
                {
                    if (plotData[i][j] != MissingVal)
                    {
                        ds.X.Add(j);
                        ds.Y.Add(plotData[i][j]);
                    }
                }
            
            }

            if (iteration > 0)
            {
                chart.Repaint = true;
                chart.Refresh();
            }

        }

        public void WriteStoredData(string filename)
        {
            int i, j;
            TextWriter tw;

            try
            {
                tw = new StreamWriter(filename);
            }
            catch
            {
                MessageBox.Show("Failure to open file " + filename + " for saving Graph data. Sorry.");
                return;
            }

            tw.Write("Iteration; LineLabel");
            for (i = 0; i <= Years; i++) tw.Write("; " + i.ToString());
            tw.WriteLine();

            for(j = 0; j < Iterations; j++) 
            {
                for (i = 0; i < plotNames.Count; i++)
                {
                    tw.Write((j + 1).ToString() + "; " + plotNames[i]);

                    for (int k = 0; k <= Years; k++)
                    {
                        tw.Write("; ");
                        if (allPlotData[j][i][k] != MissingVal) 
                            tw.Write((allPlotData[j][i][k]).ToString());
                    }
                    tw.WriteLine();
                }
            }

            tw.Close();

            MessageBox.Show("Data used in the chart were saved in file: " + filename);
        }


        private void PlotN(C1.Win.C1Chart.C1Chart chart, int iteration, int year)
        {
            int i;

            if (year == 0)
            {
                PrepPlotNames();

                for (int j = 0; j < plotNames.Count; j++)
                {
                    if (plotType[j] == 'N')
                    {
                        chart.ChartGroups.Group0.ChartData.SeriesList.Add(new C1.Win.C1Chart.ChartDataSeries());
                        chart.ChartGroups.Group0.ChartData.SeriesList[chart.ChartGroups.Group0.ChartData.SeriesList.Count - 1].Label = plotNames[j];
                        chart.ChartGroups.Group0.ChartData.SeriesList[chart.ChartGroups.Group0.ChartData.SeriesList.Count - 1].LegendEntry = (iteration == 0);
                    }
                    else if (plotType[j] == 'G')
                    {
                        int vi = DataSet.GetVarIndex(plotNames[j].Substring(7));
                        if (vi >= 0)
                        {
                            chart.ChartGroups.Group0.ChartData.SeriesList.Add(new C1.Win.C1Chart.ChartDataSeries());
                            chart.ChartGroups.Group0.ChartData.SeriesList[chart.ChartGroups.Group0.ChartData.SeriesList.Count - 1].Label = plotNames[j];
                            chart.ChartGroups.Group0.ChartData.SeriesList[chart.ChartGroups.Group0.ChartData.SeriesList.Count - 1].LegendEntry = (iteration == 0);
                        }
                    }
                    else
                    {
                        for (i = 0; i < DataSet.Populations.Count; i++)
                        {
                            if (!plotNames[j].StartsWith(DataSet.Populations[i].Name)) continue;
                            int vi = DataSet.Populations[i].GetVarIndex(plotNames[j].Substring((DataSet.Populations[i].Name + ":").Length));
                            if (vi >= 0)
                            {
                                chart.ChartGroups.Group0.ChartData.SeriesList.Add(new C1.Win.C1Chart.ChartDataSeries());
                                chart.ChartGroups.Group0.ChartData.SeriesList[chart.ChartGroups.Group0.ChartData.SeriesList.Count - 1].Label = plotNames[j]; 
//                                    DataSet.Populations[i].Name + ": " + PlotVarList[j].Substring(11);
                                chart.ChartGroups.Group0.ChartData.SeriesList[chart.ChartGroups.Group0.ChartData.SeriesList.Count - 1].LegendEntry = (iteration == 0);
                            }
                        }
                    }
                }
            }

//            int lineCount = plotNames.Count;
            int lineIndex = chart.ChartGroups.Group0.ChartData.SeriesList.Count - plotNames.Count; // lineCount;
//            int colorIndex = DataSet.Populations.Count;

            for (int j = 0; j < plotNames.Count; j++)
            {
                if (plotType[j] == 'N')
                {
                    for (i = 0; i < DataSet.Populations.Count; i++)
                    {
                        if (plotNames[j] == DataSet.Populations[i].Name)
                        {
                            C1.Win.C1Chart.ChartDataSeries ds =
                                chart.ChartGroups.Group0.ChartData.SeriesList[lineIndex++];

                            ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Dot;
                            //ds.SymbolStyle.Color = colorList[i % colorList.Count];
                            //ds.LineStyle.Color = colorList[i % colorList.Count];
                            ds.SymbolStyle.Color = colorList[j % colorList.Count];
                            ds.LineStyle.Color = colorList[j % colorList.Count];
                            ds.SymbolStyle.Size = 1;
                            ds.LineStyle.Thickness = 1;

                            ds.X.Add(year);
                            //ds.Y.Add(DataSet.Populations[i].IndList.Count);
                            ds.Y.Add(DataSet.Populations[i].Nindividuals);

                            break;
                        }
                    }
                }
                    
                else if (plotType[j] == 'G')
                {
                    int vi = DataSet.GetVarIndex(plotNames[j].Substring(7));
                    if (vi >= 0)
                    {
                        double val = 0.0;
                        try
                        {
                            val = Convert.ToDouble(DataSet.Vars[vi]);
                        }
                        catch
                        { }

                        C1.Win.C1Chart.ChartDataSeries ds =
                            chart.ChartGroups.Group0.ChartData.SeriesList[lineIndex++];

                        ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Diamond;
                        ds.SymbolStyle.Color = colorList[j % colorList.Count];
                        ds.LineStyle.Color = colorList[j % colorList.Count];
                        //ds.SymbolStyle.Color = colorList[(j + colorIndex) % colorList.Count];
                        //ds.LineStyle.Color = colorList[(j + colorIndex) % colorList.Count];
                        ds.SymbolStyle.Size = 1;
                        ds.LineStyle.Thickness = 1;

                        ds.X.Add(year);
                        ds.Y.Add(val); 
                    }

                }
                else
                {
                    for (i = 0; i < DataSet.Populations.Count; i++)
                    {
                        if (!plotNames[j].StartsWith(DataSet.Populations[i].Name)) continue; 
                        int vi = DataSet.Populations[i].GetVarIndex(plotNames[j].Substring((DataSet.Populations[i].Name + ":").Length));
                        if (vi >= 0)
                        {
                            double val = 0.0;
                            try
                            {
                                val = Convert.ToDouble(DataSet.Populations[i].Vars[vi]);
                            }
                            catch
                            { }

                            C1.Win.C1Chart.ChartDataSeries ds =
                                chart.ChartGroups.Group0.ChartData.SeriesList[lineIndex++];

                            ds.SymbolStyle.Shape = C1.Win.C1Chart.SymbolShapeEnum.Box;
                            ds.SymbolStyle.Color = colorList[j % colorList.Count];
                            ds.LineStyle.Color = colorList[j % colorList.Count];
                            //ds.SymbolStyle.Color = colorList[(j + colorIndex) % colorList.Count];
                            //ds.LineStyle.Color = colorList[(j + colorIndex) % colorList.Count];
                            ds.SymbolStyle.Size = 1;
                            ds.LineStyle.Thickness = 1;

                            ds.X.Add(year);
                            ds.Y.Add(val);
                        }
                    }
                }
            }


            chart.Repaint = true;
            chart.Refresh();

        }

    }
}
