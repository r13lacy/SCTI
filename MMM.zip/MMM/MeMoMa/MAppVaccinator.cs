using System;
using System.Collections.Generic;
using System.Text;

using System.Xml;
using System.Xml.XPath;

using MMMCore;

namespace MeMoMa
{
    public class MAppVaccinator : MApp
    {

        private List<MVariable> GlobalVariables = new List<MVariable>();
        private List<MVariable> PopulationVariables = new List<MVariable>();
        private List<MVariable> IndividualVariables = new List<MVariable>();

        private string ProjectFile;

        private MMVaccinator.Meta Vaccinator = null;

        private bool FirstRun = true;

        public int PopStartIndex, NumPops;

        private int AppIndex;

        private bool DoOutput;


        public MAppVaccinator()
        {

            PopulationVariables.Add(new MVariable("Prevalence", typeof(double), "Current disease level in the population", true));

            IndividualVariables.Add(new MVariable("Index", typeof(int), "Index of the individual", false));
            IndividualVariables.Add(new MVariable("Age", typeof(int), "Age of the individual, in days", false));
            IndividualVariables.Add(new MVariable("Sex", typeof(int), "Sex of the individual", false));
            IndividualVariables.Add(new MVariable("Alive", typeof(int), "1 if alive, 0 if dead", false));
            IndividualVariables.Add(new MVariable("DiseaseState", typeof(int), "Disease state of the individual (P/S/E/I/R)", false));
            IndividualVariables.Add(new MVariable("IsVaccinated", typeof(int), "Whether or not the individual has been vaccinated", false));
            
        }


        public override string ToString()
        {
            return GetName() + " - " + GetDescription();
        }


        public void SetDoOutput(bool output) { DoOutput = output; }
        public bool GetDoOutput() { return DoOutput; }



        //INHERITED FROM MApp

        // Bob -- in case needed
        private int appStepCount;
        public void SetAppStepCount(int val) { appStepCount = val; }
        public int GetAppStepCount() { return appStepCount; }


        public string GetName()
        {
            return "Vaccinator";
        }

        public string GetDescription()
        {
            return "Vaccination module";
        }

        public string GetProjectFile()
        {
            return ProjectFile;
        }

        public void SetProjectFile(string fileName)
        {
            ProjectFile = fileName;
        }

        public List<MVariable> GetGlobalVariables()
        {
            return GlobalVariables;
        }

        public List<MVariable> GetPopulationVariables()
        {
            return PopulationVariables;
        }

        public List<MVariable> GetIndividualVariables()
        {
            return IndividualVariables;
        }

        public bool DoTurn(MDataSet dataSet, int numTimeSteps, int iteration, int year)
        {


            if (FirstRun)
            {
                Vaccinator = new MMVaccinator.Meta();

                if (!Vaccinator.Initialize(dataSet.Populations[PopStartIndex], ProjectFile))
                    return false;

                FirstRun = false;


            }


            //check if extinct, if so, no Vaccinator!
            if (dataSet.Populations[PopStartIndex].IndList.Count == 0)
                return true;

            for (int i = PopStartIndex; i < PopStartIndex + NumPops; i++)
                Vaccinator.Simulate(dataSet.Populations[i], year, numTimeSteps);

            return true;

        }

        public bool WriteResults()
        {
            return Vaccinator.CloseDLL();

        }

        public int GetAppIndex()
        {
            return AppIndex;
        }

        public void SetAppIndex(int index)
        {
            AppIndex = index;
        }

        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Vaccinator");
            iNode.AppendChild(appNode);

            XmlElement n = doc.CreateElement("ProjectFile");
            n.InnerText = ProjectFile.Substring(ProjectFile.LastIndexOf("\\") + 1);
            appNode.AppendChild(n);

            return true;
        }

        public bool ToXMLShort(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Vaccinator");
            appNode.InnerText = AppIndex.ToString();
            iNode.AppendChild(appNode);

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("ProjectFile");
            if (iter.MoveNext())
                ProjectFile = folderLocation + "\\" + iter.Current.Value;

            return true;
        }

    }
}
