namespace MeMoMa
{
    partial class frmEvaluatorSetup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lstVars = new System.Windows.Forms.ListBox();
            this.txtEq = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cboVarGlobal = new System.Windows.Forms.ComboBox();
            this.radioGlobal = new System.Windows.Forms.RadioButton();
            this.radioPop = new System.Windows.Forms.RadioButton();
            this.cboVarPop = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cboPopListPop = new System.Windows.Forms.ComboBox();
            this.cboPopListInd = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.radioInd = new System.Windows.Forms.RadioButton();
            this.cboVarInd = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(439, 533);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(76, 30);
            this.btnCancel.TabIndex = 28;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(523, 533);
            this.btnOK.Margin = new System.Windows.Forms.Padding(4);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(76, 30);
            this.btnOK.TabIndex = 27;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 357);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(220, 17);
            this.label2.TabIndex = 32;
            this.label2.Text = "Variables accessible to evaluator:";
            // 
            // lstVars
            // 
            this.lstVars.FormattingEnabled = true;
            this.lstVars.ItemHeight = 16;
            this.lstVars.Location = new System.Drawing.Point(20, 377);
            this.lstVars.Margin = new System.Windows.Forms.Padding(4);
            this.lstVars.Name = "lstVars";
            this.lstVars.Size = new System.Drawing.Size(577, 148);
            this.lstVars.TabIndex = 31;
            // 
            // txtEq
            // 
            this.txtEq.Location = new System.Drawing.Point(20, 304);
            this.txtEq.Margin = new System.Windows.Forms.Padding(4);
            this.txtEq.Name = "txtEq";
            this.txtEq.Size = new System.Drawing.Size(577, 22);
            this.txtEq.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(16, 283);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(583, 17);
            this.label1.TabIndex = 29;
            this.label1.Text = "Enter a function in the box below to modify the variable, using variables from th" +
    "e list below:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 11);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(262, 17);
            this.label3.TabIndex = 33;
            this.label3.Text = "Which variable would you like to modify?";
            // 
            // cboVarGlobal
            // 
            this.cboVarGlobal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVarGlobal.FormattingEnabled = true;
            this.cboVarGlobal.Location = new System.Drawing.Point(213, 42);
            this.cboVarGlobal.Margin = new System.Windows.Forms.Padding(4);
            this.cboVarGlobal.Name = "cboVarGlobal";
            this.cboVarGlobal.Size = new System.Drawing.Size(231, 24);
            this.cboVarGlobal.TabIndex = 34;
            // 
            // radioGlobal
            // 
            this.radioGlobal.AutoSize = true;
            this.radioGlobal.Checked = true;
            this.radioGlobal.Location = new System.Drawing.Point(20, 43);
            this.radioGlobal.Margin = new System.Windows.Forms.Padding(4);
            this.radioGlobal.Name = "radioGlobal";
            this.radioGlobal.Size = new System.Drawing.Size(154, 21);
            this.radioGlobal.TabIndex = 35;
            this.radioGlobal.TabStop = true;
            this.radioGlobal.Text = "The global variable:";
            this.radioGlobal.UseVisualStyleBackColor = true;
            this.radioGlobal.CheckedChanged += new System.EventHandler(this.radioGlobal_CheckedChanged);
            // 
            // radioPop
            // 
            this.radioPop.AutoSize = true;
            this.radioPop.Location = new System.Drawing.Point(20, 94);
            this.radioPop.Margin = new System.Windows.Forms.Padding(4);
            this.radioPop.Name = "radioPop";
            this.radioPop.Size = new System.Drawing.Size(182, 21);
            this.radioPop.TabIndex = 37;
            this.radioPop.Text = "The population variable:";
            this.radioPop.UseVisualStyleBackColor = true;
            this.radioPop.CheckedChanged += new System.EventHandler(this.radioPop_CheckedChanged);
            // 
            // cboVarPop
            // 
            this.cboVarPop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVarPop.Enabled = false;
            this.cboVarPop.FormattingEnabled = true;
            this.cboVarPop.Location = new System.Drawing.Point(213, 92);
            this.cboVarPop.Margin = new System.Windows.Forms.Padding(4);
            this.cboVarPop.Name = "cboVarPop";
            this.cboVarPop.Size = new System.Drawing.Size(231, 24);
            this.cboVarPop.TabIndex = 36;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(60, 129);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 17);
            this.label4.TabIndex = 38;
            this.label4.Text = "from the population:";
            // 
            // cboPopListPop
            // 
            this.cboPopListPop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPopListPop.Enabled = false;
            this.cboPopListPop.FormattingEnabled = true;
            this.cboPopListPop.Location = new System.Drawing.Point(213, 126);
            this.cboPopListPop.Margin = new System.Windows.Forms.Padding(4);
            this.cboPopListPop.Name = "cboPopListPop";
            this.cboPopListPop.Size = new System.Drawing.Size(231, 24);
            this.cboPopListPop.TabIndex = 39;
            // 
            // cboPopListInd
            // 
            this.cboPopListInd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPopListInd.Enabled = false;
            this.cboPopListInd.FormattingEnabled = true;
            this.cboPopListInd.Location = new System.Drawing.Point(213, 210);
            this.cboPopListInd.Margin = new System.Windows.Forms.Padding(4);
            this.cboPopListInd.Name = "cboPopListInd";
            this.cboPopListInd.Size = new System.Drawing.Size(231, 24);
            this.cboPopListInd.TabIndex = 43;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(60, 214);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 17);
            this.label5.TabIndex = 42;
            this.label5.Text = "from the population:";
            // 
            // radioInd
            // 
            this.radioInd.AutoSize = true;
            this.radioInd.Location = new System.Drawing.Point(20, 178);
            this.radioInd.Margin = new System.Windows.Forms.Padding(4);
            this.radioInd.Name = "radioInd";
            this.radioInd.Size = new System.Drawing.Size(175, 21);
            this.radioInd.TabIndex = 41;
            this.radioInd.Text = "The individual variable:";
            this.radioInd.UseVisualStyleBackColor = true;
            this.radioInd.CheckedChanged += new System.EventHandler(this.radioInd_CheckedChanged);
            // 
            // cboVarInd
            // 
            this.cboVarInd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVarInd.Enabled = false;
            this.cboVarInd.FormattingEnabled = true;
            this.cboVarInd.Location = new System.Drawing.Point(213, 177);
            this.cboVarInd.Margin = new System.Windows.Forms.Padding(4);
            this.cboVarInd.Name = "cboVarInd";
            this.cboVarInd.Size = new System.Drawing.Size(231, 24);
            this.cboVarInd.TabIndex = 40;
            // 
            // frmEvaluatorSetup
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(613, 571);
            this.Controls.Add(this.cboPopListInd);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.radioInd);
            this.Controls.Add(this.cboVarInd);
            this.Controls.Add(this.cboPopListPop);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.radioPop);
            this.Controls.Add(this.cboVarPop);
            this.Controls.Add(this.radioGlobal);
            this.Controls.Add(this.cboVarGlobal);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lstVars);
            this.Controls.Add(this.txtEq);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmEvaluatorSetup";
            this.Text = "Evaluator Step Setup";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmEvaluatorSetup_KeyUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lstVars;
        private System.Windows.Forms.TextBox txtEq;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboVarGlobal;
        private System.Windows.Forms.RadioButton radioGlobal;
        private System.Windows.Forms.RadioButton radioPop;
        private System.Windows.Forms.ComboBox cboVarPop;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboPopListPop;
        private System.Windows.Forms.ComboBox cboPopListInd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton radioInd;
        private System.Windows.Forms.ComboBox cboVarInd;
    }
}