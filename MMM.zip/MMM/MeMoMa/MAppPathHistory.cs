using System.Collections.Generic;

using System.Xml;
using System.Xml.XPath;

using MMMCore;

namespace MeMoMa
{
    public class MAppPathHistory : MApp
    {

        private List<MVariable> GlobalVariables = new List<MVariable>();
        private List<MVariable> PopulationVariables = new List<MVariable>();
        private List<MVariable> IndividualVariables = new List<MVariable>();

        private string ProjectFile;

        private MMPathHistory.Meta PathHistory = null;

        private bool FirstRun = true;

        public int PopStartIndex, NumPops;

        private int AppIndex;
//        private bool DoOutput;


        public MAppPathHistory()
        {
            IndividualVariables.Add(new MVariable("X", typeof(int), "Location of the individual", false));
            IndividualVariables.Add(new MVariable("Y", typeof(int), "Location of the individual", false));

        }


        //public void SetDoOutput(bool output) { DoOutput = output; }
        //public bool GetDoOutput() { return DoOutput; }

        public override string ToString()
        {
            return GetName() + " - " + GetDescription();
        }





        //INHERITED FROM MApp

        // Bob -- in case needed
        private int appStepCount;
        public void SetAppStepCount(int val) { appStepCount = val; }
        public int GetAppStepCount() { return appStepCount; }

        public string GetName()
        {
            return "PathHistory";
        }

        public string GetDescription()
        {
            return "Helper Module for Spatial";
        }

        public string GetProjectFile()
        {
            return ProjectFile;
        }

        public void SetProjectFile(string fileName)
        {
            ProjectFile = fileName;
        }

        public List<MVariable> GetGlobalVariables()
        {
            return GlobalVariables;
        }

        public List<MVariable> GetPopulationVariables()
        {
            return PopulationVariables;
        }

        public List<MVariable> GetIndividualVariables()
        {
            return IndividualVariables;
        }

        public bool DoTurn(MDataSet dataSet, int numTimeSteps, int iteration, int year)
        {
            int i;

            if (FirstRun)
            {
                PathHistory = new MMPathHistory.Meta();
                if (!PathHistory.Initialize(ProjectFile, NumPops))
                    return false;

                FirstRun = false;

                //the app makes sure it has all the right variables...

                //but we should load the app's var's into the list
                List<string> vars = PathHistory.GetVars();

                for (i = 0; i < vars.Count; i++)
                    IndividualVariables.Add(new MVariable(vars[i], typeof(string), "Custom variable", false));
                

            }

            //check if extinct, if so, no Path!
            bool[] extinct = new bool[NumPops];
            int exCount = 0;
            for (i = 0; i < NumPops; i++)
            {
                if (dataSet.Populations[i + PopStartIndex].IndList.Count == 0)
                {
                    extinct[i] = (dataSet.Populations[i + PopStartIndex].IndList.Count == 0);
                    exCount++;
                }
            }

            if (exCount == NumPops)
                return true;



            for (i = PopStartIndex; i < PopStartIndex + NumPops; i++)
                PathHistory.Simulate(dataSet.Populations[i], year, numTimeSteps, i);

            return true;

        }

        public bool WriteResults()
        {
            return PathHistory.CloseDLL();

        }

        public int GetAppIndex()
        {
            return AppIndex;
        }

        public void SetAppIndex(int index)
        {
            AppIndex = index;
        }

        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("PathHistory");
            iNode.AppendChild(appNode);

            XmlElement n = doc.CreateElement("ProjectFile");
            n.InnerText = ProjectFile;
            //n.InnerText = ProjectFile.Substring(ProjectFile.LastIndexOf("\\") + 1);
            appNode.AppendChild(n);

            return true;
        }

        public bool ToXMLShort(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("PathHistory");
            appNode.InnerText = AppIndex.ToString();
            iNode.AppendChild(appNode);

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("ProjectFile");
            if (iter.MoveNext())
            {
                ProjectFile = iter.Current.Value;
                if (!ProjectFile.Contains("\\")) ProjectFile = folderLocation + "\\" + ProjectFile;
            }
            //ProjectFile = folderLocation + "\\" + iter.Current.Value;

            return true;
        }

    }
}
