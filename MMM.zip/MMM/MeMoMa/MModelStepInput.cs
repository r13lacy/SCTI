using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.XPath;

namespace MeMoMa
{
    public class MModelStepInput : MModelStep
    {
        #region MModelStep Members

        public string FileName;
        public List<string> VarsToImport = new List<string>();

        public int InputFileType = 0; //0 standard, 1 ramas to one pop
        public string RAMASVar = "";

        private int[][] ramas = null; // ramas data


        public int GetNumTimeSteps()
        {
            return -1;
        }

        public void SetNumTimeSteps(int numTimeSteps)
        {
            //do nothing
        }

        private bool GetInput(MMMCore.MDataSet dataSet)
        {
            return false;

        }

        public bool Simulate(MMMCore.MDataSet dataSet, int iteration, int year)
        {
            //read in from the output file and update the appropriate variables
            //the line to be read from the file is based on the year

            int yr = year; // we will protect against missing years in input file
            char[] delims = { ' ', ':' };

            if (InputFileType == 0) //Standard File
            {
                List<string> file = JPUtils.ReadFileToList(FileName);

                int i = 0;
                while (i < file.Count)
                {
                    if (file[i][0] == '#')
                        file.RemoveAt(i);
                    else
                        i++;
                }

                if (yr >= file.Count) yr = file.Count - 1;

                string[] correctLine = file[yr].Split(';');


                //find the correct var to update
                //VarsToImport format is "global.varname" or "population.varname"

                int[] varIndex = new int[VarsToImport.Count];
                bool[] varGlobal = new bool[VarsToImport.Count];
                for (i = 0; i < VarsToImport.Count; i++)
                {
                    if (string.Compare(VarsToImport[i].Substring(0, "global".Length), "global", true) == 0)
                    {
                        varIndex[i] = dataSet.GetVarIndex(VarsToImport[i].Substring("global".Length + 1));
                        if (varIndex[i] < 0)
                        {
                            dataSet.VarNames.Add(VarsToImport[i].Substring("global".Length + 1).ToUpper());
                            dataSet.Vars.Add("");
                            dataSet.VarTypes.Add(typeof(string));
                            varIndex[i] = dataSet.VarNames.Count - 1;
                        }
                        varGlobal[i] = true;
                    }
                    else
                    if (string.Compare(VarsToImport[i].Substring(0, "population".Length), "population", true) == 0)
                    {
                        for (int p = 0; p < dataSet.Populations.Count; p++)
                        {
                            varIndex[i] = dataSet.Populations[p].GetVarIndex(VarsToImport[i].Substring("population".Length + 1));
                            if (varIndex[i] < 0)
                            {
                                dataSet.Populations[p].VarNames.Add(VarsToImport[i].Substring("population".Length + 1).ToUpper());
                                dataSet.Populations[p].Vars.Add("");
                                dataSet.Populations[p].VarTypes.Add(typeof(string));
                                varIndex[i] = dataSet.Populations[p].VarNames.Count - 1;
                            }
                        }
                        varGlobal[i] = false;
                    }
                }


                //parse correctLine based on the list of vars

                for (i = 0; i < Math.Min(correctLine.Length, VarsToImport.Count); i++) //only go as many items as there are in either list
                {
                    if (varIndex[i] >= 0 && varGlobal[i]) 
                    {
//                        dataSet.Vars[varIndex[i]] = correctLine[i];
                        dataSet.SetVarVal(varIndex[i],correctLine[i]);
                    }
                    else if (varIndex[i] >= 0 && !varGlobal[i]) //TODO test Population var input!
                    {
                        string[] correctPop = correctLine[i].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                        for(int p = 0; p < dataSet.Populations.Count; p++) 
                        {
                            int datap = p;
                            if (datap >= correctPop.GetLength(0)) datap = correctPop.GetLength(0) - 1;
                            dataSet.Populations[p].Vars[varIndex[i]] = correctPop[datap];
                        }
                    }
                }
            }
            else if (InputFileType == 1) //RAMAS 1 Pop
            {
                if (ramas == null)
                    ProcessRamasFile1Pop();

                //find the correct var to update
                //VarsToImport format is "global.varname" or "population.varname"

                int varIndex = -1;
                
                if (string.Compare(RAMASVar.Substring(0, "global".Length), "global", true) == 0)
                {
                    varIndex = dataSet.GetVarIndex(RAMASVar.Substring("global".Length + 1));
                    if (varIndex < 0)
                    {
                        dataSet.VarNames.Add(RAMASVar.Substring("global".Length + 1).ToUpper());
                        dataSet.Vars.Add(ramas[iteration][year].ToString());
                        dataSet.VarTypes.Add(typeof(string));
                        varIndex = dataSet.VarNames.Count - 1;
                    }
                    else
                        dataSet.SetVarVal(varIndex, ramas[iteration][year]);
                    //dataSet.Vars[varIndex] = ramas[iteration][year].ToString();

                }
                else
                {
                    

                }
                


            }

            return true;
        }

        private void ProcessRamasFile1Pop()
        {
            List<string> file = JPUtils.ReadFileToList(FileName, false); //don't trim it

            int i = 0, j, k;

            file.RemoveAt(0);
            file.RemoveAt(0);

            while (file[i].Trim() == "")
                i++;

            //this should be the number of iterations
            string[] s = file[i++].Split(' ');
            int iters = Convert.ToInt32(s[0]);
            
            s = file[i++].Split(' ');
            int years = Convert.ToInt32(s[0]);

            s = file[i++].Split(' ');
            int pops = Convert.ToInt32(s[0]);

            //now the rest are the data
            int filePos = i + 1;

            ramas = new int[iters][];

            for (i = 0; i < iters; i++)
            {
                ramas[i] = new int[years];

                for (j = 0; j < years; j++)
                {
                    int popSize = 0;
                    for (k = 0; k < pops; k++)
                    {
                        s = file[filePos++].Substring(13).Split(' ');
                        popSize += Convert.ToInt32(s[0]);
                    }

                    ramas[i][j] = popSize;
                }


            }
        }


        public bool WriteResults()
        {
            //do nothing
            return true;
        }


        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement n = doc.CreateElement("Input");
            iNode.AppendChild(n);

            XmlElement nn = doc.CreateElement("FileName");
            nn.InnerText = FileName;
            //nn.InnerText = FileName.Substring(FileName.LastIndexOf("\\") + 1);
            n.AppendChild(nn);

            nn = doc.CreateElement("InputFileType");
            nn.InnerText = InputFileType.ToString();
            n.AppendChild(nn);

            if (InputFileType == 1)
            {
                nn = doc.CreateElement("RAMASVar");
                nn.InnerText = RAMASVar.ToString();
                n.AppendChild(nn);
            }

            nn = doc.CreateElement("VarList");
            n.AppendChild(nn);

            for (int i = 0; i < VarsToImport.Count; i++)
            {
                XmlElement v = doc.CreateElement("Var");
                v.InnerText = VarsToImport[i];
                nn.AppendChild(v);
            }


            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("FileName");
            if (iter.MoveNext())
            {
                FileName = iter.Current.Value;
                if(!FileName.Contains("\\")) FileName = folderLocation + "\\" + FileName;
            }
            
            iter = n.Select("InputFileType");
            if (iter.MoveNext())
                InputFileType = Convert.ToInt32(iter.Current.Value);

            if (InputFileType == 1)
            {
                iter = n.Select("RAMASVar");
                if (iter.MoveNext())
                    RAMASVar = iter.Current.Value;
            }

            iter = n.Select("VarList");
            iter.MoveNext();
            XPathNodeIterator it2 = iter.Current.Clone().Select("Var");
            while (it2.MoveNext())
                VarsToImport.Add(it2.Current.Value);

            return true;
        }

        #endregion
    }
}
