using System;
using System.Collections.Generic;

namespace MeMoMa
{
    public class MVariable
    {
        public string Name = "";
        public string DescriptionShort = "";
        public string DescriptionLong = "";

        public Type VariableType = typeof(object);

        public bool ReadOnly = false;


        public MVariable(string name, Type type, string shortDesc, bool readOnly)
        {
            Name = name.ToUpper();  // 18 dec 2014 
            VariableType = type;
            DescriptionShort = shortDesc;
            ReadOnly = readOnly;
        }


        public static int VarListIndexOf(List<MVariable> list, string name)
        {
            int i = 0;
            while (i < list.Count)
            {
                if (list[i].Name == name.ToUpper())
                    return i;
                else
                    i++;
            }

            return -1;
        }


        public override string ToString()
        {
            return Name;
        }

    }
}
