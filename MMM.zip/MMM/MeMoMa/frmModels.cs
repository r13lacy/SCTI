using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MeMoMa
{
    public partial class frmModels : Form
    {
        private List<MApp> AppList = null;
        private List<MApp> SysAppList = null;

        public frmModels(List<MApp> sysappList, List<MApp> appList)
        {
            InitializeComponent();

            AppList = appList;
            SysAppList = sysappList;

            for (int i = 0; i < SysAppList.Count; i++)
            {
                if (SysAppList[i].GetType() == typeof(MSystemAppExternal))
                    lstSysApps.Items.Add(SysAppList[i]);
            }

            for (int i = 0; i < AppList.Count; i++)
            {
                if (AppList[i].GetType() == typeof(MAppExternal))
                    lstApps.Items.Add(AppList[i]);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            MAppExternal app = new MAppExternal();
            new frmModelSpec(app).ShowDialog();

            app.SetAppIndex(AppList.Count);
            AppList.Add(app);
            lstApps.Items.Add(app);
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to remove the following application?", "Delete?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                AppList.Remove((MApp)lstApps.SelectedItem);
                lstApps.Items.Remove(lstApps.SelectedItem);
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {

        }

        private void btnMod_Click(object sender, EventArgs e)
        {
            if (lstApps.SelectedItem != null)
            {
                new frmModelSpec((MAppExternal)lstApps.SelectedItem).ShowDialog();

            }
        }

        private void lstApps_DoubleClick(object sender, EventArgs e)
        {
            btnMod_Click(lstApps, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "XML Files (*.xml)|*.xml";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                //try
                //{
                    MAppExternal app = new MAppExternal(dlg.FileName);

                    app.SetAppIndex(AppList.Count);
                    AppList.Add(app);
                    lstApps.Items.Add(app);
                //}
                //catch
                //{
                //    MessageBox.Show("Unable to use the specified file to add a new model.  Please check the file carefully and try again, or select a different file.");
                //}
            }

        }

        private void btnAddSys_Click(object sender, EventArgs e)
        {
            MSystemAppExternal app = new MSystemAppExternal();
            new frmModelSpec(app).ShowDialog();

            app.SetAppIndex(SysAppList.Count);
            SysAppList.Add(app);
            lstSysApps.Items.Add(app);
        }

        private void btnAddSysXML_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "XML Files (*.xml)|*.xml";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                MSystemAppExternal app = new MSystemAppExternal(dlg.FileName);

                app.SetAppIndex(SysAppList.Count);
                SysAppList.Add(app);
                lstSysApps.Items.Add(app);
            }

        }

        private void btnDelSys_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to remove the following application?", "Delete?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                SysAppList.Remove((MSystemApp)lstSysApps.SelectedItem);
                lstSysApps.Items.Remove(lstSysApps.SelectedItem);
            }
        }

        private void btnModSys_Click(object sender, EventArgs e)
        {
            if (lstSysApps.SelectedItem != null)
            {
                new frmModelSpec((MSystemAppExternal)lstSysApps.SelectedItem).ShowDialog();
            }
        }

        private void lstSysApps_DoubleClick(object sender, EventArgs e)
        {
            btnModSys_Click(lstSysApps, e);
        }

        private void frmModels_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("Models");
        }

    }
}