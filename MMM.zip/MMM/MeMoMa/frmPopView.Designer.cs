namespace MeMoMa
{
    partial class frmPopView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fgPop = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblVars = new System.Windows.Forms.Label();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnWriteToFile = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.fgPop)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // fgPop
            // 
            this.fgPop.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.fgPop.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.MultiColumn;
            this.fgPop.ColumnInfo = "10,0,0,0,0,85,Columns:";
            this.fgPop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fgPop.Location = new System.Drawing.Point(0, 58);
            this.fgPop.Margin = new System.Windows.Forms.Padding(4);
            this.fgPop.Name = "fgPop";
            this.fgPop.Rows.DefaultSize = 17;
            this.fgPop.Size = new System.Drawing.Size(836, 375);
            this.fgPop.TabIndex = 6;
            this.fgPop.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgPop_AfterEdit);
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.lblVars);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Margin = new System.Windows.Forms.Padding(4);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(836, 58);
            this.pnlTop.TabIndex = 5;
            // 
            // lblVars
            // 
            this.lblVars.AutoSize = true;
            this.lblVars.Location = new System.Drawing.Point(16, 22);
            this.lblVars.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVars.Name = "lblVars";
            this.lblVars.Size = new System.Drawing.Size(138, 17);
            this.lblVars.TabIndex = 0;
            this.lblVars.Text = "Population Variables";
            // 
            // pnlBottom
            // 
            this.pnlBottom.Controls.Add(this.btnWriteToFile);
            this.pnlBottom.Controls.Add(this.btnReset);
            this.pnlBottom.Controls.Add(this.btnOK);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 433);
            this.pnlBottom.Margin = new System.Windows.Forms.Padding(4);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(836, 43);
            this.pnlBottom.TabIndex = 4;
            // 
            // btnWriteToFile
            // 
            this.btnWriteToFile.Location = new System.Drawing.Point(164, 7);
            this.btnWriteToFile.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteToFile.Name = "btnWriteToFile";
            this.btnWriteToFile.Size = new System.Drawing.Size(184, 28);
            this.btnWriteToFile.TabIndex = 2;
            this.btnWriteToFile.Text = "Write to File...";
            this.btnWriteToFile.UseVisualStyleBackColor = true;
            this.btnWriteToFile.Click += new System.EventHandler(this.btnWriteToFile_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(16, 7);
            this.btnReset.Margin = new System.Windows.Forms.Padding(4);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(140, 28);
            this.btnReset.TabIndex = 1;
            this.btnReset.Text = "Reset Changes";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(716, 7);
            this.btnOK.Margin = new System.Windows.Forms.Padding(4);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(103, 28);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // frmPopView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(836, 476);
            this.Controls.Add(this.fgPop);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.pnlBottom);
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmPopView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Population";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmPopView_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.fgPop)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.C1FlexGrid.C1FlexGrid fgPop;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnWriteToFile;
        private System.Windows.Forms.Label lblVars;
    }
}