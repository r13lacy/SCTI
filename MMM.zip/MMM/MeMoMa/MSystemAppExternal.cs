using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

using MMMCore;

using System.Xml;
using System.Xml.XPath;
using System.Reflection;

namespace MeMoMa
{
    public class MSystemAppExternal : MSystemApp
    {
        private List<MApp> m_SubModels = new List<MApp>();

        public int curYear = -1;
        public int curIter = 0;

        private MPopulation Mpop;
        public int StartingPopIndex = 0;
        public int NumPops = 0;

        public string ProjectName;

        private List<MVariable> GlobalVariables = new List<MVariable>();
        private List<MVariable> PopulationVariables = new List<MVariable>();
        private List<MVariable> IndividualVariables = new List<MVariable>();

        private string ProjectFile;

        private string Name;
        private string Description;

        public string SpecFile;

        public string DLLFile;
        public string LibNameSpace;
        public bool IsStandard = false;
        public bool popbase = false;

        private int AppIndex = -1;

        private Assembly Lib = null;
        private object LibObj = null;

        public string InitFunction = "Initialize";
        public string SimFunction = "Simulate";
        public string CloseFunction = "CloseDLL";
        public string Year0Function = "SimYear0";

        // in case External App needs them
        public int numYears, numIterations;

        private int appStepCount;
        public void SetAppStepCount(int val) { appStepCount = val; }
        public int GetAppStepCount() { return appStepCount; }

        public string userData;

        public MSystemAppExternal()
        {
            userData = Application.LocalUserAppDataPath.Substring(0, Application.LocalUserAppDataPath.LastIndexOf("\\"));

        }


        public MSystemAppExternal(string specFileName)
        {
            userData = Application.LocalUserAppDataPath.Substring(0, Application.LocalUserAppDataPath.LastIndexOf("\\"));
            LoadSpecFile(specFileName);
        }

        //public ~MSystemAppExternal()
        //{

        //}


        public List<MApp> SubModels() { return m_SubModels; }


        private void LoadSpecFile(string fileName)
        {

            SpecFile = fileName;

            //XML Load File
            XmlDocument doc = new XmlDocument();

            //make sure it is a valid document
            doc.Load(fileName);

            //doc is loaded, start reading

            XPathNavigator Nav = doc.CreateNavigator();
            XPathNodeIterator iter;

            //get the project name, if it has one
            iter = Nav.SelectChildren("MSystemAppSpecs", "");

            if (!iter.MoveNext())
                return;


            iter = Nav.Select("MSystemAppSpecs/Name");
            if (iter.Count == 0) throw new Exception("Name field not defined");
            iter.MoveNext();
            this.Name = iter.Current.Value;

            iter = Nav.Select("MSystemAppSpecs/Description");
            if (iter.Count == 0) throw new Exception("Description field not defined");
            iter.MoveNext();
            this.Description = iter.Current.Value;

            iter = Nav.Select("MSystemAppSpecs/PopBase");
            if (iter.MoveNext())
            {
                char c = iter.Current.Value[0];
                this.popbase = (c == 'T' || c == 't' || c == '1');
            }
            iter = Nav.Select("MSystemAppSpecs/DLL");
            if (iter.Count == 0) throw new Exception("DLL field not defined");
            iter.MoveNext();
            this.DLLFile = iter.Current.Value;

            iter = Nav.Select("MSystemAppSpecs/NameSpace");
            if (iter.Count == 0) throw new Exception("NameSpace field not defined");
            iter.MoveNext();
            this.LibNameSpace = iter.Current.Value;

                    //XPathNodeIterator iterSec = iterSc.Current.Select("Notes");
                    //if (iterSec.MoveNext())
                    //{
                    //    iter = iterSec.Current.Select("Scene");
                    //    if (iter.MoveNext())
                    //        SceneNotes = iter.Current.Value;
                    //    iter = iterSec.Current.Select("Species");
                    //    if (iter.MoveNext())
                    //        SpeciesNotes = iter.Current.Value;

            //XmlElement xNotes = doc.CreateElement("Notes");
            //xNotes.SetAttribute("scenario", iscStr);
            //xNotes.InnerText = notes;
            //xscene.AppendChild(xNotes);

            //XmlElement inote = doc.CreateElement("Scene");
            //inote.InnerText = SceneNotes;
            //xNotes.AppendChild(inote);



            iter = Nav.Select("MSystemAppSpecs/Variables/Individual");
            while (iter.MoveNext())
            {
                string ivar = "";
                XPathNodeIterator iter2 = iter.Current.Select("VarName");
                if (iter2.MoveNext()) ivar = iter2.Current.Value;

                Type tt = typeof(string);
                iter2 = iter.Current.Select("Type");
                if (iter2.MoveNext()) tt = JPUtils.stringToType(iter2.Current.Value);
                    
                IndividualVariables.Add(new MVariable(ivar, tt, "", false));

                //do description, type, etc
            }

            iter = Nav.Select("MSystemAppSpecs/Variables/Global");
            while (iter.MoveNext())
            {
                string Gvar = "";
                XPathNodeIterator iter2 = iter.Current.Select("VarName");
                if (iter2.MoveNext()) Gvar = iter2.Current.Value;

                Type tt = typeof(double);
                iter2 = iter.Current.Select("Type");
                if (iter2.MoveNext()) tt = JPUtils.stringToType(iter2.Current.Value);

                GlobalVariables.Add(new MVariable(Gvar, tt, "", false));

                //do description, type, etc
            }

            iter = Nav.Select("MSystemAppSpecs/Variables/Population");
            while (iter.MoveNext())
            {
                string pvar = "";
                XPathNodeIterator iter2 = iter.Current.Select("VarName");
                if (iter2.MoveNext()) pvar = iter2.Current.Value;

                Type tt = typeof(string);
                iter2 = iter.Current.Select("Type");
                if (iter2.MoveNext()) tt = JPUtils.stringToType(iter2.Current.Value);

                PopulationVariables.Add(new MVariable(pvar, tt, "", false));
            }

            iter = Nav.Select("MSystemAppSpecs/Functions/Standard");
            if (iter.MoveNext())
            {
                char c = iter.Current.Value[0];
                this.IsStandard = (c == 'T' || c == 't' || c == '1');
            }

            if (!this.IsStandard)
            {
                //read in function strings
                // by Bob
                iter = Nav.Select("MSystemAppSpecs/Functions/Initialize");
                if (iter.MoveNext())
                {
                    this.InitFunction = iter.Current.Value.Trim();
                }
                iter = Nav.Select("MSystemAppSpecs/Functions/Simulate");
                if (iter.MoveNext())
                {
                    this.SimFunction = iter.Current.Value.Trim();
                }
                iter = Nav.Select("MSystemAppSpecs/Functions/Year0");
                if (iter.MoveNext())
                {
                    this.Year0Function = iter.Current.Value.Trim();
                    if (this.Year0Function == "" || this.Year0Function == "none") this.Year0Function = null;
                }
                iter = Nav.Select("MSystemAppSpecs/Functions/Close");
                if (iter.MoveNext())
                {
                    this.CloseFunction = iter.Current.Value.Trim();
                }

            }
            else
            {
                //what do we need to do for a standard library? probably nothing
            }

            try
            {
                Lib = Assembly.LoadFrom(DLLFile);
            }
            catch
            {
                Lib = Assembly.LoadFrom(Application.StartupPath + "\\" + DLLFile);
            }
            Lib = Assembly.LoadFrom(DLLFile);
            LibObj = Lib.CreateInstance(LibNameSpace);

        }

        public int GetAppIndex()
        {
            return AppIndex;
        }

        public void SetAppIndex(int index)
        {
            AppIndex = index;
        }

        public void SaveToXML(string fileName)
        {
            XmlDocument doc = new XmlDocument();
            int i;

            //add top node and name as attrib
            XmlElement topNode = doc.CreateElement("MSystemAppSpecs");
            doc.AppendChild(topNode);

            XmlElement n = doc.CreateElement("Name");
            n.InnerText = this.Name;
            topNode.AppendChild(n);

            n = doc.CreateElement("Description");
            n.InnerText = this.Description;
            topNode.AppendChild(n);

            n = doc.CreateElement("DLL");
            n.InnerText = this.DLLFile;
            topNode.AppendChild(n);

            n = doc.CreateElement("NameSpace");
            n.InnerText = this.LibNameSpace;
            topNode.AppendChild(n);

            n = doc.CreateElement("Variables");
            topNode.AppendChild(n);

            for (i = 0; i < IndividualVariables.Count; i++)
            {
                XmlElement nn = doc.CreateElement("Individual");
                //nn.InnerText = IndividualVariables[i].Name;
                n.AppendChild(nn);

                XmlElement nn2 = doc.CreateElement("VarName");
                nn2.InnerText = IndividualVariables[i].Name;
                nn.AppendChild(nn2);

                nn2 = doc.CreateElement("Type");
                nn2.InnerText = IndividualVariables[i].VariableType.ToString();
                nn.AppendChild(nn2);
            }

            for (i = 0; i < PopulationVariables.Count; i++)
            {
                XmlElement nn = doc.CreateElement("Population");
//                nn.InnerText = PopulationVariables[i].Name;
                n.AppendChild(nn);

                XmlElement nn2 = doc.CreateElement("VarName");
                nn2.InnerText = PopulationVariables[i].Name;
                nn.AppendChild(nn2);

                nn2 = doc.CreateElement("Type");
                nn2.InnerText = PopulationVariables[i].VariableType.ToString();
                nn.AppendChild(nn2);
            }

            for (i = 0; i < GlobalVariables.Count; i++)
            {
                XmlElement nn = doc.CreateElement("Global");
//                nn.InnerText = GlobalVariables[i].Name;
                n.AppendChild(nn);

                XmlElement nn2 = doc.CreateElement("VarName");
                nn2.InnerText = GlobalVariables[i].Name;
                nn.AppendChild(nn2);

                nn2 = doc.CreateElement("Type");
                nn2.InnerText = GlobalVariables[i].VariableType.ToString();
                nn.AppendChild(nn2);
            }


            n = doc.CreateElement("Functions");
            topNode.AppendChild(n);

            if (this.IsStandard)
            {
                XmlElement nn = doc.CreateElement("Standard");
                nn.InnerText = "True";
                n.AppendChild(nn);
            }
            else
            {
                XmlElement nn = doc.CreateElement("Standard");
                nn.InnerText = "False";
                n.AppendChild(nn);
                nn = doc.CreateElement("Initialize");
                nn.InnerText = InitFunction;
                n.AppendChild(nn);
                nn = doc.CreateElement("Simulate");
                nn.InnerText = SimFunction;
                n.AppendChild(nn);
                nn = doc.CreateElement("Year0");
                if (Year0Function == null)
                    nn.InnerText = "none";
                else nn.InnerText = Year0Function;
                n.AppendChild(nn);
                nn = doc.CreateElement("Close");
                nn.InnerText = CloseFunction;
                n.AppendChild(nn);
            }

            doc.Save(fileName);

        }


        public override string ToString()
        {
            return GetName() + " - " + GetDescription();
        }

        //INHERITED FROM MApp
        public string GetName()
        {
            return this.Name;
        }

        public string GetDescription()
        {
            return this.Description;
        }

        public List<MVariable> GetGlobalVariables()
        {
            return GlobalVariables;
        }

        public int GetScenarioIndex() { return 1; }
        public int GetStartingPopIndex() { return StartingPopIndex; }
        public void SetStartingPopIndex(int val) { StartingPopIndex = val; }
        public void SetNumPops(int val) { NumPops = val; }
        public int GetNumPops() { return NumPops; }
        public void SetNumYears(int val) { numYears = val; }
        public void SetNumIter(int val) { numIterations = val; }

        public string GetScenarioName() { return "ExternalSystemScenario"; }
        public void SetScenarioIndex(int val) {  }

        public void SetName(string name)
        {
            Name = name;
        }

        public void SetDescription(string descr)
        {
            Description = descr;
        }

        public void SetGlobalVariables(List<MVariable> vlist)
        {
            GlobalVariables = vlist;
        }

        public string GetProjectFile()
        {
            return ProjectFile;
        }

        public void SetProjectFile(string fileName)
        {
            ProjectFile = fileName;
        }

        public List<MVariable> GetPopulationVariables()
        {
            return PopulationVariables;
        }

        public List<MVariable> GetIndividualVariables()
        {
            return IndividualVariables;
        }

        public void SetPopulationVariables(List<MVariable> vlist)
        {
            PopulationVariables = vlist;
        }

        public void SetIndividualVariables(List<MVariable> vlist)
        {
            IndividualVariables = vlist;
        }

        public string GetProjectName() { return ProjectName; }

        public bool Init(MDataSet dataSet, int totalTimeStepsToRun)
        {
            try
            {
                Type t = Lib.GetType(LibNameSpace);

                MethodInfo mm;
                ParameterInfo[] pp;

                mm = t.GetMethod(InitFunction);
                pp = mm.GetParameters();

                if (pp[0].ParameterType.FullName == "MMMCore.MDataSet")
                {
                    if (pp[1].ParameterType.FullName == "MMMCore.MPopulation")
                    {
                        Mpop = dataSet.Populations[StartingPopIndex];

                        if (pp.Length == 5)
                        {
                            mm.Invoke(LibObj, new object[5] { dataSet, Mpop, ProjectFile, numIterations, numYears });
                        }
                        else if (pp.Length == 6)
                        {
                            mm.Invoke(LibObj, new object[6] { dataSet, Mpop, ProjectFile, numIterations, numYears, totalTimeStepsToRun });
                        }
                        else mm.Invoke(LibObj, new object[3] { dataSet, Mpop, ProjectFile });
                    }
                    else
                    {
                        if (pp.Length == 4)
                        {
                            mm.Invoke(LibObj, new object[4] { dataSet, ProjectFile, numIterations, numYears });
                        }
                        else if (pp.Length == 5)
                        {
                            mm.Invoke(LibObj, new object[5] { dataSet, ProjectFile, numIterations, numYears, totalTimeStepsToRun });
                        }
                        else mm.Invoke(LibObj, new object[2] { dataSet, ProjectFile });
                    }
                }
                else if (pp[0].ParameterType.FullName == "MMMCore.MPopulation")
                {
                    Mpop = dataSet.Populations[StartingPopIndex];

                    if (pp.Length == 4)
                    {
                        mm.Invoke(LibObj, new object[4] { Mpop, ProjectFile, numIterations, numYears });
                    }
                    else if (pp.Length == 5)
                    {
                        mm.Invoke(LibObj, new object[5] { Mpop, ProjectFile, numIterations, numYears, totalTimeStepsToRun });
                    }
                    else mm.Invoke(LibObj, new object[2] { Mpop, ProjectFile });
                }
                else // assume it is passing a file
                {
//                    string filename = "xchangefile.txt";
                    string filename = ProjectFile.Substring(0, ProjectFile.LastIndexOf('\\') + 1) + "xchangefile.txt";

                    WriteDataFile(dataSet, filename, 0, 0, totalTimeStepsToRun);
                    // note: most init functions wouldn't need dataSet, but some might

                    if (pp.Length == 4)
                    {
                        mm.Invoke(LibObj, new object[4] { filename, ProjectFile, numIterations, numYears });
                    }
                    else if (pp.Length == 5)
                    {
                        mm.Invoke(LibObj, new object[5] { filename, ProjectFile, numIterations, numYears, totalTimeStepsToRun });
                    }
                    else mm.Invoke(LibObj, new object[2] { filename, ProjectFile });

                    ReadDataFile(ref dataSet, filename);
                }

            }
            catch
            {
                return false;
            }

            return true;
        }

        public bool DoYear0(MDataSet dataSet, int iteration)
        {
            if (Year0Function == null || Year0Function == "" || Year0Function == "none") return true;

            try
            {
                Type t = Lib.GetType(LibNameSpace);

                MethodInfo mm;
                ParameterInfo[] pp;

                mm = t.GetMethod(Year0Function); 

                pp = mm.GetParameters();

                if (pp[0].ParameterType.FullName == "MMMCore.MDataSet")
                {
                    if (pp[1].ParameterType.FullName == "MMMCore.MPopulation")
                    {
                        Mpop = dataSet.Populations[StartingPopIndex];
                        return Convert.ToBoolean(mm.Invoke(LibObj, new object[3] { dataSet, Mpop, iteration }));
                    }
                    else
                    {
                        return Convert.ToBoolean(mm.Invoke(LibObj, new object[2] { dataSet, iteration }));
                    }
                }
                else if (pp[0].ParameterType.FullName == "MMMCore.MPopulation")
                {
                    Mpop = dataSet.Populations[StartingPopIndex];
                    return Convert.ToBoolean(mm.Invoke(LibObj, new object[2] { Mpop, iteration }));
                }
                else // assume it is passing a filename 
                {
                    //string filename = "xchangefile.txt";
                    string filename = ProjectFile.Substring(0, ProjectFile.LastIndexOf('\\') + 1) + "xchangefile.txt";
                    
                    WriteDataFile(dataSet, filename, iteration, 0, 1);  // not needed before Year0 setup?

                    bool a = Convert.ToBoolean(mm.Invoke(LibObj, new object[2] { filename, iteration }));
                    
                    ReadDataFile(ref dataSet, filename);
                    return a;
                }
            }
            catch (Exception ex)
            {
                var mes = ex.Message;
                return false;
            }
        }


        public bool DoTurn(MDataSet dataSet, int numTimeSteps, int iteration, int year)
        {
            try
            {
                Type t = Lib.GetType(LibNameSpace);

                MethodInfo mm;
                ParameterInfo[] pp;

                mm = t.GetMethod(SimFunction);

                pp = mm.GetParameters();

                if (pp[0].ParameterType.FullName == "MMMCore.MDataSet")
                {
                    if (pp[1].ParameterType.FullName == "MMMCore.MPopulation")
                    {
                        Mpop = dataSet.Populations[StartingPopIndex];
                        return Convert.ToBoolean(mm.Invoke(LibObj, new object[5] { dataSet, Mpop, iteration, year, numTimeSteps }));
                    }
                    else
                    {
                        return Convert.ToBoolean(mm.Invoke(LibObj, new object[4] { dataSet, iteration, year, numTimeSteps }));
                    }
                }
                else if (pp[0].ParameterType.FullName == "MMMCore.MPopulation")
                {
                    Mpop = dataSet.Populations[StartingPopIndex];
                    return Convert.ToBoolean(mm.Invoke(LibObj, new object[4] { Mpop, iteration, year, numTimeSteps }));
                }
                else // assume it is passing a filename 
                {
//                    string filename = "xchangefile.txt";
                    string filename = ProjectFile.Substring(0, ProjectFile.LastIndexOf('\\') + 1) + "xchangefile.txt";

                    WriteDataFile(dataSet, filename, iteration, year, numTimeSteps);
                    bool a = Convert.ToBoolean(mm.Invoke(LibObj, new object[4] { filename, iteration, year, numTimeSteps }));
                    ReadDataFile(ref dataSet, filename);
                    return a;
                }
            }
            catch (Exception ex)
            {
                var mes = ex.Message;
                return false;
            }
        }


        public void WriteDataFile(MDataSet dataSet, string fileLocation, int iteration, int year, int numTimeSteps)
        {
            WriteDataFile(dataSet, fileLocation, iteration, year, numTimeSteps, false);
        }

        public void WriteDataFile(MDataSet dataSet, string fileLocation, int iteration, int year, int numTimeSteps, bool popbase)
        {
            //Creator = MMM ...
            //Iteration = 1, Year = 50, Timesteps = 5
            //GlobalVariables, NumGS Vars = 2
            //GS1, GS2
            //1.0000,2.0000
            //PopulationVariables, NumPS Vars = 2, Population 1: PopName
            //PS1,PS2
            //22.000000; 11.000000
            //PopulationSize = 100
            //AgeStructure
            //Females: 12;22;33
            //Males: 32;12;11
            //IndividualVariables, NumISVars = 2
            //Name,Index,Age,Sex,Var1,Var2
            //33;0;11688;0;33.00000000;34.00000000
            //35;1;11688;1;33.00000000;34.00000000
            //PopulationVariables, NumPS Vars = 2, Population 2: PopName
            //PS1,PS2
            //222.000000; 111.000000
            //IndividualVariables, NumISVars = 2
            //Name,Index,Age,Sex,Var1,Var2
            //33;0;11688;0;33.00000000;34.00000000
            //35;1;11688;1;33.00000000;34.00000000


            using (var writer = new StreamWriter(fileLocation, false))
            {
                writer.AutoFlush = true;

                writer.WriteLine("MData File Created by MMM - " + DateTime.Now.ToLongDateString());
                writer.WriteLine("Iteration = " + iteration.ToString() + ", Year = " + year.ToString() + ", Timesteps = " + numTimeSteps.ToString());
                writer.WriteLine("GlobalVariables, NumGSVars = " + GlobalVariables.Count.ToString());

                if (GlobalVariables.Count > 0)
                {
                    int[] GVs = new int[GlobalVariables.Count];
                    for (int i = 0; i < GlobalVariables.Count; i++)
                        GVs[i] = dataSet.GetVarIndex(GlobalVariables[i].Name); // note: GlobalVariables within MAppExternal might be a subset of all GSvars in MData

                    writer.Write(GlobalVariables[0].Name);
                    for (int j = 1; j < GlobalVariables.Count; j++)
                        writer.Write("," + GlobalVariables[j].Name);
                    writer.WriteLine();

                    // New
                    writer.Write(GlobalVariables[0].VariableType.ToString());
                    for (int j = 1; j < GlobalVariables.Count; j++)
                    {
                        writer.Write("," + GlobalVariables[j].VariableType.ToString());
                    }
                    writer.WriteLine();

                    for (int j = 0; j < GlobalVariables.Count; j++)
                    {
                        if (GVs[j] >= 0)
                            writer.Write(dataSet.GetVarVal(GVs[j]));
                            //writer.Write(dataSet.Vars[GVs[j]]);
                        if (j < GlobalVariables.Count - 1)
                            writer.Write(";"); // don't use comma delimiters between numbers, EU format problem
                    }
                    writer.WriteLine();
                }

                for (int p = 0; p < dataSet.Populations.Count; p++)
                {
                    MPopulation mpop = dataSet.Populations[p];

                    writer.WriteLine("PopulationVariables, NumPSVars = " + PopulationVariables.Count.ToString() + ", Population " + (p + 1).ToString() + ": " + mpop.Name);

                    if (PopulationVariables.Count > 0)
                    {
                        int[] PVs = new int[PopulationVariables.Count];
                        for (int i = 0; i < PopulationVariables.Count; i++)
                            PVs[i] = mpop.GetVarIndex(PopulationVariables[i].Name);

                        writer.Write(PopulationVariables[0].Name);
                        for (int j = 1; j < PopulationVariables.Count; j++)
                            writer.Write("," + PopulationVariables[j].Name);
                        writer.WriteLine();

                        writer.Write(PopulationVariables[0].VariableType.ToString());
                        for (int j = 1; j < PopulationVariables.Count; j++)
                        {
                            writer.Write("," + PopulationVariables[j].VariableType.ToString());
                        }
                        writer.WriteLine();

                        for (int j = 0; j < PopulationVariables.Count; j++)
                        {
                            if (PVs[j] >= 0)
                                writer.Write(mpop.Vars[PVs[j]]);
                            if (j < PopulationVariables.Count - 1)
                                writer.Write(";"); // don't use comma delimiters between numbers, EU format problem
                        }
                        writer.WriteLine();
                    }

                    writer.WriteLine("PopulationSize = " + mpop.Nindividuals.ToString());
                    //if (mpop.Females.Count > 0 || mpop.Males.Count > 0)
                    //{
                    writer.WriteLine("AgeStructure");
                    string tally = "Females: ";
                    for (int j = 0; j < mpop.Females.Count; j++) tally += mpop.Females[j].ToString() + ";";
                    writer.WriteLine(tally.Trim(';'));
                    tally = "Males: ";
                    for (int j = 0; j < mpop.Males.Count; j++) tally += mpop.Males[j].ToString() + ";";
                    writer.WriteLine(tally.Trim(';'));
                    //}

//                    if (!popbase) writer.WriteLine("IndividualVariables, NumISVars = " + IndividualVariables.Count.ToString());

                    if (!popbase && IndividualVariables.Count > 1) // check of .Count will often catch popbased programs that didn't declare popbase
                    {
                        writer.WriteLine("IndividualVariables, NumISVars = " + IndividualVariables.Count.ToString());
                        writer.Write(IndividualVariables[0].Name);
                        for (int j = 1; j < IndividualVariables.Count; j++)
                            writer.Write("," + IndividualVariables[j].Name);
                        writer.WriteLine();

                        writer.Write(IndividualVariables[0].VariableType.ToString());
                        for (int j = 1; j < IndividualVariables.Count; j++)
                        {
                            writer.Write("," + IndividualVariables[j].VariableType.ToString());
                        }
                        writer.WriteLine();

                        if (mpop.IndList.Count > 0)
                        {
                            int[] varInds = new int[IndividualVariables.Count];
                            for (int j = 0; j < IndividualVariables.Count; j++)
                                varInds[j] = mpop.GetIndividualVarIndex(IndividualVariables[j].Name);

                            for (int m = 0; m < mpop.IndList.Count; m++)
                            {
                                string sLine = "";

                                for (int j = 0; j < varInds.Length; j++)
                                {
                                    if (varInds[j] >= 0)
                                        sLine += mpop.IndList[m].Vars[varInds[j]];
                                    if (j < varInds.Length - 1)
                                        //if (j < mpop.IndList.Count - 1)
                                            sLine += ";"; // don't use comma delimiters between numbers, EU format problem
                                }

                                writer.WriteLine(sLine);
//                                writer.WriteLine(sLine.Substring(1));
                            }
                        }
                    }
                }
                writer.Close();
            }
        }

        private void ReadDataFile(ref MDataSet dataSet, string fileLocation)
        {

            int lIndex;
            int popIndex = 0;

            List<string> lines = JPUtils.ReadFileToList(fileLocation);

            string[] ss, ss1, ss2;
            char[] delims = { ',', ' ', ';', '\t', '=' }; // don't use commas to separate numbers, EU format problem
            char[] delims1 = { ' ', ';', '\t' }; // don't use commas to separate numbers, EU format problem

            //GLOBAL VARS
            lIndex = 2;
            if (lines.Count > lIndex + 1 && lines[lIndex].StartsWith("GlobalVar") &&
                !lines[++lIndex].StartsWith("PopulationVar")) // otherwise, no GSvars
            {
                ss = lines[lIndex].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                ss2 = lines[++lIndex].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                ss1 = lines[++lIndex].Split(delims1, StringSplitOptions.RemoveEmptyEntries);

                for (int j = 0; j < ss.Length; j++)
                {
                    string ssName = ss[j].Trim();
                    string ssVal = "0";
                    string ssType = "double";
                    Type tt = typeof(double);

                    if (ss1.Length > j) ssVal = ss1[j].Trim();

                    if (ss2.Length > j)
                    {
                        ssType = ss2[j].Trim();
                        tt = JPUtils.stringToType(ssType);
                    }
                    
                    int k = MVariable.VarListIndexOf(GlobalVariables, ssName);
                    if (k < 0)
                        GlobalVariables.Add(new MVariable(ssName, tt, "", false));
//                    GlobalVariables.Add(new MVariable(ssName, typeof(string), "", false));
                    // add to MApp if missing

                    k = dataSet.GetVarIndex(ssName); // add to MData if missing
                    if (k < 0) dataSet.AddVar(ssName, ssVal, tt);
                    else dataSet.SetVarVal(k, ssVal);
                    //else dataSet.Vars[k] = ssVal;
                }
                ++lIndex;
            }

            //Population VARS
            while (lines.Count > lIndex + 1 && lines[lIndex].StartsWith("PopulationVar") &&
                   !lines[++lIndex].StartsWith("IndividualVar")) // otherwise, no PSvars
            {
                MPopulation mpop = dataSet.Populations[popIndex++];

                ss = lines[lIndex].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                ss2 = lines[++lIndex].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                ss1 = lines[++lIndex].Split(delims1, StringSplitOptions.RemoveEmptyEntries);

                //make sure has pop vars
                for (int j = 0; j < ss.Length; j++)
                {
                    string ssName = ss[j].Trim();
                    string ssVal = "0";
                    string ssType = "string";
                    Type tt = typeof(string);

                    if (ss1.Length > j) ssVal = ss1[j].Trim();

                    if (ss2.Length > j)
                    {
                        ssType = ss2[j].Trim();
                        tt = JPUtils.stringToType(ssType);
                    }

                    int k = MVariable.VarListIndexOf(PopulationVariables, ssName);
                    if (k < 0)
                        PopulationVariables.Add(new MVariable(ssName, tt, "", false));

                    k = mpop.GetVarIndex(ssName);
                    if (k < 0) mpop.AddVar(ssName, ssVal, tt);
                    else mpop.Vars[k] = ssVal;
                }
                ++lIndex;


                
                // Read age structure, for pop-based models

                if (lines[lIndex].StartsWith("PopulationSize"))
                {
                    if (lines.Count > lIndex)
                    {
                        ss = lines[lIndex++].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                        mpop.Nindividuals = Convert.ToInt32(ss[1]);
                    }
                }

                mpop.Females.Clear();
                mpop.Males.Clear();
                if (lines[lIndex++].StartsWith("AgeStructure"))
                {
                    if (lines.Count > lIndex)
                    {
                        ss = lines[lIndex++].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                        for (int j = 1; j < ss.Length; j++) mpop.Females.Add(Convert.ToInt32(ss[j]));
                    }

                    if (lines.Count > lIndex)
                    {
                        ss = lines[lIndex++].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                        for (int j = 1; j < ss.Length; j++) mpop.Males.Add(Convert.ToInt32(ss[j]));
                    }

                    // Test by Bob of no age structure info ... *********
                    //mpop.Count();
                }

                if (mpop.Females.Count > 0 || mpop.Males.Count > 0) mpop.Count(); // otherwise assume model didn't pass back the age-sex structure

                //IND VARS, embedded within mpop
                //                if (!popbase)
                //                {
                int namePlace = 0;
                if (lines.Count > lIndex + 1 && lines[lIndex].StartsWith("IndividualVar") &&
                    !lines[++lIndex].StartsWith("PopulationVar")) // otherwise, no Individuals
                {
                    ss = lines[lIndex].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                    ss2 = lines[++lIndex].Split(delims, StringSplitOptions.RemoveEmptyEntries);
                    int[] inds = new int[ss.Length];

                    //make sure has ind vars
                    for (int j = 0; j < ss.Length; j++)
                    {
                        string ssName = ss[j].Trim();
                        string ssType = "string";
                        Type tt = typeof(string);

                        if (ss2.Length > j)
                        {
                            ssType = ss2[j].Trim();
                            tt = JPUtils.stringToType(ssType);
                        }

                        //add var to individual vars if need to
                        if (MVariable.VarListIndexOf(IndividualVariables, ssName) < 0)
                            IndividualVariables.Add(new MVariable(ssName, tt, "", false));

                        int k = mpop.GetIndividualVarIndex(ssName);
                        if (k < 0) mpop.AddIndVar(ssName,"-1",tt);
                        inds[j] = k;

                        if (ssName == "Name") namePlace = j;
                    }

                    bool[] used = new bool[mpop.IndList.Count];
                    for (int m = 0; m < mpop.IndList.Count; m++) used[m] = false;
                    int mi = 0;

                    while (lines.Count > ++lIndex && !lines[lIndex].StartsWith("PopulationVar"))
                    // otherwise, end of individuals in that pop
                    {
                        ss1 = lines[lIndex].Split(delims1);
                        // don't remove empty entries, because indVars can be empty

                        string ssName = ss[namePlace].Trim();

                        int pos = mpop.GetMIndividualIndexFromName(mi, ssName);

                        MIndividual individual = null;

                        if (pos < 0)
                        {
                            individual = new MIndividual(mpop);
                        }
                        else
                        {
                            individual = mpop.IndList[pos];
                            used[pos] = true;
                            mi++;
                        }

                        for (int j = 0; j < ss1.Length; j++)
                        {
                            individual.Vars[inds[j]] = ss1[j];
                        }
                    }

                    //clean up lists -- remove missing animals from the list
                    if (used.Length > 0)
                    {
                        for (int j = used.Length - 1; j >= 0; j--)
                            if (!used[j]) mpop.IndList.RemoveAt(j);
                    }

                    mpop.tallyPopulation();
                }
                //                }
            }
        }





        public bool WriteResults()
        {
            try
            {
                Type t = Lib.GetType(LibNameSpace);
                MethodInfo mm;

                mm = t.GetMethod(CloseFunction);

                return Convert.ToBoolean(mm.Invoke(LibObj, null));
            }
            catch
            {
                return false;
            }

        }

        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("ExtSystem");
            iNode.AppendChild(appNode);

            XmlElement n = doc.CreateElement("AppSpecFile");
            n.InnerText = SpecFile.Substring(SpecFile.LastIndexOf("\\") + 1);
            appNode.AppendChild(n);

            n = doc.CreateElement("ProjectFile");
            n.InnerText = ProjectFile;
            //n.InnerText = ProjectFile.Substring(ProjectFile.LastIndexOf("\\") + 1);
            appNode.AppendChild(n);

            n = doc.CreateElement("ProjectName");
            n.InnerText = ProjectName;
            appNode.AppendChild(n);

            n = doc.CreateElement("SubApps");
            appNode.AppendChild(n);

            for (int i = 0; i < m_SubModels.Count; i++)
                m_SubModels[i].ToXML(n, doc);
            return true;
        }


        public bool ToXMLShort(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("ExtSystem");
            appNode.InnerText = AppIndex.ToString();
            iNode.AppendChild(appNode);

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("AppSpecFile");
            if (iter.MoveNext())
                LoadSpecFile(userData + "\\" + iter.Current.Value);

            iter = n.Select("ProjectFile");
            if (iter.MoveNext())
            {
                ProjectFile = iter.Current.Value;
                if (!ProjectFile.Contains("\\")) ProjectFile = folderLocation + "\\" + ProjectFile;
            }
            //ProjectFile = folderLocation + "\\" + iter.Current.Value;

            iter = n.Select("ProjectName");
            if (iter.MoveNext())
                ProjectName = iter.Current.Value;

            iter = n.Select("SubApps");

            if (iter.MoveNext())
            {
                iter = iter.Current.Clone().SelectChildren(XPathNodeType.All);

                while (iter.MoveNext())
                {
                    if (iter.Current.Name == "Spatial")
                    {
                        MAppSpatial s = new MAppSpatial();
                        s.LoadXML(iter.Current.Clone(), folderLocation);
                        m_SubModels.Add(s);
                    }
                    else if (iter.Current.Name == "PathHistory")
                    {
                        MAppPathHistory ph = new MAppPathHistory();
                        ph.LoadXML(iter.Current.Clone(), folderLocation);
                        m_SubModels.Add(ph);
                    }
                    else if (iter.Current.Name == "Outbreak2")
                    {
                        MAppOutbreak2 ob2 = new MAppOutbreak2();
                        ob2.LoadXML(iter.Current.Clone(), folderLocation);
                        m_SubModels.Add(ob2);
                    }
                    else if (iter.Current.Name == "External")
                    {
                        MAppExternal b = new MAppExternal();
                        b.LoadXML(iter.Current.Clone(), folderLocation);
                        m_SubModels.Add(b);
                    }
                }
            }

            return true;
        }

    }
}
