using System;
using System.Xml;
using System.Xml.XPath;

using MMMCore;

namespace MeMoMa
{
    public class MModelStepApp : MModelStep
    {
        public MApp App;
        private int NumTimeSteps = 1;

        public MModelStepApp()
        { }

        public MModelStepApp(MApp app)
        {
            App = app;
        }

        #region MModelStep Members

        public int GetNumTimeSteps()
        {
            return NumTimeSteps;
        }

        public void SetNumTimeSteps(int numTimeSteps)
        {
            NumTimeSteps = numTimeSteps;
        }

        public bool Simulate(MDataSet dataSet, int iteration, int year)
        {
            //do any prepwork to the populations, etc.
            //?

            //call appropriate class
            if (!App.DoTurn(dataSet, NumTimeSteps, iteration, year))
                throw new Exception("Simulation failed when trying to run " + App.GetName());

            //do anything else?

            return true;

        }

        public bool WriteResults()
        {
            return App.WriteResults();
        }

        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Step");
            iNode.AppendChild(appNode);

            App.ToXMLShort(appNode, doc);

            XmlElement n = doc.CreateElement("NumTimeSteps");
            n.InnerText = NumTimeSteps.ToString();
            appNode.AppendChild(n);

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {

            return true;
        }

        #endregion
    }
}
