using System;
using System.Collections.Generic;

using System.Xml;
using System.Xml.XPath;

using MMMCore;

namespace MeMoMa
{
    public class MAppOutbreak2 : MApp
    {

        private List<MVariable> GlobalVariables = new List<MVariable>();
        private List<MVariable> PopulationVariables = new List<MVariable>();
        private List<MVariable> IndividualVariables = new List<MVariable>();

        private string ProjectFile;

        private List<Outbreak2.MMOutbreak2> OProjs = new List<Outbreak2.MMOutbreak2>();
        private Outbreak2.MMOutbreak2 OProj = null;

        private bool FirstRun = true;

        public int PopStartIndex, NumPops;
        public string dzTag = "";

        private int AppIndex;

        public int ScenarioIndex = 0;
        public string ScenarioName;
//        public List<string> ScenarioNames = new List<string>();

        //private bool DoOutput;

        private int numYears;
        private int numIterations;


        public MAppOutbreak2()
        {
            IndividualVariables.Add(new MVariable("Index", typeof(int), "Index of the individual", false));
            IndividualVariables.Add(new MVariable("Name", typeof(int), "Name (ID) of the individual", false));
            IndividualVariables.Add(new MVariable("Age", typeof(int), "Age of the individual, in days", false));
            IndividualVariables.Add(new MVariable("Sex", typeof(int), "Sex of the individual", false));
            IndividualVariables.Add(new MVariable("Alive", typeof(int), "1 if alive, 0 if dead", false));

            //IndividualVariables.Add(new MVariable("X", typeof(int), "X-coordinate", false));  // what default value gets assigned?
            //IndividualVariables.Add(new MVariable("Y", typeof(int), "Y-coordinate", false));

            // can't yet add Dz variables, because don't yet have dzTag
        }


        public override string ToString()
        {
            return GetName() + " - " + GetDescription();
        }


        //public void SetDoOutput(bool output) { DoOutput = output; }
        //public bool GetDoOutput() { return DoOutput; }

        public void SetNumYears(int val) { numYears = val; }
        public void SetNumIter(int val) { numIterations = val; }



        //INHERITED FROM MApp

        private int appStepCount;
        public void SetAppStepCount(int val) { appStepCount = val; }
        public int GetAppStepCount() { return appStepCount; }

        public string GetName()
        {
            return "Outbreak";
        }

        public string GetDescription()
        {
            return "Outbreak model of infectious disease";
        }

        public string GetProjectFile()
        {
            return ProjectFile;
        }

        public void SetProjectFile(string fileName)
        {
            ProjectFile = fileName;
        }

        public List<MVariable> GetGlobalVariables()
        {
            return GlobalVariables;
        }

        // Bob added, to try to get these in before setup forms shown
        public void SetPopulationVariables()
        {
            PopulationVariables.Clear();

            string dztag = "-" + dzTag;
            if (dzTag.Trim() == "") dztag = "";

            PopulationVariables.Add(new MVariable("Prevalence" + dztag, typeof(string), "", false));
            PopulationVariables.Add(new MVariable("nP" + dztag, typeof(string), "", false));
            PopulationVariables.Add(new MVariable("nS" + dztag, typeof(string), "", false));
            PopulationVariables.Add(new MVariable("nE" + dztag, typeof(string), "", false));
            PopulationVariables.Add(new MVariable("nI" + dztag, typeof(string), "", false));
            PopulationVariables.Add(new MVariable("nR" + dztag, typeof(string), "", false));
            PopulationVariables.Add(new MVariable("nV" + dztag, typeof(string), "", false));
        }

        public List<MVariable> GetPopulationVariables()
        {
            return PopulationVariables;
        }

        public List<MVariable> GetIndividualVariables()
        {
            return IndividualVariables;
        }

        // Bob added, to try to get these in before setup forms shown
        public void SetIndividualVariables()
        {
            IndividualVariables.Clear();

            string dztag = "-" + dzTag;
            if (dzTag.Trim() == "") dztag = "";

            IndividualVariables.Add(new MVariable("DiseaseState" + dztag, typeof(string), "", false));
            IndividualVariables.Add(new MVariable("DaysInState" + dztag, typeof(string), "", false));
            IndividualVariables.Add(new MVariable("Tenure" + dztag, typeof(string), "", false));
            IndividualVariables.Add(new MVariable("StatePermanent" + dztag, typeof(string), "", false));
            IndividualVariables.Add(new MVariable("IsVaccinated" + dztag, typeof(string), "", false));
        }

        public bool DoTurn(MDataSet dataSet, int numTimeSteps, int iteration, int year)
        {
            if (FirstRun) OProjs.Clear();
                
            for (int i = PopStartIndex; i < PopStartIndex + NumPops; i++)
            {
                //                pops.Add(dataSet.Populations[i]);

                if (FirstRun)
                {
                    OProj = new Outbreak2.MMOutbreak2(false);

                    //if (ScenarioName != "" && ScenarioName != ScenarioNames[ScenarioIndex])
                    //{
                    //    if (MessageBox.Show("Outbreak Scenario name does not match index. Do you want to reset the index?", "Outbreak model warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    //        ScenarioIndex = ScenarioNames.IndexOf(ScenarioName);
                    //}

                    if (!OProj.Initialize(dataSet, dataSet.Populations[i], ProjectFile, ScenarioIndex, numIterations, numYears, GetAppStepCount())) 
                        return false;

                    OProjs.Add(OProj);
                }

                //check if extinct
                //            if (dataSet.Populations[PopStartIndex].IndList.Count == 0) return true;

                //OProj.Simulate(dataSet.Populations[i], iteration, year, numTimeSteps);
                OProjs[i - PopStartIndex].Simulate(dataSet.Populations[i], iteration, year, numTimeSteps);

            }
            FirstRun = false;

            return true;

        }

        public bool WriteResults()
        {
            foreach (Outbreak2.MMOutbreak2 op in OProjs)
            {
                if (!op.CloseDLL()) return false;
            }
            return true;

        }

        public int GetAppIndex()
        {
            return AppIndex;
        }

        public void SetAppIndex(int index)
        {
            AppIndex = index;
        }

        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Outbreak2");
            iNode.AppendChild(appNode);

            XmlElement n = doc.CreateElement("ProjectFile");
            n.InnerText = ProjectFile;
            //n.InnerText = ProjectFile.Substring(ProjectFile.LastIndexOf("\\") + 1);
            appNode.AppendChild(n);

            n = doc.CreateElement("ScenarioIndex");
            n.InnerText = ScenarioIndex.ToString();
            appNode.AppendChild(n);

            n = doc.CreateElement("ScenarioName");
            n.InnerText = ScenarioName;
            appNode.AppendChild(n);

            return true;
        }

        public bool ToXMLShort(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Outbreak2");
            appNode.InnerText = AppIndex.ToString();
            iNode.AppendChild(appNode);

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("ProjectFile");
            if (iter.MoveNext())
            {
                ProjectFile = iter.Current.Value;
                if (!ProjectFile.Contains("\\")) ProjectFile = folderLocation + "\\" + ProjectFile;
            }
            //ProjectFile = folderLocation + "\\" + iter.Current.Value;

            iter = n.Select("ScenarioIndex");
            if (iter.MoveNext())
                ScenarioIndex = Convert.ToInt32(iter.Current.Value);

            iter = n.Select("ScenarioName");
            if (iter.MoveNext())
            {
                ScenarioName = iter.Current.Value;
            }

            return true;
        }

    }
}
