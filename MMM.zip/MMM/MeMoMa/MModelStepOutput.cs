using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.XPath;

namespace MeMoMa
{
    public class MModelStepOutput : MModelStep
    {
        #region MModelStep Members

        public string FileName;
        public List<string> VarsToImport = new List<string>();

        public bool AddYandR = false;


        public int GetNumTimeSteps()
        {
            return -1;
        }

        public void SetNumTimeSteps(int numTimeSteps)
        {
            //do nothing
        }

        private bool GetInput(MMMCore.MDataSet dataSet)
        {
            return false;

        }

        public bool Simulate(MMMCore.MDataSet dataSet, int iteration, int year)
        {
            int i, j;
            //print output files for each population
            for (int p = 0; p < dataSet.Populations.Count; p++)
            {
                List<string> lines = new List<string>();

                //write global vars
                lines.Add("#GLOBAL VARIABLES#");
                for (i = 0; i < dataSet.VarNames.Count; i++)
                    if (i < dataSet.VarNames.Count)
                        lines.Add(dataSet.VarNames[i] + "," + dataSet.GetVarVal(i));
                        //lines.Add(dataSet.VarNames[i] + "," + dataSet.Vars[i]);

                //write pop state vars
                lines.Add("#POPULATION VARIABLES#");
                for (i = 0; i < dataSet.Populations[p].VarNames.Count; i++)
                    if (i < dataSet.Populations[p].VarNames.Count)
                        lines.Add(dataSet.Populations[p].VarNames[i] + "," + dataSet.Populations[p].Vars[i]);

                //write ind vars
                // Bob added check to see if IndList exists
                if (dataSet.Populations[p].IndList.Count > 0)
                {
                    lines.Add("#INDIVIDUAL VARIABLES#");
                    string s = "";
                    for (i = 0; i < dataSet.Populations[p].IndVarNames.Count; i++)
                        s += "," + dataSet.Populations[p].IndVarNames[i];

                    lines.Add(s.Substring(1));

                    for (i = 0; i < dataSet.Populations[p].IndList.Count; i++)
                    {
                        s = "";
                        for (j = 0; j < dataSet.Populations[p].IndVarNames.Count; j++)
                            if (j < dataSet.Populations[p].IndList[i].Vars.Count)
                                s += "," + dataSet.Populations[p].IndList[i].Vars[j];

                        lines.Add(s.Substring(1));
                    }
                }

                string outFile = FileName;

                // Bob added checks for bad or missing FileName
                if (outFile == null || outFile == "") outFile = "Output.txt";
                if (!outFile.Contains(".")) outFile = outFile + ".txt";

                if (AddYandR)
                    outFile = outFile.Substring(0, outFile.LastIndexOf(".")) + "_" + dataSet.Populations[p].Name + "_r" + iteration.ToString() + "_y" + year.ToString() + outFile.Substring(outFile.LastIndexOf("."));
                else
                    outFile = outFile.Substring(0, outFile.LastIndexOf(".")) + "_" + dataSet.Populations[p].Name + outFile.Substring(outFile.LastIndexOf("."));

                JPUtils.WriteListToFile(outFile, lines);

            }

            

            return true;
        }

        public bool WriteResults()
        {
            //do nothing
            return true;
        }


        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement n = doc.CreateElement("Output");
            iNode.AppendChild(n);

            XmlElement nn = doc.CreateElement("FileName");
            nn.InnerText = FileName;
            n.AppendChild(nn);

            nn = doc.CreateElement("YAndR");
            nn.InnerText = AddYandR.ToString();
            n.AppendChild(nn);
            

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("FileName");
            if (iter.MoveNext())
                FileName = iter.Current.Value;

            iter = n.Select("YAndR");
            if (iter.MoveNext())
                AddYandR = Convert.ToBoolean(iter.Current.Value);
            return true;
        }

        #endregion
    }
}
