using System.Collections.Generic;
using MMMCore;

using System.Xml;
using System.Xml.XPath;

namespace MeMoMa
{
    public interface MApp
    {
        string GetName();
        string GetDescription();

        string GetProjectFile();
        void SetProjectFile(string fileName);

        //void SetDoOutput(bool output);
        //bool GetDoOutput();

        int GetAppIndex();
        void SetAppIndex(int index);

        // The MVariable lists are used for input/output of what variables are shared with MMM
        List<MVariable> GetGlobalVariables();
        List<MVariable> GetPopulationVariables();
        List<MVariable> GetIndividualVariables();

        bool DoTurn(MDataSet dataSet, int numTimeSteps, int iteration, int year);

        bool WriteResults();

        bool ToXML(XmlElement iNode, XmlDocument doc);
        bool ToXMLShort(XmlElement iNode, XmlDocument doc);
        bool LoadXML(XPathNavigator n, string folderLocation);

        // in case needed by App (as is the case for Outbreak2), for setting up arrays for output
        void SetAppStepCount(int val);
        int GetAppStepCount();
    }
}
