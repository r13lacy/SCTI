using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.XPath;

using EvaluatorLibrary;

namespace MeMoMa
{
    public class MModelStepEvaluator : MModelStep
    {
        #region MModelStep Members

        public string FunctionString;

        public string VarSolve = "";
        public int PopIndex = -1; //-1 is for all populations

//        public List<string> VarLexicon = new List<string>();
        public List<string> VarsToImport = new List<string>();
        public List<string> SpecVars = new List<string>();

        public Evaluator Eval = null;

        public bool SetFunctionString(string fun)
        {
            FunctionString = fun;
            Eval = new Evaluator(fun);

            addspecs(Eval); 

            return Eval.Translate();
        }

        //private void addsynons(Evaluator eval)
        //{
        //    eval.addSynonymy("RUN", "A");
        //    eval.addSynonymy("YEAR", "B");

        //    char c = 'C';
        //    for (int i = 0; i < VarsToImport.Count; i++)
        //    {
        //        if (i < 24)
        //            eval.addSynonymy(VarsToImport[i], (c + i).ToString());
        //        else
        //            eval.addSynonymy(VarsToImport[i], "VAR" + (i - 23).ToString());
        //    }
        //}

        private void addspecs(Evaluator eval)
        {
            SpecVars = new List<string>();

            eval.clearSpecials();
            eval.addSpecial("RUN");
            eval.addSpecial("YEAR");
            SpecVars.Add("RUN");
            SpecVars.Add("YEAR");
            // any other standard ones to add?

            for (int i = 0; i < VarsToImport.Count; i++)
            {
                string sv = "";

                if (VarsToImport[i].StartsWith("G"))
                {
                    sv = VarsToImport[i].Substring("global.".Length);
                }
                else if (VarsToImport[i].StartsWith("P"))
                {
                    sv = VarsToImport[i].Substring("population.".Length);
                }
                else if (VarsToImport[i].StartsWith("I"))
                {
                    sv = VarsToImport[i].Substring("individual.".Length);
                }

                eval.addSpecial(sv);
                SpecVars.Add(sv);
            }
        }



        public int GetNumTimeSteps()
        {
            return -1;
        }

        public void SetNumTimeSteps(int numTimeSteps)
        {
            //do nothing
        }

        private bool GetInput(MMMCore.MDataSet dataSet)
        {
            return false;

        }


// Bob's version, so that can use PSvars to modify GSvars
        public bool Simulate(MMMCore.MDataSet dataSet, int iteration, int year)
        {
            int i, j;
            List<double> vals = new List<double>();

            // Bob
            vals.Add((double)iteration);
            vals.Add((double)year);

            int p = 0;
            for (p = 0; p < dataSet.Populations.Count; p++)
            {
                if (PopIndex < 0 || p == PopIndex) //only evaluate on selected pop or if they have selected all pops
                {
                    for (i = 0; i < VarsToImport.Count; i++)
                    {
                        if (VarsToImport[i].StartsWith("G"))
                        {
                            j = dataSet.GetVarIndex(VarsToImport[i].Substring("global.".Length));

                            if (j < 0)
                                vals.Add(0.0);
                            else
                                vals.Add(dataSet.GetVarDouble(j));
                            //vals.Add(Convert.ToDouble(dataSet.Vars[j]));
                        }
                        else if (VarsToImport[i].StartsWith("P"))
                        {
                            j = dataSet.Populations[p].GetVarIndex(VarsToImport[i].Substring("population.".Length));

                            if (j < 0)
                                vals.Add(0.0);
                            else
                                vals.Add(Convert.ToDouble(dataSet.Populations[p].Vars[j]));
                        }
                    }
                    break; // this leaves p at selected pop
                }
            }

            if (VarSolve.StartsWith("G")) //Global
            {
                j = dataSet.GetVarIndex(VarSolve.Substring("global.".Length));
                if (j < 0)
                    return true;
                else
                    dataSet.SetVarVal(j, Eval.doEval(SpecVars, vals));
                //dataSet.Vars[j] = Eval.doEval(vals).ToString();

            }
            else if (VarSolve.StartsWith("P"))
            {
                j = dataSet.Populations[p].GetVarIndex(VarSolve.Substring("population.".Length));
                if (j < 0)
                    return true;
                else
                    dataSet.Populations[p].Vars[j] = Eval.doEval(SpecVars, vals).ToString();
            }
            else
            {
                //Individual vars

                //loop through all of the individuals, looping through the vars again to find the individual ones

                for (int ii = 0; ii < dataSet.Populations[p].IndList.Count; ii++)
                {
                    for (i = 0; i < VarsToImport.Count; i++)
                    {
                        if (VarsToImport[i].StartsWith("I"))
                        {
                            j = dataSet.Populations[p].GetIndividualVarIndex(VarsToImport[i].Substring("individual.".Length));

                            if (j < 0)
                                vals.Add(0.0);
                            else
                            {
                                if (i + 2 >= vals.Count)
                                    vals.Add(Convert.ToDouble(dataSet.Populations[p].IndList[ii].Vars[j]));
                                else
                                    vals[i + 2] = Convert.ToDouble(dataSet.Populations[p].IndList[ii].Vars[j]); // Bob changed from [i] to accommodate Yr and Iter
                            }
                        }
                    }

                    //now do the eval
                    j = dataSet.Populations[p].GetIndividualVarIndex(VarSolve.Substring("individual.".Length));
                    if (j < 0)
                        return true;
                    else
                        dataSet.Populations[p].IndList[ii].Vars[j] = Eval.doEval(SpecVars, vals).ToString();

                }
            }

            return true;
        }



        public bool WriteResults()
        {
            //do nothing
            return true;
        }


        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement n = doc.CreateElement("Evaluator");
            iNode.AppendChild(n);

            XmlElement nn = doc.CreateElement("FunctionString");
            nn.InnerText = FunctionString;
            n.AppendChild(nn);

            nn = doc.CreateElement("VarSolve");
            nn.InnerText = VarSolve;
            n.AppendChild(nn);

            nn = doc.CreateElement("PopIndex");
            nn.InnerText = PopIndex.ToString();
            n.AppendChild(nn);

            int i;

            //nn = doc.CreateElement("VarLexicon");
            //n.AppendChild(nn);

            //for (i = 0; i < VarsToImport.Count; i++)
            //{
            //    XmlElement v = doc.CreateElement("Var");
            //    v.InnerText = VarLexicon[i];
            //    nn.AppendChild(v);
            //}

            nn = doc.CreateElement("VarsToImport");
            n.AppendChild(nn);

            for (i = 0; i < VarsToImport.Count; i++)
            {
                XmlElement v = doc.CreateElement("Var");
                v.InnerText = VarsToImport[i];
                nn.AppendChild(v);
            }


            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("FunctionString");
            if (iter.MoveNext())
                FunctionString = iter.Current.Value;

            iter = n.Select("VarSolve");
            if (iter.MoveNext())
                VarSolve = iter.Current.Value;

            iter = n.Select("PopIndex");
            if (iter.MoveNext())
                PopIndex = Convert.ToInt32(iter.Current.Value);

            //iter = n.Select("VarLexicon");
            //iter.MoveNext();
            //XPathNodeIterator it2 = iter.Current.Clone().Select("Var");
            //while (it2.MoveNext())
            //    VarLexicon.Add(it2.Current.Value);

            iter = n.Select("VarsToImport");
            iter.MoveNext();
            XPathNodeIterator it2 = iter.Current.Clone().Select("Var");
            while (it2.MoveNext())
                VarsToImport.Add(it2.Current.Value);

            Eval = new Evaluator(FunctionString);
            addspecs(Eval);
            Eval.Translate();

            return true;
        }

        #endregion
    }
}
