using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MeMoMa
{
    public partial class frmPicker : Form
    {

        public frmPicker(string instructions, List<string> list)
        {
            InitializeComponent();

            lblText.Text = instructions;

            for (int i = 0; i < list.Count; i++)
                lstMain.Items.Add(list[i]);

            lstMain.SelectedIndex = 0;

        }

        public frmPicker(string instructions, string[] list)
        {
            InitializeComponent();

            lblText.Text = instructions;

            for (int i = 0; i < list.Length; i++)
                lstMain.Items.Add(list[i]);

            lstMain.SelectedIndex = 0;

        }

        public int SelectedIndex { get { return lstMain.SelectedIndex; } }

        private void lstMain_DoubleClick(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void frmPicker_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            
            if(lblText.Text.Contains("scenarios")) MMMHelp.LaunchHelp("ModelSelection");
            if (lblText.Text.Contains("variable")) MMMHelp.LaunchHelp("InputStepSetup");
            else MMMHelp.LaunchHelp(null);
        }

    }
}