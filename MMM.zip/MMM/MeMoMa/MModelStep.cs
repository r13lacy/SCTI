using System.Xml;
using System.Xml.XPath;

using MMMCore;

namespace MeMoMa
{
    public interface MModelStep
    {
        int GetNumTimeSteps();
        void SetNumTimeSteps(int numTimeSteps);

        bool Simulate(MDataSet dataSet, int iteration, int year);
        bool WriteResults();


        bool ToXML(XmlElement iNode, XmlDocument doc);
        bool LoadXML(XPathNavigator n, string folderLocation);
    }
}
