﻿using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Linq;
//using System.Text;
using System.Windows.Forms;

namespace SCTI
{
    public partial class frmSCTI2 : Form
    {
        bool m_Open;

        public frmSCTI2(bool keepOpen)
        {
            Timer timer1 = new Timer();
            m_Open = keepOpen;

            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // closes window after 10 seconds, if user doesn't close it first

            if(!m_Open) Close();
        }
    }
}
