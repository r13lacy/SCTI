using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MeMoMa
{
    public partial class frmEvaluatorSetup : Form
    {
        private MModel m_Model = null;
        private MModelStepEvaluator m_EvStep = null;

        List<string> varsGlobal = new List<string>(), varsPop = new List<string>(), varsInd = new List<string>();

        public frmEvaluatorSetup(MModel model, MModelStepEvaluator step)
        {
            InitializeComponent();
            m_Model = model;
            m_EvStep = step;

            txtEq.Text = m_EvStep.FunctionString;


            int i, j, k;

            for (i = 0; i < m_Model.SystemApps.Count; i++)
            {
                for (j = 0; j < m_Model.SystemApps[i].GetGlobalVariables().Count; j++)
                {
                    if (varsGlobal.IndexOf("Global." + m_Model.SystemApps[i].GetGlobalVariables()[j].Name) < 0)
                        varsGlobal.Add("Global." + m_Model.SystemApps[i].GetGlobalVariables()[j].Name);
                }

                for (j = 0; j < m_Model.SystemApps[i].GetPopulationVariables().Count; j++)
                {
                    if (varsPop.IndexOf("Population." + m_Model.SystemApps[i].GetPopulationVariables()[j].Name) < 0)
                        varsPop.Add("Population." + m_Model.SystemApps[i].GetPopulationVariables()[j].Name);
                }

                for (j = 0; j < m_Model.SystemApps[i].GetIndividualVariables().Count; j++)
                {
                    if (varsInd.IndexOf("Individual." + m_Model.SystemApps[i].GetIndividualVariables()[j].Name) < 0)
                        varsInd.Add("Individual." + m_Model.SystemApps[i].GetIndividualVariables()[j].Name);
                }

                //recurse through submodels
                for (k = 0; k < m_Model.SystemApps[i].SubModels().Count; k++)
                {
                    for (j = 0; j < m_Model.SystemApps[i].SubModels()[k].GetGlobalVariables().Count; j++)
                    {
                        if (varsGlobal.IndexOf("Global." + m_Model.SystemApps[i].SubModels()[k].GetGlobalVariables()[j].Name) < 0)
                            varsGlobal.Add("Global." + m_Model.SystemApps[i].SubModels()[k].GetGlobalVariables()[j].Name);
                    }

                    for (j = 0; j < m_Model.SystemApps[i].SubModels()[k].GetPopulationVariables().Count; j++)
                    {
                        if (varsPop.IndexOf("Population." + m_Model.SystemApps[i].SubModels()[k].GetPopulationVariables()[j].Name) < 0)
                            varsPop.Add("Population." + m_Model.SystemApps[i].SubModels()[k].GetPopulationVariables()[j].Name);
                    }

                    for (j = 0; j < m_Model.SystemApps[i].SubModels()[k].GetIndividualVariables().Count; j++)
                    {
                        if (varsInd.IndexOf("Individual." + m_Model.SystemApps[i].SubModels()[k].GetIndividualVariables()[j].Name) < 0)
                            varsInd.Add("Individual." + m_Model.SystemApps[i].SubModels()[k].GetIndividualVariables()[j].Name);
                    }
                }

            }

            varsGlobal.Sort();
            varsPop.Sort();
            varsInd.Sort();

            lstVars.Items.Clear();
//            List<string> vars = new List<string>();

            // Iteration and Year as default vars always available; are there any others that we want?
            lstVars.Items.Add("RUN");
            lstVars.Items.Add("YEAR");

            for (i = 0; i < varsGlobal.Count; i++)
            {
                cboVarGlobal.Items.Add(varsGlobal[i]);
                lstVars.Items.Add(varsGlobal[i]);
            }

            for (i = 0; i < varsPop.Count; i++)
            {
                cboVarPop.Items.Add(varsPop[i]);
            }

            for (i = 0; i < varsInd.Count; i++)
            {
                cboVarInd.Items.Add(varsInd[i]);
            }

            if (radioPop.Checked || radioPop.Checked)
                for (i = 0; i < varsPop.Count; i++)
                {
                    lstVars.Items.Add(varsPop[i]);
                }

            if (radioInd.Checked)
                for (i = 0; i < varsInd.Count; i++)
                {
                    lstVars.Items.Add(varsInd[i]);
                }


            //for (i = 0; i < vars.Count; i++)
            //{
            //    //char c = 'C';
            //    //if (i < 24)
            //    //    lstVars.Items.Add((char)(c + i) + " - " + vars[i]);
            //    //else
            //    //    lstVars.Items.Add("Var" + (i - 23).ToString() + " - " + vars[i]); // Bob -- this was i % 26 + 1, but that wouldn't be right
            //}

            if (cboVarGlobal.Items.Count > 0)
                cboVarGlobal.SelectedIndex = 0;

            if (cboVarPop.Items.Count > 0)
                cboVarPop.SelectedIndex = 0;

            if (cboVarInd.Items.Count > 0)
                cboVarInd.SelectedIndex = 0;

            cboPopListPop.Items.Add("All Populations");
            cboPopListInd.Items.Add("All Populations");

            for (i = 0; i < m_Model.DataSet.Populations.Count; i++)
            {
                cboPopListPop.Items.Add(m_Model.DataSet.Populations[i].Name);
                cboPopListInd.Items.Add(m_Model.DataSet.Populations[i].Name);
            }

            cboPopListPop.SelectedIndex = 0;
            cboPopListInd.SelectedIndex = 0;

            // stuff added by Bob to finish loading Evaluator if previously created
            if (m_EvStep.VarSolve != "")
            {
                if (m_EvStep.VarSolve.StartsWith("G")) 
                {
                    radioGlobal.Checked = true;
                    int varindex = cboVarGlobal.Items.IndexOf(m_EvStep.VarSolve);
                    cboVarGlobal.SelectedIndex = varindex;
                }
                else if(m_EvStep.VarSolve.StartsWith("P")) 
                {
                    radioPop.Checked = true;
                    int varindex = cboVarPop.Items.IndexOf(m_EvStep.VarSolve);
                    cboVarPop.SelectedIndex = varindex;
                    cboPopListPop.SelectedIndex = m_EvStep.PopIndex + 1;
                }
                else if(m_EvStep.VarSolve.StartsWith("I")) 
                {
                    radioInd.Checked = true;
                    int varindex = cboVarInd.Items.IndexOf(m_EvStep.VarSolve);
                    cboVarInd.SelectedIndex = varindex;
                    cboPopListInd.SelectedIndex = m_EvStep.PopIndex + 1;
                }
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (radioGlobal.Checked)
            {
                m_EvStep.VarSolve = cboVarGlobal.SelectedItem.ToString();
                m_EvStep.PopIndex = -1;
            }
            else if (radioPop.Checked)
            {
                m_EvStep.VarSolve = cboVarPop.SelectedItem.ToString();
                m_EvStep.PopIndex = cboPopListPop.SelectedIndex - 1;
            }
            else
            {
                m_EvStep.VarSolve = cboVarInd.SelectedItem.ToString();
                m_EvStep.PopIndex = cboPopListInd.SelectedIndex - 1;
            }

            m_EvStep.VarsToImport.Clear();
//            m_EvStep.VarLexicon.Clear();

            //get varlist -- starting after Iter and Year
            for (int i = 2; i < lstVars.Items.Count; i++)
            {
                string s = lstVars.Items[i].ToString();

//                m_EvStep.VarLexicon.Add(s.Substring(0, s.IndexOf("-") - 1));
//                m_EvStep.VarsToImport.Add(s.Substring(s.IndexOf("-") + 2));
                m_EvStep.VarsToImport.Add(s);
            }

            m_EvStep.SetFunctionString(txtEq.Text.Trim());

        }

        private void radioGlobal_CheckedChanged(object sender, EventArgs e)
        {
            cboVarGlobal.Enabled = radioGlobal.Checked;

            if (radioGlobal.Checked)
            {
                int i;
                //List<string> vars = new List<string>();
                lstVars.Items.Clear();

                lstVars.Items.Add("RUN");
                lstVars.Items.Add("YEAR");

                for (i = 0; i < varsGlobal.Count; i++)
                    lstVars.Items.Add(varsGlobal[i]);

                //for (i = 0; i < vars.Count; i++)
                //{
                //    char c = 'C';
                //    if (i < 24)
                //        lstVars.Items.Add((char)(c + i) + " - " + vars[i]);
                //    else
                //        lstVars.Items.Add("Var" + (i - 23).ToString() + " - " + vars[i]);
                //}
            }
        }

        private void radioPop_CheckedChanged(object sender, EventArgs e)
        {
            cboPopListPop.Enabled = cboVarPop.Enabled = radioPop.Checked;

            if (radioPop.Checked)
            {
                int i;
//                List<string> vars = new List<string>();

                lstVars.Items.Clear();

                lstVars.Items.Add("RUN");
                lstVars.Items.Add("YEAR");

                for (i = 0; i < varsGlobal.Count; i++)
                    lstVars.Items.Add(varsGlobal[i]);

                for (i = 0; i < varsPop.Count; i++)
                    lstVars.Items.Add(varsPop[i]);

                //for (i = 0; i < vars.Count; i++)
                //{
                //    char c = 'C';
                //    if (i < 24)
                //        lstVars.Items.Add((char)(c + i) + " - " + vars[i]);
                //    else
                //        lstVars.Items.Add("Var" + (i - 23).ToString() + " - " + vars[i]);
                //}
            }
        }

        private void radioInd_CheckedChanged(object sender, EventArgs e)
        {
            cboVarInd.Enabled = cboPopListInd.Enabled = radioInd.Checked;

            if (radioInd.Checked)
            {
                int i;
//                List<string> vars = new List<string>();

                lstVars.Items.Clear();

                lstVars.Items.Add("RUN");
                lstVars.Items.Add("YEAR");

                for (i = 0; i < varsGlobal.Count; i++)
                    lstVars.Items.Add(varsGlobal[i]);

                for (i = 0; i < varsPop.Count; i++)
                    lstVars.Items.Add(varsPop[i]);

                for (i = 0; i < varsInd.Count; i++)
                    lstVars.Items.Add(varsInd[i]);

                //for (i = 0; i < vars.Count; i++)
                //{
                //    char c = 'C';
                //    if (i < 24)
                //        lstVars.Items.Add((char)(c + i) + " - " + vars[i]);
                //    else
                //        lstVars.Items.Add("Var" + (i - 23).ToString() + " - " + vars[i]);
                //}
            }
        }

        private void frmEvaluatorSetup_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("Evaluator");
        }
    }
}