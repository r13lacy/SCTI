using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MeMoMa
{
    public partial class frmInputStepSetup : Form
    {
        private MModel m_Model;
        public MModelStepInput InputStep = null;

        private List<string> vars = new List<string>();

        public frmInputStepSetup(MModel model, MModelStepInput step)
        {
            InitializeComponent();
            m_Model = model;
            InputStep = step;
            vars = new List<string>();
            int i, j, k;

            for (i = 0; i < m_Model.SystemApps.Count; i++)
            {
                for (j = 0; j < m_Model.SystemApps[i].GetGlobalVariables().Count; j++)
                {
                    if (vars.IndexOf("Global." + m_Model.SystemApps[i].GetGlobalVariables()[j].Name) < 0)
                        vars.Add("Global." + m_Model.SystemApps[i].GetGlobalVariables()[j].Name);
                }

                for (j = 0; j < m_Model.SystemApps[i].GetPopulationVariables().Count; j++)
                {
                    if (vars.IndexOf("Population." + m_Model.SystemApps[i].GetPopulationVariables()[j].Name) < 0)
                        vars.Add("Population." + m_Model.SystemApps[i].GetPopulationVariables()[j].Name);
                }

                //recurse through submodels
                for (k = 0; k < m_Model.SystemApps[i].SubModels().Count; k++)
                {
                    for (j = 0; j < m_Model.SystemApps[i].SubModels()[k].GetGlobalVariables().Count; j++)
                    {
                        if (vars.IndexOf("Global." + m_Model.SystemApps[i].SubModels()[k].GetGlobalVariables()[j].Name) < 0)
                            vars.Add("Global." + m_Model.SystemApps[i].SubModels()[k].GetGlobalVariables()[j].Name);
                    }

                    for (j = 0; j < m_Model.SystemApps[i].SubModels()[k].GetPopulationVariables().Count; j++)
                    {
                        if (vars.IndexOf("Population." + m_Model.SystemApps[i].SubModels()[k].GetPopulationVariables()[j].Name) < 0)
                            vars.Add("Population." + m_Model.SystemApps[i].SubModels()[k].GetPopulationVariables()[j].Name);
                    }
                }

            }

            vars.Sort();

            for (i = 0; i < vars.Count; i++)
                cboVars.Items.Add(vars[i]);

            if (cboVars.Items.Count > 1)
                cboVars.SelectedIndex = 0;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                txtFile.Text = dlg.FileName;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            string inst = "Choose a variable from the list below.";
            frmPicker pick = new frmPicker(inst, vars);
            if (pick.ShowDialog() == DialogResult.OK)
            {
                if (lstVars.Items.IndexOf(vars[pick.SelectedIndex]) < 0)
                    lstVars.Items.Add(vars[pick.SelectedIndex]);
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (lstVars.SelectedIndex >= 0)
                lstVars.Items.RemoveAt(lstVars.SelectedIndex);
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            if (lstVars.SelectedIndex >= 1)
            {
                int i = lstVars.SelectedIndex;
                string s = lstVars.SelectedItem.ToString();
                lstVars.Items.RemoveAt(i);
                lstVars.Items.Insert(i - 1, s);
                lstVars.SelectedIndex = i - 1;
            }
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            if (lstVars.SelectedIndex >= 0 && lstVars.SelectedIndex < lstVars.Items.Count - 1)
            {
                int i = lstVars.SelectedIndex;
                string s = lstVars.SelectedItem.ToString();
                lstVars.Items.RemoveAt(i);
                lstVars.Items.Insert(i + 1, s);
                lstVars.SelectedIndex = i + 1;
            }
        }


        private void btnOK_Click(object sender, EventArgs e)
        {
            InputStep.FileName = txtFile.Text;

            List<string> l = new List<string>();
            for (int i = 0; i < lstVars.Items.Count; i++)
                l.Add(lstVars.Items[i].ToString());

            InputStep.VarsToImport = l;

            if (radioStandardInput.Checked)
                InputStep.InputFileType = 0;
            else if (radioRAMAS1Pop.Checked)
                InputStep.InputFileType = 1;

            InputStep.RAMASVar = cboVars.SelectedItem.ToString();
        }

        private void frmInputStepSetup_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("InputStepSetup");
        }
        
    }
}