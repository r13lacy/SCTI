using System;
using System.Windows.Forms;

namespace MeMoMa
{
    public partial class frmStepOrder : Form
    {
        private MModel m_Model;
//        bool saved = false;
        private bool settingUp = true;

        //TODO: This will not work with multiple nested groups!!
        public frmStepOrder(MModel model)
        {
            InitializeComponent();
            
            int i, j, r;

            m_Model = model;

            fgVars.Rows.Count = 1;
            fgVars.Cols.Count++;
            fgVars.Cols[fgVars.Cols.Count - 1].Visible = false;

            txtYears.Text = model.Years.ToString();
            txtIter.Text = model.Iterations.ToString();
            txtYears.Enabled = true;
            txtIter.Enabled = true;
            for (i = 0; i < model.SystemApps.Count; i++)
            {
                if (model.SystemApps[i].GetName() == "MetaPop")
                {
                    txtYears.Enabled = false;
                    txtIter.Enabled = false;
                    break;
                }
            }

            button1.Left = panel1.Width - button1.Width - 8;
            btnQuit.Left = button1.Left - btnQuit.Width - 8;
            btnBack.Left = btnQuit.Left - btnBack.Width - 8;

            if (model.OrderedSteps.Count == 0) //new project, create new set up
            {
                m_Model = model;
                model.OrderedSteps.Clear();

                for (i = 0; i < m_Model.SystemApps.Count; i++)
                {
                    r = fgVars.Rows.Add().Index;

                    fgVars[r, 0] = m_Model.SystemApps[i].GetName() + " System - " + m_Model.SystemApps[i].GetProjectName();
                    if (m_Model.SystemApps[i].GetType() == typeof(MAppVortex))
                        fgVars[r, 0] += " [" + ((MAppVortex)m_Model.SystemApps[i]).ScenarioName + "]";
                    
                    fgVars[r, 1] = 1;
                    fgVars.SetCellStyle(r, 0, "TopNode");
                    fgVars.Rows[r].IsNode = true;
                    fgVars.Rows[r].Node.Level = 0;

                    MModelStepSystemGroup mssg = new MModelStepSystemGroup();
                    mssg.AppName = m_Model.SystemApps[i].GetName();
                    fgVars[r, fgVars.Cols.Count - 1] = mssg;

                    for (j = 0; j < m_Model.SystemApps[i].SubModels().Count; j++)
                    {
                        r = fgVars.Rows.Add().Index;
                        fgVars[r, 0] = m_Model.SystemApps[i].SubModels()[j].GetName();
                        fgVars.Rows[r].IsNode = true;
                        fgVars.Rows[r].Node.Level = 1;
                        fgVars[r, 1] = 1;

                        fgVars[r, fgVars.Cols.Count - 1] = new MModelStepApp(m_Model.SystemApps[i].SubModels()[j]);
                    }

                    r = fgVars.Rows.Add().Index;
                    fgVars[r, 0] = "Do " + m_Model.SystemApps[i].GetName() + " Functions";
//                    fgVars[r, 0] = m_Model.SystemApps[i].GetName();
                    fgVars.Rows[r].IsNode = true;
                    fgVars.Rows[r].Node.Level = 1;
                    fgVars[r, 1] = 1;
                    fgVars[r, fgVars.Cols.Count - 1] = new MModelStepApp(m_Model.SystemApps[i]);
                }
            }
            else //existing project, load based on the ordered steps
            {
                for (i = 0; i < model.OrderedSteps.Count; i++)
                {
                    //at this level, the steps should all be system groups
                    if (model.OrderedSteps[i].GetType() == typeof(MModelStepSystemGroup))
                    {
                        MModelStepSystemGroup mssg = (MModelStepSystemGroup)model.OrderedSteps[i];

                        r = fgVars.Rows.Add().Index;
                        fgVars[r, 0] = mssg.AppName + " System";  //TODO: Put project name, etc. here
                        fgVars[r, 1] = mssg.GetNumTimeSteps();
                        fgVars[r, fgVars.Cols.Count - 1] = mssg;

                        fgVars.SetCellStyle(r, 0, "TopNode");
                        fgVars.Rows[r].IsNode = true;
                        fgVars.Rows[r].Node.Level = 0;

                        //need to get the substep that is the vortex app and get the project and scenario name
                        j = 0;
                        while (j < mssg.SubSteps.Count)
                        {
                            if (mssg.SubSteps[j].GetType() == typeof(MModelStepApp))
                            {
                                if (((MModelStepApp)mssg.SubSteps[j]).App.GetType() == typeof(MAppVortex))
                                {
                                    fgVars[r, 0] = fgVars[r, 0].ToString() + " - " + ((MAppVortex)((MModelStepApp)mssg.SubSteps[j]).App).ProjectName +
                                        " [" + ((MAppVortex)((MModelStepApp)mssg.SubSteps[j]).App).ScenarioName + "]";

                                    // added 13 Dec 2015, for re-runs of MM
                                    ((MAppVortex)((MModelStepApp)mssg.SubSteps[j]).App).curYear = 0;
                                    ((MAppVortex)((MModelStepApp)mssg.SubSteps[j]).App).curIter = 0;

                                    break;
                                }
                                else if (((MModelStepApp)mssg.SubSteps[j]).App.GetType() == typeof(MAppOutbreak))
                                {
                                    fgVars[r, 0] = fgVars[r, 0].ToString() + " - " + ((MAppOutbreak)((MModelStepApp)mssg.SubSteps[j]).App).ProjectName;

                                    // added 13 Dec 2015, for re-runs of MM
                                    ((MAppOutbreak)((MModelStepApp)mssg.SubSteps[j]).App).curIter = 0;
                                    ((MAppOutbreak)((MModelStepApp)mssg.SubSteps[j]).App).curYear = 0;

                                    break;
                                }
                                //else if (((MModelStepApp)mssg.SubSteps[j]).App.GetType() == typeof(MAppSimSimba))
                                //{
                                //    fgVars[r, 0] = fgVars[r, 0].ToString() + " - " + ((MAppSimSimba)((MModelStepApp)mssg.SubSteps[j]).App).GetProjectName();

                                //    break;
                                //}
                            }

                            j++;
                        }


                        for (j = 0; j < mssg.SubSteps.Count; j++)
                            LoadingAddStep(mssg.SubSteps[j], 1);

                    }
                }
            }

            settingUp = false;
        }

        private void LoadingAddStep(MModelStep step, int nodeLevel)
        {
            int r, i;

            if (step.GetType() == typeof(MModelStepGroup))
            {
                r = fgVars.Rows.Add().Index;
                fgVars.SetCellStyle(r, 0, "TopNode");
                fgVars[r, 0] = "Group";
                fgVars[r, 1] = step.GetNumTimeSteps();
                fgVars.Rows[r].IsNode = true;
                fgVars.Rows[r].Node.Level = nodeLevel;
                fgVars[r, fgVars.Cols.Count - 1] = step;

                for (i = 0; i < ((MModelStepGroup)step).SubSteps.Count; i++)
                    LoadingAddStep(((MModelStepGroup)step).SubSteps[i], nodeLevel + 1);
            }
            else if (step.GetType() == typeof(MModelStepApp))
            {
                r = fgVars.Rows.Add().Index;
                fgVars[r, 0] = ((MModelStepApp)step).App.GetName();
                fgVars.Rows[r].IsNode = true;
                fgVars.Rows[r].Node.Level = nodeLevel;
                fgVars[r, 1] = step.GetNumTimeSteps();

                fgVars[r, fgVars.Cols.Count - 1] = step;
            }
            else if (step.GetType() == typeof(MModelStepBreak))
            {
                r = fgVars.Rows.Add().Index;
                fgVars[r, 0] = "Break";
                fgVars.Rows[r].IsNode = true;
                fgVars.Rows[r].Node.Level = nodeLevel;
                fgVars[r, 1] = 1;

                fgVars[r, fgVars.Cols.Count - 1] = step;
            }
            else if (step.GetType() == typeof(MModelStepInput))
            {
                r = fgVars.Rows.Add().Index;
                fgVars[r, 0] = "Input";
                fgVars.Rows[r].IsNode = true;
                fgVars.Rows[r].Node.Level = nodeLevel;
                fgVars[r, 1] = 1;

                fgVars[r, fgVars.Cols.Count - 1] = step;
            }
            else if (step.GetType() == typeof(MModelStepOutput))
            {
                r = fgVars.Rows.Add().Index;
                fgVars[r, 0] = "Output";
                fgVars.Rows[r].IsNode = true;
                fgVars.Rows[r].Node.Level = nodeLevel;
                fgVars[r, 1] = 1;

                fgVars[r, fgVars.Cols.Count - 1] = step;
            }
            else if (step.GetType() == typeof(MModelStepEvaluator))
            {
                r = fgVars.Rows.Add().Index;
                fgVars[r, 0] = "Evaluator";
                fgVars.Rows[r].IsNode = true;
                fgVars.Rows[r].Node.Level = nodeLevel;
                fgVars[r, 1] = 1;

                fgVars[r, fgVars.Cols.Count - 1] = step;
            }
        }

        //move up
        private void button2_Click(object sender, EventArgs e)
        {
            if (!settingUp) m_Model.saved = false;

            if (fgVars.Row > 2)
            {
                if (fgVars[fgVars.Row, 0].ToString() == "Group")
                {
                    //??????


                }
                else
                {
                    if (fgVars.Rows[fgVars.Row].Node.Level > 0)
                    {
                        fgVars.Rows[fgVars.Row].Move(fgVars.Row - 1);

                    }
                }

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!settingUp) m_Model.saved = false;

            if (fgVars.Row < fgVars.Rows.Count - 1 && fgVars.Rows[fgVars.Row].Node.Level == 1)
            {
                fgVars.Rows[fgVars.Row].Move(fgVars.Row + 1);

            }
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
            if (!settingUp) m_Model.saved = false;

            if (fgVars.Row > 0)
            {
                if (fgVars.Rows[fgVars.Row].Node.Level > 1)
                {
                    fgVars.Rows[fgVars.Row].Node.Level--;
                    //need to move it out from under the group

                    int r = fgVars.Row;
                    while (fgVars.Rows[r].Node.Level < fgVars.Rows[r + 1].Node.Level)
                    {
                        fgVars.Rows[r].Move(r + 1);
                        r++;
                    }
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!settingUp) m_Model.saved = false;

            if (fgVars.Row > 0)
            {
                if (fgVars.Rows[fgVars.Row].Node.Level > 0 && 
                    (fgVars.Rows[fgVars.Row - 1].Node.Level > fgVars.Rows[fgVars.Row].Node.Level || fgVars[fgVars.Row - 1, 0].ToString() == "Group"))
                {
                    // see if there's a group above it

                    fgVars.Rows[fgVars.Row].Node.Level++;


            }
        }
    }

        private void btnAddGroup_Click(object sender, EventArgs e)
        {
            if (!settingUp) m_Model.saved = false;

            int r = 1;

            if (fgVars.Row > 1)
                r = fgVars.Rows.Insert(fgVars.Row).Index;

            fgVars.SetCellStyle(r, 0, "TopNode");
            fgVars[r, 0] = "Group";
            fgVars[r, 1] = 1;
            fgVars.Rows[r].IsNode = true;
            fgVars.Rows[r].Node.Level = Math.Max(1, fgVars.Rows[r - 1].Node.Level);
            fgVars[r, fgVars.Cols.Count - 1] = new MModelStepGroup();


        }

        private void btnDelGroup_Click(object sender, EventArgs e)
        {
            if (!settingUp) m_Model.saved = false;

            if (fgVars.Row > 0 && fgVars[fgVars.Row, 0].ToString() == "Group")
            {
                int r = fgVars.Row;
                int lev = fgVars.Rows[r].Node.Level;

                fgVars.Rows.Remove(r);

                while (fgVars.Rows[r].Node.Level > lev)
                    fgVars.Rows[r++].Node.Level--;
            }
                


        }

        private void AddGroupNode(ref int i, int curLevel)
        {
            //add the group
            MModelStepGroup g = (MModelStepGroup)fgVars[i, fgVars.Cols.Count - 1];
            g.SetNumTimeSteps(Convert.ToInt32(fgVars[i, 1]));
            m_Model.OrderedSteps.Add(g);

            i++;

            while (i < fgVars.Rows.Count && fgVars.Rows[i].Node.Level > curLevel)
            {
                if (fgVars[i, 0].ToString() == "Group")
                    AddGroupNode(ref i, fgVars.Rows[i].Node.Level);
                else
                {
                    g.SubSteps.Add((MModelStep)fgVars[i, fgVars.Cols.Count - 1]);
                    g.SubSteps[g.SubSteps.Count - 1].SetNumTimeSteps(Convert.ToInt32(fgVars[i, 1]));
                    i++;
                }
            }

        }

        private void AddGroupNodeToSys(ref int i, int curLevel, MModelStepSystemGroup sysGroup)
        {
            //add the group
            MModelStepGroup g = (MModelStepGroup)fgVars[i, fgVars.Cols.Count - 1];
            g.SetNumTimeSteps(Convert.ToInt32(fgVars[i, 1]));
            sysGroup.SubSteps.Add(g);
            g.SubSteps.Clear();

            i++;

            while (i < fgVars.Rows.Count && fgVars.Rows[i].Node.Level > curLevel)
            {
                if (fgVars[i, 0].ToString() == "Group")
                    AddGroupNode(ref i, fgVars.Rows[i].Node.Level);
                else
                {
                    g.SubSteps.Add((MModelStep)fgVars[i, fgVars.Cols.Count - 1]);
                    g.SubSteps[g.SubSteps.Count - 1].SetNumTimeSteps(Convert.ToInt32(fgVars[i, 1]));
                    i++;
                }
            }

        }

        private void AddSystemGroupNode(ref int i, int curLevel)
        {
            //add the group
            MModelStepSystemGroup g = (MModelStepSystemGroup)fgVars[i, fgVars.Cols.Count - 1];
            g.SetNumTimeSteps(Convert.ToInt32(fgVars[i, 1]));
            m_Model.OrderedSteps.Add(g);
            g.SubSteps.Clear();

            i++;

            while (i < fgVars.Rows.Count && fgVars.Rows[i].Node.Level > curLevel)
            {
                if (fgVars[i, 0].ToString() == "Group")
                    AddGroupNodeToSys(ref i, fgVars.Rows[i].Node.Level, g);
                else
                {
                    g.SubSteps.Add((MModelStep)fgVars[i, fgVars.Cols.Count - 1]);
                    g.SubSteps[g.SubSteps.Count - 1].SetNumTimeSteps(Convert.ToInt32(fgVars[i, 1]));
                    i++;
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {


            SetUpSteps();


            // Bob changed order of showing forms, so can set Options before saving
            frmSimOptions frm = new frmSimOptions(m_Model);

            if (frm.ShowDialog() != DialogResult.OK)
            {
                return;
            }


            //see if saved
            if (!m_Model.saved)
            {
                DialogResult r = MessageBox.Show("Save this project before continuing?", "Save Project", MessageBoxButtons.YesNoCancel);

                if (r == DialogResult.Cancel)
                    return;
                else if (r == DialogResult.Yes)
                {
                    btnSave_Click(this, e);
                }
            }

            //frmSimOptions frm = new frmSimOptions(m_Model);

            //if (frm.ShowDialog() == DialogResult.OK)
            //{
            //    new frmSimulate(m_Model).ShowDialog();
            //}

            new frmSimulate(m_Model).ShowDialog();

        }

        private void SetUpSteps()
        {
            m_Model.OrderedSteps.Clear();

            
            int i, curLevel = -1;

            m_Model.Years = Convert.ToInt32(txtYears.Text);
            m_Model.Iterations = Convert.ToInt32(txtIter.Text);

            //set num years, iters
            m_Model.assignNYearsNIterations();
            //for (i = 0; i < m_Model.SystemApps.Count; i++)
            //{
            //    m_Model.SystemApps[i].SetNumYears(m_Model.Years);
            //    m_Model.SystemApps[i].SetNumIter(m_Model.Iterations);

            //    // added by Bob, in case needed by Modifier App
            //    for (int k = 0; k < m_Model.SystemApps[i].SubModels().Count; k++)
            //    {
            //        if (m_Model.SystemApps[i].SubModels()[k].GetType() == typeof(MAppExternal))
            //        {
            //            ((MAppExternal)m_Model.SystemApps[i].SubModels()[k]).SetNumIter(m_Model.Iterations);
            //            ((MAppExternal)m_Model.SystemApps[i].SubModels()[k]).SetNumYears(m_Model.Years);
            //        }
            //        if (m_Model.SystemApps[i].SubModels()[k].GetType() == typeof(MAppOutbreak2))
            //        {
            //            ((MAppOutbreak2)m_Model.SystemApps[i].SubModels()[k]).SetNumIter(m_Model.Iterations);
            //            ((MAppOutbreak2)m_Model.SystemApps[i].SubModels()[k]).SetNumYears(m_Model.Years);
            //        }
            //    }
            //}

            i = 1;

            while (i < fgVars.Rows.Count && fgVars.Rows[i].Node.Level >= curLevel)
            {
                if (fgVars.Rows[i].Node.Level > curLevel)
                {
                    if (fgVars[i, 0].ToString().StartsWith("Vortex System"))
                        AddSystemGroupNode(ref i, fgVars.Rows[i].Node.Level);
                    //else if (fgVars[i, 0].ToString().StartsWith("SimSimba System"))
                    //    AddSystemGroupNode(ref i, fgVars.Rows[i].Node.Level);
                    else if (fgVars[i, 0].ToString().StartsWith("Outbreak System"))
                        AddSystemGroupNode(ref i, fgVars.Rows[i].Node.Level);
                    else if (fgVars[i, 0].ToString().Contains("MetaPop"))
                        AddSystemGroupNode(ref i, fgVars.Rows[i].Node.Level);
                    else if (fgVars[i, 0].ToString() == "Group")
                        AddGroupNode(ref i, fgVars.Rows[i].Node.Level);
                    else
                    {
                        m_Model.OrderedSteps.Add((MModelStep)fgVars[i, fgVars.Cols.Count - 1]);
                        m_Model.OrderedSteps[m_Model.OrderedSteps.Count - 1].SetNumTimeSteps(Convert.ToInt32(fgVars[i, 1]));
                        i++;
                    }
                }
                else
                {
                    if (fgVars[i, fgVars.Cols.Count - 1] != null
                        && (fgVars[i, fgVars.Cols.Count - 1].GetType() == typeof(MModelStepBreak)
                        || fgVars[i, fgVars.Cols.Count - 1].GetType() == typeof(MModelStepInput)
                        || fgVars[i, fgVars.Cols.Count - 1].GetType() == typeof(MModelStepEvaluator)))
                    {
                        m_Model.OrderedSteps.Add((MModelStep)fgVars[i, fgVars.Cols.Count - 1]);
                    }

                    i++;
                }
            }
        }

        private void btnAddBreak_Click(object sender, EventArgs e)
        {
            MModelStepBreak brk = new MModelStepBreak();
            if (new frmBreakSetup(brk, m_Model, m_Model.DataSet).ShowDialog() == DialogResult.OK)
            {
                if (!settingUp) m_Model.saved = false;

                int r = 1;

                if (fgVars.Row > 0)
                {
                    r = fgVars.Rows.Insert(fgVars.Row).Index;

                    string brkString = "Break";
                    if (brk.BreakOnYear <= 1)
                        brkString += " (Yearly)";
                    else
                        brkString += " Every " + brk.BreakOnYear.ToString() + " Years";

                    fgVars[r, 0] = brkString;
                    fgVars[r, 1] = 1;
                    fgVars.Rows[r].IsNode = true;
                    if (r == 1)
                        fgVars.Rows[r].Node.Level = 0;
                    else
                        fgVars.Rows[r].Node.Level = Math.Max(1, fgVars.Rows[r - 1].Node.Level);
                    fgVars[r, fgVars.Cols.Count - 1] = brk;
                    fgVars.Row = r;
                }
            }
        }

        private void btnDelBreak_Click(object sender, EventArgs e)
        {
            if (!settingUp) m_Model.saved = false;

            if (fgVars.Row > 0 && fgVars[fgVars.Row, fgVars.Cols.Count - 1].GetType() == typeof(MModelStepBreak))
                fgVars.RemoveItem(fgVars.Row);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "MMM Project File (*.mmmm)|*.mmmm";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                SetUpSteps();
                m_Model.saved = m_Model.SaveXML(dlg.FileName);
            }

        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Program.isExiting = true;
            Application.Exit();
        }

        private void btnAddInputStep_Click(object sender, EventArgs e)
        {
            MModelStepInput inp = new MModelStepInput();
            if (new frmInputStepSetup(m_Model, inp).ShowDialog() == DialogResult.OK)
            {
                if (!settingUp) m_Model.saved = false;

                int r = 1;

                if (fgVars.Row > 0)
                {
                    r = fgVars.Rows.Insert(fgVars.Row).Index;

                    string inpString = "Input";

                    fgVars[r, 0] = inpString;
                    fgVars[r, 1] = 1;
                    fgVars.Rows[r].IsNode = true;
                    if (r == 1)
                        fgVars.Rows[r].Node.Level = 0;
                    else
                        fgVars.Rows[r].Node.Level = Math.Max(1, fgVars.Rows[r - 1].Node.Level);
                    fgVars[r, fgVars.Cols.Count - 1] = inp;
                    fgVars.Row = r;
                }
            }
        }

        private void btnDelInputStep_Click(object sender, EventArgs e)
        {
            if (!settingUp) m_Model.saved = false;

            if (fgVars.Row > 0 && fgVars[fgVars.Row, fgVars.Cols.Count - 1].GetType() == typeof(MModelStepInput))
                fgVars.RemoveItem(fgVars.Row);
        }

        private void btnAddEvaluatorStep_Click(object sender, EventArgs e)
        {
            MModelStepEvaluator ev = new MModelStepEvaluator();
            if (new frmEvaluatorSetup(m_Model, ev).ShowDialog() == DialogResult.OK)
            {
                if (!settingUp) m_Model.saved = false;

                int r = 1;

                if (fgVars.Row > 0)
                {
                    r = fgVars.Rows.Insert(fgVars.Row).Index;

                    string inpString = "Evaluator";

                    fgVars[r, 0] = inpString;
                    fgVars[r, 1] = 1;
                    fgVars.Rows[r].IsNode = true;
                    if (r == 1)
                        fgVars.Rows[r].Node.Level = 0;
                    else
                        fgVars.Rows[r].Node.Level = Math.Max(1, fgVars.Rows[r - 1].Node.Level);
                    fgVars[r, fgVars.Cols.Count - 1] = ev;
                    fgVars.Row = r;
                }
            }
        }

        private void btnDelEvaluatorStep_Click(object sender, EventArgs e)
        {
            if (!settingUp) m_Model.saved = false;

            if (fgVars.Row > 0 && fgVars[fgVars.Row, fgVars.Cols.Count - 1].GetType() == typeof(MModelStepEvaluator))
                fgVars.RemoveItem(fgVars.Row);
        }

        private void btnAddOutputStep_Click(object sender, EventArgs e)
        {
            MModelStepOutput o = new MModelStepOutput();
            if (new frmOutputStepSetup(m_Model, o).ShowDialog() == DialogResult.OK)
            {
                if (!settingUp) m_Model.saved = false;

                int r = 1;

                if (fgVars.Row > 0)
                {
                    r = fgVars.Rows.Insert(fgVars.Row).Index;

                    string oString = "Output";

                    fgVars[r, 0] = oString;
                    fgVars[r, 1] = 1;
                    fgVars.Rows[r].IsNode = true;
                    if (r == 1)
                        fgVars.Rows[r].Node.Level = 0;
                    else
                        fgVars.Rows[r].Node.Level = Math.Max(1, fgVars.Rows[r - 1].Node.Level);
                    fgVars[r, fgVars.Cols.Count - 1] = o;
                    fgVars.Row = r;
                }
            }
        }

        private void btnDelOutputStep_Click(object sender, EventArgs e)
        {
            if (!settingUp) m_Model.saved = false;

            if (fgVars.Row > 0 && fgVars[fgVars.Row, fgVars.Cols.Count - 1].GetType() == typeof(MModelStepOutput))
                fgVars.RemoveItem(fgVars.Row);
        }

        private void fgVars_DoubleClick(object sender, EventArgs e)
        {
            if (fgVars.Row < 1 || fgVars.Row >= fgVars.Rows.Count || fgVars[fgVars.Row, fgVars.Cols.Count - 1] == null)
                return;

            if (fgVars[fgVars.Row, fgVars.Cols.Count - 1].GetType() == typeof(MModelStepBreak))
            {
                MModelStepBreak brk = (MModelStepBreak)fgVars[fgVars.Row, fgVars.Cols.Count - 1];

                if (new frmBreakSetup(brk, m_Model, m_Model.DataSet).ShowDialog() == DialogResult.OK)
                {
                    string brkString = "Break";
                    if (brk.BreakOnYear <= 1)
                        brkString += " (Yearly)";
                    else
                        brkString += " Every " + brk.BreakOnYear.ToString() + " Years";

                    fgVars[fgVars.Row, 0] = brkString;
                }
            }
            else if (fgVars[fgVars.Row, fgVars.Cols.Count - 1].GetType() == typeof(MModelStepEvaluator))
                new frmEvaluatorSetup(m_Model, (MModelStepEvaluator)fgVars[fgVars.Row, fgVars.Cols.Count - 1]).ShowDialog();
            else if (fgVars[fgVars.Row, fgVars.Cols.Count - 1].GetType() == typeof(MModelStepInput))
                new frmInputStepSetup(m_Model, (MModelStepInput)fgVars[fgVars.Row, fgVars.Cols.Count - 1]).ShowDialog();
            else if (fgVars[fgVars.Row, fgVars.Cols.Count - 1].GetType() == typeof(MModelStepOutput))
                new frmOutputStepSetup(m_Model, (MModelStepOutput)fgVars[fgVars.Row, fgVars.Cols.Count - 1]).ShowDialog();
            else
                return;

        }

        private void txtYears_TextChanged(object sender, EventArgs e)
        {
            if (!settingUp) m_Model.saved = false;
        }

        private void txtIter_TextChanged(object sender, EventArgs e)
        {
            if (!settingUp) m_Model.saved = false;
        }

        private void fgVars_CellChanged(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (!settingUp && e.Col == 1) m_Model.saved = false;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmStepOrder_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("StepOrder");
        }
    }
}