using System;
using System.Collections.Generic;
using System.Windows.Forms;

using MMMCore;


namespace MeMoMa
{
    public partial class frmBreakSetup : Form
    {
        MModelStepBreak m_Break;

        public frmBreakSetup(MModelStepBreak brk, MModel model, MDataSet dataSet)
        {
            InitializeComponent();

            m_Break = brk;

            List<string> varsGlobal = new List<string>(), varsPop = new List<string>(), varsInd = new List<string>();

            int i, j, k;

            for (i = 0; i < model.SystemApps.Count; i++)
            {
                for (j = 0; j < model.SystemApps[i].GetGlobalVariables().Count; j++)
                {
                    if (varsGlobal.IndexOf(model.SystemApps[i].GetGlobalVariables()[j].Name) < 0)
                        varsGlobal.Add(model.SystemApps[i].GetGlobalVariables()[j].Name);
                }

                //for (j = 0; j < model.SystemApps[i].GetGlobalVariables().Count; j++)
                //{
                //    if (varsGlobal.IndexOf("Global." + model.SystemApps[i].GetGlobalVariables()[j].Name) < 0)
                //        varsGlobal.Add("Global." + model.SystemApps[i].GetGlobalVariables()[j].Name);
                //}

                //for (j = 0; j < model.SystemApps[i].GetPopulationVariables().Count; j++)
                //{
                //    if (varsPop.IndexOf("Population." + model.SystemApps[i].GetPopulationVariables()[j].Name) < 0)
                //        varsPop.Add("Population." + model.SystemApps[i].GetPopulationVariables()[j].Name);
                //}

                //for (j = 0; j < model.SystemApps[i].GetIndividualVariables().Count; j++)
                //{
                //    if (varsInd.IndexOf("Individual." + model.SystemApps[i].GetIndividualVariables()[j].Name) < 0)
                //        varsInd.Add("Individual." + model.SystemApps[i].GetIndividualVariables()[j].Name);
                //}

                //recurse through submodels
                for (k = 0; k < model.SystemApps[i].SubModels().Count; k++)
                {
                    for (j = 0; j < model.SystemApps[i].SubModels()[k].GetGlobalVariables().Count; j++)
                    {
                        if (varsGlobal.IndexOf(model.SystemApps[i].SubModels()[k].GetGlobalVariables()[j].Name) < 0)
                            varsGlobal.Add(model.SystemApps[i].SubModels()[k].GetGlobalVariables()[j].Name);
                    }

                    //for (j = 0; j < model.SystemApps[i].SubModels()[k].GetGlobalVariables().Count; j++)
                    //{
                    //    if (varsGlobal.IndexOf("Global." + model.SystemApps[i].SubModels()[k].GetGlobalVariables()[j].Name) < 0)
                    //        varsGlobal.Add("Global." + model.SystemApps[i].SubModels()[k].GetGlobalVariables()[j].Name);
                    //}

                    //for (j = 0; j < model.SystemApps[i].SubModels()[k].GetPopulationVariables().Count; j++)
                    //{
                    //    if (varsPop.IndexOf("Population." + model.SystemApps[i].SubModels()[k].GetPopulationVariables()[j].Name) < 0)
                    //        varsPop.Add("Population." + model.SystemApps[i].SubModels()[k].GetPopulationVariables()[j].Name);
                    //}

                    //for (j = 0; j < model.SystemApps[i].SubModels()[k].GetIndividualVariables().Count; j++)
                    //{
                    //    if (varsInd.IndexOf("Individual." + model.SystemApps[i].SubModels()[k].GetIndividualVariables()[j].Name) < 0)
                    //        varsInd.Add("Individual." + model.SystemApps[i].SubModels()[k].GetIndividualVariables()[j].Name);
                    //}
                }

            }

            varsGlobal.Sort();
            //varsPop.Sort();
            //varsInd.Sort();

            if (varsGlobal.Count == 0)
            {
                chkOnGSVar.Enabled = false;
                cboGSOp.Enabled = false;
                cboGSVars.Enabled = false;
                txtGSVal.Enabled = false;
            }
            else
            {
                for (i = 0; i < varsGlobal.Count; i++)
                    cboGSVars.Items.Add(varsGlobal[i]);

                cboGSVars.SelectedIndex = 0;
                cboGSOp.SelectedIndex = 0;
            }

            if (brk.BreakOnYear >= 0)
            {
                chkOnYear.Checked = true;
                txtOnYear.Text = brk.BreakOnYear.ToString();

            }
            else
                chkOnYear.Checked = false;

            if (brk.BreakOnGSVar != "")
            {
                chkOnGSVar.Checked = true;
                cboGSVars.Text = brk.BreakOnGSVar;
                cboGSOp.Text = brk.BreakOnGSOp;
                txtGSVal.Text = brk.BreakOnGSVal;
            }



        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (chkOnYear.Checked)
            {
                try
                {
                    int i = Convert.ToInt32(txtOnYear.Text);

                    if (i < 1)
                        MessageBox.Show("Please enter a number greater than 0 for the year on which to break.");
                    else
                        m_Break.BreakOnYear = i;
                }
                catch
                {
                    MessageBox.Show("Please enter a numeric value for the year on which to break.");
                }
            }
            else
                m_Break.BreakOnYear = -1;
            
            if (chkOnGSVar.Checked)
            {
                m_Break.BreakOnGSVar = cboGSVars.SelectedItem.ToString();
                m_Break.BreakOnGSOp = cboGSOp.SelectedItem.ToString();
                m_Break.BreakOnGSVal = txtGSVal.Text;
            }


            this.DialogResult = DialogResult.OK;

        }

        private void frmBreakSetup_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("BreakSetup");
        }
    }
}