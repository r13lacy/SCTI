using System;
using System.Windows.Forms;

using System.Threading;

namespace MeMoMa
{
    public partial class frmSimulate : Form
    {
        MModel m_Model;

        Thread threadSim = null;

        public frmSimulate(MModel model)
        {
            InitializeComponent();

            m_Model = model;

            chartSim.ChartGroups.Group0.ChartData.SeriesList.Clear();
            chartSim.ChartArea.AxisX.Max = m_Model.Years;
            //chartSim.ChartArea.AxisY.Max = 300;
            chartSim.ChartArea.AxisY.Min = 0;
            lblSpeed.Text = "";
            if (m_Model.Name.Trim() != "")
                label1.Text = "MM project: " + m_Model.Name;
            else label1.Text = "";
        }

        private void btnSimulate_Click(object sender, EventArgs e)
        {
            chartSim.ChartGroups.Group0.ChartData.SeriesList.Clear();

            //add a legend
            chartSim.Legend.Visible = true;
            chartSim.Legend.Compass = C1.Win.C1Chart.CompassEnum.South;

            prgSim.Visible = true;
            btnGraphSave.Visible = false;
            btnPrintGraph.Visible = false;

            //BELOW IS CODE FOR BOTH THREADED AND UNTHREADED OPERATION.  ALWAYS COMMENT OUT ONE OF THE FOLLOWING
            
            //1 -- THREADED CODE
            //btnStopSimulation.Visible = true;
            //threadSim = new Thread(new ParameterizedThreadStart((m_Model.SimulateFromThread)));
            //threadSim.Start(chartSim);

            //2 -- UNTHREADED CODE
            m_Model.Simulate(chartSim, prgSim, lblSpeed);

            prgSim.Visible = false;
            btnGraphSave.Visible = true;
            btnPrintGraph.Visible = true;

            MessageBox.Show("Complete!");

            //prgSim.Visible = true;
            //btnGraphSave.Visible = false;
        }

        // some useful stuff added by Bob
        private void dblClick_Click(object sender, EventArgs e)
        {
            chartSim.ShowProperties();
        }

        private void btnPrintGraph_Click(object sender, EventArgs e)
        {
            chartSim.PrintChart();
        }


        private void btnGraphSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "JPEG File (*.jpg) | *.jpg|PNG File (*.png) | *.png|WMF File (*.wmf) | *.wmf|Tiff File (*.tiff) | *.tiff|Gif File (*.gif) | *.gif";

            string fname = "";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    fname = dlg.FileName;
                    if(fname.ToLower().EndsWith(".png"))
                        chartSim.SaveImage(fname, System.Drawing.Imaging.ImageFormat.Png);
                    else if (fname.ToLower().EndsWith(".jpg"))
                        chartSim.SaveImage(fname, System.Drawing.Imaging.ImageFormat.Jpeg);
                    else if (fname.ToLower().EndsWith(".wmf"))
                        chartSim.SaveImage(fname, System.Drawing.Imaging.ImageFormat.Wmf);
                    else if (fname.ToLower().EndsWith(".tiff"))
                        chartSim.SaveImage(fname, System.Drawing.Imaging.ImageFormat.Tiff);
                    else if (fname.ToLower().EndsWith(".gif"))
                        chartSim.SaveImage(fname, System.Drawing.Imaging.ImageFormat.Gif);
                    else
                        MessageBox.Show("Unrecognized image format.");
                }
                catch
                {
                    MessageBox.Show("Failure to save the graph.");
                }
            }
            else
                return;

            try
            {
                    int index = fname.LastIndexOf(".");
                    string filename = dlg.FileName.Substring(0, index) + ".csv";

                    m_Model.WriteStoredData(filename);

                    //string title = chartSim.Header.Text;
                    //List<string> xdata = new List<string>();
                    //List<List<double>> ydata = new List<List<double>>();

                    //string xlabel = chartSim.ChartArea.AxisX.Text;
                    //List<string> ylabel = new List<string>();

                    ////Get y data for Group0
                    //foreach (C1.Win.C1Chart.ChartDataSeries ds in chartSim.ChartGroups.Group0.ChartData.SeriesList)
                    //{
                    //    List<double> y = new List<double>();

                    //    ylabel.Add(chartSim.ChartArea.AxisY.Text);
                    //    //ylabel.Add(ds.Label);

                    //    if (ds.Y[0].GetType() == typeof(double))
                    //    {
                    //        foreach (double x in ds.Y) y.Add(x);
                    //    }
                    //    else
                    //    {
                    //        foreach (int x in ds.Y) y.Add((double)x);
                    //    }
                    //    //foreach (double x in ds.Y)
                    //    //    y.Add((double)x);

                    //    ydata.Add(y);
                    //}


                    ////Get y data for Group1
                    //foreach (C1.Win.C1Chart.ChartDataSeries ds in chartSim.ChartGroups.Group1.ChartData.SeriesList)
                    //{
                    //    List<double> y = new List<double>();

                    //    ylabel.Add(chartSim.ChartArea.AxisY2.Text);
                    //    //ylabel.Add(ds.Label);

                    //    if (ds.Y[0].GetType() == typeof(double))
                    //    {
                    //        foreach (double x in ds.Y) y.Add(x);
                    //    }
                    //    else
                    //    {
                    //        foreach (int x in ds.Y) y.Add((double)x);
                    //    }
                    //    //foreach (double x in ds.Y)
                    //    //    y.Add(x);

                    //    ydata.Add(y);
                    //}


                    ////Get x data
                    ////                if (chartMain.ChartGroups.Group0.ChartType == Chart2DTypeEnum.XYPlot || chartMain.ChartGroups.Group0.ChartType == Chart2DTypeEnum.Bar)
                    //if (chartSim.ChartArea.AxisX.ValueLabels.Count == 0)
                    //{
                    //    C1.Win.C1Chart.ChartDataSeries dx = chartSim.ChartGroups.Group0.ChartData.SeriesList[0];
                    //    //if (dx.X[0].GetType() == typeof(double))
                    //    //{
                    //    //    foreach (double x in dx.X) xdata.Add(x.ToString());
                    //    //}
                    //    //else
                    //    //{
                    //    //    foreach (int x in dx.X) xdata.Add(x.ToString());
                    //    //}
                    //    for (int jj = 0; jj < dx.X.Length; jj++) xdata.Add(dx.X[jj].ToString());
                    //}
                    //else
                    //{
                    //    for (int j = 0; j < chartSim.ChartArea.AxisX.ValueLabels.Count; j++)
                    //    {
                    //        xdata.Add(chartSim.ChartArea.AxisX.ValueLabels[j].Text);
                    //    }
                    //}
                    //WriteChartDataToCSVFile(filename, title, xdata, xlabel, ydata, ylabel);

            }
            catch
            {
                MessageBox.Show("Failure to save Graph data as a .csv file. Sorry.");
            }
        }

        //public void WriteChartDataToCSVFile(string filename, string title, List<string> xdata, string xtitle, List<List<double>> ydata, List<string> ytitles)
        //{
        //    TextWriter tw;

        //    try
        //    {
        //        tw = new StreamWriter(filename);
        //    }
        //    catch
        //    {
        //        MessageBox.Show("Failure to open file " + filename + " for saving Graph data. Sorry.");
        //        return;
        //    }

        //    string text = "";
        //    string s = "; ";

        //    if (title != "")
        //        tw.WriteLine(title);
        //    text = xtitle;
        //    foreach (string t in ytitles)
        //        text += s + t;
        //    tw.WriteLine(text);

        //    for (int i = 0; i < xdata.Count; i++)
        //    {
        //        text = xdata[i];
        //        foreach (List<double> data in ydata)
        //        {
        //            for (int j = 0; j < xdata.Count - data.Count; j++) text += s; // in case some x points don't have a y
        //            if(i < data.Count) text += s + data[i].ToString(); // don't try to add y values that don't exist
        //        }

        //        tw.WriteLine(text);
        //    }

        //    tw.Close();

        //    MessageBox.Show("Data used in the chart were saved in file: " + filename);

        //}


        private void btnQuit_Click(object sender, EventArgs e)
        {
            Program.isExiting = true;
            Application.Exit();
        }

        private void btnStopSimulation_Click(object sender, EventArgs e)
        {
            this.Close(); // doesn't work. Doesn't check for user input until runs are done. 

            //threading commented out.

            ////TODO Figure out how to do this without obselete functions
            //if (threadSim != null)
            //{
            //    if (suspended)
            //    {
            //        threadSim.Resume();
            //        btnStopSimulation.Text = "Stop Simulation";
            //        suspended = false;
            //    }
            //    else
            //    {
            //        threadSim.Suspend();
            //        btnStopSimulation.Text = "Resume Simulation";
            //        suspended = true;
            //    }
            //}
        }

        private void frmSimulate_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (threadSim != null)
            {
                //System.Threading.Monitor.
                //threadSim.Abort();
                threadSim = null;
            }
        }

        private void pnlBottom_Layout(object sender, LayoutEventArgs e)
        {
            btnQuit.Left = pnlBottom.Width - btnQuit.Width - 8;

            prgSim.Width = btnQuit.Left - prgSim.Left - 16;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmSimulate_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("Simulate");
        }

    }
}