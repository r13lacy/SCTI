using System;
using System.Collections.Generic;
using System.Text;

using System.Xml;
using System.Xml.XPath;

using MMMCore;

namespace MeMoMa
{
    public class MAppBecky : MApp
    {

        private List<MVariable> GlobalVariables = new List<MVariable>();
        private List<MVariable> PopulationVariables = new List<MVariable>();
        private List<MVariable> IndividualVariables = new List<MVariable>();

        private string ProjectFile;

        //private BeckyLib.Meta Becky = null;

        private bool FirstRun = true;

        public int PopStartIndex, NumPops;

        private int AppIndex;

        private bool DoOutput;

        public MAppBecky()
        {
            PopulationVariables.Add(new MVariable("OpenTerritories", typeof(int), "Number of territories that are currently open", false));

            IndividualVariables.Add(new MVariable("Age", typeof(int), "Age of the individual", false));
            IndividualVariables.Add(new MVariable("Sex", typeof(int), "Sex of the individual", false));
            IndividualVariables.Add(new MVariable("Disperser", typeof(bool), "Whether or not the individual is a disperser", false));
            IndividualVariables.Add(new MVariable("TerritoryHolder", typeof(bool), "Whether or not the individual is a territory holder", false));
            IndividualVariables.Add(new MVariable("Territory", typeof(int), "The index of the territory in which the individual resides, or 0", false));
            IndividualVariables.Add(new MVariable("Breeder", typeof(bool), "Whether or not the individual is a breeder", false));
            IndividualVariables.Add(new MVariable("Mate", typeof(string), "The Vortex Name of the individual's mate", false));
            IndividualVariables.Add(new MVariable("X", typeof(int), "Location of the individual", false));
            IndividualVariables.Add(new MVariable("Y", typeof(int), "Location of the individual", false));
            IndividualVariables.Add(new MVariable("HabitatQuality", typeof(double), "Measure of quality of the landscape experienced", false));

        }


        public override string ToString()
        {
            return GetName() + " - " + GetDescription();
        }


        public void SetDoOutput(bool output) { DoOutput = output; }
        public bool GetDoOutput() { return DoOutput; }



        //INHERITED FROM MApp


        // Bob -- in case needed
        private int appStepCount;
        public void SetAppStepCount(int val) { appStepCount = val; }
        public int GetAppStepCount() { return appStepCount; }

        public string GetName()
        {
            return "Becky";
        }

        public string GetDescription()
        {
            return "GHLT Territorial and Social Model";
        }

        public string GetProjectFile()
        {
            return ProjectFile;
        }

        public void SetProjectFile(string fileName)
        {
            ProjectFile = fileName;
        }

        public List<MVariable> GetGlobalVariables()
        {
            return GlobalVariables;
        }

        public List<MVariable> GetPopulationVariables()
        {
            return PopulationVariables;
        }

        public List<MVariable> GetIndividualVariables()
        {
            return IndividualVariables;
        }

        public bool DoTurn(MDataSet dataSet, int numTimeSteps, int iteration, int year)
        {
            //make sure pop has individual vars
            //for (int j = 0; j < dataSet.Populations[PopStartIndex].IndList.Count; j++)
            //{
            //    for (int k = 0; k < IndividualVariables.Count; k++)
            //    {

            //        if (dataSet.Populations[PopStartIndex].IndList[j].VarNames.IndexOf(IndividualVariables[k].Name) < 0)
            //        {
            //            dataSet.Populations[PopStartIndex].IndList[j].VarNames.Add(IndividualVariables[k].Name);
            //            dataSet.Populations[PopStartIndex].IndList[j].Vars.Add("-1");
            //            dataSet.Populations[PopStartIndex].IndList[j].VarTypes.Add(IndividualVariables[k].VariableType);
            //        }
            //    }
            //}

            for (int k = 0; k < IndividualVariables.Count; k++)
            {
                if (dataSet.Populations[PopStartIndex].IndVarNames.IndexOf(IndividualVariables[k].Name) < 0)
                {
                    dataSet.Populations[PopStartIndex].AddIndVar(IndividualVariables[k].Name, "-1", IndividualVariables[k].VariableType);
                }
            }
            

            if (FirstRun)
            {
                //Becky = new BeckyLib.Meta();
                //if (!Becky.Initialize(dataSet.Populations[PopStartIndex], ProjectFile))
                //    return false;

                //FirstRun = false;

                
            }

            //check if extinct, if so, no becky!
            if (dataSet.Populations[PopStartIndex].IndList.Count == 0)
                return true;


            return false; // Becky.Simulate(dataSet.Populations[PopStartIndex], numTimeSteps);

        }

        public bool WriteResults()
        {
            return true; // Becky.CloseDLL();

        }

        public int GetAppIndex()
        {
            return AppIndex;
        }

        public void SetAppIndex(int index)
        {
            AppIndex = index;
        }

        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Becky");
            iNode.AppendChild(appNode);

            XmlElement n = doc.CreateElement("ProjectFile");
            n.InnerText = ProjectFile.Substring(ProjectFile.LastIndexOf("\\") + 1);
            appNode.AppendChild(n);

            return true;
        }

        public bool ToXMLShort(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Becky");
            appNode.InnerText = AppIndex.ToString();
            iNode.AppendChild(appNode);

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("ProjectFile");
            if (iter.MoveNext())
                ProjectFile = folderLocation + "\\" + iter.Current.Value;

            return true;
        }

    }
}
