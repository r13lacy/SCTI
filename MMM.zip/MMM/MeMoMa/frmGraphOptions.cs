using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MeMoMa
{
    public partial class frmSimOptions : Form
    {
        private MModel m_Model;
        private bool settingUp = true;

        public frmSimOptions(MModel model)
        {
            InitializeComponent();

            m_Model = model;

            List<string> varsGlobal = new List<string>(), varsPop = new List<string>();

            int i, j, k;

            // Bob 14 Dec 2012 added Pop Ns to list, so becomes optional if to plot them
            List<string> varsN = new List<string>();
            for (i = 0; i < m_Model.DataSet.Populations.Count; i++)
            {
                varsN.Add("N." + m_Model.DataSet.Populations[i].Name);
            }


            for (i = 0; i < m_Model.SystemApps.Count; i++)
            {
                for (j = 0; j < m_Model.SystemApps[i].GetGlobalVariables().Count; j++)
                {
                    if (varsGlobal.IndexOf("Global." + m_Model.SystemApps[i].GetGlobalVariables()[j].Name) < 0)
                        varsGlobal.Add("Global." + m_Model.SystemApps[i].GetGlobalVariables()[j].Name);
                }

                for (j = 0; j < m_Model.SystemApps[i].GetPopulationVariables().Count; j++)
                {
                    if (varsPop.IndexOf("Population." + m_Model.SystemApps[i].GetPopulationVariables()[j].Name) < 0)
                        varsPop.Add("Population." + m_Model.SystemApps[i].GetPopulationVariables()[j].Name);
                }


                //recurse through submodels
                for (k = 0; k < m_Model.SystemApps[i].SubModels().Count; k++)
                {
                    for (j = 0; j < m_Model.SystemApps[i].SubModels()[k].GetGlobalVariables().Count; j++)
                    {
                        if (varsGlobal.IndexOf("Global." + m_Model.SystemApps[i].SubModels()[k].GetGlobalVariables()[j].Name) < 0)
                            varsGlobal.Add("Global." + m_Model.SystemApps[i].SubModels()[k].GetGlobalVariables()[j].Name);
                    }

                    for (j = 0; j < m_Model.SystemApps[i].SubModels()[k].GetPopulationVariables().Count; j++)
                    {
                        if (varsPop.IndexOf("Population." + m_Model.SystemApps[i].SubModels()[k].GetPopulationVariables()[j].Name) < 0)
                            varsPop.Add("Population." + m_Model.SystemApps[i].SubModels()[k].GetPopulationVariables()[j].Name);
                    }
                }

            }

            varsGlobal.Sort();
            varsPop.Sort();

            fgVars.Rows.Count = varsN.Count + varsGlobal.Count + varsPop.Count + 1;
            for (i = 0; i < varsN.Count; i++)
            {
                fgVars[i + 1, 0] = varsN[i];
//                if (model.PlotVarList.Count <= i) 
                if(model.PlotVarList.Count == 0) fgVars.SetCellCheck(i + 1, 1, C1.Win.C1FlexGrid.CheckEnum.Checked); // initialize with a check, if things not already set
            }

            for (i = 0; i < varsGlobal.Count; i++)
                fgVars[i + 1 + varsN.Count, 0] = varsGlobal[i];

            for (i = 0; i < varsPop.Count; i++)
                fgVars[i + 1 + varsN.Count + varsGlobal.Count, 0] = varsPop[i];

//            for (i = varsN.Count + 1; i < fgVars.Rows.Count; i++)
            for (i = 1; i < fgVars.Rows.Count; i++)
            {
                if (model.PlotVarList.IndexOf(fgVars[i, 0].ToString()) >= 0)
                    fgVars.SetCellCheck(i, 1, C1.Win.C1FlexGrid.CheckEnum.Checked);
                //else
                //    fgVars.SetCellCheck(i, 1, C1.Win.C1FlexGrid.CheckEnum.Unchecked);
            }


            if (m_Model.Iterations * m_Model.Years < 1000)
                radioRealTime.Checked = true;
            else if (m_Model.Iterations * m_Model.Years < 10000)
                radioEachIteration.Checked = true;
            else if (m_Model.Iterations * m_Model.Years < 50000)
                radioEndIterations.Checked = true;
            else
                radioNone.Checked = true;

            //fgApps.Rows.Count = 1;
            //fgApps.Cols.Count++;
            //fgApps.Cols[fgApps.Cols.Count - 1].Visible = false;

            //for (i = 0; i < m_Model.SystemApps.Count; i++)
            //{
            //    for (j = 0; j < m_Model.SystemApps[i].SubModels().Count; j++)
            //    {
            //        int r = fgApps.Rows.Add().Index;

            //        fgApps[r, 0] = m_Model.SystemApps[i].GetName() + " - " + m_Model.SystemApps[i].SubModels()[j].GetName();
            //        if(m_Model.SystemApps[i].SubModels()[j].GetDoOutput())
            //            fgApps.SetCellCheck(r, 1, C1.Win.C1FlexGrid.CheckEnum.Checked); // Bob -- check set to default DoOutput for Model
            //        else
            //            fgApps.SetCellCheck(r, 1, C1.Win.C1FlexGrid.CheckEnum.Unchecked); 
            //        fgApps[r, 2] = m_Model.SystemApps[i].SubModels()[j];
            //    }
            //}

            settingUp = false;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (radioRealTime.Checked)
                m_Model.PlotShowAllIter = 0;
            else if (radioEachIteration.Checked)
                m_Model.PlotShowAllIter = 1;
            else if (radioEndIterations.Checked)
                m_Model.PlotShowAllIter = 3;
            else
                m_Model.PlotShowAllIter = 2;

            m_Model.PlotVarList.Clear();

            for (int i = 1; i < fgVars.Rows.Count; i++)
                if (fgVars.GetCellCheck(i, 1) == C1.Win.C1FlexGrid.CheckEnum.Checked)
                    m_Model.PlotVarList.Add(fgVars[i, 0].ToString());

            //for (int i = 1; i < fgApps.Rows.Count; i++)
            //    ((MApp)fgApps[i, 2]).SetDoOutput(fgApps.GetCellCheck(i, 1) == C1.Win.C1FlexGrid.CheckEnum.Checked);

        }

        private void fgVars_CellChecked(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (!settingUp) m_Model.saved = false;
        }

        private void frmSimOptions_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("GraphOptions");
        }

    }
}