namespace MeMoMa
{
    partial class frmBreakSetup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chkOnYear = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtOnYear = new System.Windows.Forms.TextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.chkOnGSVar = new System.Windows.Forms.CheckBox();
            this.cboGSVars = new System.Windows.Forms.ComboBox();
            this.cboGSOp = new System.Windows.Forms.ComboBox();
            this.txtGSVal = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // chkOnYear
            // 
            this.chkOnYear.AutoSize = true;
            this.chkOnYear.Checked = true;
            this.chkOnYear.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkOnYear.Location = new System.Drawing.Point(16, 48);
            this.chkOnYear.Margin = new System.Windows.Forms.Padding(4);
            this.chkOnYear.Name = "chkOnYear";
            this.chkOnYear.Size = new System.Drawing.Size(154, 21);
            this.chkOnYear.TabIndex = 0;
            this.chkOnYear.Text = "Year is a multiple of";
            this.chkOnYear.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Break when";
            // 
            // txtOnYear
            // 
            this.txtOnYear.Location = new System.Drawing.Point(180, 44);
            this.txtOnYear.Margin = new System.Windows.Forms.Padding(4);
            this.txtOnYear.Name = "txtOnYear";
            this.txtOnYear.Size = new System.Drawing.Size(56, 22);
            this.txtOnYear.TabIndex = 2;
            this.txtOnYear.Text = "1";
            this.txtOnYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(381, 250);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(76, 30);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(465, 250);
            this.btnOK.Margin = new System.Windows.Forms.Padding(4);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(76, 30);
            this.btnOK.TabIndex = 8;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // chkOnGSVar
            // 
            this.chkOnGSVar.AutoSize = true;
            this.chkOnGSVar.Location = new System.Drawing.Point(16, 91);
            this.chkOnGSVar.Margin = new System.Windows.Forms.Padding(4);
            this.chkOnGSVar.Name = "chkOnGSVar";
            this.chkOnGSVar.Size = new System.Drawing.Size(184, 21);
            this.chkOnGSVar.TabIndex = 10;
            this.chkOnGSVar.Text = "When the gobal variable";
            this.chkOnGSVar.UseVisualStyleBackColor = true;
            // 
            // cboGSVars
            // 
            this.cboGSVars.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGSVars.FormattingEnabled = true;
            this.cboGSVars.Location = new System.Drawing.Point(213, 89);
            this.cboGSVars.Margin = new System.Windows.Forms.Padding(4);
            this.cboGSVars.Name = "cboGSVars";
            this.cboGSVars.Size = new System.Drawing.Size(124, 24);
            this.cboGSVars.TabIndex = 11;
            // 
            // cboGSOp
            // 
            this.cboGSOp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGSOp.FormattingEnabled = true;
            this.cboGSOp.Items.AddRange(new object[] {
            "=",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.cboGSOp.Location = new System.Drawing.Point(347, 89);
            this.cboGSOp.Margin = new System.Windows.Forms.Padding(4);
            this.cboGSOp.Name = "cboGSOp";
            this.cboGSOp.Size = new System.Drawing.Size(64, 24);
            this.cboGSOp.TabIndex = 12;
            // 
            // txtGSVal
            // 
            this.txtGSVal.Location = new System.Drawing.Point(420, 90);
            this.txtGSVal.Margin = new System.Windows.Forms.Padding(4);
            this.txtGSVal.Name = "txtGSVal";
            this.txtGSVal.Size = new System.Drawing.Size(120, 22);
            this.txtGSVal.TabIndex = 13;
            this.txtGSVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // frmBreakSetup
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(557, 294);
            this.Controls.Add(this.txtGSVal);
            this.Controls.Add(this.cboGSOp);
            this.Controls.Add(this.cboGSVars);
            this.Controls.Add(this.chkOnGSVar);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.txtOnYear);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chkOnYear);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmBreakSetup";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "New Break";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmBreakSetup_KeyUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkOnYear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtOnYear;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.CheckBox chkOnGSVar;
        private System.Windows.Forms.ComboBox cboGSVars;
        private System.Windows.Forms.ComboBox cboGSOp;
        private System.Windows.Forms.TextBox txtGSVal;
    }
}