using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.XPath;

using System.Windows.Forms;
using MMMCore;
using Outbreak2;

namespace MeMoMa
{

    public class MAppOutbreak : MSystemApp
    {
        Outbreak2.MMOutbreak2 OProj = null;

        private List<MApp> m_SubModels = new List<MApp>();

        private int AppIndex;

        private string ProjectFile;

        public int curYear = -1;
        public int curIter = 0;

        public int ScenarioIndex = 0;
        public string ScenarioName;
//        public List<string> ScenarioNames = new List<string>();

        public int StartingPopIndex = 0;
        public int NumPops = 0;
        private MPopulation Mpop;

        public string ProjectName;
        public string dzTag = "";

        public int NumYears, numIterations;

        private List<MVariable> GlobalVariables = new List<MVariable>();
        private List<MVariable> PopulationVariables = new List<MVariable>();
        private List<MVariable> IndividualVariables = new List<MVariable>();

        public MAppOutbreak()
        {
            IndividualVariables.Add(new MVariable("Name", typeof(string), "Individual's ID", false));
            IndividualVariables.Add(new MVariable("Index", typeof(string), "Individual's Index internal to Vortex", false));
            IndividualVariables.Add(new MVariable("Age", typeof(string), "Age of the individual, in days", false));
            IndividualVariables.Add(new MVariable("Sex", typeof(string), "Sex of the individual (M/F)", false));
            IndividualVariables.Add(new MVariable("Alive", typeof(string), "Whether or not the individual is alive (T/F)", false));

            IndividualVariables.Add(new MVariable("X", typeof(string), "X-coordinate", false));  // what default value gets assigned?
            IndividualVariables.Add(new MVariable("Y", typeof(string), "Y-coordinate", false));

            //IndividualVariables.Add(new MVariable("DiseaseState", typeof(string), "SEIR state", false));
            //IndividualVariables.Add(new MVariable("DaysInState", typeof(string), "Days since entering Dz state", false));
            //IndividualVariables.Add(new MVariable("Tenure", typeof(string), "Days to remain in Dz state", false));
            //IndividualVariables.Add(new MVariable("IsVaccinated", typeof(string), "Whether or not the individual is vaccinated", false));
            //IndividualVariables.Add(new MVariable("StatePermanent", typeof(string), "Whether or not the Dz state is permanent", false));
        
            //PopulationVariables.Add(new MVariable("Prevalence", typeof(string), "Proportion of individuals in Dz state E or I",false));
            PopulationVariables.Add(new MVariable("N", typeof(string), "Population size", false));
            //PopulationVariables.Add(new MVariable("nP", typeof(string), "number PreSusceptible", false));
            //PopulationVariables.Add(new MVariable("nS", typeof(string), "number Susceptible", false));
            //PopulationVariables.Add(new MVariable("nE", typeof(string), "number Exposed", false));
            //PopulationVariables.Add(new MVariable("nI", typeof(string), "number Infectious", false));
            //PopulationVariables.Add(new MVariable("nR", typeof(string), "number Resistant", false));
            //PopulationVariables.Add(new MVariable("nV", typeof(string), "number Vaccinated", false));
        }

        public List<MApp> SubModels() { return m_SubModels; }

        public override string ToString()
        {
            return GetName() + " - " + GetDescription();
        }


        public bool WriteResults()
        {
            return OProj.CloseDLL();

        }

        //INHERITED FROM MApp
        public string GetName()
        {
            return "Outbreak";
        }

        public string GetDescription()
        {
            return "Epidemiological model of infectious disease";
        }


        public string GetProjectFile()
        {
            return ProjectFile;
        }

        public void SetProjectFile(string fileName)
        {
            ProjectFile = fileName;
        }

        public List<MVariable> GetGlobalVariables()
        {
            return GlobalVariables;
        }

        public List<MVariable> GetPopulationVariables()
        {
            return PopulationVariables;
        }

        public void SetPopulationVariables()
        {
            PopulationVariables.Clear();

            string dztag = "-" + dzTag;
            if (dzTag.Trim() == "") dztag = "";

            PopulationVariables.Add(new MVariable("Prevalence" + dztag, typeof(string), "", false));
            PopulationVariables.Add(new MVariable("nP" + dztag, typeof(string), "", false));
            PopulationVariables.Add(new MVariable("nS" + dztag, typeof(string), "", false));
            PopulationVariables.Add(new MVariable("nE" + dztag, typeof(string), "", false));
            PopulationVariables.Add(new MVariable("nI" + dztag, typeof(string), "", false));
            PopulationVariables.Add(new MVariable("nR" + dztag, typeof(string), "", false));
            PopulationVariables.Add(new MVariable("nV" + dztag, typeof(string), "", false));
        }

        public List<MVariable> GetIndividualVariables()
        {
            return IndividualVariables;
        }

        // Bob added, to try to get these in before setup forms shown
        public void SetIndividualVariables()
        {
            IndividualVariables.Clear();

            string dztag = "-" + dzTag;
            if (dzTag.Trim() == "") dztag = "";

            IndividualVariables.Add(new MVariable("DiseaseState" + dztag, typeof(string), "", false));
            IndividualVariables.Add(new MVariable("DaysInState" + dztag, typeof(string), "", false));
            IndividualVariables.Add(new MVariable("Tenure" + dztag, typeof(string), "", false));
            IndividualVariables.Add(new MVariable("StatePermanent" + dztag, typeof(string), "", false));
            IndividualVariables.Add(new MVariable("IsVaccinated" + dztag, typeof(string), "", false));
        }

        public int GetScenarioIndex() { return ScenarioIndex; }
        public string GetProjectName() { return ProjectName; }
        public int GetStartingPopIndex() { return StartingPopIndex; }
        public void SetStartingPopIndex(int val) { StartingPopIndex = val; }
        public void SetNumPops(int val) { NumPops = val; }
        public int GetNumPops() { return NumPops; }
        public void SetNumYears(int val) { NumYears = val; }
        public void SetNumIter(int val) { numIterations = val; }

        //public string GetScenarioName() { return "OutbreakScenario"; }
        //public void SetScenarioIndex(int val) {  }
        public string GetScenarioName() { return ScenarioName; }
        public void SetScenarioIndex(int val) { ScenarioIndex = val; }

        // Bob -- in case needed
        private int appStepCount;
        public void SetAppStepCount(int val) { appStepCount = val; }
        public int GetAppStepCount() { return appStepCount; }


        public bool Init(MDataSet dataSet, int totalTimeStepsToRun)
        {
            try
            {
                OProj = new Outbreak2.MMOutbreak2(true);
//                int totalDays = totalTimeStepsToRun / NumYears; 
                int totalDays = GetAppStepCount(); // alternative method

                Mpop = dataSet.Populations[StartingPopIndex];

                //if (ScenarioName != "" && ScenarioName != ScenarioNames[ScenarioIndex])
                //{
                //    if (MessageBox.Show("Outbreak Scenario name does not match index. Do you want to reset the index?", "Outbreak model warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                //        ScenarioIndex = ScenarioNames.IndexOf(ScenarioName);
                //}

                OProj.Initialize(dataSet, Mpop, ProjectFile, ScenarioIndex, numIterations, NumYears, totalDays);
                ProjectName = OProj.Opop.SceneName;
            }
            catch
            {
                MessageBox.Show("Failure to Initialize Outbreak system model.");
                return false;
            }

            return true;
        }

        public bool DoYear0(MDataSet dataSet, int iteration)
        {
            try 
            {
                curYear = 0;
                return OProj.MMStartOutbreak();
            }
            catch
            {
                MessageBox.Show("Year0 Failed in Outbreak System Model.");
                return false;
            }
        }

        public bool DoTurn(MDataSet dataSet, int numTimeSteps, int iteration, int year)
        {
            return OProj.Simulate(Mpop, iteration, year, numTimeSteps);
        }


        public int GetAppIndex()
        {
            return AppIndex;
        }

        public void SetAppIndex(int index)
        {
            AppIndex = index;
        }



        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Outbreak");
            iNode.AppendChild(appNode);

            XmlElement n = doc.CreateElement("ProjectFile");
            n.InnerText = ProjectFile;
            //n.InnerText = ProjectFile.Substring(ProjectFile.LastIndexOf("\\") + 1);
            appNode.AppendChild(n);

            n = doc.CreateElement("ProjectName");
            n.InnerText = ProjectName;
            appNode.AppendChild(n);

            n = doc.CreateElement("ScenarioIndex");
            n.InnerText = ScenarioIndex.ToString();
            appNode.AppendChild(n);

            n = doc.CreateElement("ScenarioName");
            n.InnerText = ScenarioName;
            appNode.AppendChild(n);

            n = doc.CreateElement("SubApps");
            appNode.AppendChild(n);

            for (int i = 0; i < m_SubModels.Count; i++)
                m_SubModels[i].ToXML(n, doc);

            return true;
        }


        public bool ToXMLShort(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Outbreak");
            appNode.InnerText = AppIndex.ToString();
            iNode.AppendChild(appNode);

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("ProjectFile");
            if (iter.MoveNext())
//                ProjectFile =  folderLocation + "\\" + iter.Current.Value;
            {
                ProjectFile = iter.Current.Value;
                if (!ProjectFile.Contains("\\")) ProjectFile = folderLocation + "\\" + ProjectFile;
            }

            iter = n.Select("ProjectName");
            if (iter.MoveNext())
                ProjectName = iter.Current.Value;

            iter = n.Select("ScenarioIndex");
            if (iter.MoveNext())
                ScenarioIndex = Convert.ToInt32(iter.Current.Value);

            iter = n.Select("ScenarioName");
            if (iter.MoveNext())
            {
                ScenarioName = iter.Current.Value;
            }

            iter = n.Select("SubApps");

            if (iter.MoveNext())
            {
                iter = iter.Current.Clone().SelectChildren(XPathNodeType.All);

                while (iter.MoveNext())
                {
                    if (iter.Current.Name == "Spatial")
                    {
                        MAppSpatial s = new MAppSpatial();
                        s.LoadXML(iter.Current.Clone(), folderLocation);
                        m_SubModels.Add(s);
                    }
                    else if (iter.Current.Name == "PathHistory")
                    {
                        MAppPathHistory ph = new MAppPathHistory();
                        ph.LoadXML(iter.Current.Clone(), folderLocation);
                        m_SubModels.Add(ph);
                    }
                    else if (iter.Current.Name == "Outbreak2")
                    {
                        MAppOutbreak2 ob2 = new MAppOutbreak2();
                        ob2.LoadXML(iter.Current.Clone(), folderLocation);
                        m_SubModels.Add(ob2);
                    }
                    //else if (iter.Current.Name == "Vaccinator")
                    //{
                    //    MAppVaccinator vac = new MAppVaccinator();
                    //    vac.LoadXML(iter.Current.Clone(), folderLocation);
                    //    m_SubModels.Add(vac);
                    //}
                    //else if (iter.Current.Name == "Infector")
                    //{
                    //    MAppInfector infect = new MAppInfector();
                    //    infect.LoadXML(iter.Current.Clone(), folderLocation);
                    //    m_SubModels.Add(infect);
                    //}
                    //else if (iter.Current.Name == "Becky")
                    //{
                    //    MAppBecky b = new MAppBecky();
                    //    b.LoadXML(iter.Current.Clone(), folderLocation);
                    //    m_SubModels.Add(b);
                    //}
                    else if (iter.Current.Name == "External")
                    {
                        MAppExternal b = new MAppExternal();
                        b.LoadXML(iter.Current.Clone(), folderLocation);
                        m_SubModels.Add(b);
                    }
                }
            }

            return true;
        }


    }
}
