namespace MeMoMa
{
    partial class frmStepOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmStepOrder));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnDelOutputStep = new System.Windows.Forms.Button();
            this.btnAddOutputStep = new System.Windows.Forms.Button();
            this.btnDelEvaluatorStep = new System.Windows.Forms.Button();
            this.btnAddEvaluatorStep = new System.Windows.Forms.Button();
            this.btnDelInputStep = new System.Windows.Forms.Button();
            this.btnAddInputStep = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIter = new System.Windows.Forms.TextBox();
            this.btnDelBreak = new System.Windows.Forms.Button();
            this.btnAddBreak = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtYears = new System.Windows.Forms.TextBox();
            this.btnDelGroup = new System.Windows.Forms.Button();
            this.btnAddGroup = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btnLeft = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.fgVars = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgVars)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnBack);
            this.panel1.Controls.Add(this.btnQuit);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 571);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1064, 47);
            this.panel1.TabIndex = 0;
            // 
            // btnBack
            // 
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnBack.Location = new System.Drawing.Point(715, 8);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(76, 30);
            this.btnBack.TabIndex = 19;
            this.btnBack.Text = "<< Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(819, 7);
            this.btnQuit.Margin = new System.Windows.Forms.Padding(4);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(103, 28);
            this.btnQuit.TabIndex = 3;
            this.btnQuit.Text = "Quit MMM";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(16, 7);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(103, 28);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "Save...";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(945, 7);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 28);
            this.button1.TabIndex = 1;
            this.button1.Text = "Next >>";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnDelOutputStep);
            this.panel2.Controls.Add(this.btnAddOutputStep);
            this.panel2.Controls.Add(this.btnDelEvaluatorStep);
            this.panel2.Controls.Add(this.btnAddEvaluatorStep);
            this.panel2.Controls.Add(this.btnDelInputStep);
            this.panel2.Controls.Add(this.btnAddInputStep);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtIter);
            this.panel2.Controls.Add(this.btnDelBreak);
            this.panel2.Controls.Add(this.btnAddBreak);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.txtYears);
            this.panel2.Controls.Add(this.btnDelGroup);
            this.panel2.Controls.Add(this.btnAddGroup);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.btnLeft);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 497);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1064, 74);
            this.panel2.TabIndex = 1;
            // 
            // btnDelOutputStep
            // 
            this.btnDelOutputStep.Location = new System.Drawing.Point(477, 38);
            this.btnDelOutputStep.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelOutputStep.Name = "btnDelOutputStep";
            this.btnDelOutputStep.Size = new System.Drawing.Size(76, 31);
            this.btnDelOutputStep.TabIndex = 17;
            this.btnDelOutputStep.Text = "- Output";
            this.btnDelOutputStep.UseVisualStyleBackColor = true;
            this.btnDelOutputStep.Click += new System.EventHandler(this.btnDelOutputStep_Click);
            // 
            // btnAddOutputStep
            // 
            this.btnAddOutputStep.Location = new System.Drawing.Point(477, 6);
            this.btnAddOutputStep.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddOutputStep.Name = "btnAddOutputStep";
            this.btnAddOutputStep.Size = new System.Drawing.Size(76, 31);
            this.btnAddOutputStep.TabIndex = 16;
            this.btnAddOutputStep.Text = "+Output";
            this.btnAddOutputStep.UseVisualStyleBackColor = true;
            this.btnAddOutputStep.Click += new System.EventHandler(this.btnAddOutputStep_Click);
            // 
            // btnDelEvaluatorStep
            // 
            this.btnDelEvaluatorStep.Location = new System.Drawing.Point(584, 39);
            this.btnDelEvaluatorStep.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelEvaluatorStep.Name = "btnDelEvaluatorStep";
            this.btnDelEvaluatorStep.Size = new System.Drawing.Size(96, 31);
            this.btnDelEvaluatorStep.TabIndex = 15;
            this.btnDelEvaluatorStep.Text = "- Evaluator";
            this.btnDelEvaluatorStep.UseVisualStyleBackColor = true;
            this.btnDelEvaluatorStep.Click += new System.EventHandler(this.btnDelEvaluatorStep_Click);
            // 
            // btnAddEvaluatorStep
            // 
            this.btnAddEvaluatorStep.Location = new System.Drawing.Point(584, 7);
            this.btnAddEvaluatorStep.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddEvaluatorStep.Name = "btnAddEvaluatorStep";
            this.btnAddEvaluatorStep.Size = new System.Drawing.Size(96, 31);
            this.btnAddEvaluatorStep.TabIndex = 14;
            this.btnAddEvaluatorStep.Text = "+ Evaluator";
            this.btnAddEvaluatorStep.UseVisualStyleBackColor = true;
            this.btnAddEvaluatorStep.Click += new System.EventHandler(this.btnAddEvaluatorStep_Click);
            // 
            // btnDelInputStep
            // 
            this.btnDelInputStep.Location = new System.Drawing.Point(365, 39);
            this.btnDelInputStep.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelInputStep.Name = "btnDelInputStep";
            this.btnDelInputStep.Size = new System.Drawing.Size(76, 31);
            this.btnDelInputStep.TabIndex = 13;
            this.btnDelInputStep.Text = "- Input";
            this.btnDelInputStep.UseVisualStyleBackColor = true;
            this.btnDelInputStep.Click += new System.EventHandler(this.btnDelInputStep_Click);
            // 
            // btnAddInputStep
            // 
            this.btnAddInputStep.Location = new System.Drawing.Point(365, 7);
            this.btnAddInputStep.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddInputStep.Name = "btnAddInputStep";
            this.btnAddInputStep.Size = new System.Drawing.Size(76, 31);
            this.btnAddInputStep.TabIndex = 12;
            this.btnAddInputStep.Text = "+ Input";
            this.btnAddInputStep.UseVisualStyleBackColor = true;
            this.btnAddInputStep.Click += new System.EventHandler(this.btnAddInputStep_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(916, 15);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 17);
            this.label2.TabIndex = 11;
            this.label2.Text = "Iterations:";
            // 
            // txtIter
            // 
            this.txtIter.Location = new System.Drawing.Point(990, 11);
            this.txtIter.Margin = new System.Windows.Forms.Padding(4);
            this.txtIter.Name = "txtIter";
            this.txtIter.Size = new System.Drawing.Size(56, 22);
            this.txtIter.TabIndex = 1;
            this.txtIter.Text = "1";
            this.txtIter.TextChanged += new System.EventHandler(this.txtIter_TextChanged);
            // 
            // btnDelBreak
            // 
            this.btnDelBreak.Location = new System.Drawing.Point(257, 39);
            this.btnDelBreak.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelBreak.Name = "btnDelBreak";
            this.btnDelBreak.Size = new System.Drawing.Size(76, 31);
            this.btnDelBreak.TabIndex = 9;
            this.btnDelBreak.Text = "- Break";
            this.btnDelBreak.UseVisualStyleBackColor = true;
            this.btnDelBreak.Click += new System.EventHandler(this.btnDelBreak_Click);
            // 
            // btnAddBreak
            // 
            this.btnAddBreak.Location = new System.Drawing.Point(257, 7);
            this.btnAddBreak.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddBreak.Name = "btnAddBreak";
            this.btnAddBreak.Size = new System.Drawing.Size(76, 31);
            this.btnAddBreak.TabIndex = 8;
            this.btnAddBreak.Text = "+ Break";
            this.btnAddBreak.UseVisualStyleBackColor = true;
            this.btnAddBreak.Click += new System.EventHandler(this.btnAddBreak_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(712, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "MetaModel cycles:";
            // 
            // txtYears
            // 
            this.txtYears.Location = new System.Drawing.Point(838, 11);
            this.txtYears.Margin = new System.Windows.Forms.Padding(4);
            this.txtYears.Name = "txtYears";
            this.txtYears.Size = new System.Drawing.Size(67, 22);
            this.txtYears.TabIndex = 0;
            this.txtYears.Text = "10";
            this.txtYears.TextChanged += new System.EventHandler(this.txtYears_TextChanged);
            // 
            // btnDelGroup
            // 
            this.btnDelGroup.Location = new System.Drawing.Point(153, 39);
            this.btnDelGroup.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelGroup.Name = "btnDelGroup";
            this.btnDelGroup.Size = new System.Drawing.Size(75, 31);
            this.btnDelGroup.TabIndex = 5;
            this.btnDelGroup.Text = "- Group";
            this.btnDelGroup.UseVisualStyleBackColor = true;
            this.btnDelGroup.Click += new System.EventHandler(this.btnDelGroup_Click);
            // 
            // btnAddGroup
            // 
            this.btnAddGroup.Location = new System.Drawing.Point(153, 7);
            this.btnAddGroup.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddGroup.Name = "btnAddGroup";
            this.btnAddGroup.Size = new System.Drawing.Size(75, 31);
            this.btnAddGroup.TabIndex = 4;
            this.btnAddGroup.Text = "+ Group";
            this.btnAddGroup.UseVisualStyleBackColor = true;
            this.btnAddGroup.Click += new System.EventHandler(this.btnAddGroup_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(68, 39);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(60, 31);
            this.button4.TabIndex = 3;
            this.button4.Text = "-->";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnLeft
            // 
            this.btnLeft.Location = new System.Drawing.Point(4, 39);
            this.btnLeft.Margin = new System.Windows.Forms.Padding(4);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(60, 31);
            this.btnLeft.TabIndex = 2;
            this.btnLeft.Text = "<--";
            this.btnLeft.UseVisualStyleBackColor = true;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(68, 7);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(60, 31);
            this.button3.TabIndex = 1;
            this.button3.Text = "Down";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(4, 7);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(60, 31);
            this.button2.TabIndex = 0;
            this.button2.Text = "Up";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // fgVars
            // 
            this.fgVars.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.fgVars.ColumnInfo = "2,0,0,0,0,90,Columns:0{Width:661;AllowSorting:False;Caption:\"Model\";AllowDragging" +
    ":False;AllowEditing:False;}\t1{Caption:\"Time Steps\";}\t";
            this.fgVars.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fgVars.ExtendLastCol = true;
            this.fgVars.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.fgVars.Location = new System.Drawing.Point(0, 0);
            this.fgVars.Margin = new System.Windows.Forms.Padding(4);
            this.fgVars.Name = "fgVars";
            this.fgVars.Rows.DefaultSize = 23;
            this.fgVars.Size = new System.Drawing.Size(1064, 497);
            this.fgVars.StyleInfo = resources.GetString("fgVars.StyleInfo");
            this.fgVars.TabIndex = 2;
            this.fgVars.Tree.Column = 0;
            this.fgVars.CellChanged += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgVars_CellChanged);
            this.fgVars.DoubleClick += new System.EventHandler(this.fgVars_DoubleClick);
            // 
            // frmStepOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 618);
            this.Controls.Add(this.fgVars);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmStepOrder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Order Model Steps";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmStepOrder_KeyUp);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgVars)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private C1.Win.C1FlexGrid.C1FlexGrid fgVars;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.Button btnDelGroup;
        private System.Windows.Forms.Button btnAddGroup;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtYears;
        private System.Windows.Forms.Button btnDelBreak;
        private System.Windows.Forms.Button btnAddBreak;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIter;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Button btnDelInputStep;
        private System.Windows.Forms.Button btnAddInputStep;
        private System.Windows.Forms.Button btnDelEvaluatorStep;
        private System.Windows.Forms.Button btnAddEvaluatorStep;
        private System.Windows.Forms.Button btnDelOutputStep;
        private System.Windows.Forms.Button btnAddOutputStep;
        private System.Windows.Forms.Button btnBack;
    }
}