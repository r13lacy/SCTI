using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MeMoMa
{
    public partial class frmDataSet : Form
    {
        private MModel m_Model;

        public frmDataSet(MModel model)
        {
            InitializeComponent();

            m_Model = model;

            MModel.LoadData(model, fgPops);
            
            //vars
            UpdateVarList();

        }

        private void AddAppVars(MApp app, List<string> gVars, List<string> pVars, List<string> iVars,
            List<List<string>> gUsed, List<List<string>> pUsed, List<List<string>> iUsed)
        {
            int j, k;

            for (j = 0; j < app.GetGlobalVariables().Count; j++)
            {
                k = gVars.IndexOf(app.GetGlobalVariables()[j].Name);

                if (k < 0)
                {
                    //not in var list yet, add it, and record sys model as using it
                    k = gVars.Count;
                    gVars.Add(app.GetGlobalVariables()[j].Name);
                    gUsed.Add(new List<string>());
                    gUsed[k].Add(app.GetName());
                }
                else
                {
                    //var exists, record sys model as using it, if not already
                    if (gUsed[k].IndexOf(app.GetName()) < 0)
                        gUsed[k].Add(app.GetName());
                }
            }

            for (j = 0; j < app.GetPopulationVariables().Count; j++)
            {
                k = pVars.IndexOf(app.GetPopulationVariables()[j].Name);

                if (k < 0)
                {
                    //not in var list yet, add it, and record sys model as using it
                    k = pVars.Count;
                    pVars.Add(app.GetPopulationVariables()[j].Name);
                    pUsed.Add(new List<string>());
                    pUsed[k].Add(app.GetName());
                }
                else
                {
                    //var exists, record sys model as using it, if not already
                    if (pUsed[k].IndexOf(app.GetName()) < 0)
                        pUsed[k].Add(app.GetName());
                }
            }

            for (j = 0; j < app.GetIndividualVariables().Count; j++)
            {
                k = iVars.IndexOf(app.GetIndividualVariables()[j].Name);

                if (k < 0)
                {
                    //not in var list yet, add it, and record sys model as using it
                    k = iVars.Count;
                    iVars.Add(app.GetIndividualVariables()[j].Name);
                    iUsed.Add(new List<string>());
                    iUsed[k].Add(app.GetName());
                }
                else
                {
                    //var exists, record sys model as using it, if not already
                    if (iUsed[k].IndexOf(app.GetName()) < 0)
                        iUsed[k].Add(app.GetName());
                }
            }

        }

        private void UpdateVarList()
        {
            //do this properly.  create lists, and look in the lists, etc. then write to grid.

            int i, j, r;

            List<string> gVars = new List<string>(), pVars = new List<string>(), iVars = new List<string>();
            List<List<string>> gUsed = new List<List<string>>(), pUsed = new List<List<string>>(), iUsed = new List<List<string>>();

            for (i = 0; i < m_Model.SystemApps.Count; i++)
            {
                AddAppVars(m_Model.SystemApps[i], gVars, pVars, iVars, gUsed, pUsed, iUsed);

                
                for (j = 0; j < m_Model.SystemApps[i].SubModels().Count; j++)
                    AddAppVars(m_Model.SystemApps[i].SubModels()[j], gVars, pVars, iVars, gUsed, pUsed, iUsed);

            }


            //fgVars.Rows.Count = 1;

            r = fgVars.Rows.Add().Index;

            fgVars[r, 0] = "Global Variables";
            fgVars.SetCellStyle(r, 0, "TopNode");
            fgVars.Rows[r].IsNode = true;
            fgVars.Rows[r].Node.Level = 0;

            for (i = 0; i < gVars.Count; i++)
            {
                r = fgVars.Rows.Add().Index;
                fgVars[r, 0] = gVars[i];

                string s = gUsed[i][0];
                for (j = 1; j < gUsed[i].Count; j++)
                    s += ", " + gUsed[i][j];

                fgVars[r, 1] = s;
                fgVars.Rows[r].IsNode = true;
                fgVars.Rows[r].Node.Level = 1;

            }

            r = fgVars.Rows.Add().Index;
            r = fgVars.Rows.Add().Index;
            fgVars[r, 0] = "Population Variables";
            fgVars.SetCellStyle(r, 0, "TopNode");
            fgVars.Rows[r].IsNode = true;
            fgVars.Rows[r].Node.Level = 0;

            for (i = 0; i < pVars.Count; i++)
            {
                r = fgVars.Rows.Add().Index;
                fgVars[r, 0] = pVars[i];

                string s = pUsed[i][0];
                for (j = 1; j < pUsed[i].Count; j++)
                    s += ", " + pUsed[i][j];

                fgVars[r, 1] = s;
                fgVars.Rows[r].IsNode = true;
                fgVars.Rows[r].Node.Level = 1;

            }




            r = fgVars.Rows.Add().Index;
            r = fgVars.Rows.Add().Index;
            fgVars[r, 0] = "Individual Variables";
            fgVars.SetCellStyle(r, 0, "TopNode");
            fgVars.Rows[r].IsNode = true;
            fgVars.Rows[r].Node.Level = 0;

            for (i = 0; i < iVars.Count; i++)
            {
                r = fgVars.Rows.Add().Index;
                fgVars[r, 0] = iVars[i];

                string s = iUsed[i][0];
                for (j = 1; j < iUsed[i].Count; j++)
                    s += ", " + iUsed[i][j];

                fgVars[r, 1] = s;
                fgVars.Rows[r].IsNode = true;
                fgVars.Rows[r].Node.Level = 1;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 1; i < fgPops.Rows.Count; i++)
                m_Model.DataSet.Populations[i - 1].Name = fgPops[i, 0].ToString();

            frmStepOrder frm = new frmStepOrder(m_Model);
            frm.ShowDialog();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
            // Bob -- there was a "Back" button, but it didn't invoke anything and it messed up the project because it didn't clean up the old Model settings before adding them on again
            // so I just swapped the Back button for a Quit button, as on other screens
        }

//        bool leaving = false;
        private void frmDataSet_FormClosing(object sender, FormClosingEventArgs e)
        {
//            if (leaving) return;
            if (Program.isExiting) return;
            
            if (MessageBox.Show("You cannot back up from this window to change the project model specification on the previous window. Do you want to exit MMM?", "Notice!", MessageBoxButtons.YesNo)
                == DialogResult.Yes)
            {
//                leaving = true;
                Program.isExiting = true;
                Application.Exit();
            }
            else e.Cancel = true;
        }

        private void frmDataSet_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("DataSet");
        }

    }
}