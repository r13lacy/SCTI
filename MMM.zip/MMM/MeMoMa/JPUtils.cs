using System;
using System.Collections.Generic;

using System.IO;

namespace MeMoMa
{
    public class JPUtils
    {
        public static bool WriteListToFile(string fileName, List<string> list)
        {
            try
            {
                using (StreamWriter r = new StreamWriter(fileName))
                {
                    r.AutoFlush = true;

                    for (int i = 0; i < list.Count; i++)
                        r.WriteLine(list[i]);

                    r.Close(); 
                }

                return true;
            }
            catch
            {
                return false;
            }

        }
        public static List<string> ReadFileToList(string fileName)
        {
            return ReadFileToList(fileName, false);
        }

        public static List<string> ReadFileToList(string fileName, bool trim)
        {
            List<string> arrText = new List<string>();
            string sLine = "";

            using (StreamReader objReader = new StreamReader(fileName))
            {
                while (sLine != null)
                {
                    sLine = objReader.ReadLine();
                    if (sLine != null)
                    {
                        if (trim)
                            arrText.Add(sLine.Trim());
                        else
                            arrText.Add(sLine);
                    }
                }
                objReader.Close();
            }
            
            return arrText; // note: Jonathan had the return within the using {}
            
        }

        public static Type stringToType(string ssType)
        {
            Type tt = typeof(object);
            if (ssType == "double" || ssType == "System.Double") tt = typeof(double);
            else if (ssType == "string" || ssType == "System.String") tt = typeof(string);
            else if (ssType == "int" || ssType == "System.Int32") tt = typeof(int);
            else if (ssType == "decimal" || ssType == "System.Decimal") tt = typeof(decimal);
            else if (ssType == "short" || ssType == "System.Int16") tt = typeof(short);
            else if (ssType == "long" || ssType == "System.Int64") tt = typeof(long);
            else if (ssType == "uint" || ssType == "System.UInt32") tt = typeof(uint);
            else if (ssType == "ushort" || ssType == "System.UInt16") tt = typeof(ushort);
            else if (ssType == "ulong" || ssType == "System.UInt64") tt = typeof(ulong);
            else if (ssType == "bool" || ssType == "System.Boolean") tt = typeof(bool);
            else if (ssType == "byte" || ssType == "System.Byte") tt = typeof(byte);
            else if (ssType == "sbyte" || ssType == "System.SByte") tt = typeof(sbyte);
            else if (ssType == "float" || ssType == "single" || ssType == "System.Single") tt = typeof(float);
            else if (ssType == "DateTime" || ssType == "System.DateTime") tt = typeof(DateTime);

            return tt;
        }
    }
}
