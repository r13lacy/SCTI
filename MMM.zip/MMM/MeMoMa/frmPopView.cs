using System;
using System.Collections.Generic;
using System.Windows.Forms;

using MMMCore;

namespace MeMoMa
{
    public partial class frmPopView : Form
    {
        public bool UpdatePopulation = false;

        private MPopulation m_Population = null;

        private List<MIndividual> changeInd = new List<MIndividual>();
        private List<int> changeVarIndex = new List<int>();
        private List<string> changeBackTo = new List<string>();

        private MDataSet dataSet;
        private int popIndex;
        

        public frmPopView(MDataSet ds, MPopulation pop, int populationIndex)
        {
            InitializeComponent();

            m_Population = pop;
            dataSet = ds;
            popIndex = populationIndex;

            UpdatePopTable();


        }

        private void UpdatePopTable()
        {
            this.Text = "Population '" + m_Population.Name + "'";

            int i, j, k;

            string s = "Pop Vars: ";
            if (m_Population.Vars.Count > 0)
            {
                s += m_Population.VarNames[0] + " = " + m_Population.Vars[0];

                for (i = 1; i < m_Population.VarNames.Count; i++)
                    s += "; " + m_Population.VarNames[i] + m_Population.Vars[i];
            }
            lblVars.Text = s;

            //load m_Populationulation

            fgPop.Cols.Count = 0;
            fgPop.Rows.Count = m_Population.IndList.Count + 1;

            List<string> cols = new List<string>();

            if (m_Population.IndList.Count > 0)
            {
                for (i = 0; i < m_Population.IndList.Count; i++)
                {
                    for (j = 0; j < m_Population.IndVarNames.Count; j++)
                    {
                        k = cols.IndexOf(m_Population.IndVarNames[j].ToUpper());

                        if (k < 0) //didn't find it, need to add the column
                        {
                            cols.Add(m_Population.IndVarNames[j].ToUpper());
                            fgPop.Cols.Add();
                            fgPop[0, fgPop.Cols.Count - 1] = cols[cols.Count - 1];
                            k = cols.Count - 1;
                        }


                        fgPop[i + 1, k] = m_Population.IndList[i].Vars[j].ToString();
                    }
                }

                //now add one more col, make it invisible, and add the individual obj to the table.
                fgPop.Cols.Add();
                fgPop.Cols[fgPop.Cols.Count - 1].Visible = false;

                for (i = 0; i < m_Population.IndList.Count; i++)
                    fgPop[i + 1, fgPop.Cols.Count - 1] = m_Population.IndList[i];
            }


        }

        private void fgPop_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            //update the individual data
            string val = fgPop[fgPop.Row, fgPop.Col].ToString();
            string name = fgPop[0, fgPop.Col].ToString();

            MIndividual ind = (MIndividual)fgPop[fgPop.Row, fgPop.Cols.Count - 1];
            MPopulation pop = ind.MPop;

            //get var index

            int i = 0;
            while (i < pop.IndVarNames.Count && pop.IndVarNames[i].ToUpper() != name)
                i++;

            if (i < pop.IndVarNames.Count)
            {
                changeInd.Add(ind);
                changeVarIndex.Add(i);
                changeBackTo.Add(ind.Vars[i]);

                ind.Vars[i] = val;

            }
            
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void btnReset_Click(object sender, EventArgs e)
        {
            if (changeInd.Count > 0)
            {
                for (int i = changeInd.Count - 1; i >= 0; i--)
                    changeInd[i].Vars[changeVarIndex[i]] = changeBackTo[i];

                changeInd.Clear();
                changeVarIndex.Clear();
                changeBackTo.Clear();

                UpdatePopTable();
            }

        }

        private void btnWriteToFile_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "Text File (*.txt)|*.txt";

            if (dlg.ShowDialog() == DialogResult.OK)
                dataSet.WritePopulationFile(dlg.FileName, popIndex);
        }

        private void frmPopView_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("PopView");
        }

    }
}