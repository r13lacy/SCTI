using System;
using System.Collections.Generic;
using System.Text;

using System.Xml;
using System.Xml.XPath;

using MMMCore;

namespace MeMoMa
{
    public class MAppInfector : MApp
    {

        private List<MVariable> GlobalVariables = new List<MVariable>();
        private List<MVariable> PopulationVariables = new List<MVariable>();
        private List<MVariable> IndividualVariables = new List<MVariable>();

        private string ProjectFile;

        private MMInfectorDLL.Meta Infector = null;

        private bool FirstRun = true;

        public int PopStartIndex, NumPops;

        private int AppIndex;

        private bool DoOutput;



        public MAppInfector()
        {
            IndividualVariables.Add(new MVariable("Index", typeof(int), "Index of the individual", false));
            IndividualVariables.Add(new MVariable("Age", typeof(int), "Age of the individual, in days", false));
            IndividualVariables.Add(new MVariable("Sex", typeof(int), "Sex of the individual", false));
            IndividualVariables.Add(new MVariable("Mom", typeof(int), "Dam of the individual", false));
            IndividualVariables.Add(new MVariable("TerritorySequence", typeof(int), "Territories this time step", false));
            IndividualVariables.Add(new MVariable("InsideGroup", typeof(int), "Inside groups part of", false));
            IndividualVariables.Add(new MVariable("OutsideGroup", typeof(int), "Outside groups part of", false));
            IndividualVariables.Add(new MVariable("DiseaseState", typeof(int), "Disease state of the individual (P/S/E/I/R)", false));
            IndividualVariables.Add(new MVariable("DaysInState", typeof(int), "Number of days the individual has been in this state", false));
            IndividualVariables.Add(new MVariable("IsVaccinated", typeof(int), "Whether or not the individual has been vaccinated", false));

            GlobalVariables.Add(new MVariable("TerritoryeExposureProbs", typeof(string), "Exposure likelihood by territory", false));
        }

        public void SetDoOutput(bool output) { DoOutput = output; }
        public bool GetDoOutput() { return DoOutput; }

        public override string ToString()
        {
            return GetName() + " - " + GetDescription();
        }





        //INHERITED FROM MApp

        // Bob -- in case needed
        private int appStepCount;
        public void SetAppStepCount(int val) { appStepCount = val; }
        public int GetAppStepCount() { return appStepCount; }

        public string GetName()
        {
            return "Infector";
        }

        public string GetDescription()
        {
            return "Lion Infection Model Helper";
        }

        public string GetProjectFile()
        {
            return ProjectFile;
        }

        public void SetProjectFile(string fileName)
        {
            ProjectFile = fileName;
        }

        public List<MVariable> GetGlobalVariables()
        {
            return GlobalVariables;
        }

        public List<MVariable> GetPopulationVariables()
        {
            return PopulationVariables;
        }

        public List<MVariable> GetIndividualVariables()
        {
            return IndividualVariables;
        }

        public bool DoTurn(MDataSet dataSet, int numTimeSteps, int iteration, int year)
        {
            //INFECTOR should NOT check if has outbreak vars and add them.  if has no outbreak vars, skip it

            

            //make sure pop has individual vars
            //for (int j = 0; j < dataSet.Populations[PopStartIndex].IndList.Count; j++)
            //{
            //    for (int k = 0; k < IndividualVariables.Count; k++)
            //    {

            //        if (dataSet.Populations[PopStartIndex].IndList[j].VarNames.IndexOf(IndividualVariables[k].Name) < 0)
            //        {
            //            dataSet.Populations[PopStartIndex].IndList[j].VarNames.Add(IndividualVariables[k].Name);
            //            dataSet.Populations[PopStartIndex].IndList[j].Vars.Add("-1");
            //            dataSet.Populations[PopStartIndex].IndList[j].VarTypes.Add(IndividualVariables[k].VariableType);
            //        }
            //    }
            //}



            if (FirstRun)
            {
                Infector = new MMInfectorDLL.Meta();

                if (!Infector.Initialize(dataSet.Populations[PopStartIndex], ProjectFile))
                    return false;

                FirstRun = false;


            }

            //check if extinct, if so, no Infector!
            if (dataSet.Populations[PopStartIndex].IndList.Count == 0)
                return true;

            string tep = Infector.GetTerritoryExposureProbs();

            if (tep != "")
            {

                //read in new territory exposure probs
                int index = dataSet.VarNames.IndexOf("TerritoryeExposureProbs");
                if (index < 0)
                {
                    dataSet.VarNames.Add("TerritoryeExposureProbs");
                    dataSet.Vars.Add("");
                    dataSet.VarTypes.Add(typeof(string));
                    index = dataSet.Vars.Count - 1;
                }

                if (dataSet.Vars[index] != "")
                    Infector.SetTerritoryExposureProbs(dataSet.Vars[index]);

                if (Infector.Simulate(dataSet.Populations[PopStartIndex], year, numTimeSteps, iteration))
                {
                    //write backout territory exposure probs
                    dataSet.Vars[index] = Infector.GetTerritoryExposureProbs();

                    return true;
                }
                else
                    return false;
            }
            else
            {
                return Infector.Simulate(dataSet.Populations[PopStartIndex], year, numTimeSteps, iteration);
            }

        }

        public bool WriteResults()
        {
            return Infector.CloseDLL();

        }

        public int GetAppIndex()
        {
            return AppIndex;
        }

        public void SetAppIndex(int index)
        {
            AppIndex = index;
        }

        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Infector");
            iNode.AppendChild(appNode);

            XmlElement n = doc.CreateElement("ProjectFile");
            n.InnerText = ProjectFile.Substring(ProjectFile.LastIndexOf("\\") + 1);
            appNode.AppendChild(n);

            return true;
        }

        public bool ToXMLShort(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Infector");
            appNode.InnerText = AppIndex.ToString();
            iNode.AppendChild(appNode);

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("ProjectFile");
            if (iter.MoveNext())
                ProjectFile = folderLocation + "\\" + iter.Current.Value;

            return true;
        }

    }
}
