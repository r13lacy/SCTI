using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.XPath;

using vortex10lib;

using System.Windows.Forms;
using MMMCore;

namespace MeMoMa
{

    public class MAppVortex : MSystemApp
    {
        vortex10lib.v10Project V = null;

        private List<MApp> m_SubModels = new List<MApp>();

        private int AppIndex;

        private string ProjectFile;

        public int ScenarioIndex;
        public int curYear = -1;
        public int curIter = 0;

        public int StartingPopIndex = 0;
        public int NumPops = 0;

        public string ProjectName;
        public string ScenarioName;

        public int NumYears, numIterations;

        private List<MVariable> GlobalVariables = new List<MVariable>();
        private List<MVariable> PopulationVariables = new List<MVariable>();
        private List<MVariable> IndividualVariables = new List<MVariable>();

        public MAppVortex()
        {
            IndividualVariables.Add(new MVariable("Name", typeof(string), "Individual's ID", false));
            IndividualVariables.Add(new MVariable("Index", typeof(string), "Individual's Index internal to Vortex", false));
            IndividualVariables.Add(new MVariable("Age", typeof(string), "Age of the individual, in days", false));
            IndividualVariables.Add(new MVariable("Sex", typeof(string), "Sex of the individual (M/F)", false));
            IndividualVariables.Add(new MVariable("Alive", typeof(string), "Whether or not the individual is alive (M/F)", false));
            //IndividualVariables.Add(new MVariable("Dam", typeof(string), "Dam of the animal", false));
            //IndividualVariables.Add(new MVariable("Sire", typeof(string), "Sire of the animal", false));
        }

        public List<MApp> SubModels() { return m_SubModels; }

        public override string ToString()
        {
            return GetName() + " - " + GetDescription();
        }

        private int appStepCount;
        public void SetAppStepCount(int val) { appStepCount = val; }
        public int GetAppStepCount() { return appStepCount; }

        public bool WriteResults()
        {
            return V.CloseDLL();

        }

        //INHERITED FROM MApp
        public string GetName()
        {
            return "Vortex";
        }

        public string GetDescription()
        {
            return "Stochastic Population Viability Assessment Model";
        }


        public string GetProjectFile()
        {
            return ProjectFile;
        }

        public void SetProjectFile(string fileName)
        {
            ProjectFile = fileName;
        }

        public List<MVariable> GetGlobalVariables()
        {
            return GlobalVariables;
        }

        public List<MVariable> GetPopulationVariables()
        {
            return PopulationVariables;
        }

        public List<MVariable> GetIndividualVariables()
        {
            return IndividualVariables;
        }

        public int GetScenarioIndex() { return ScenarioIndex; }
        public string GetProjectName() { return ProjectName; }
        public int GetStartingPopIndex() { return StartingPopIndex; }
        public void SetStartingPopIndex(int val) { StartingPopIndex = val; }
        public void SetNumPops(int val) { NumPops = val; }
        public int GetNumPops() { return NumPops; }
        public void SetNumYears(int val) { NumYears = val; }
        public void SetNumIter(int val) { numIterations = val; }

        public string GetScenarioName() { return ScenarioName; }
        public void SetScenarioIndex(int val) { ScenarioIndex = val; }

        public bool Init(MDataSet dataSet, int totalTimeStepsToRun)
        {
            try
            {
                V = new v10Project(ProjectFile, false);
            }
            catch
            {
                return false;
            }

            int dex = V.scenarioNames.IndexOf(ScenarioName);
            if (dex != ScenarioIndex)
            {
                if (MessageBox.Show("Vortex Scenario name does not match index. Do you want to reset the index?", "Vortex model warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    ScenarioIndex = dex;
            }

            bool a = V.Initialize(ProjectFile, ScenarioIndex, totalTimeStepsToRun, numIterations);

            return a;
        }

        public bool DoYear0(MDataSet dataSet, int iteration)
        {
            
            if (V.MMVortexYear0(dataSet, StartingPopIndex, iteration))
            {
                //V should have sent back the populations at this point

                curYear = 0;

                return true;
            }
            else
            {
                MessageBox.Show("Year0 Failed.");
                return false;
            }

        }

        public bool DoTurn(MDataSet dataSet, int numTimeSteps, int iteration, int year)
        {
            int i;

            for (i = 0; i < numTimeSteps; i++)
            {
                if (!V.Simulate(dataSet, StartingPopIndex, iteration, curYear++))
                    return false;
            }
            
            return true;
        }


        public int GetAppIndex()
        {
            return AppIndex;
        }

        public void SetAppIndex(int index)
        {
            AppIndex = index;
        }



        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Vortex");
            iNode.AppendChild(appNode);

            XmlElement n = doc.CreateElement("ProjectFile");
            n.InnerText = ProjectFile;
            appNode.AppendChild(n);

            n = doc.CreateElement("ScenarioIndex");
            n.InnerText = ScenarioIndex.ToString();
            appNode.AppendChild(n);

            n = doc.CreateElement("ProjectName");
            n.InnerText = ProjectName;
            appNode.AppendChild(n);

            n = doc.CreateElement("ScenarioName");
            n.InnerText = ScenarioName;
            appNode.AppendChild(n);

            n = doc.CreateElement("SubApps");
            appNode.AppendChild(n);

            for (int i = 0; i < m_SubModels.Count; i++)
                m_SubModels[i].ToXML(n, doc);

            return true;
        }



        public bool ToXMLShort(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("Vortex");
            appNode.InnerText = AppIndex.ToString();
            iNode.AppendChild(appNode);

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("ProjectFile");
            if (iter.MoveNext())
            {
                ProjectFile = iter.Current.Value;
                if(!ProjectFile.Contains("\\")) ProjectFile = folderLocation + "\\" + ProjectFile;
            }

            iter = n.Select("ScenarioIndex");
            if (iter.MoveNext())
                ScenarioIndex = Convert.ToInt32(iter.Current.Value);

            iter = n.Select("ProjectName");
            if (iter.MoveNext())
                ProjectName = iter.Current.Value;

            iter = n.Select("ScenarioName");
            if (iter.MoveNext())
            {
                ScenarioName = iter.Current.Value;
            }

            iter = n.Select("SubApps");

            if (iter.MoveNext())
            {
                iter = iter.Current.Clone().SelectChildren(XPathNodeType.All);

                while (iter.MoveNext())
                {
                    //TEMP -- make a function to link names with apps
                    if (iter.Current.Name == "Spatial")
                    {
                        MAppSpatial s = new MAppSpatial();
                        s.LoadXML(iter.Current.Clone(), folderLocation);
                        m_SubModels.Add(s);
                    }
                    else if (iter.Current.Name == "PathHistory")
                    {
                        MAppPathHistory ph = new MAppPathHistory();
                        ph.LoadXML(iter.Current.Clone(), folderLocation);
                        m_SubModels.Add(ph);
                    }
                    else if (iter.Current.Name == "Outbreak2")
                    {
                        MAppOutbreak2 ob2 = new MAppOutbreak2();
                        ob2.LoadXML(iter.Current.Clone(), folderLocation);
                        m_SubModels.Add(ob2);
                    }
                    else if (iter.Current.Name == "MMM-RLink")
                    {
                        MAppRLink rLink = new MAppRLink();
                        rLink.LoadXML(iter.Current.Clone(), folderLocation);
                        m_SubModels.Add(rLink);
                    }
                    //else if (iter.Current.Name == "Becky")
                    //{
                    //    MAppBecky b = new MAppBecky();
                    //    b.LoadXML(iter.Current.Clone(), folderLocation);
                    //    m_SubModels.Add(b);
                    //}
                    else if (iter.Current.Name == "External")
                    {
                        MAppExternal b = new MAppExternal();
                        b.LoadXML(iter.Current.Clone(), folderLocation);
                        m_SubModels.Add(b);
                    }

                }

            }

            return true;
        }

    }
}
