namespace MeMoMa
{
    partial class frmModelSelection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnApps = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnRemoveModel = new System.Windows.Forms.Button();
            this.btnAddModifierModel = new System.Windows.Forms.Button();
            this.btnAddSystemModel = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.fgModel = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.pnlBottom.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgModel)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            this.pnlBottom.Controls.Add(this.btnQuit);
            this.pnlBottom.Controls.Add(this.btnApps);
            this.pnlBottom.Controls.Add(this.btnNext);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 458);
            this.pnlBottom.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1212, 43);
            this.pnlBottom.TabIndex = 1;
            this.pnlBottom.Layout += new System.Windows.Forms.LayoutEventHandler(this.pnlBottom_Layout);
            // 
            // btnQuit
            // 
            this.btnQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnQuit.Location = new System.Drawing.Point(669, 8);
            this.btnQuit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(106, 28);
            this.btnQuit.TabIndex = 6;
            this.btnQuit.Text = "Quit MMM";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnApps
            // 
            this.btnApps.Location = new System.Drawing.Point(20, 7);
            this.btnApps.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnApps.Name = "btnApps";
            this.btnApps.Size = new System.Drawing.Size(160, 28);
            this.btnApps.TabIndex = 1;
            this.btnApps.Text = "Manage Apps";
            this.btnApps.UseVisualStyleBackColor = true;
            this.btnApps.Visible = false;
            this.btnApps.Click += new System.EventHandler(this.btnApps_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(783, 7);
            this.btnNext.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(103, 28);
            this.btnNext.TabIndex = 0;
            this.btnNext.Text = "Next >>";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnRemoveModel);
            this.panel1.Controls.Add(this.btnAddModifierModel);
            this.panel1.Controls.Add(this.btnAddSystemModel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 415);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1212, 43);
            this.panel1.TabIndex = 2;
            // 
            // btnRemoveModel
            // 
            this.btnRemoveModel.Location = new System.Drawing.Point(365, 7);
            this.btnRemoveModel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRemoveModel.Name = "btnRemoveModel";
            this.btnRemoveModel.Size = new System.Drawing.Size(144, 28);
            this.btnRemoveModel.TabIndex = 4;
            this.btnRemoveModel.Text = "Remove Model";
            this.btnRemoveModel.UseVisualStyleBackColor = true;
            this.btnRemoveModel.Click += new System.EventHandler(this.btnRemoveModel_Click);
            // 
            // btnAddModifierModel
            // 
            this.btnAddModifierModel.Location = new System.Drawing.Point(168, 7);
            this.btnAddModifierModel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAddModifierModel.Name = "btnAddModifierModel";
            this.btnAddModifierModel.Size = new System.Drawing.Size(144, 28);
            this.btnAddModifierModel.TabIndex = 3;
            this.btnAddModifierModel.Text = "Add Modifier Model";
            this.btnAddModifierModel.UseVisualStyleBackColor = true;
            this.btnAddModifierModel.Click += new System.EventHandler(this.btnAddModifierModel_Click);
            // 
            // btnAddSystemModel
            // 
            this.btnAddSystemModel.Location = new System.Drawing.Point(16, 7);
            this.btnAddSystemModel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAddSystemModel.Name = "btnAddSystemModel";
            this.btnAddSystemModel.Size = new System.Drawing.Size(144, 28);
            this.btnAddSystemModel.TabIndex = 2;
            this.btnAddSystemModel.Text = "Add System Model";
            this.btnAddSystemModel.UseVisualStyleBackColor = true;
            this.btnAddSystemModel.Click += new System.EventHandler(this.btnAddSystemModel_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1212, 43);
            this.panel2.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 11);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(247, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "Population/ System Models";
            // 
            // fgModel
            // 
            this.fgModel.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.fgModel.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.fgModel.ColumnInfo = "4,0,0,0,0,85,Columns:0{Width:153;Caption:\"Model\";}\t1{Width:276;Caption:\"Descripti" +
    "on\";}\t2{Width:298;Caption:\"Project File\";}\t3{Caption:\"Add\'l Info\";}\t";
            this.fgModel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fgModel.ExtendLastCol = true;
            this.fgModel.Location = new System.Drawing.Point(0, 43);
            this.fgModel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fgModel.Name = "fgModel";
            this.fgModel.Rows.Count = 2;
            this.fgModel.Rows.DefaultSize = 17;
            this.fgModel.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Cell;
            this.fgModel.Size = new System.Drawing.Size(1212, 372);
            this.fgModel.TabIndex = 4;
            this.fgModel.Tree.Column = 0;
            this.fgModel.BeforeEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgModel_BeforeEdit);
            this.fgModel.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgModel_AfterEdit);
            this.fgModel.CellButtonClick += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgModel_CellButtonClick);
            // 
            // frmModelSelection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1212, 501);
            this.Controls.Add(this.fgModel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlBottom);
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmModelSelection";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Set System Level and Modifier Programs";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmModelSelection_KeyUp);
            this.pnlBottom.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgModel)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnApps;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAddSystemModel;
        private System.Windows.Forms.Button btnRemoveModel;
        private System.Windows.Forms.Button btnAddModifierModel;
        private C1.Win.C1FlexGrid.C1FlexGrid fgModel;
        private System.Windows.Forms.Button btnQuit;
    }
}