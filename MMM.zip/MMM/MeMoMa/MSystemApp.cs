using System.Collections.Generic;
using MMMCore;

namespace MeMoMa
{
    public interface MSystemApp : MApp
    {
        bool Init(MDataSet dataSet, int totalTimeStepsToRun);
        List<MApp> SubModels();

        int GetStartingPopIndex();
        void SetStartingPopIndex(int val);
        void SetNumPops(int val);
        int GetNumPops();
        string GetProjectName();
        int GetScenarioIndex();
        void SetScenarioIndex(int val);
        string GetScenarioName();
        void SetNumYears(int val);
        void SetNumIter(int val);

    }
}
