namespace MeMoMa
{
    partial class frmSimulate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSimulate));
            this.pnlTop = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnPrintGraph = new System.Windows.Forms.Button();
            this.btnGraphSave = new System.Windows.Forms.Button();
            this.prgSim = new System.Windows.Forms.ProgressBar();
            this.btnStopSimulation = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnSimulate = new System.Windows.Forms.Button();
            this.chartSim = new C1.Win.C1Chart.C1Chart();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSpeed = new System.Windows.Forms.Label();
            this.pnlTop.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartSim)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Margin = new System.Windows.Forms.Padding(4);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(900, 41);
            this.pnlTop.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(405, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Displaying population size over time for each iteration.";
            // 
            // pnlBottom
            // 
            this.pnlBottom.Controls.Add(this.btnBack);
            this.pnlBottom.Controls.Add(this.btnPrintGraph);
            this.pnlBottom.Controls.Add(this.btnGraphSave);
            this.pnlBottom.Controls.Add(this.prgSim);
            this.pnlBottom.Controls.Add(this.btnStopSimulation);
            this.pnlBottom.Controls.Add(this.btnQuit);
            this.pnlBottom.Controls.Add(this.btnSimulate);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 462);
            this.pnlBottom.Margin = new System.Windows.Forms.Padding(4);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(900, 49);
            this.pnlBottom.TabIndex = 1;
            this.pnlBottom.Layout += new System.Windows.Forms.LayoutEventHandler(this.pnlBottom_Layout);
            // 
            // btnBack
            // 
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnBack.Location = new System.Drawing.Point(145, 8);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(76, 30);
            this.btnBack.TabIndex = 20;
            this.btnBack.Text = "<< Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnPrintGraph
            // 
            this.btnPrintGraph.Location = new System.Drawing.Point(269, 9);
            this.btnPrintGraph.Margin = new System.Windows.Forms.Padding(4);
            this.btnPrintGraph.Name = "btnPrintGraph";
            this.btnPrintGraph.Size = new System.Drawing.Size(125, 31);
            this.btnPrintGraph.TabIndex = 5;
            this.btnPrintGraph.Text = "Print Graph";
            this.btnPrintGraph.UseVisualStyleBackColor = true;
            this.btnPrintGraph.Visible = false;
            this.btnPrintGraph.Click += new System.EventHandler(this.btnPrintGraph_Click);
            // 
            // btnGraphSave
            // 
            this.btnGraphSave.Location = new System.Drawing.Point(501, 9);
            this.btnGraphSave.Margin = new System.Windows.Forms.Padding(4);
            this.btnGraphSave.Name = "btnGraphSave";
            this.btnGraphSave.Size = new System.Drawing.Size(199, 31);
            this.btnGraphSave.TabIndex = 4;
            this.btnGraphSave.Text = "Save Graph and Data";
            this.btnGraphSave.UseVisualStyleBackColor = true;
            this.btnGraphSave.Visible = false;
            this.btnGraphSave.Click += new System.EventHandler(this.btnGraphSave_Click);
            // 
            // prgSim
            // 
            this.prgSim.Location = new System.Drawing.Point(269, 9);
            this.prgSim.Margin = new System.Windows.Forms.Padding(4);
            this.prgSim.Name = "prgSim";
            this.prgSim.Size = new System.Drawing.Size(491, 30);
            this.prgSim.TabIndex = 3;
            // 
            // btnStopSimulation
            // 
            this.btnStopSimulation.Location = new System.Drawing.Point(120, 7);
            this.btnStopSimulation.Margin = new System.Windows.Forms.Padding(4);
            this.btnStopSimulation.Name = "btnStopSimulation";
            this.btnStopSimulation.Size = new System.Drawing.Size(125, 31);
            this.btnStopSimulation.TabIndex = 2;
            this.btnStopSimulation.Text = "Stop Simulation";
            this.btnStopSimulation.UseVisualStyleBackColor = true;
            this.btnStopSimulation.Visible = false;
            this.btnStopSimulation.Click += new System.EventHandler(this.btnStopSimulation_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(768, 7);
            this.btnQuit.Margin = new System.Windows.Forms.Padding(4);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(116, 31);
            this.btnQuit.TabIndex = 1;
            this.btnQuit.Text = "Quit MMM";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnSimulate
            // 
            this.btnSimulate.Location = new System.Drawing.Point(16, 7);
            this.btnSimulate.Margin = new System.Windows.Forms.Padding(4);
            this.btnSimulate.Name = "btnSimulate";
            this.btnSimulate.Size = new System.Drawing.Size(96, 31);
            this.btnSimulate.TabIndex = 0;
            this.btnSimulate.Text = "Simulate!";
            this.btnSimulate.UseVisualStyleBackColor = true;
            this.btnSimulate.Click += new System.EventHandler(this.btnSimulate_Click);
            // 
            // chartSim
            // 
            this.chartSim.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartSim.Location = new System.Drawing.Point(0, 41);
            this.chartSim.Margin = new System.Windows.Forms.Padding(4);
            this.chartSim.Name = "chartSim";
            this.chartSim.PropBag = resources.GetString("chartSim.PropBag");
            this.chartSim.Size = new System.Drawing.Size(900, 382);
            this.chartSim.TabIndex = 2;
            this.chartSim.DoubleClick += new System.EventHandler(this.dblClick_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblSpeed);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 423);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(900, 39);
            this.panel1.TabIndex = 3;
            // 
            // lblSpeed
            // 
            this.lblSpeed.AutoSize = true;
            this.lblSpeed.Location = new System.Drawing.Point(16, 12);
            this.lblSpeed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSpeed.Name = "lblSpeed";
            this.lblSpeed.Size = new System.Drawing.Size(46, 17);
            this.lblSpeed.TabIndex = 0;
            this.lblSpeed.Text = "label2";
            // 
            // frmSimulate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 511);
            this.Controls.Add(this.chartSim);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlTop);
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimizeBox = false;
            this.Name = "frmSimulate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Simulate";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSimulate_FormClosing);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmSimulate_KeyUp);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartSim)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Panel pnlBottom;
        private C1.Win.C1Chart.C1Chart chartSim;
        private System.Windows.Forms.Button btnSimulate;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Button btnStopSimulation;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar prgSim;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSpeed;
        private System.Windows.Forms.Button btnGraphSave;
        private System.Windows.Forms.Button btnPrintGraph;
        private System.Windows.Forms.Button btnBack;
    }
}