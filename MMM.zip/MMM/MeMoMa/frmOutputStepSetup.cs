using System;
using System.Windows.Forms;

namespace MeMoMa
{
    public partial class frmOutputStepSetup : Form
    {
        MModel m_Model = null;
        MModelStepOutput m_OutputStep = null;

        public frmOutputStepSetup(MModel model, MModelStepOutput step)
        {
            InitializeComponent();

            m_Model = model;
            m_OutputStep = step;

            txtFile.Text = step.FileName;
            checkYandR.Checked = step.AddYandR;

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            m_OutputStep.FileName = txtFile.Text.Trim();
            m_OutputStep.AddYandR = checkYandR.Checked;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "Text Files (*.txt)|*.txt";

            if (dlg.ShowDialog() == DialogResult.OK)
                txtFile.Text = dlg.FileName;
        }

        private void frmOutputStepSetup_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("OutputStepSetup");
        }
    }
}