﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.XPath;
using MMMCore;
using RDotNet;
using System.IO;
using Google.Protobuf;
using System.Windows.Forms;
using RLink;


namespace MeMoMa
{
    class MAppRLink : MApp
    {
        private List<MVariable> GlobalVariables = new List<MVariable>();
        private List<MVariable> PopulationVariables = new List<MVariable>();
        private List<MVariable> IndividualVariables = new List<MVariable>();

        private int AppIndex;   // Not sure we need this
        private string ProjectFile;
        public string ProjectDir    // Need to make sure we're looking for/writing data to projectDir
        {
            get
            {
                if (ProjectFile != null)
                {
                    return ProjectFile.Substring(0, ProjectFile.LastIndexOf("\\"));
                }
                else
                    return Application.LocalUserAppDataPath;
            }
        }

        private int AppStepCount;
        private bool firstTurn = true;
        public int TotalIterations { get; private set; }
        private REngine _myEngine;
        private MMRLink _myRLink = new MMRLink();

        public MAppRLink()
        {
            // Constructor doesn't need to do anything
        }

        public bool DoTurn(MDataSet dataSet, int numTimeSteps, int iteration, int year)
        {
            // We might eventually check the year or timestep or whatever to see if we're supposed to run at this turn
            // For now we're just running once every year

            // Get the current set of data and serialize it
            //_myDataSet = dataSet;
            SerializeData(dataSet);

            // Check the iteration number to see which iteration we're on
            // Initialize the engine on the 0th iteration and close it when all iterations are finished
            //if (!(year == 0 && iteration == 0)) firstTurn = false;
            if (firstTurn)
            {
               _myEngine = _myRLink.Initialize(ProjectFile);
            }

            // Run the r script
            _myRLink.RunRScript(_myEngine);
            DeSerializeData(dataSet);
            firstTurn = false;
            return true;

        }

        public List<MVariable> GetGlobalVariables()
        {
            return GlobalVariables;
        }

        public List<MVariable> GetPopulationVariables()
        {
            return PopulationVariables;
        }

        public List<MVariable> GetIndividualVariables()
        {
            return IndividualVariables;
        }

        public void SetPopulationVariables(List<MVariable> vlist)
        {
            PopulationVariables = vlist;
        }

        public void SetIndividualVariables(List<MVariable> vlist)
        {
            IndividualVariables = vlist;
        }

        public int GetAppIndex()
        {
            return AppIndex;
        }

        public void SetAppIndex(int index)
        {
            AppIndex = index;
        }

        public int GetAppStepCount()
        {
            return AppStepCount;
        }

        public void SetAppStepCount(int val)
        {
            AppStepCount = val;
        }

        public string GetDescription()
        {
            return "Runs an R script to modify MMM variables";
        }

        public string GetName()
        {
            return "MMM-R Link";
        }

        public string GetProjectFile()
        {
            return ProjectFile;
        }

        public void SetProjectFile(string fileName)
        {
            ProjectFile = fileName;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("ProjectFile");
            if (iter.MoveNext())
            {
                ProjectFile = iter.Current.Value;
                if (!ProjectFile.Contains("\\")) ProjectFile = folderLocation + "\\" + ProjectFile;
            }
            return true;
        }


        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("MMM-RLink");
            iNode.AppendChild(appNode);

            XmlElement n = doc.CreateElement("ProjectFile");
            n.InnerText = ProjectFile;
            appNode.AppendChild(n);

            return true;
        }

        public bool ToXMLShort(XmlElement iNode, XmlDocument doc)
        {
            XmlElement appNode = doc.CreateElement("MMM-RLink");
            appNode.InnerText = AppIndex.ToString();
            iNode.AppendChild(appNode);

            return true;
        }

        public bool WriteResults()
        {
            //_myRLink.CloseDLL(_myEngine);
            return true;
        }


        public void SerializeData(MDataSet dataSet)
        {
            // Serialize the data
            ProjMessage myProjMessage = new ProjMessage();
            for (int i = 0; i < dataSet.VarNames.Count; i++)
            {
                myProjMessage.GSVarNames.Add(dataSet.VarNames[i]);
                myProjMessage.GSVars.Add(dataSet.Vars[i].ToString());
            }
            for (int i = 0; i < dataSet.Populations.Count; i++)
            {
                PopMessage myPopMessage = new PopMessage();
                for (int j = 0; j < dataSet.Populations[i].Vars.Count; j++)
                {
                    myPopMessage.PopVars.Add(dataSet.Populations[i].Vars[j].ToString());
                    myPopMessage.PopVarNames.Add(dataSet.Populations[i].VarNames.ToString());
                }
                for (int j = 0; j < dataSet.Populations[i].IndVarNames.Count; j++)
                {
                    myPopMessage.IndivVarNames.Add(dataSet.Populations[i].IndVarNames[j]);
                }
                for (int j = 0; j < dataSet.Populations[i].IndList.Count; j++)
                {
                    IndivMessage myIndivMessage = new IndivMessage();
                    for (int k = 0; k < dataSet.Populations[i].IndList[j].Vars.Count; k++)
                    {
                        myIndivMessage.MyVars.Add(dataSet.Populations[i].IndList[j].Vars[k]);
                    }
                    myPopMessage.MyIndivs.Add(myIndivMessage);
                }
                myProjMessage.MyPops.Add(myPopMessage);
            }
            // Save the serialized data to the place where R expects to find it
            using (var writer = File.Create(ProjectDir + "\\tempData.dat"))
            {
                myProjMessage.WriteTo(writer);
            }
        }

        public void DeSerializeData(MDataSet MMsData)
        {
            // Read it from where R put it
            if (!File.Exists(ProjectDir + "\\tempRData.dat"))
            {
                MessageBox.Show("File " + ProjectDir + "\\tempRData.dat not found. Using data pre-R");
                // MAppRLink's _myDataSet reference is pointing to the MDataSet object set parameter from DoTurn()
                return;
            }

            byte[] input = File.ReadAllBytes(ProjectDir + "\\tempRData.dat");
            ProjMessage importThisProj;
            importThisProj = ProjMessage.Parser.ParseFrom(input);
            // Clear the input byte[]
            Array.Clear(input, 0, input.Length);


            // put the serialized data back into MDataSet 
            for (int i = 0; i < MMsData.Populations.Count; i++)
            {
                for (int j = 0; j < MMsData.Populations[i].Vars.Count; j++)
                {
                    MMsData.Populations[i].Vars[j] = importThisProj.MyPops[i].PopVars[j];
                }

                for (int k = 0; k < MMsData.Populations[i].IndList.Count; k++)
                {
                    for (int l = 0; l < MMsData.Populations[i].IndVarNames.Count; l++)
                    {
                        MMsData.Populations[i].IndList[k].Vars[l] = importThisProj.MyPops[i].MyIndivs[k].MyVars[l];

                    }
                }
            }
            // MMsData object is referenced by local var _myDataSet and MMDataSet parameter from DoTurn()
        }

    }
}
