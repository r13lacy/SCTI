using System;
using System.Collections.Generic;
using System.Windows.Forms;

using System.IO;

using MMMCore;

namespace MeMoMa
{
    public partial class frmModelSelection : Form
    {
        private string comboListSysModels, comboListSubModels;

        private MModel m_Model = new MModel();

        private List<MApp> m_Apps;
        private List<MApp> m_SystemApps;

        private List<string> m_AppNames = new List<string>();
        private List<string> m_SystemAppNames = new List<string>();

        private string m_appPath; // note m_appPath is userData

        public frmModelSelection(List<MApp> sysApps, List<MApp> apps, string appPath)
        {
            InitializeComponent();

            m_appPath = appPath;

            m_Model.DataSet = new MDataSet();

            m_SystemApps = sysApps;
            m_Apps = apps;

            int i;

            for (i = 0; i < m_SystemApps.Count; i++)
            {
                m_SystemAppNames.Add(m_SystemApps[i].GetName());
                comboListSysModels += "|" + m_SystemApps[i].GetName();
            }

            for (i = 0; i < m_Apps.Count; i++)
            {
                m_AppNames.Add(m_Apps[i].GetName());
                comboListSubModels += "|" + m_Apps[i].GetName();
            }

            fgModel.Cols.Count += 1;
            fgModel.Cols[fgModel.Cols.Count - 1].Visible = false;
            fgModel[1, 0] = "Choose a model";
            fgModel[1, fgModel.Cols.Count - 1] = "system";
            fgModel.Rows[1].IsNode = true;
            fgModel.Rows[1].Node.Level = 0;

        }


        private void fgModel_BeforeEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (e.Col == 0)
            {
                if (fgModel[e.Row, fgModel.Cols.Count - 1].ToString() == "system")
                    fgModel.ComboList = comboListSysModels;
                else
                    fgModel.ComboList = comboListSubModels;
            }
            else if (e.Col == 2)
            {
                if (fgModel[e.Row, 0].ToString() == "Choose a model")
                    e.Cancel = true;
                else
                    fgModel.ComboList = "...";
            }
            else
                e.Cancel = true;
        }

        private void fgModel_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (e.Col == 0)
            {
                if (fgModel[e.Row, fgModel.Cols.Count - 1].ToString() == "system")
                {
                    //keeping system models separate and as a special case for now in case there's anything else we want to do here
                    if (fgModel[e.Row, 0].ToString() == "Vortex")
                    {
                        fgModel[e.Row, 1] = new MAppVortex().GetDescription();
                        fgModel[e.Row, 2] = "Choose a Vortex project file";
                    }
                    if (fgModel[e.Row, 0].ToString() == "Outbreak")
                    {
                        fgModel[e.Row, 1] = new MAppOutbreak().GetDescription();
                        fgModel[e.Row, 2] = "Choose an Outbreak project file";
                    }
                    //else if (fgModel[e.Row, 0].ToString() == "SimSimba")
                    //{
                    //    fgModel[e.Row, 1] = new MAppSimSimba().GetDescription();
                    //    fgModel[e.Row, 2] = "Choose SimSimba project and pop spec files";
                    //}
                    else
                    {
                        //we can accommodate other models by using Reflection to get the app by name, then create a new instance of it.

                        int ai = m_SystemAppNames.IndexOf(fgModel[e.Row, 0].ToString());

                        if (ai >= 0)
                        {
                            fgModel[e.Row, 1] = m_SystemApps[ai].GetDescription();
                            fgModel[e.Row, 2] = "Choose a " + m_SystemApps[ai].GetName() + " project file";
                        }
                    }
                }
                else if (fgModel[e.Row, fgModel.Cols.Count - 1].ToString() == "sub")
                {
                    int ai = m_AppNames.IndexOf(fgModel[e.Row, 0].ToString());

                    if (ai >= 0)
                    {
                        fgModel[e.Row, 1] = m_Apps[ai].GetDescription();
                        fgModel[e.Row, 2] = "Choose a " + m_Apps[ai].GetName() + " project file";
                    }
                }
                fgModel.Col = 2;
            }

        }

        private void btnApps_Click(object sender, EventArgs e)
        {
            new frmModels(m_SystemApps, m_Apps).ShowDialog();

            //rewrite apps.l file

            StreamWriter w = new StreamWriter(m_appPath + "\\apps.l");

            for (int i = 0; i < m_Apps.Count; i++)
            {
                if (m_Apps[i].GetType() == typeof(MAppExternal))
                {
                    w.WriteLine(m_appPath + "\\" + ((MAppExternal)m_Apps[i]).GetName() + ".xml");
                    ((MAppExternal)m_Apps[i]).SaveToXML(m_appPath + "\\" + ((MAppExternal)m_Apps[i]).GetName() + ".xml");
                }
            }
            w.Close();

            //rewrite sysapps.l file

            w = new StreamWriter(m_appPath + "\\sysapps.l");

            for (int i = 0; i < m_SystemApps.Count; i++)
            {
                if (m_SystemApps[i].GetType() == typeof(MSystemAppExternal))
                {
                    w.WriteLine(m_appPath + "\\" + ((MSystemAppExternal)m_SystemApps[i]).GetName() + ".xml");
                    ((MSystemAppExternal)m_SystemApps[i]).SaveToXML(m_appPath + "\\" + ((MSystemAppExternal)m_SystemApps[i]).GetName() + ".xml");
                }
            }
            w.Close();
        }

        private void btnAddSystemModel_Click(object sender, EventArgs e)
        {
            fgModel.Rows.Count++;
            fgModel[fgModel.Rows.Count - 1, 0] = "Choose a model";
            fgModel[fgModel.Rows.Count - 1, fgModel.Cols.Count - 1] = "system";
            fgModel.Rows[fgModel.Rows.Count - 1].IsNode = true;
            fgModel.Rows[fgModel.Rows.Count - 1].Node.Level = 0;
        }

        private void btnAddModifierModel_Click(object sender, EventArgs e)
        {
            if (fgModel.Row < 1 || fgModel[fgModel.Row, 0].ToString() == "Choose a model")
            {
                MessageBox.Show("Please select a system model before adding a modifier model.");
                return;
            }

            //add to the last row still "owned" by the system model pertaining to the current row
            
            int r;

            if (fgModel.Row == fgModel.Rows.Count - 1) //if somehow they don't have a row selected, or the last row is selected
                r = fgModel.Rows.Add().Index;
            else
            {
                r = fgModel.FindRow("system", fgModel.Row + 1, fgModel.Cols.Count - 1, false);

                if (r < 0) //didn't find, just append!
                    r = fgModel.Rows.Add().Index;
                else //found it
                    fgModel.Rows.Insert(r);

            }

            fgModel[r, 0] = "Choose a model";
            fgModel[r, fgModel.Cols.Count - 1] = "sub";
            fgModel.Rows[r].IsNode = true;
            fgModel.Rows[r].Node.Level = 1;

        }

        private void btnRemoveModel_Click(object sender, EventArgs e)
        {
            if (fgModel.Row >= 1)
            {
                if (fgModel.Row == fgModel.Rows.Count - 1 || fgModel[fgModel.Row, fgModel.Cols.Count - 1].ToString() == "sub")
                    fgModel.Rows.Remove(fgModel.Row);
                else if (fgModel[fgModel.Row, fgModel.Cols.Count - 1].ToString() == "system") //is a system model, delete it and all of it's subs
                {
                    int r = fgModel.FindRow("system", fgModel.Row + 1, fgModel.Cols.Count - 1, false);

                    int delstart, delstop = fgModel.Row;

                    if (r < 0)
                        delstart = fgModel.Rows.Count - 1;
                    else
                        delstart = r - 1;

                    for (int i = delstart; i >= delstop; i--)
                        fgModel.Rows.Remove(i);
                }


            }
        }

        private int nscenes = 1; // so know if to ask for which scenario (with Outbreak)
//        private List<string> scNames = new List<string>();

        private void fgModel_CellButtonClick(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            string app = fgModel[e.Row, 0].ToString();

            OpenFileDialog dlg = new OpenFileDialog();

            //if (app == "SimSimba")
            //{
            //    frmSimSimbaProj frm = new frmSimSimbaProj();
            //    if (frm.ShowDialog() == DialogResult.OK)
            //    {
            //        if (File.Exists(frm.ProjFile))
            //            fgModel[e.Row, 2] = frm.ProjFile;

            //        if (File.Exists(frm.PopFile))
            //            fgModel[e.Row, 3] = frm.PopFile;
            //    }

            //}
            //else
            //{
                if (app == "Vortex")
                {
                    dlg.Filter = "Vortex Project Files (*.xml)|*.xml| (*.vpj)|*.vpj";
                }
                else if (app == "Outbreak")
                    dlg.Filter = "Outbreak Settings Files (*.xml)|*.xml"; 
                else if (app == "Spatial")
                    dlg.Filter = "Spatial Project Files (*.spj)|*.spj";
                else if (app == "PathHistory")
                    dlg.Filter = "PathHistory Project Files (*.phproj)|*.phproj";
                //else if (app == "Becky")
                //    dlg.Filter = "Becky Project Files (*.bek)|*.bek";

                if (dlg.ShowDialog() == DialogResult.OK)
                {

                    if (app == "Vortex")
                    {
                        vortex10lib.v10Project v = new vortex10lib.v10Project(dlg.FileName, false);

                        if (v.nscenes == 1)
                            fgModel[e.Row, 3] = v.name + ": Scene 1 (" + v.scenarioNames[0] + ")";
                        else
                        {

                            frmPicker frm = new frmPicker("Please select from one of the following scenarios identified in your Vortex project file to use in this model:", v.scenarioNames);

                            if (frm.ShowDialog() == DialogResult.OK)
                            {
                                fgModel[e.Row, 3] = v.name + ": Scene " + (frm.SelectedIndex + 1).ToString()
                                    + " (" + v.scenarioNames[frm.SelectedIndex] + ")";
                            }
                            else
                                return;
                        }
                    }

                    else if (app == "Outbreak")
                    {
                        Outbreak2.Outbreak2 o = new Outbreak2.Outbreak2(dlg.FileName, false);

                        if (o.nscenes > 1) 
                        {
                            nscenes = o.nscenes;
//                            o.ScenarioNames = new List<string>();
                            List<string> scNames = new List<string>();
                            for (int nsc = 0; nsc < nscenes; nsc++)
                            {
//                                o.ScenarioNames.Add(o.Oscenes[nsc].SceneName);
                                scNames.Add(o.Oscenes[nsc].SceneName);
                            }

                            frmPicker frm = new frmPicker("Please select from one of the following scenarios identified in your Outbreak project file to use in this model:", scNames);

                            if (frm.ShowDialog() == DialogResult.OK)
                            {
                                fgModel[e.Row, 3] = o.OName + ": Scene " + (frm.SelectedIndex + 1).ToString()
                                    + " (" + scNames[frm.SelectedIndex] + ")";
                            }
                            else
                                return;
                        }
                    }

                    fgModel[e.Row, 2] = dlg.FileName;
                }
//            }
        }

        private void pnlBottom_Layout(object sender, LayoutEventArgs e)
        {
            btnNext.Left = pnlBottom.Width - btnNext.Width - 8;
            btnQuit.Left = btnNext.Left - btnQuit.Width - 8;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            int i, j;

            //check that all systems don't = choose, and that all proj files have been selected
            for (i = 1; i < fgModel.Rows.Count; i++)
            {
                if (fgModel[i, 0].ToString() == "Choose a model" || fgModel[i, 2].ToString().StartsWith("Choose"))
                {
                    MessageBox.Show("Please make sure that for every row of the specification table you have selected a system and chosen a project file if needed.");
                    return;
                }
            }

            Cursor.Current = Cursors.WaitCursor;

            List<int> rsys = new List<int>(); //rows with system apps

            // added 13 dec 2015, so don't accumulate models if come back into form
            m_Model.SystemApps.Clear();
            MModel.MasterAppList.Clear();


            for (i = 1; i < fgModel.Rows.Count; i++)
                if (fgModel[i, fgModel.Cols.Count - 1].ToString() == "system")
                    rsys.Add(i);

            //TODO: for multipops, do we need to count pops in each sys model??

            for (i = 0; i < rsys.Count; i++)
            {
                MSystemApp ms = null;

                if (fgModel[rsys[i], 0].ToString() == "Vortex")
                {
                    MAppVortex v = new MAppVortex();

                    string[] s = fgModel[rsys[i], 3].ToString().Split(':');

                    v.ProjectName = s[0];

                    int stop = s[1].IndexOf('(');
                    v.ScenarioIndex = -1 + Convert.ToInt32(s[1].Substring("Scene ".Length, stop - "Scene ".Length));
                    v.ScenarioName = s[1].Substring(stop + 1, s[1].Length - stop - 2);
//                    v.SetProjectFile(fgModel[rsys[i], 2].ToString());

                    ms = v;

                }
                else if (fgModel[rsys[i], 0].ToString() == "Outbreak")
                {
                    MAppOutbreak ob = new MAppOutbreak();

//                    ob.ProjectName = s[0];
//                    ob.ScenarioNames = scNames;

                    // for multi-scene Outbreaks
                    if (nscenes > 1)
                    {
                        string[] s = fgModel[rsys[i], 3].ToString().Split(':');
                        ob.ProjectName = s[0];

                        int stop = s[1].IndexOf('(');
                        ob.ScenarioIndex = -1 + Convert.ToInt32(s[1].Substring("Scene ".Length, stop - "Scene ".Length));
                        ob.ScenarioName = s[1].Substring(stop + 1, s[1].Length - stop - 2);
                    }
                    else
                    {
                        string s = fgModel[rsys[i], 2].ToString();
                        s = s.Substring(s.LastIndexOf("\\") + 1);
                        ob.ProjectName = s.Replace(".xml", "");  // 2 jan 2017

                        ob.ScenarioIndex = 0;
                        ob.ScenarioName = "";
                    }
                    
                    //                    ob.SetProjectFile(fgModel[rsys[i], 2].ToString());

                    ms = ob;

                }
                //else if (fgModel[rsys[i], 0].ToString() == "SimSimba")
                //{
                //    MAppSimSimba ss = new MAppSimSimba();

                //    ss.PopFile = fgModel[rsys[i], 3].ToString();

                //    ms = ss;
                //}
                else // External
                {
                    MSystemAppExternal ae = (MSystemAppExternal)m_SystemApps[m_SystemAppNames.IndexOf(fgModel[rsys[i], 0].ToString())];
                    ms = new MSystemAppExternal(ae.SpecFile);
//                    ms.SetProjectFile(fgModel[rsys[i], 2].ToString());
                }

                ms.SetProjectFile(fgModel[rsys[i], 2].ToString());
                ms.SetStartingPopIndex(i);

                m_Model.SystemApps.Add(ms);
                ms.SetAppIndex(MModel.MasterAppList.Count);
                MModel.MasterAppList.Add(ms);

                //now get all of the sub models
                int lastApp;

                if (i == rsys.Count - 1)
                    lastApp = fgModel.Rows.Count;
                else
                    lastApp = rsys[i + 1];

                for (j = rsys[i] + 1; j < lastApp; j++)
                {
                    MApp app;

                    //since we don't know what type of app it will be, we get the type then create a new instance
                    Type t = m_Apps[m_AppNames.IndexOf(fgModel[j, 0].ToString())].GetType();

                    if (t == typeof(MAppExternal))
                    {
                        //MAppExternal mae = (MAppExternal)((ComboBox)sender).SelectedItem;
                        MAppExternal mae = (MAppExternal)m_Apps[m_AppNames.IndexOf(fgModel[j, 0].ToString())];

                        app = (MApp)Activator.CreateInstance(t, new object[1] { mae.SpecFile });
                    }
                    else
                        app = (MApp)Activator.CreateInstance(t);

                    if (app.GetType() == typeof(MAppSpatial))
                    {
                        ((MAppSpatial)app).PopStartIndex = ms.GetStartingPopIndex();
                        //((MAppSpatial)((ComboBox)sender).SelectedItem).NumPops = SystemApplication.NumPops; //-get this later!
                    }
                    else if (app.GetType() == typeof(MAppPathHistory))
                    {
                        ((MAppPathHistory)app).PopStartIndex = ms.GetStartingPopIndex();
                    }
                    //else if (app.GetType() == typeof(MAppBecky))
                    //{
                    //    ((MAppBecky)app).PopStartIndex = ms.GetStartingPopIndex();
                    //}
                    else if (app.GetType() == typeof(MAppOutbreak2))
                    {
                        ((MAppOutbreak2)app).PopStartIndex = ms.GetStartingPopIndex();
//                        ((MAppOutbreak2)app).ScenarioNames = scNames;

                        // for multi-scene Outbreaks
                        if (nscenes > 1)
                        {
                            string[] s = fgModel[j, 3].ToString().Split(':');
                            int stop = s[1].IndexOf('(');
                            ((MAppOutbreak2)app).ScenarioIndex = -1 + Convert.ToInt32(s[1].Substring("Scene ".Length, stop - "Scene ".Length));
                            ((MAppOutbreak2)app).ScenarioName = s[1].Substring(stop + 1, s[1].Length - stop - 2);
                        }
                        else
                        {
                            ((MAppOutbreak2)app).ScenarioIndex = 0;
                            ((MAppOutbreak2)app).ScenarioName = "";
                        }

                    }
                    else if (app.GetType() == typeof(MAppRLink))
                    {
                        // Might need to do something here...
                    }
                    //else if (app.GetType() == typeof(MAppOutbreak))
                    //{
                    //    ((MAppOutbreak)app).PopStartIndex = ms.GetStartingPopIndex();
                    //}
                    //else if (app.GetType() == typeof(MAppVaccinator))
                    //{
                    //    ((MAppVaccinator)app).PopStartIndex = ms.GetStartingPopIndex();
                    //}
                    //else if (app.GetType() == typeof(MAppInfector))
                    //{
                    //    ((MAppInfector)app).PopStartIndex = ms.GetStartingPopIndex();
                    //}

                    app.SetProjectFile(fgModel[j, 2].ToString());

                    ms.SubModels().Add(app);

                    app.SetAppIndex(MModel.MasterAppList.Count);
                    MModel.MasterAppList.Add(app);
                }
            }

            Cursor.Current = Cursors.Default;

            frmDataSet frmDS = new frmDataSet(m_Model);
            frmDS.ShowDialog();
        }

        // button added by Bob, to be consistent with other setup screens
        private void btnQuit_Click(object sender, EventArgs e)
        {
            Program.isExiting = true;
            Application.Exit(); 
        }

        private void frmModelSelection_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("ModelSelection");
        }

    }
}