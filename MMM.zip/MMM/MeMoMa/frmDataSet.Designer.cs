namespace MeMoMa
{
    partial class frmDataSet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataSet));
            this.label1 = new System.Windows.Forms.Label();
            this.fgPops = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.fgVars = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.fgPops)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgVars)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(355, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Populations -- Defined by System level specification file";
            // 
            // fgPops
            // 
            this.fgPops.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.fgPops.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.None;
            this.fgPops.ColumnInfo = "2,0,0,0,0,85,Columns:0{Width:484;Caption:\"Population Name\";}\t1{Caption:\"N\";AllowE" +
    "diting:False;}\t";
            this.fgPops.ExtendLastCol = true;
            this.fgPops.Location = new System.Drawing.Point(20, 31);
            this.fgPops.Margin = new System.Windows.Forms.Padding(4);
            this.fgPops.Name = "fgPops";
            this.fgPops.Rows.Count = 1;
            this.fgPops.Rows.DefaultSize = 17;
            this.fgPops.Size = new System.Drawing.Size(792, 192);
            this.fgPops.TabIndex = 1;
            // 
            // fgVars
            // 
            this.fgVars.ColumnInfo = "2,0,0,0,0,85,Columns:0{Width:294;Caption:\"Variable Name\";AllowEditing:False;}\t1{W" +
    "idth:255;Caption:\"Used By\";AllowEditing:False;}\t";
            this.fgVars.ExtendLastCol = true;
            this.fgVars.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.fgVars.Location = new System.Drawing.Point(20, 260);
            this.fgVars.Margin = new System.Windows.Forms.Padding(4);
            this.fgVars.Name = "fgVars";
            this.fgVars.Rows.Count = 1;
            this.fgVars.Rows.DefaultSize = 22;
            this.fgVars.Size = new System.Drawing.Size(792, 313);
            this.fgVars.StyleInfo = resources.GetString("fgVars.StyleInfo");
            this.fgVars.TabIndex = 3;
            this.fgVars.Tree.Column = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 240);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(775, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Global variables will be shared across all applications; Population and Individua" +
    "l Variables will be shared within the System";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(711, 581);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 28);
            this.button1.TabIndex = 4;
            this.button1.Text = "Next >>";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnQuit.Location = new System.Drawing.Point(600, 581);
            this.btnQuit.Margin = new System.Windows.Forms.Padding(4);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(103, 28);
            this.btnQuit.TabIndex = 5;
            this.btnQuit.Text = "Quit MMM";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // frmDataSet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(829, 624);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.fgVars);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.fgPops);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDataSet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DataSet Definition";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmDataSet_FormClosing);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmDataSet_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.fgPops)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgVars)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private C1.Win.C1FlexGrid.C1FlexGrid fgPops;
        private C1.Win.C1FlexGrid.C1FlexGrid fgVars;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnQuit;
    }
}