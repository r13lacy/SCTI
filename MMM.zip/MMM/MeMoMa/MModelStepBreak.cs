using System;
using System.Xml;
using System.Xml.XPath;

using System.Windows.Forms;

namespace MeMoMa
{
    public class MModelStepBreak : MModelStep
    {
        #region MModelStep Members

        public int BreakOnYear = 1;

        public string BreakOnGSVar = "";
        public string BreakOnGSOp = "";
        public string BreakOnGSVal = "";



        public int GetNumTimeSteps()
        {
            return -1;
        }

        public void SetNumTimeSteps(int numTimeSteps)
        {
            //do nothing
        }

        private bool DoBreakOnGSComparison(MMMCore.MDataSet dataSet)
        {
            if (BreakOnGSVar == "")
                return false;
            else
            {
                int i = dataSet.GetVarIndex(BreakOnGSVar);

                if (i < 0)
                    return false;
                else
                {

                    try
                    {
                        double db = Convert.ToDouble(BreakOnGSVal);
                        double dv = Convert.ToDouble(dataSet.Vars[i]);

                        switch (BreakOnGSOp)
                        {
                            case "=":
                                return dv == db;
                            case ">=":
                                return dv >= db;
                            case ">":
                                return dv > db;
                            case "<=":
                                return dv <= db;
                            case "<":
                                return dv < db;
                            case "!=":
                                return dv != db;
                            default:
                                return false;
                        }
                    }
                    catch
                    {
                        string ss = dataSet.GetVarVal(i);
                        switch (BreakOnGSOp)
                        {
                            case "=":
                                return ss == BreakOnGSVal;
                            case ">=":
                                return string.Compare(ss, BreakOnGSVal) >= 0;
                            case ">":
                                return string.Compare(ss, BreakOnGSVal) > 0;
                            case "<=":
                                return string.Compare(ss, BreakOnGSVal) <= 0;
                            case "<":
                                return string.Compare(ss, BreakOnGSVal) < 0;
                            case "!=":
                                return ss != BreakOnGSVal;
                            default:
                                return false;
                        }
                    }
                }
            }

        }

        public bool Simulate(MMMCore.MDataSet dataSet, int iteration, int year)
        {
            //doesn't actually simulate, but instead opens a form that lets the user view/ edit data

            if ((BreakOnYear >= 0 && BreakOnYear <= 1) || (BreakOnYear > 1 && year % BreakOnYear == 0) || (DoBreakOnGSComparison(dataSet)))
            {
                return (new frmDataViewer(dataSet, iteration, year).ShowDialog() == DialogResult.OK);
            }
            else
                return true;
            
        }

        public bool WriteResults()
        {
            //do nothing
            return true;
        }


        public bool ToXML(XmlElement iNode, XmlDocument doc)
        {
            XmlElement n = doc.CreateElement("Break");
            iNode.AppendChild(n);

            XmlElement nn = doc.CreateElement("BreakOnYear");
            nn.InnerText = BreakOnYear.ToString();
            n.AppendChild(nn);

            nn = doc.CreateElement("BreakOnGSVar");
            nn.InnerText = BreakOnGSVar;
            n.AppendChild(nn);

            nn = doc.CreateElement("BreakOnGSOp");
            nn.InnerText = BreakOnGSOp;
            n.AppendChild(nn);

            nn = doc.CreateElement("BreakOnGSVal");
            nn.InnerText = BreakOnGSVal;
            n.AppendChild(nn);

            return true;
        }

        public bool LoadXML(XPathNavigator n, string folderLocation)
        {
            XPathNodeIterator iter = n.Select("BreakOnYear");
            if (iter.MoveNext())
                BreakOnYear = Convert.ToInt32(iter.Current.Value);
            
            iter = n.Select("BreakOnGSVar");
            if (iter.MoveNext())
                BreakOnGSVar = iter.Current.Value;

            iter = n.Select("BreakOnGSOp");
            if (iter.MoveNext())
                BreakOnGSOp = iter.Current.Value;

            iter = n.Select("BreakOnGSVal");
            if (iter.MoveNext())
                BreakOnGSVal = iter.Current.Value;



            return true;
        }

        #endregion
    }
}
