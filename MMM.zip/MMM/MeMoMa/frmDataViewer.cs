using System;
using System.Collections.Generic;
using System.Windows.Forms;

using MMMCore;

namespace MeMoMa
{
    public partial class frmDataViewer : Form
    {
        private MDataSet m_DataSet = null;


        public frmDataViewer(MDataSet dataSet, int iteration, int year)
        {
            int i, j, k;

            InitializeComponent();

            this.Text = "Paused: Iteration " + iteration.ToString() + ", Year " + year.ToString();

            m_DataSet = dataSet;

            fgGlobalVars.Cols.Count = dataSet.Vars.Count;

            for (i = 0; i < dataSet.Vars.Count; i++)
            {
                fgGlobalVars[0, i] = dataSet.VarNames[i];
                fgGlobalVars[1, i] = dataSet.GetVarVal(i); // .Vars[i];
            }

            //display the populations in the table with their vars
            fgPops.Rows.Count = dataSet.Populations.Count + 1;
            fgPops.Cols.Count = 2;
            fgPops[0, 0] = "Population";
            fgPops[0, 1] = "N";

            List<string> cols = new List<string>();

            for (i = 0; i < dataSet.Populations.Count; i++)
            {
                fgPops[i + 1, 0] = dataSet.Populations[i].Name;
                fgPops[i + 1, 1] = dataSet.Populations[i].IndList.Count;

                for (j = 0; j < dataSet.Populations[i].VarNames.Count; j++)
                {
                    k = cols.IndexOf(dataSet.Populations[i].VarNames[j]);

                    if (k < 0) //didn't find it, need to add the column
                    {
                        cols.Add(dataSet.Populations[i].VarNames[j]);
                        fgPops.Cols.Add();
                        fgPops[0, fgPops.Cols.Count - 1] = cols[cols.Count - 1];
                        k = cols.Count - 1;
                    }


                    fgPops[i + 1, k + 2] = dataSet.Populations[i].Vars[j].ToString();
                }

            }

            //add a col to store the pop, make it hidden
            fgPops.Cols.Add().Visible = false;

            for (i = 0; i < dataSet.Populations.Count; i++)
                fgPops[i + 1, fgPops.Cols.Count - 1] = dataSet.Populations[i];

            fgPops.AutoSizeCols();

        }

        private void frmDataViewer_Load(object sender, EventArgs e)
        {

        }

        private void btnViewPop_Click(object sender, EventArgs e)
        {
            if (fgPops.Row > 0)
                new frmPopView(m_DataSet, (MPopulation)fgPops[fgPops.Row, fgPops.Cols.Count - 1], fgPops.Row - 1).Show(this);

        }

        private void btnStopSim_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Abort;
        }

        private void fgPops_DoubleClick(object sender, EventArgs e)
        {
            btnViewPop_Click(sender, e);
        }

        private void fgGlobalVars_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            //            m_DataSet.Vars[e.Col] = fgGlobalVars[1, e.Col].ToString();
            m_DataSet.SetVarVal(e.Col, fgGlobalVars[1, e.Col].ToString());
        }

        private void fgPops_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {

            int i = m_DataSet.Populations[e.Row - 1].GetVarIndex(fgPops[0, e.Col].ToString());

            if (i >= 0)
                m_DataSet.Populations[e.Row - 1].Vars[i] = fgPops[e.Row, e.Col].ToString();
            else
            {
                MessageBox.Show("The population '" + m_DataSet.Populations[e.Row - 1].Name + "' does not contain the variable '" + fgPops[0, e.Col].ToString() + ".");
                fgPops[e.Row, e.Col] = "";
            }

        }

        private void fgGlobalVars_BeforeEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
        }

        private void fgPops_BeforeEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {

            if (e.Col == 0)
                e.Cancel = true;
        }

        private void frmDataViewer_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.F1) return;
            MMMHelp.LaunchHelp("DataViewer");
        }
    }
}